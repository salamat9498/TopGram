package android.content.pm;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IPackageStatsObserver extends IInterface {
	public static abstract class Stub extends Binder implements IPackageStatsObserver {
		private static final String DESCRIPTOR = "android.content.pm.IPackageStatsObserver";
		static final int TRANSACTION_onGetStatsCompleted = 1;

		private static class Proxy implements IPackageStatsObserver {
			private IBinder mRemote;

			Proxy(IBinder remote) {
				super();
				mRemote = remote;
			}

			public IBinder asBinder() {
				return mRemote;
			}

			public String getInterfaceDescriptor() {
				return DESCRIPTOR;
			}

			public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException {
				int r1i = TRANSACTION_onGetStatsCompleted;
				Parcel _data = Parcel.obtain();
				_data.writeInterfaceToken(DESCRIPTOR);
				if (pStats != null) {
					_data.writeInt(TRANSACTION_onGetStatsCompleted);
					pStats.writeToParcel(_data, 0);
				} else {
					_data.writeInt(0);
				}
				if (succeeded) {
					_data.writeInt(r1i);
					mRemote.transact(TRANSACTION_onGetStatsCompleted, _data, null, TRANSACTION_onGetStatsCompleted);
					_data.recycle();
				} else {
					r1i = 0;
					_data.writeInt(r1i);
					mRemote.transact(TRANSACTION_onGetStatsCompleted, _data, null, TRANSACTION_onGetStatsCompleted);
					_data.recycle();
				}
			}
		}


		public Stub() {
			super();
			attachInterface(this, DESCRIPTOR);
		}

		public static IPackageStatsObserver asInterface(IBinder obj) {
			if (obj == null) {
				return null;
			} else {
				IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
				if (iin == null || !(iin instanceof IPackageStatsObserver)) {
					return new Proxy(obj);
				} else {
					return (IPackageStatsObserver) iin;
				}
			}
		}

		public IBinder asBinder() {
			return this;
		}

		public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
			switch(code) {
			case TRANSACTION_onGetStatsCompleted:
				PackageStats _arg0;
				boolean _arg1;
				data.enforceInterface(DESCRIPTOR);
				if (data.readInt() != 0) {
					_arg0 = (PackageStats) PackageStats.CREATOR.createFromParcel(data);
				} else {
					_arg0 = null;
				}
				if (data.readInt() != 0) {
					_arg1 = true;
				} else {
					_arg1 = false;
				}
				onGetStatsCompleted(_arg0, _arg1);
				return true;
			case 1598968902:
				reply.writeString(DESCRIPTOR);
				return true;
			}
			return super.onTransact(code, data, reply, flags);
		}
	}


	public void onGetStatsCompleted(PackageStats r1_PackageStats, boolean r2z) throws RemoteException;
}
