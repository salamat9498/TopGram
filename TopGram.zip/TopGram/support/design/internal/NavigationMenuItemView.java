package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.StateListDrawable;
import android.support.design.R;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuView.ItemView;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import org.telegram.tgnet.TLRPC;

public class NavigationMenuItemView extends ForegroundLinearLayout implements ItemView {
	private static final int[] CHECKED_STATE_SET;
	private final AccessibilityDelegateCompat mAccessibilityDelegate;
	private FrameLayout mActionArea;
	boolean mCheckable;
	private Drawable mEmptyDrawable;
	private boolean mHasIconTintList;
	private final int mIconSize;
	private ColorStateList mIconTintList;
	private MenuItemImpl mItemData;
	private boolean mNeedsEmptyIcon;
	private final CheckedTextView mTextView;

	class AnonymousClass_1 extends AccessibilityDelegateCompat {
		final /* synthetic */ NavigationMenuItemView this$0;

		AnonymousClass_1(NavigationMenuItemView this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfoCompat info) {
			super.onInitializeAccessibilityNodeInfo(host, info);
			info.setCheckable(this$0.mCheckable);
		}
	}


	static {
		int[] r0_int_A = new int[1];
		r0_int_A[0] = 16842912;
		CHECKED_STATE_SET = r0_int_A;
	}

	public NavigationMenuItemView(Context context) {
		this(context, null);
	}

	public NavigationMenuItemView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public NavigationMenuItemView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		mAccessibilityDelegate = new AnonymousClass_1(this);
		setOrientation(0);
		LayoutInflater.from(context).inflate(R.layout.design_navigation_menu_item, this, true);
		mIconSize = context.getResources().getDimensionPixelSize(R.dimen.design_navigation_icon_size);
		mTextView = (CheckedTextView) findViewById(R.id.design_menu_item_text);
		mTextView.setDuplicateParentStateEnabled(true);
		ViewCompat.setAccessibilityDelegate(mTextView, mAccessibilityDelegate);
	}

	private void adjustAppearance() {
		LayoutParams params;
		if (shouldExpandActionArea()) {
			mTextView.setVisibility(TLRPC.USER_FLAG_USERNAME);
			if (mActionArea != null) {
				params = (android.support.v7.widget.LinearLayoutCompat.LayoutParams) mActionArea.getLayoutParams();
				params.width = -1;
				mActionArea.setLayoutParams(params);
			}
		} else {
			mTextView.setVisibility(0);
			if (mActionArea != null) {
				params = (android.support.v7.widget.LinearLayoutCompat.LayoutParams) mActionArea.getLayoutParams();
				params.width = -2;
				mActionArea.setLayoutParams(params);
			}
		}
	}

	private StateListDrawable createDefaultBackground() {
		TypedValue value = new TypedValue();
		if (getContext().getTheme().resolveAttribute(android.support.v7.appcompat.R.attr.colorControlHighlight, value, true)) {
			StateListDrawable drawable = new StateListDrawable();
			drawable.addState(CHECKED_STATE_SET, new ColorDrawable(value.data));
			drawable.addState(EMPTY_STATE_SET, new ColorDrawable(0));
			return drawable;
		} else {
			return null;
		}
	}

	private void setActionView(View actionView) {
		if (actionView != null) {
			if (mActionArea == null) {
				mActionArea = (FrameLayout) ((ViewStub) findViewById(R.id.design_menu_item_action_area_stub)).inflate();
			}
			mActionArea.removeAllViews();
			mActionArea.addView(actionView);
		}
	}

	private boolean shouldExpandActionArea() {
		if (mItemData.getTitle() != null || mItemData.getIcon() != null || mItemData.getActionView() == null) {
			return false;
		} else {
			return true;
		}
	}

	public MenuItemImpl getItemData() {
		return mItemData;
	}

	public void initialize(MenuItemImpl itemData, int menuType) {
		int r0i;
		mItemData = itemData;
		if (itemData.isVisible()) {
			r0i = 0;
		} else {
			r0i = TLRPC.USER_FLAG_USERNAME;
		}
		setVisibility(r0i);
		if (getBackground() == null) {
			setBackgroundDrawable(createDefaultBackground());
		}
		setCheckable(itemData.isCheckable());
		setChecked(itemData.isChecked());
		setEnabled(itemData.isEnabled());
		setTitle(itemData.getTitle());
		setIcon(itemData.getIcon());
		setActionView(itemData.getActionView());
		adjustAppearance();
	}

	protected int[] onCreateDrawableState(int extraSpace) {
		int[] drawableState = super.onCreateDrawableState(extraSpace + 1);
		if (mItemData == null || !mItemData.isCheckable() || !mItemData.isChecked()) {
			return drawableState;
		} else {
			mergeDrawableStates(drawableState, CHECKED_STATE_SET);
			return drawableState;
		}
	}

	public boolean prefersCondensedTitle() {
		return false;
	}

	public void recycle() {
		if (mActionArea != null) {
			mActionArea.removeAllViews();
		}
		mTextView.setCompoundDrawables(null, null, null, null);
	}

	public void setCheckable(boolean checkable) {
		refreshDrawableState();
		if (mCheckable != checkable) {
			mCheckable = checkable;
			mAccessibilityDelegate.sendAccessibilityEvent(mTextView, TLRPC.MESSAGE_FLAG_HAS_BOT_ID);
		}
	}

	public void setChecked(boolean checked) {
		refreshDrawableState();
		mTextView.setChecked(checked);
	}

	public void setIcon(Drawable icon) {
		if (icon != null) {
			if (mHasIconTintList) {
				ConstantState state = icon.getConstantState();
				if (state == null) {
					icon = DrawableCompat.wrap(icon).mutate();
					DrawableCompat.setTintList(icon, mIconTintList);
				} else {
					icon = state.newDrawable();
					icon = DrawableCompat.wrap(icon).mutate();
					DrawableCompat.setTintList(icon, mIconTintList);
				}
			}
			icon.setBounds(0, 0, mIconSize, mIconSize);
		} else if (mNeedsEmptyIcon) {
			if (mEmptyDrawable == null) {
				mEmptyDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.navigation_empty_icon, getContext().getTheme());
				if (mEmptyDrawable != null) {
					mEmptyDrawable.setBounds(0, 0, mIconSize, mIconSize);
				}
			}
			icon = mEmptyDrawable;
		}
		TextViewCompat.setCompoundDrawablesRelative(mTextView, icon, null, null, null);
	}

	void setIconTintList(ColorStateList tintList) {
		boolean r0z;
		mIconTintList = tintList;
		if (mIconTintList != null) {
			r0z = true;
		} else {
			r0z = false;
		}
		mHasIconTintList = r0z;
		if (mItemData != null) {
			setIcon(mItemData.getIcon());
		}
	}

	public void setNeedsEmptyIcon(boolean needsEmptyIcon) {
		mNeedsEmptyIcon = needsEmptyIcon;
	}

	public void setShortcut(boolean showShortcut, char shortcutKey) {
	}

	public void setTextAppearance(Context context, int textAppearance) {
		mTextView.setTextAppearance(context, textAppearance);
	}

	public void setTextColor(ColorStateList colors) {
		mTextView.setTextColor(colors);
	}

	public void setTitle(CharSequence title) {
		mTextView.setText(title);
	}

	public boolean showsIcon() {
		return true;
	}
}
