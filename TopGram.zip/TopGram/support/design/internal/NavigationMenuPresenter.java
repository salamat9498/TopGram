package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StyleRes;
import android.support.design.R;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuPresenter;
import android.support.v7.view.menu.MenuPresenter.Callback;
import android.support.v7.view.menu.MenuView;
import android.support.v7.view.menu.SubMenuBuilder;
import android.support.v7.widget.RecyclerView.Adapter;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;

public class NavigationMenuPresenter implements MenuPresenter {
	private static final String STATE_ADAPTER = "android:menu:adapter";
	private static final String STATE_HIERARCHY = "android:menu:list";
	NavigationMenuAdapter mAdapter;
	private Callback mCallback;
	LinearLayout mHeaderLayout;
	ColorStateList mIconTintList;
	private int mId;
	Drawable mItemBackground;
	LayoutInflater mLayoutInflater;
	MenuBuilder mMenu;
	private NavigationMenuView mMenuView;
	final OnClickListener mOnClickListener;
	int mPaddingSeparator;
	private int mPaddingTopDefault;
	int mTextAppearance;
	boolean mTextAppearanceSet;
	ColorStateList mTextColor;

	class AnonymousClass_1 implements OnClickListener {
		final /* synthetic */ NavigationMenuPresenter this$0;

		AnonymousClass_1(NavigationMenuPresenter this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onClick(View v) {
			this$0.setUpdateSuspended(true);
			MenuItemImpl item = ((NavigationMenuItemView) v).getItemData();
			boolean result = this$0.mMenu.performItemAction(item, this$0, 0);
			if (item == null || !item.isCheckable() || !result) {
				this$0.setUpdateSuspended(false);
				this$0.updateMenuView(false);
			} else {
				this$0.mAdapter.setCheckedItem(item);
				this$0.setUpdateSuspended(false);
				this$0.updateMenuView(false);
			}
		}
	}

	private static abstract class ViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder {
		public ViewHolder(View itemView) {
			super(itemView);
		}
	}

	private static class HeaderViewHolder extends NavigationMenuPresenter.ViewHolder {
		public HeaderViewHolder(View itemView) {
			super(itemView);
		}
	}

	private class NavigationMenuAdapter extends Adapter<NavigationMenuPresenter.ViewHolder> {
		private static final String STATE_ACTION_VIEWS = "android:menu:action_views";
		private static final String STATE_CHECKED_ITEM = "android:menu:checked";
		private static final int VIEW_TYPE_HEADER = 3;
		private static final int VIEW_TYPE_NORMAL = 0;
		private static final int VIEW_TYPE_SEPARATOR = 2;
		private static final int VIEW_TYPE_SUBHEADER = 1;
		private MenuItemImpl mCheckedItem;
		private final ArrayList<NavigationMenuPresenter.NavigationMenuItem> mItems;
		private boolean mUpdateSuspended;
		final /* synthetic */ NavigationMenuPresenter this$0;

		NavigationMenuAdapter(NavigationMenuPresenter r2_NavigationMenuPresenter) {
			super();
			this$0 = r2_NavigationMenuPresenter;
			mItems = new ArrayList();
			prepareMenuItems();
		}

		private void appendTransparentIconIfMissing(int startIndex, int endIndex) {
			int i = startIndex;
			while (i < endIndex) {
				((NavigationMenuPresenter.NavigationMenuTextItem) mItems.get(i)).needsEmptyIcon = true;
				i++;
			}
		}

		private void prepareMenuItems() {
			if (mUpdateSuspended) {
			} else {
				mUpdateSuspended = true;
				mItems.clear();
				mItems.add(new NavigationMenuPresenter.NavigationMenuHeaderItem());
				int currentGroupId = -1;
				int currentGroupStart = VIEW_TYPE_NORMAL;
				boolean currentGroupHasIcon = false;
				int i = VIEW_TYPE_NORMAL;
				while (i < this$0.mMenu.getVisibleItems().size()) {
					MenuItemImpl item = (MenuItemImpl) this$0.mMenu.getVisibleItems().get(i);
					if (item.isChecked()) {
						setCheckedItem(item);
					}
					if (item.isCheckable()) {
						item.setExclusiveCheckable(false);
					}
					if (item.hasSubMenu()) {
						SubMenu subMenu = item.getSubMenu();
						if (subMenu.hasVisibleItems()) {
							if (i != 0) {
								mItems.add(new NavigationMenuPresenter.NavigationMenuSeparatorItem(this$0.mPaddingSeparator, 0));
							}
							mItems.add(r16_NavigationMenuPresenter_NavigationMenuTextItem);
							boolean subMenuHasIcon = false;
							int subMenuStart = mItems.size();
							int j = VIEW_TYPE_NORMAL;
							while (j < subMenu.size()) {
								MenuItemImpl subMenuItem = (MenuItemImpl) subMenu.getItem(j);
								if (subMenuItem.isVisible()) {
									if (subMenuHasIcon || subMenuItem.getIcon() == null) {
										if (!subMenuItem.isCheckable()) {
											subMenuItem.setExclusiveCheckable(false);
										}
										if (item.isChecked()) {
											setCheckedItem(item);
										}
										mItems.add(r16_NavigationMenuPresenter_NavigationMenuTextItem);
									} else {
										subMenuHasIcon = true;
										if (!subMenuItem.isCheckable()) {
											if (item.isChecked()) {
												mItems.add(r16_NavigationMenuPresenter_NavigationMenuTextItem);
											} else {
												setCheckedItem(item);
												mItems.add(r16_NavigationMenuPresenter_NavigationMenuTextItem);
											}
										} else {
											subMenuItem.setExclusiveCheckable(false);
											if (item.isChecked()) {
												setCheckedItem(item);
											}
											mItems.add(r16_NavigationMenuPresenter_NavigationMenuTextItem);
										}
									}
								}
								j++;
							}
							if (subMenuHasIcon) {
								appendTransparentIconIfMissing(subMenuStart, mItems.size());
							}
						}
					} else {
						NavigationMenuPresenter.NavigationMenuTextItem textItem;
						int groupId = item.getGroupId();
						if (groupId != currentGroupId) {
							currentGroupStart = mItems.size();
							if (item.getIcon() != null) {
								currentGroupHasIcon = true;
							} else {
								currentGroupHasIcon = false;
							}
							if (i != 0) {
								currentGroupStart++;
								mItems.add(new NavigationMenuPresenter.NavigationMenuSeparatorItem(this$0.mPaddingSeparator, this$0.mPaddingSeparator));
							}
						} else if (currentGroupHasIcon || item.getIcon() == null) {
							textItem = new NavigationMenuPresenter.NavigationMenuTextItem(item);
							textItem.needsEmptyIcon = currentGroupHasIcon;
							mItems.add(textItem);
							currentGroupId = groupId;
						} else {
							appendTransparentIconIfMissing(currentGroupStart, mItems.size());
						}
						textItem = new NavigationMenuPresenter.NavigationMenuTextItem(item);
						textItem.needsEmptyIcon = currentGroupHasIcon;
						mItems.add(textItem);
						currentGroupId = groupId;
					}
					i++;
				}
				mUpdateSuspended = false;
			}
		}

		public Bundle createInstanceState() {
			Bundle state = new Bundle();
			if (mCheckedItem != null) {
				state.putInt(STATE_CHECKED_ITEM, mCheckedItem.getItemId());
			}
			SparseArray<ParcelableSparseArray> actionViewStates = new SparseArray();
			Iterator r6_Iterator = mItems.iterator();
			while (r6_Iterator.hasNext()) {
				NavigationMenuPresenter.NavigationMenuItem navigationMenuItem = (NavigationMenuPresenter.NavigationMenuItem) r6_Iterator.next();
				if (navigationMenuItem instanceof NavigationMenuPresenter.NavigationMenuTextItem) {
					View actionView;
					MenuItemImpl item = ((NavigationMenuPresenter.NavigationMenuTextItem) navigationMenuItem).getMenuItem();
					if (item != null) {
						actionView = item.getActionView();
					} else {
						actionView = null;
					}
					if (actionView != null) {
						SparseArray container = new ParcelableSparseArray();
						actionView.saveHierarchyState(container);
						actionViewStates.put(item.getItemId(), container);
					}
				}
			}
			state.putSparseParcelableArray(STATE_ACTION_VIEWS, actionViewStates);
			return state;
		}

		public int getItemCount() {
			return mItems.size();
		}

		public long getItemId(int position) {
			return (long) position;
		}

		public int getItemViewType(int position) {
			NavigationMenuPresenter.NavigationMenuItem item = (NavigationMenuPresenter.NavigationMenuItem) mItems.get(position);
			if (item instanceof NavigationMenuPresenter.NavigationMenuSeparatorItem) {
				return VIEW_TYPE_SEPARATOR;
			} else if (item instanceof NavigationMenuPresenter.NavigationMenuHeaderItem) {
				return VIEW_TYPE_HEADER;
			} else if (item instanceof NavigationMenuPresenter.NavigationMenuTextItem) {
				if (((NavigationMenuPresenter.NavigationMenuTextItem) item).getMenuItem().hasSubMenu()) {
					return VIEW_TYPE_SUBHEADER;
				} else {
					return VIEW_TYPE_NORMAL;
				}
			} else {
				throw new RuntimeException("Unknown item type.");
			}
		}

		public void onBindViewHolder(NavigationMenuPresenter.ViewHolder holder, int position) {
			switch(getItemViewType(position)) {
			case VIEW_TYPE_NORMAL:
				Drawable r3_Drawable;
				NavigationMenuItemView itemView = (NavigationMenuItemView) holder.itemView;
				itemView.setIconTintList(this$0.mIconTintList);
				if (this$0.mTextAppearanceSet) {
					itemView.setTextAppearance(itemView.getContext(), this$0.mTextAppearance);
				}
				if (this$0.mTextColor != null) {
					itemView.setTextColor(this$0.mTextColor);
				}
				if (this$0.mItemBackground != null) {
					r3_Drawable = this$0.mItemBackground.getConstantState().newDrawable();
				} else {
					r3_Drawable = null;
				}
				itemView.setBackgroundDrawable(r3_Drawable);
				NavigationMenuPresenter.NavigationMenuTextItem item = (NavigationMenuPresenter.NavigationMenuTextItem) mItems.get(position);
				itemView.setNeedsEmptyIcon(item.needsEmptyIcon);
				itemView.initialize(item.getMenuItem(), VIEW_TYPE_NORMAL);
			case VIEW_TYPE_SUBHEADER:
				((TextView) holder.itemView).setText(mItems.get(position).getMenuItem().getTitle());
			case VIEW_TYPE_SEPARATOR:
				NavigationMenuPresenter.NavigationMenuSeparatorItem item_2 = (NavigationMenuPresenter.NavigationMenuSeparatorItem) mItems.get(position);
				holder.itemView.setPadding(VIEW_TYPE_NORMAL, item_2.getPaddingTop(), VIEW_TYPE_NORMAL, item_2.getPaddingBottom());
			}
		}

		public NavigationMenuPresenter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			switch(viewType) {
			case VIEW_TYPE_NORMAL:
				return new NavigationMenuPresenter.NormalViewHolder(this$0.mLayoutInflater, parent, this$0.mOnClickListener);
			case VIEW_TYPE_SUBHEADER:
				return new NavigationMenuPresenter.SubheaderViewHolder(this$0.mLayoutInflater, parent);
			case VIEW_TYPE_SEPARATOR:
				return new NavigationMenuPresenter.SeparatorViewHolder(this$0.mLayoutInflater, parent);
			case VIEW_TYPE_HEADER:
				return new NavigationMenuPresenter.HeaderViewHolder(this$0.mHeaderLayout);
			}
			return null;
		}

		public void onViewRecycled(NavigationMenuPresenter.ViewHolder holder) {
			if (holder instanceof NavigationMenuPresenter.NormalViewHolder) {
				((NavigationMenuItemView) holder.itemView).recycle();
			}
		}

		public void restoreInstanceState(Bundle state) {
			int checkedItem = state.getInt(STATE_CHECKED_ITEM, VIEW_TYPE_NORMAL);
			if (checkedItem != 0) {
				mUpdateSuspended = true;
				Iterator r6_Iterator = mItems.iterator();
				while (r6_Iterator.hasNext()) {
					NavigationMenuPresenter.NavigationMenuItem item = (NavigationMenuPresenter.NavigationMenuItem) r6_Iterator.next();
					if (item instanceof NavigationMenuPresenter.NavigationMenuTextItem) {
						MenuItemImpl menuItem = ((NavigationMenuPresenter.NavigationMenuTextItem) item).getMenuItem();
						if (menuItem == null || menuItem.getItemId() != checkedItem) {
						} else {
							setCheckedItem(menuItem);
						}
					}
				}
				mUpdateSuspended = false;
				prepareMenuItems();
			}
			SparseArray<ParcelableSparseArray> actionViewStates = state.getSparseParcelableArray(STATE_ACTION_VIEWS);
			Iterator r7_Iterator = mItems.iterator();
			while (r7_Iterator.hasNext()) {
				NavigationMenuPresenter.NavigationMenuItem navigationMenuItem = (NavigationMenuPresenter.NavigationMenuItem) r7_Iterator.next();
				if (navigationMenuItem instanceof NavigationMenuPresenter.NavigationMenuTextItem) {
					View actionView;
					MenuItemImpl item_2 = ((NavigationMenuPresenter.NavigationMenuTextItem) navigationMenuItem).getMenuItem();
					if (item_2 != null) {
						actionView = item_2.getActionView();
					} else {
						actionView = null;
					}
					if (actionView != null) {
						actionView.restoreHierarchyState((SparseArray) actionViewStates.get(item_2.getItemId()));
					}
				}
			}
		}

		public void setCheckedItem(MenuItemImpl checkedItem) {
			if (mCheckedItem == checkedItem || !checkedItem.isCheckable()) {
			} else {
				if (mCheckedItem != null) {
					mCheckedItem.setChecked(false);
				}
				mCheckedItem = checkedItem;
				checkedItem.setChecked(true);
			}
		}

		public void setUpdateSuspended(boolean updateSuspended) {
			mUpdateSuspended = updateSuspended;
		}

		public void update() {
			prepareMenuItems();
			notifyDataSetChanged();
		}
	}

	private static interface NavigationMenuItem {
	}

	private static class NavigationMenuHeaderItem implements NavigationMenuPresenter.NavigationMenuItem {
		NavigationMenuHeaderItem() {
			super();
		}
	}

	private static class NavigationMenuSeparatorItem implements NavigationMenuPresenter.NavigationMenuItem {
		private final int mPaddingBottom;
		private final int mPaddingTop;

		public NavigationMenuSeparatorItem(int paddingTop, int paddingBottom) {
			super();
			mPaddingTop = paddingTop;
			mPaddingBottom = paddingBottom;
		}

		public int getPaddingBottom() {
			return mPaddingBottom;
		}

		public int getPaddingTop() {
			return mPaddingTop;
		}
	}

	private static class NavigationMenuTextItem implements NavigationMenuPresenter.NavigationMenuItem {
		private final MenuItemImpl mMenuItem;
		boolean needsEmptyIcon;

		NavigationMenuTextItem(MenuItemImpl item) {
			super();
			mMenuItem = item;
		}

		public MenuItemImpl getMenuItem() {
			return mMenuItem;
		}
	}

	private static class NormalViewHolder extends NavigationMenuPresenter.ViewHolder {
		public NormalViewHolder(LayoutInflater inflater, ViewGroup parent, OnClickListener listener) {
			super(inflater.inflate(R.layout.design_navigation_item, parent, false));
			itemView.setOnClickListener(listener);
		}
	}

	private static class SeparatorViewHolder extends NavigationMenuPresenter.ViewHolder {
		public SeparatorViewHolder(LayoutInflater inflater, ViewGroup parent) {
			super(inflater.inflate(R.layout.design_navigation_item_separator, parent, false));
		}
	}

	private static class SubheaderViewHolder extends NavigationMenuPresenter.ViewHolder {
		public SubheaderViewHolder(LayoutInflater inflater, ViewGroup parent) {
			super(inflater.inflate(R.layout.design_navigation_item_subheader, parent, false));
		}
	}


	public NavigationMenuPresenter() {
		super();
		mOnClickListener = new AnonymousClass_1(this);
	}

	public void addHeaderView(@NonNull View view) {
		mHeaderLayout.addView(view);
		mMenuView.setPadding(0, 0, 0, mMenuView.getPaddingBottom());
	}

	public boolean collapseItemActionView(MenuBuilder menu, MenuItemImpl item) {
		return false;
	}

	public void dispatchApplyWindowInsets(WindowInsetsCompat insets) {
		int top = insets.getSystemWindowInsetTop();
		if (mPaddingTopDefault != top) {
			mPaddingTopDefault = top;
			if (mHeaderLayout.getChildCount() == 0) {
				mMenuView.setPadding(0, mPaddingTopDefault, 0, mMenuView.getPaddingBottom());
			}
		}
		ViewCompat.dispatchApplyWindowInsets(mHeaderLayout, insets);
	}

	public boolean expandItemActionView(MenuBuilder menu, MenuItemImpl item) {
		return false;
	}

	public boolean flagActionItems() {
		return false;
	}

	public int getHeaderCount() {
		return mHeaderLayout.getChildCount();
	}

	public View getHeaderView(int index) {
		return mHeaderLayout.getChildAt(index);
	}

	public int getId() {
		return mId;
	}

	@Nullable
	public Drawable getItemBackground() {
		return mItemBackground;
	}

	@Nullable
	public ColorStateList getItemTextColor() {
		return mTextColor;
	}

	@Nullable
	public ColorStateList getItemTintList() {
		return mIconTintList;
	}

	public MenuView getMenuView(ViewGroup root) {
		if (mMenuView == null) {
			mMenuView = (NavigationMenuView) mLayoutInflater.inflate(R.layout.design_navigation_menu, root, false);
			if (mAdapter == null) {
				mAdapter = new NavigationMenuAdapter(this);
			}
			mHeaderLayout = (LinearLayout) mLayoutInflater.inflate(R.layout.design_navigation_item_header, mMenuView, false);
			mMenuView.setAdapter(mAdapter);
		}
		return mMenuView;
	}

	public View inflateHeaderView(@LayoutRes int res) {
		View view = mLayoutInflater.inflate(res, mHeaderLayout, false);
		addHeaderView(view);
		return view;
	}

	public void initForMenu(Context context, MenuBuilder menu) {
		mLayoutInflater = LayoutInflater.from(context);
		mMenu = menu;
		mPaddingSeparator = context.getResources().getDimensionPixelOffset(R.dimen.design_navigation_separator_vertical_padding);
	}

	public void onCloseMenu(MenuBuilder menu, boolean allMenusAreClosing) {
		if (mCallback != null) {
			mCallback.onCloseMenu(menu, allMenusAreClosing);
		}
	}

	public void onRestoreInstanceState(Parcelable parcelable) {
		if (parcelable instanceof Bundle) {
			Bundle state = (Bundle) parcelable;
			SparseArray<Parcelable> hierarchy = state.getSparseParcelableArray(STATE_HIERARCHY);
			if (hierarchy != null) {
				mMenuView.restoreHierarchyState(hierarchy);
			}
			Bundle adapterState = state.getBundle(STATE_ADAPTER);
			if (adapterState != null) {
				mAdapter.restoreInstanceState(adapterState);
			}
		}
	}

	public Parcelable onSaveInstanceState() {
		if (VERSION.SDK_INT >= 11) {
			Bundle state = new Bundle();
			if (mMenuView != null) {
				SparseArray<Parcelable> hierarchy = new SparseArray();
				mMenuView.saveHierarchyState(hierarchy);
				state.putSparseParcelableArray(STATE_HIERARCHY, hierarchy);
			}
			if (mAdapter != null) {
				state.putBundle(STATE_ADAPTER, mAdapter.createInstanceState());
				return state;
			} else {
				return state;
			}
		} else {
			return null;
		}
	}

	public boolean onSubMenuSelected(SubMenuBuilder subMenu) {
		return false;
	}

	public void removeHeaderView(@NonNull View view) {
		mHeaderLayout.removeView(view);
		if (mHeaderLayout.getChildCount() == 0) {
			mMenuView.setPadding(0, mPaddingTopDefault, 0, mMenuView.getPaddingBottom());
		}
	}

	public void setCallback(Callback cb) {
		mCallback = cb;
	}

	public void setCheckedItem(MenuItemImpl item) {
		mAdapter.setCheckedItem(item);
	}

	public void setId(int id) {
		mId = id;
	}

	public void setItemBackground(@Nullable Drawable itemBackground) {
		mItemBackground = itemBackground;
		updateMenuView(false);
	}

	public void setItemIconTintList(@Nullable ColorStateList tint) {
		mIconTintList = tint;
		updateMenuView(false);
	}

	public void setItemTextAppearance(@StyleRes int resId) {
		mTextAppearance = resId;
		mTextAppearanceSet = true;
		updateMenuView(false);
	}

	public void setItemTextColor(@Nullable ColorStateList textColor) {
		mTextColor = textColor;
		updateMenuView(false);
	}

	public void setUpdateSuspended(boolean updateSuspended) {
		if (mAdapter != null) {
			mAdapter.setUpdateSuspended(updateSuspended);
		}
	}

	public void updateMenuView(boolean cleared) {
		if (mAdapter != null) {
			mAdapter.update();
		}
	}
}
