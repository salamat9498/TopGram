package android.support.design.internal;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.design.R;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.AttributeSet;
import android.view.Gravity;

public class ForegroundLinearLayout extends LinearLayoutCompat {
	private Drawable mForeground;
	boolean mForegroundBoundsChanged;
	private int mForegroundGravity;
	protected boolean mForegroundInPadding;
	private final Rect mOverlayBounds;
	private final Rect mSelfBounds;

	public ForegroundLinearLayout(Context context) {
		this(context, null);
	}

	public ForegroundLinearLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public ForegroundLinearLayout(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		mSelfBounds = new Rect();
		mOverlayBounds = new Rect();
		mForegroundGravity = 119;
		mForegroundInPadding = true;
		mForegroundBoundsChanged = false;
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ForegroundLinearLayout, defStyle, 0);
		mForegroundGravity = a.getInt(R.styleable.ForegroundLinearLayout_android_foregroundGravity, mForegroundGravity);
		Drawable d = a.getDrawable(R.styleable.ForegroundLinearLayout_android_foreground);
		if (d != null) {
			setForeground(d);
		}
		mForegroundInPadding = a.getBoolean(R.styleable.ForegroundLinearLayout_foregroundInsidePadding, true);
		a.recycle();
	}

	public void draw(@NonNull Canvas canvas) {
		super.draw(canvas);
		if (mForeground != null) {
			Drawable foreground = mForeground;
			if (mForegroundBoundsChanged) {
				mForegroundBoundsChanged = false;
				Rect selfBounds = mSelfBounds;
				Rect overlayBounds = mOverlayBounds;
				int w = getRight() - getLeft();
				int h = getBottom() - getTop();
				if (mForegroundInPadding) {
					selfBounds.set(0, 0, w, h);
				} else {
					selfBounds.set(getPaddingLeft(), getPaddingTop(), w - getPaddingRight(), h - getPaddingBottom());
				}
				Gravity.apply(mForegroundGravity, foreground.getIntrinsicWidth(), foreground.getIntrinsicHeight(), selfBounds, overlayBounds);
				foreground.setBounds(overlayBounds);
			}
			foreground.draw(canvas);
		}
	}

	public void drawableHotspotChanged(float x, float y) {
		super.drawableHotspotChanged(x, y);
		if (mForeground != null) {
			mForeground.setHotspot(x, y);
		}
	}

	protected void drawableStateChanged() {
		super.drawableStateChanged();
		if (mForeground == null || !mForeground.isStateful()) {
		} else {
			mForeground.setState(getDrawableState());
		}
	}

	public Drawable getForeground() {
		return mForeground;
	}

	public int getForegroundGravity() {
		return mForegroundGravity;
	}

	public void jumpDrawablesToCurrentState() {
		super.jumpDrawablesToCurrentState();
		if (mForeground != null) {
			mForeground.jumpToCurrentState();
		}
	}

	protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
		super.onLayout(changed, left, top, right, bottom);
		mForegroundBoundsChanged |= changed;
	}

	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		mForegroundBoundsChanged = true;
	}

	public void setForeground(Drawable drawable) {
		if (mForeground != drawable) {
			if (mForeground != null) {
				mForeground.setCallback(null);
				unscheduleDrawable(mForeground);
			}
			mForeground = drawable;
			if (drawable != null) {
				setWillNotDraw(false);
				drawable.setCallback(this);
				if (drawable.isStateful()) {
					drawable.setState(getDrawableState());
				}
				if (mForegroundGravity == 119) {
					drawable.getPadding(new Rect());
				}
			} else {
				setWillNotDraw(true);
			}
			requestLayout();
			invalidate();
		}
	}

	public void setForegroundGravity(int foregroundGravity) {
		if (mForegroundGravity != foregroundGravity) {
			if ((8388615 & foregroundGravity) == 0) {
				foregroundGravity |= 8388611;
			}
			if ((foregroundGravity & 112) == 0) {
				foregroundGravity |= 48;
			}
			mForegroundGravity = foregroundGravity;
			if (mForegroundGravity != 119 || mForeground == null) {
				requestLayout();
			} else {
				mForeground.getPadding(new Rect());
				requestLayout();
			}
		}
	}

	protected boolean verifyDrawable(Drawable who) {
		if (super.verifyDrawable(who) || who == mForeground) {
			return true;
		} else {
			return false;
		}
	}
}
