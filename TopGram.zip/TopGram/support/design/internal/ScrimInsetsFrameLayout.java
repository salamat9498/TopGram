package android.support.design.internal;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.design.R;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

public class ScrimInsetsFrameLayout extends FrameLayout {
	Drawable mInsetForeground;
	Rect mInsets;
	private Rect mTempRect;

	class AnonymousClass_1 implements OnApplyWindowInsetsListener {
		final /* synthetic */ ScrimInsetsFrameLayout this$0;

		AnonymousClass_1(ScrimInsetsFrameLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
			boolean r0z;
			if (this$0.mInsets == null) {
				this$0.mInsets = new Rect();
			}
			this$0.mInsets.set(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
			this$0.onInsetsChanged(insets);
			ScrimInsetsFrameLayout r1_ScrimInsetsFrameLayout = this$0;
			if (this$0.mInsets.isEmpty() || this$0.mInsetForeground == null) {
				r0z = true;
			} else {
				r0z = false;
			}
			r1_ScrimInsetsFrameLayout.setWillNotDraw(r0z);
			ViewCompat.postInvalidateOnAnimation(this$0);
			return insets.consumeSystemWindowInsets();
		}
	}


	public ScrimInsetsFrameLayout(Context context) {
		this(context, null);
	}

	public ScrimInsetsFrameLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public ScrimInsetsFrameLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		mTempRect = new Rect();
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ScrimInsetsFrameLayout, defStyleAttr, R.style.Widget_Design_ScrimInsetsFrameLayout);
		mInsetForeground = a.getDrawable(R.styleable.ScrimInsetsFrameLayout_insetForeground);
		a.recycle();
		setWillNotDraw(true);
		ViewCompat.setOnApplyWindowInsetsListener(this, new AnonymousClass_1(this));
	}

	public void draw(@NonNull Canvas canvas) {
		super.draw(canvas);
		int width = getWidth();
		int height = getHeight();
		if (mInsets == null || mInsetForeground == null) {
		} else {
			canvas.translate((float) getScrollX(), (float) getScrollY());
			mTempRect.set(0, 0, width, mInsets.top);
			mInsetForeground.setBounds(mTempRect);
			mInsetForeground.draw(canvas);
			mTempRect.set(0, height - mInsets.bottom, width, height);
			mInsetForeground.setBounds(mTempRect);
			mInsetForeground.draw(canvas);
			mTempRect.set(0, mInsets.top, mInsets.left, height - mInsets.bottom);
			mInsetForeground.setBounds(mTempRect);
			mInsetForeground.draw(canvas);
			mTempRect.set(width - mInsets.right, mInsets.top, width, height - mInsets.bottom);
			mInsetForeground.setBounds(mTempRect);
			mInsetForeground.draw(canvas);
			canvas.restoreToCount(canvas.save());
		}
	}

	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		if (mInsetForeground != null) {
			mInsetForeground.setCallback(this);
		}
	}

	protected void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		if (mInsetForeground != null) {
			mInsetForeground.setCallback(null);
		}
	}

	protected void onInsetsChanged(WindowInsetsCompat insets) {
	}
}
