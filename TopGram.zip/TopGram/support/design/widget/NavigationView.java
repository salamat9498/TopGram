package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.DrawableRes;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StyleRes;
import android.support.design.R;
import android.support.design.internal.NavigationMenu;
import android.support.design.internal.NavigationMenuPresenter;
import android.support.design.internal.ScrimInsetsFrameLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v7.content.res.AppCompatResources;
import android.support.v7.view.SupportMenuInflater;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuBuilder.Callback;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.widget.TintTypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import org.telegram.tgnet.ConnectionsManager;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.Components.Glow;

public class NavigationView extends ScrimInsetsFrameLayout {
	private static final int[] CHECKED_STATE_SET;
	private static final int[] DISABLED_STATE_SET;
	private static final int PRESENTER_NAVIGATION_VIEW_ID = 1;
	OnNavigationItemSelectedListener mListener;
	private int mMaxWidth;
	private final NavigationMenu mMenu;
	private MenuInflater mMenuInflater;
	private final NavigationMenuPresenter mPresenter;

	class AnonymousClass_1 implements Callback {
		final /* synthetic */ NavigationView this$0;

		AnonymousClass_1(NavigationView this$0) {
			super();
			this.this$0 = this$0;
		}

		public boolean onMenuItemSelected(MenuBuilder menu, MenuItem item) {
			if (this$0.mListener == null || !this$0.mListener.onNavigationItemSelected(item)) {
				return false;
			} else {
				return true;
			}
		}

		public void onMenuModeChange(MenuBuilder menu) {
		}
	}

	public static interface OnNavigationItemSelectedListener {
		public boolean onNavigationItemSelected(@NonNull MenuItem r1_MenuItem);
	}

	public static class SavedState extends AbsSavedState {
		public static final Creator<NavigationView.SavedState> CREATOR;
		public Bundle menuState;

		static class AnonymousClass_1 implements ParcelableCompatCreatorCallbacks<NavigationView.SavedState> {
			AnonymousClass_1() {
				super();
			}

			public NavigationView.SavedState createFromParcel(Parcel parcel, ClassLoader loader) {
				return new NavigationView.SavedState(parcel, loader);
			}

			public NavigationView.SavedState[] newArray(int size) {
				return new NavigationView.SavedState[size];
			}
		}


		static {
			CREATOR = ParcelableCompat.newCreator(new AnonymousClass_1());
		}

		public SavedState(Parcel in, ClassLoader loader) {
			super(in, loader);
			menuState = in.readBundle(loader);
		}

		public SavedState(Parcelable superState) {
			super(superState);
		}

		public void writeToParcel(@NonNull Parcel dest, int flags) {
			super.writeToParcel(dest, flags);
			dest.writeBundle(menuState);
		}
	}


	static {
		int[] r0_int_A = new int[1];
		r0_int_A[0] = 16842912;
		CHECKED_STATE_SET = r0_int_A;
		r0_int_A = new int[1];
		r0_int_A[0] = -16842910;
		DISABLED_STATE_SET = r0_int_A;
	}

	public NavigationView(Context context) {
		this(context, null);
	}

	public NavigationView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public NavigationView(Context context, AttributeSet attrs, int defStyleAttr) {
		ColorStateList itemIconTint;
		super(context, attrs, defStyleAttr);
		mPresenter = new NavigationMenuPresenter();
		ThemeUtils.checkAppCompatTheme(context);
		mMenu = new NavigationMenu(context);
		TintTypedArray a = TintTypedArray.obtainStyledAttributes(context, attrs, R.styleable.NavigationView, defStyleAttr, R.style.Widget_Design_NavigationView);
		setBackgroundDrawable(a.getDrawable(R.styleable.NavigationView_android_background));
		if (a.hasValue(R.styleable.NavigationView_elevation)) {
			ViewCompat.setElevation(this, (float) a.getDimensionPixelSize(R.styleable.NavigationView_elevation, 0));
		}
		ViewCompat.setFitsSystemWindows(this, a.getBoolean(R.styleable.NavigationView_android_fitsSystemWindows, false));
		mMaxWidth = a.getDimensionPixelSize(R.styleable.NavigationView_android_maxWidth, 0);
		if (a.hasValue(R.styleable.NavigationView_itemIconTint)) {
			itemIconTint = a.getColorStateList(R.styleable.NavigationView_itemIconTint);
		} else {
			itemIconTint = createDefaultColorStateList(16842808);
		}
		boolean textAppearanceSet = false;
		int textAppearance = 0;
		if (a.hasValue(R.styleable.NavigationView_itemTextAppearance)) {
			textAppearance = a.getResourceId(R.styleable.NavigationView_itemTextAppearance, 0);
			textAppearanceSet = true;
		}
		ColorStateList itemTextColor = null;
		if (a.hasValue(R.styleable.NavigationView_itemTextColor)) {
			itemTextColor = a.getColorStateList(R.styleable.NavigationView_itemTextColor);
		}
		Drawable itemBackground;
		if (textAppearanceSet || itemTextColor != null) {
			itemBackground = a.getDrawable(R.styleable.NavigationView_itemBackground);
			mMenu.setCallback(new AnonymousClass_1(this));
			mPresenter.setId(PRESENTER_NAVIGATION_VIEW_ID);
			mPresenter.initForMenu(context, mMenu);
			mPresenter.setItemIconTintList(itemIconTint);
			if (!textAppearanceSet) {
				mPresenter.setItemTextAppearance(textAppearance);
			}
			mPresenter.setItemTextColor(itemTextColor);
			mPresenter.setItemBackground(itemBackground);
			mMenu.addMenuPresenter(mPresenter);
			addView((View) mPresenter.getMenuView(this));
			if (a.hasValue(R.styleable.NavigationView_menu)) {
				inflateMenu(a.getResourceId(R.styleable.NavigationView_menu, 0));
			}
			if (!a.hasValue(R.styleable.NavigationView_headerLayout)) {
				inflateHeaderView(a.getResourceId(R.styleable.NavigationView_headerLayout, 0));
			}
			a.recycle();
		} else {
			itemTextColor = createDefaultColorStateList(16842806);
			itemBackground = a.getDrawable(R.styleable.NavigationView_itemBackground);
			mMenu.setCallback(new AnonymousClass_1(this));
			mPresenter.setId(PRESENTER_NAVIGATION_VIEW_ID);
			mPresenter.initForMenu(context, mMenu);
			mPresenter.setItemIconTintList(itemIconTint);
			if (!textAppearanceSet) {
				mPresenter.setItemTextColor(itemTextColor);
				mPresenter.setItemBackground(itemBackground);
				mMenu.addMenuPresenter(mPresenter);
				addView((View) mPresenter.getMenuView(this));
				if (a.hasValue(R.styleable.NavigationView_menu)) {
					if (!a.hasValue(R.styleable.NavigationView_headerLayout)) {
						a.recycle();
					} else {
						inflateHeaderView(a.getResourceId(R.styleable.NavigationView_headerLayout, 0));
						a.recycle();
					}
				} else {
					inflateMenu(a.getResourceId(R.styleable.NavigationView_menu, 0));
					if (!a.hasValue(R.styleable.NavigationView_headerLayout)) {
						inflateHeaderView(a.getResourceId(R.styleable.NavigationView_headerLayout, 0));
					}
					a.recycle();
				}
			} else {
				mPresenter.setItemTextAppearance(textAppearance);
				mPresenter.setItemTextColor(itemTextColor);
				mPresenter.setItemBackground(itemBackground);
				mMenu.addMenuPresenter(mPresenter);
				addView((View) mPresenter.getMenuView(this));
				if (a.hasValue(R.styleable.NavigationView_menu)) {
					inflateMenu(a.getResourceId(R.styleable.NavigationView_menu, 0));
				}
				if (!a.hasValue(R.styleable.NavigationView_headerLayout)) {
					a.recycle();
				} else {
					inflateHeaderView(a.getResourceId(R.styleable.NavigationView_headerLayout, 0));
					a.recycle();
				}
			}
		}
	}

	private ColorStateList createDefaultColorStateList(int baseColorThemeAttr) {
		int r7i = ConnectionsManager.ConnectionStateConnected;
		TypedValue value = new TypedValue();
		if (!getContext().getTheme().resolveAttribute(baseColorThemeAttr, value, true)) {
			return null;
		} else {
			ColorStateList baseColor = AppCompatResources.getColorStateList(getContext(), value.resourceId);
			if (getContext().getTheme().resolveAttribute(android.support.v7.appcompat.R.attr.colorPrimary, value, true)) {
				int defaultColor = baseColor.getDefaultColor();
				int[][] r5_int_A_A = new int[r7i][];
				r5_int_A_A[0] = DISABLED_STATE_SET;
				r5_int_A_A[1] = CHECKED_STATE_SET;
				r5_int_A_A[2] = EMPTY_STATE_SET;
				int[] r6_int_A = new int[r7i];
				r6_int_A[0] = baseColor.getColorForState(DISABLED_STATE_SET, defaultColor);
				r6_int_A[1] = value.data;
				r6_int_A[2] = defaultColor;
				return new ColorStateList(r5_int_A_A, r6_int_A);
			} else {
				return null;
			}
		}
	}

	private MenuInflater getMenuInflater() {
		if (mMenuInflater == null) {
			mMenuInflater = new SupportMenuInflater(getContext());
		}
		return mMenuInflater;
	}

	public void addHeaderView(@NonNull View view) {
		mPresenter.addHeaderView(view);
	}

	public int getHeaderCount() {
		return mPresenter.getHeaderCount();
	}

	public View getHeaderView(int index) {
		return mPresenter.getHeaderView(index);
	}

	@Nullable
	public Drawable getItemBackground() {
		return mPresenter.getItemBackground();
	}

	@Nullable
	public ColorStateList getItemIconTintList() {
		return mPresenter.getItemTintList();
	}

	@Nullable
	public ColorStateList getItemTextColor() {
		return mPresenter.getItemTextColor();
	}

	public Menu getMenu() {
		return mMenu;
	}

	public View inflateHeaderView(@LayoutRes int res) {
		return mPresenter.inflateHeaderView(res);
	}

	public void inflateMenu(int resId) {
		mPresenter.setUpdateSuspended(true);
		getMenuInflater().inflate(resId, mMenu);
		mPresenter.setUpdateSuspended(false);
		mPresenter.updateMenuView(false);
	}

	protected void onInsetsChanged(WindowInsetsCompat insets) {
		mPresenter.dispatchApplyWindowInsets(insets);
	}

	protected void onMeasure(int widthSpec, int heightSpec) {
		switch(MeasureSpec.getMode(widthSpec)) {
		case TLRPC.MESSAGE_FLAG_MEGAGROUP:
			widthSpec = MeasureSpec.makeMeasureSpec(Math.min(MeasureSpec.getSize(widthSpec), mMaxWidth), 1073741824);
			break;
		case Glow.ALWAYS:
			widthSpec = MeasureSpec.makeMeasureSpec(mMaxWidth, 1073741824);
			break;
		}
		super.onMeasure(widthSpec, heightSpec);
	}

	protected void onRestoreInstanceState(Parcelable savedState) {
		if (!(savedState instanceof SavedState)) {
			super.onRestoreInstanceState(savedState);
		} else {
			SavedState state = (SavedState) savedState;
			super.onRestoreInstanceState(state.getSuperState());
			mMenu.restorePresenterStates(state.menuState);
		}
	}

	protected Parcelable onSaveInstanceState() {
		SavedState state = new SavedState(super.onSaveInstanceState());
		state.menuState = new Bundle();
		mMenu.savePresenterStates(state.menuState);
		return state;
	}

	public void removeHeaderView(@NonNull View view) {
		mPresenter.removeHeaderView(view);
	}

	public void setCheckedItem(@IdRes int id) {
		MenuItem item = mMenu.findItem(id);
		if (item != null) {
			mPresenter.setCheckedItem((MenuItemImpl) item);
		}
	}

	public void setItemBackground(@Nullable Drawable itemBackground) {
		mPresenter.setItemBackground(itemBackground);
	}

	public void setItemBackgroundResource(@DrawableRes int resId) {
		setItemBackground(ContextCompat.getDrawable(getContext(), resId));
	}

	public void setItemIconTintList(@Nullable ColorStateList tint) {
		mPresenter.setItemIconTintList(tint);
	}

	public void setItemTextAppearance(@StyleRes int resId) {
		mPresenter.setItemTextAppearance(resId);
	}

	public void setItemTextColor(@Nullable ColorStateList textColor) {
		mPresenter.setItemTextColor(textColor);
	}

	public void setNavigationItemSelectedListener(@Nullable OnNavigationItemSelectedListener listener) {
		mListener = listener;
	}
}
