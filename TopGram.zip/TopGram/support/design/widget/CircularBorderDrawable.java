package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.ColorUtils;
import com.androidquery.util.Constants;
import com.rey.material.widget.SnackBar;

class CircularBorderDrawable extends Drawable {
	private static final float DRAW_STROKE_WIDTH_MULTIPLE = 1.3333f;
	private ColorStateList mBorderTint;
	float mBorderWidth;
	private int mBottomInnerStrokeColor;
	private int mBottomOuterStrokeColor;
	private int mCurrentBorderTintColor;
	private boolean mInvalidateShader;
	final Paint mPaint;
	final Rect mRect;
	final RectF mRectF;
	private float mRotation;
	private int mTopInnerStrokeColor;
	private int mTopOuterStrokeColor;

	public CircularBorderDrawable() {
		super();
		mRect = new Rect();
		mRectF = new RectF();
		mInvalidateShader = true;
		mPaint = new Paint(1);
		mPaint.setStyle(Style.STROKE);
	}

	private Shader createGradientShader() {
		Rect rect = mRect;
		copyBounds(rect);
		float borderRatio = mBorderWidth / ((float) rect.height());
		int[] colors = new int[6];
		colors[0] = ColorUtils.compositeColors(mTopOuterStrokeColor, mCurrentBorderTintColor);
		colors[1] = ColorUtils.compositeColors(mTopInnerStrokeColor, mCurrentBorderTintColor);
		colors[2] = ColorUtils.compositeColors(ColorUtils.setAlphaComponent(mTopInnerStrokeColor, 0), mCurrentBorderTintColor);
		colors[3] = ColorUtils.compositeColors(ColorUtils.setAlphaComponent(mBottomInnerStrokeColor, 0), mCurrentBorderTintColor);
		colors[4] = ColorUtils.compositeColors(mBottomInnerStrokeColor, mCurrentBorderTintColor);
		colors[5] = ColorUtils.compositeColors(mBottomOuterStrokeColor, mCurrentBorderTintColor);
		float[] positions = new float[6];
		positions[0] = 0.0f;
		positions[1] = borderRatio;
		positions[2] = 0.5f;
		positions[3] = 0.5f;
		positions[4] = 1.0f - borderRatio;
		positions[5] = 1.0f;
		return new LinearGradient(0.0f, (float) rect.top, 0.0f, (float) rect.bottom, colors, positions, TileMode.CLAMP);
	}

	public void draw(Canvas canvas) {
		if (mInvalidateShader) {
			mPaint.setShader(createGradientShader());
			mInvalidateShader = false;
		}
		float halfBorderWidth = mPaint.getStrokeWidth() / 2.0f;
		RectF rectF = mRectF;
		copyBounds(mRect);
		rectF.set(mRect);
		rectF.left += halfBorderWidth;
		rectF.top += halfBorderWidth;
		rectF.right -= halfBorderWidth;
		rectF.bottom -= halfBorderWidth;
		canvas.save();
		canvas.rotate(mRotation, rectF.centerX(), rectF.centerY());
		canvas.drawOval(rectF, mPaint);
		canvas.restore();
	}

	public int getOpacity() {
		if (mBorderWidth > 0.0f) {
			return Constants.PRESET;
		} else {
			return SnackBar.WRAP_CONTENT;
		}
	}

	public boolean getPadding(Rect padding) {
		int borderWidth = Math.round(mBorderWidth);
		padding.set(borderWidth, borderWidth, borderWidth, borderWidth);
		return true;
	}

	public boolean isStateful() {
		if ((mBorderTint == null || !mBorderTint.isStateful()) && !super.isStateful()) {
			return false;
		} else {
			return true;
		}
		return true;
	}

	protected void onBoundsChange(Rect bounds) {
		mInvalidateShader = true;
	}

	protected boolean onStateChange(int[] state) {
		if (mBorderTint != null) {
			int newColor = mBorderTint.getColorForState(state, mCurrentBorderTintColor);
			if (newColor != mCurrentBorderTintColor) {
				mInvalidateShader = true;
				mCurrentBorderTintColor = newColor;
			}
		}
		if (mInvalidateShader) {
			invalidateSelf();
		}
		return mInvalidateShader;
	}

	public void setAlpha(int alpha) {
		mPaint.setAlpha(alpha);
		invalidateSelf();
	}

	void setBorderTint(ColorStateList tint) {
		if (tint != null) {
			mCurrentBorderTintColor = tint.getColorForState(getState(), mCurrentBorderTintColor);
		}
		mBorderTint = tint;
		mInvalidateShader = true;
		invalidateSelf();
	}

	void setBorderWidth(float width) {
		if (mBorderWidth != width) {
			mBorderWidth = width;
			mPaint.setStrokeWidth(1.3333f * width);
			mInvalidateShader = true;
			invalidateSelf();
		}
	}

	public void setColorFilter(ColorFilter colorFilter) {
		mPaint.setColorFilter(colorFilter);
		invalidateSelf();
	}

	void setGradientColors(int topOuterStrokeColor, int topInnerStrokeColor, int bottomOuterStrokeColor, int bottomInnerStrokeColor) {
		mTopOuterStrokeColor = topOuterStrokeColor;
		mTopInnerStrokeColor = topInnerStrokeColor;
		mBottomOuterStrokeColor = bottomOuterStrokeColor;
		mBottomInnerStrokeColor = bottomInnerStrokeColor;
	}

	final void setRotation(float rotation) {
		if (rotation != mRotation) {
			mRotation = rotation;
			invalidateSelf();
		}
	}
}
