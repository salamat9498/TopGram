package android.support.design.widget;

import android.support.annotation.NonNull;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ViewDragHelper;
import android.support.v4.widget.ViewDragHelper.Callback;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import org.telegram.tgnet.ConnectionsManager;

public class SwipeDismissBehavior<V extends View> extends Behavior<V> {
	private static final float DEFAULT_ALPHA_END_DISTANCE = 0.5f;
	private static final float DEFAULT_ALPHA_START_DISTANCE = 0.0f;
	private static final float DEFAULT_DRAG_DISMISS_THRESHOLD = 0.5f;
	public static final int STATE_DRAGGING = 1;
	public static final int STATE_IDLE = 0;
	public static final int STATE_SETTLING = 2;
	public static final int SWIPE_DIRECTION_ANY = 2;
	public static final int SWIPE_DIRECTION_END_TO_START = 1;
	public static final int SWIPE_DIRECTION_START_TO_END = 0;
	float mAlphaEndSwipeDistance;
	float mAlphaStartSwipeDistance;
	private final Callback mDragCallback;
	float mDragDismissThreshold;
	private boolean mInterceptingEvents;
	OnDismissListener mListener;
	private float mSensitivity;
	private boolean mSensitivitySet;
	int mSwipeDirection;
	ViewDragHelper mViewDragHelper;

	public static interface OnDismissListener {
		public void onDismiss(View r1_View);

		public void onDragStateChanged(int r1i);
	}

	class AnonymousClass_1 extends Callback {
		private static final int INVALID_POINTER_ID = -1;
		private int mActivePointerId;
		private int mOriginalCapturedViewLeft;
		final /* synthetic */ SwipeDismissBehavior this$0;

		AnonymousClass_1(SwipeDismissBehavior this$0) {
			super();
			this.this$0 = this$0;
			mActivePointerId = -1;
		}

		private boolean shouldDismiss(View child, float xvel) {
			if (xvel != 0.0f) {
				boolean isRtl;
				if (ViewCompat.getLayoutDirection(child) == 1) {
					isRtl = true;
				} else {
					isRtl = false;
				}
				if (this$0.mSwipeDirection == 2) {
					return true;
				} else if (this$0.mSwipeDirection == 0) {
					if (isRtl) {
						if (xvel >= 0.0f) {
							return false;
						} else {
							return true;
						}
					} else if (xvel <= 0.0f) {
						return false;
					} else {
						return true;
					}
				} else if (this$0.mSwipeDirection == 1) {
					if (isRtl) {
						if (xvel <= 0.0f) {
							return false;
						} else {
							return true;
						}
					} else if (xvel >= 0.0f) {
						return false;
					} else {
						return true;
					}
				} else {
					return false;
				}
			} else if (Math.abs(child.getLeft() - mOriginalCapturedViewLeft) < Math.round(((float) child.getWidth()) * this$0.mDragDismissThreshold)) {
				return false;
			} else {
				return true;
			}
		}

		public int clampViewPositionHorizontal(View child, int left, int dx) {
			boolean isRtl;
			int min;
			int max;
			if (ViewCompat.getLayoutDirection(child) == 1) {
				isRtl = true;
			} else {
				isRtl = false;
			}
			if (this$0.mSwipeDirection == 0) {
				if (isRtl) {
					min = mOriginalCapturedViewLeft - child.getWidth();
					max = mOriginalCapturedViewLeft;
				} else {
					min = mOriginalCapturedViewLeft;
					max = mOriginalCapturedViewLeft + child.getWidth();
				}
			} else if (this$0.mSwipeDirection == 1) {
				if (isRtl) {
					min = mOriginalCapturedViewLeft;
					max = mOriginalCapturedViewLeft + child.getWidth();
				} else {
					min = mOriginalCapturedViewLeft - child.getWidth();
					max = mOriginalCapturedViewLeft;
				}
			} else {
				min = mOriginalCapturedViewLeft - child.getWidth();
				max = mOriginalCapturedViewLeft + child.getWidth();
			}
			return SwipeDismissBehavior.clamp(min, left, max);
		}

		public int clampViewPositionVertical(View child, int top, int dy) {
			return child.getTop();
		}

		public int getViewHorizontalDragRange(View child) {
			return child.getWidth();
		}

		public void onViewCaptured(View capturedChild, int activePointerId) {
			mActivePointerId = activePointerId;
			mOriginalCapturedViewLeft = capturedChild.getLeft();
			ViewParent parent = capturedChild.getParent();
			if (parent != null) {
				parent.requestDisallowInterceptTouchEvent(true);
			}
		}

		public void onViewDragStateChanged(int state) {
			if (this$0.mListener != null) {
				this$0.mListener.onDragStateChanged(state);
			}
		}

		public void onViewPositionChanged(View child, int left, int top, int dx, int dy) {
			float startAlphaDistance = ((float) mOriginalCapturedViewLeft) + (((float) child.getWidth()) * this$0.mAlphaStartSwipeDistance);
			float endAlphaDistance = ((float) mOriginalCapturedViewLeft) + (((float) child.getWidth()) * this$0.mAlphaEndSwipeDistance);
			if (((float) left) <= startAlphaDistance) {
				ViewCompat.setAlpha(child, 1.0f);
			} else if (((float) left) >= endAlphaDistance) {
				ViewCompat.setAlpha(child, DEFAULT_ALPHA_START_DISTANCE);
			} else {
				ViewCompat.setAlpha(child, SwipeDismissBehavior.clamp((float)DEFAULT_ALPHA_START_DISTANCE, 1.0f - SwipeDismissBehavior.fraction(startAlphaDistance, endAlphaDistance, (float) left), 1.0f));
			}
		}

		public void onViewReleased(View child, float xvel, float yvel) {
			int targetLeft;
			mActivePointerId = -1;
			int childWidth = child.getWidth();
			boolean dismiss = false;
			if (shouldDismiss(child, xvel)) {
				if (child.getLeft() < mOriginalCapturedViewLeft) {
					targetLeft = mOriginalCapturedViewLeft - childWidth;
				} else {
					targetLeft = mOriginalCapturedViewLeft + childWidth;
				}
				dismiss = true;
			}
			if (this$0.mViewDragHelper.settleCapturedViewAt(targetLeft, child.getTop())) {
				ViewCompat.postOnAnimation(child, new SwipeDismissBehavior.SettleRunnable(this$0, child, dismiss));
			} else if (!dismiss || this$0.mListener == null) {
			} else {
				this$0.mListener.onDismiss(child);
			}
		}

		public boolean tryCaptureView(View child, int pointerId) {
			if (mActivePointerId != -1 || !this$0.canSwipeDismissView(child)) {
				return false;
			} else {
				return true;
			}
		}
	}

	private class SettleRunnable implements Runnable {
		private final boolean mDismiss;
		private final View mView;
		final /* synthetic */ SwipeDismissBehavior this$0;

		SettleRunnable(SwipeDismissBehavior r1_SwipeDismissBehavior, View view, boolean dismiss) {
			super();
			this$0 = r1_SwipeDismissBehavior;
			mView = view;
			mDismiss = dismiss;
		}

		public void run() {
			if (this$0.mViewDragHelper == null || !this$0.mViewDragHelper.continueSettling(true)) {
				if (!mDismiss || this$0.mListener == null) {
				} else {
					this$0.mListener.onDismiss(mView);
				}
			} else {
				ViewCompat.postOnAnimation(mView, this);
			}
		}
	}


	public SwipeDismissBehavior() {
		super();
		mSensitivity = 0.0f;
		mSwipeDirection = 2;
		mDragDismissThreshold = 0.5f;
		mAlphaStartSwipeDistance = 0.0f;
		mAlphaEndSwipeDistance = 0.5f;
		mDragCallback = new AnonymousClass_1(this);
	}

	static float clamp(float min, float value, float max) {
		return Math.min(Math.max(min, value), max);
	}

	static int clamp(int min, int value, int max) {
		return Math.min(Math.max(min, value), max);
	}

	private void ensureViewDragHelper(ViewGroup parent) {
		if (mViewDragHelper == null) {
			ViewDragHelper r0_ViewDragHelper;
			if (mSensitivitySet) {
				r0_ViewDragHelper = ViewDragHelper.create(parent, mSensitivity, mDragCallback);
			} else {
				r0_ViewDragHelper = ViewDragHelper.create(parent, mDragCallback);
			}
			mViewDragHelper = r0_ViewDragHelper;
		}
	}

	static float fraction(float startValue, float endValue, float value) {
		return (value - startValue) / (endValue - startValue);
	}

	public boolean canSwipeDismissView(@NonNull View view) {
		return true;
	}

	public int getDragState() {
		if (mViewDragHelper != null) {
			return mViewDragHelper.getViewDragState();
		} else {
			return STATE_IDLE;
		}
	}

	public boolean onInterceptTouchEvent(CoordinatorLayout parent, V child, MotionEvent event) {
		boolean dispatchEventToHelper = mInterceptingEvents;
		switch(MotionEventCompat.getActionMasked(event)) {
		case STATE_IDLE:
			mInterceptingEvents = parent.isPointInChildBounds(child, (int) event.getX(), (int) event.getY());
			dispatchEventToHelper = mInterceptingEvents;
			break;
		case SWIPE_DIRECTION_END_TO_START:
		case ConnectionsManager.ConnectionStateConnected:
			mInterceptingEvents = false;
			break;
		}
		if (dispatchEventToHelper) {
			ensureViewDragHelper(parent);
			return mViewDragHelper.shouldInterceptTouchEvent(event);
		} else {
			return false;
		}
	}

	public boolean onTouchEvent(CoordinatorLayout parent, V child, MotionEvent event) {
		if (mViewDragHelper != null) {
			mViewDragHelper.processTouchEvent(event);
			return true;
		} else {
			return false;
		}
	}

	public void setDragDismissDistance(float distance) {
		mDragDismissThreshold = clamp((float)DEFAULT_ALPHA_START_DISTANCE, distance, 1.0f);
	}

	public void setEndAlphaSwipeDistance(float fraction) {
		mAlphaEndSwipeDistance = clamp((float)DEFAULT_ALPHA_START_DISTANCE, fraction, 1.0f);
	}

	public void setListener(OnDismissListener listener) {
		mListener = listener;
	}

	public void setSensitivity(float sensitivity) {
		mSensitivity = sensitivity;
		mSensitivitySet = true;
	}

	public void setStartAlphaSwipeDistance(float fraction) {
		mAlphaStartSwipeDistance = clamp((float)DEFAULT_ALPHA_START_DISTANCE, fraction, 1.0f);
	}

	public void setSwipeDirection(int direction) {
		mSwipeDirection = direction;
	}
}
