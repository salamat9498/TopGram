package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StyleRes;
import android.support.design.R;
import android.support.design.widget.AppBarLayout.OnOffsetChangedListener;
import android.support.design.widget.ValueAnimatorCompat.AnimatorUpdateListener;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import com.wdullaer.materialdatetimepicker.Utils;
import org.telegram.tgnet.TLRPC;

public class CollapsingToolbarLayout extends FrameLayout {
	private static final int DEFAULT_SCRIM_ANIMATION_DURATION = 600;
	final CollapsingTextHelper mCollapsingTextHelper;
	private boolean mCollapsingTitleEnabled;
	private Drawable mContentScrim;
	int mCurrentOffset;
	private boolean mDrawCollapsingTitle;
	private View mDummyView;
	private int mExpandedMarginBottom;
	private int mExpandedMarginEnd;
	private int mExpandedMarginStart;
	private int mExpandedMarginTop;
	WindowInsetsCompat mLastInsets;
	private OnOffsetChangedListener mOnOffsetChangedListener;
	private boolean mRefreshToolbar;
	private int mScrimAlpha;
	private long mScrimAnimationDuration;
	private ValueAnimatorCompat mScrimAnimator;
	private int mScrimVisibleHeightTrigger;
	private boolean mScrimsAreShown;
	Drawable mStatusBarScrim;
	private final Rect mTmpRect;
	private Toolbar mToolbar;
	private View mToolbarDirectChild;
	private int mToolbarDrawIndex;
	private int mToolbarId;

	class AnonymousClass_1 implements OnApplyWindowInsetsListener {
		final /* synthetic */ CollapsingToolbarLayout this$0;

		AnonymousClass_1(CollapsingToolbarLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
			return this$0.onWindowInsetChanged(insets);
		}
	}

	class AnonymousClass_2 implements AnimatorUpdateListener {
		final /* synthetic */ CollapsingToolbarLayout this$0;

		AnonymousClass_2(CollapsingToolbarLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onAnimationUpdate(ValueAnimatorCompat animator) {
			this$0.setScrimAlpha(animator.getAnimatedIntValue());
		}
	}

	public static class LayoutParams extends android.widget.FrameLayout.LayoutParams {
		public static final int COLLAPSE_MODE_OFF = 0;
		public static final int COLLAPSE_MODE_PARALLAX = 2;
		public static final int COLLAPSE_MODE_PIN = 1;
		private static final float DEFAULT_PARALLAX_MULTIPLIER = 0.5f;
		int mCollapseMode;
		float mParallaxMult;

		public LayoutParams(int width, int height) {
			super(width, height);
			mCollapseMode = 0;
			mParallaxMult = 0.5f;
		}

		public LayoutParams(int width, int height, int gravity) {
			super(width, height, gravity);
			mCollapseMode = 0;
			mParallaxMult = 0.5f;
		}

		public LayoutParams(Context c, AttributeSet attrs) {
			super(c, attrs);
			mCollapseMode = 0;
			mParallaxMult = 0.5f;
			TypedArray a = c.obtainStyledAttributes(attrs, R.styleable.CollapsingToolbarLayout_Layout);
			mCollapseMode = a.getInt(R.styleable.CollapsingToolbarLayout_Layout_layout_collapseMode, COLLAPSE_MODE_OFF);
			setParallaxMultiplier(a.getFloat(R.styleable.CollapsingToolbarLayout_Layout_layout_collapseParallaxMultiplier, DEFAULT_PARALLAX_MULTIPLIER));
			a.recycle();
		}

		public LayoutParams(android.view.ViewGroup.LayoutParams p) {
			super(p);
			mCollapseMode = 0;
			mParallaxMult = 0.5f;
		}

		public LayoutParams(MarginLayoutParams source) {
			super(source);
			mCollapseMode = 0;
			mParallaxMult = 0.5f;
		}

		public LayoutParams(android.widget.FrameLayout.LayoutParams source) {
			super(source);
			mCollapseMode = 0;
			mParallaxMult = 0.5f;
		}

		public int getCollapseMode() {
			return mCollapseMode;
		}

		public float getParallaxMultiplier() {
			return mParallaxMult;
		}

		public void setCollapseMode(int collapseMode) {
			mCollapseMode = collapseMode;
		}

		public void setParallaxMultiplier(float multiplier) {
			mParallaxMult = multiplier;
		}
	}

	private class OffsetUpdateListener implements OnOffsetChangedListener {
		final /* synthetic */ CollapsingToolbarLayout this$0;

		OffsetUpdateListener(CollapsingToolbarLayout r1_CollapsingToolbarLayout) {
			super();
			this$0 = r1_CollapsingToolbarLayout;
		}

		public void onOffsetChanged(AppBarLayout layout, int verticalOffset) {
			int insetTop;
			this$0.mCurrentOffset = verticalOffset;
			if (this$0.mLastInsets != null) {
				insetTop = this$0.mLastInsets.getSystemWindowInsetTop();
			} else {
				insetTop = 0;
			}
			int i = 0;
			while (i < this$0.getChildCount()) {
				View child = this$0.getChildAt(i);
				CollapsingToolbarLayout.LayoutParams lp = (CollapsingToolbarLayout.LayoutParams) child.getLayoutParams();
				ViewOffsetHelper offsetHelper = CollapsingToolbarLayout.getViewOffsetHelper(child);
				switch(lp.mCollapseMode) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					offsetHelper.setTopAndBottomOffset(MathUtils.constrain(-verticalOffset, 0, this$0.getMaxOffsetForPinChild(child)));
					break;
				case TLRPC.USER_FLAG_FIRST_NAME:
					offsetHelper.setTopAndBottomOffset(Math.round(((float) (-verticalOffset)) * lp.mParallaxMult));
					break;
				}
				i++;
			}
			this$0.updateScrimVisibility();
			if (this$0.mStatusBarScrim == null || insetTop <= 0) {
				this$0.mCollapsingTextHelper.setExpansionFraction(((float) Math.abs(verticalOffset)) / ((float) ((this$0.getHeight() - ViewCompat.getMinimumHeight(this$0)) - insetTop)));
			} else {
				ViewCompat.postInvalidateOnAnimation(this$0);
				this$0.mCollapsingTextHelper.setExpansionFraction(((float) Math.abs(verticalOffset)) / ((float) ((this$0.getHeight() - ViewCompat.getMinimumHeight(this$0)) - insetTop)));
			}
		}
	}


	public CollapsingToolbarLayout(Context context) {
		this(context, null);
	}

	public CollapsingToolbarLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CollapsingToolbarLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		mRefreshToolbar = true;
		mTmpRect = new Rect();
		mScrimVisibleHeightTrigger = -1;
		ThemeUtils.checkAppCompatTheme(context);
		mCollapsingTextHelper = new CollapsingTextHelper(this);
		mCollapsingTextHelper.setTextSizeInterpolator(AnimationUtils.DECELERATE_INTERPOLATOR);
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CollapsingToolbarLayout, defStyleAttr, R.style.Widget_Design_CollapsingToolbar);
		mCollapsingTextHelper.setExpandedTextGravity(a.getInt(R.styleable.CollapsingToolbarLayout_expandedTitleGravity, 8388691));
		mCollapsingTextHelper.setCollapsedTextGravity(a.getInt(R.styleable.CollapsingToolbarLayout_collapsedTitleGravity, 8388627));
		int r1i = a.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMargin, 0);
		mExpandedMarginBottom = r1i;
		mExpandedMarginEnd = r1i;
		mExpandedMarginTop = r1i;
		mExpandedMarginStart = r1i;
		if (a.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleMarginStart)) {
			mExpandedMarginStart = a.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMarginStart, 0);
		}
		if (a.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleMarginEnd)) {
			mExpandedMarginEnd = a.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMarginEnd, 0);
		}
		if (a.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleMarginTop)) {
			mExpandedMarginTop = a.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMarginTop, 0);
		}
		if (a.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleMarginBottom)) {
			mExpandedMarginBottom = a.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMarginBottom, 0);
		}
		mCollapsingTitleEnabled = a.getBoolean(R.styleable.CollapsingToolbarLayout_titleEnabled, true);
		setTitle(a.getText(R.styleable.CollapsingToolbarLayout_title));
		mCollapsingTextHelper.setExpandedTextAppearance(R.style.TextAppearance_Design_CollapsingToolbar_Expanded);
		mCollapsingTextHelper.setCollapsedTextAppearance(android.support.v7.appcompat.R.style.TextAppearance_AppCompat_Widget_ActionBar_Title);
		if (a.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleTextAppearance)) {
			mCollapsingTextHelper.setExpandedTextAppearance(a.getResourceId(R.styleable.CollapsingToolbarLayout_expandedTitleTextAppearance, 0));
		}
		if (a.hasValue(R.styleable.CollapsingToolbarLayout_collapsedTitleTextAppearance)) {
			mCollapsingTextHelper.setCollapsedTextAppearance(a.getResourceId(R.styleable.CollapsingToolbarLayout_collapsedTitleTextAppearance, 0));
		}
		mScrimVisibleHeightTrigger = a.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_scrimVisibleHeightTrigger, -1);
		mScrimAnimationDuration = (long) a.getInt(R.styleable.CollapsingToolbarLayout_scrimAnimationDuration, DEFAULT_SCRIM_ANIMATION_DURATION);
		setContentScrim(a.getDrawable(R.styleable.CollapsingToolbarLayout_contentScrim));
		setStatusBarScrim(a.getDrawable(R.styleable.CollapsingToolbarLayout_statusBarScrim));
		mToolbarId = a.getResourceId(R.styleable.CollapsingToolbarLayout_toolbarId, -1);
		a.recycle();
		setWillNotDraw(false);
		ViewCompat.setOnApplyWindowInsetsListener(this, new AnonymousClass_1(this));
	}

	private void animateScrim(int targetAlpha) {
		ensureToolbar();
		if (mScrimAnimator == null) {
			Interpolator r0_Interpolator;
			mScrimAnimator = ViewUtils.createAnimator();
			mScrimAnimator.setDuration(mScrimAnimationDuration);
			ValueAnimatorCompat r1_ValueAnimatorCompat = mScrimAnimator;
			if (targetAlpha > mScrimAlpha) {
				r0_Interpolator = AnimationUtils.FAST_OUT_LINEAR_IN_INTERPOLATOR;
			} else {
				r0_Interpolator = AnimationUtils.LINEAR_OUT_SLOW_IN_INTERPOLATOR;
			}
			r1_ValueAnimatorCompat.setInterpolator(r0_Interpolator);
			mScrimAnimator.addUpdateListener(new AnonymousClass_2(this));
		} else if (mScrimAnimator.isRunning()) {
			mScrimAnimator.cancel();
		}
		mScrimAnimator.setIntValues(mScrimAlpha, targetAlpha);
		mScrimAnimator.start();
	}

	private void ensureToolbar() {
		View r5_View = null;
		if (!mRefreshToolbar) {
		} else {
			mToolbar = r5_View;
			mToolbarDirectChild = r5_View;
			if (mToolbarId != -1) {
				mToolbar = (Toolbar) findViewById(mToolbarId);
				if (mToolbar != null) {
					mToolbarDirectChild = findDirectChild(mToolbar);
				}
			}
			if (mToolbar == null) {
				Toolbar toolbar = null;
				int i = 0;
				while (i < getChildCount()) {
					View child = getChildAt(i);
					if (child instanceof Toolbar) {
						toolbar = (Toolbar) child;
					} else {
						i++;
					}
				}
				mToolbar = toolbar;
			}
			updateDummyView();
			mRefreshToolbar = false;
		}
	}

	private View findDirectChild(View descendant) {
		View directChild = descendant;
		View p = descendant.getParent();
		while (p != this && p != null) {
			if (p instanceof View) {
				directChild = p;
			}
			p = p.getParent();
		}
		return directChild;
	}

	private static int getHeightWithMargins(@NonNull View view) {
		android.view.ViewGroup.LayoutParams lp = view.getLayoutParams();
		if (lp instanceof MarginLayoutParams) {
			MarginLayoutParams mlp = (MarginLayoutParams) lp;
			return (view.getHeight() + mlp.topMargin) + mlp.bottomMargin;
		} else {
			return view.getHeight();
		}
	}

	static ViewOffsetHelper getViewOffsetHelper(View view) {
		ViewOffsetHelper offsetHelper = (ViewOffsetHelper) view.getTag(R.id.view_offset_helper);
		if (offsetHelper == null) {
			offsetHelper = new ViewOffsetHelper(view);
			view.setTag(R.id.view_offset_helper, offsetHelper);
		}
		return offsetHelper;
	}

	private boolean isToolbarChildDrawnNext(View child) {
		if (mToolbarDrawIndex < 0 || mToolbarDrawIndex != indexOfChild(child) + 1) {
			return false;
		} else {
			return true;
		}
	}

	private void updateDummyView() {
		if (mCollapsingTitleEnabled || mDummyView == null) {
			if (!mCollapsingTitleEnabled || mToolbar == null) {
			} else {
				if (mDummyView != null) {
					mDummyView = new View(getContext());
				}
				if (mDummyView.getParent() == null) {
					mToolbar.addView(mDummyView, -1, -1);
				}
			}
		} else {
			ViewParent parent = mDummyView.getParent();
			if (parent instanceof ViewGroup) {
				((ViewGroup) parent).removeView(mDummyView);
			}
			if (!mCollapsingTitleEnabled || mToolbar == null) {
			} else if (mDummyView != null) {
				if (mDummyView.getParent() == null) {
				} else {
					mToolbar.addView(mDummyView, -1, -1);
				}
			} else {
				mDummyView = new View(getContext());
				if (mDummyView.getParent() == null) {
					mToolbar.addView(mDummyView, -1, -1);
				}
			}
		}
	}

	protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams p) {
		return p instanceof LayoutParams;
	}

	public void draw(Canvas canvas) {
		int r1i = 0;
		super.draw(canvas);
		ensureToolbar();
		int topInset;
		if (mToolbar != null || mContentScrim == null || mScrimAlpha <= 0) {
			if (!mCollapsingTitleEnabled || !mDrawCollapsingTitle) {
				if (mStatusBarScrim == null || mScrimAlpha <= 0) {
				} else {
					if (mLastInsets == null) {
						topInset = mLastInsets.getSystemWindowInsetTop();
					} else {
						topInset = 0;
					}
					if (topInset <= 0) {
						mStatusBarScrim.setBounds(r1i, -mCurrentOffset, getWidth(), topInset - mCurrentOffset);
						mStatusBarScrim.mutate().setAlpha(mScrimAlpha);
						mStatusBarScrim.draw(canvas);
					}
				}
			} else {
				mCollapsingTextHelper.draw(canvas);
				if (mStatusBarScrim == null || mScrimAlpha <= 0) {
				} else {
					if (mLastInsets == null) {
						topInset = 0;
					} else {
						topInset = mLastInsets.getSystemWindowInsetTop();
					}
					if (topInset <= 0) {
					} else {
						mStatusBarScrim.setBounds(r1i, -mCurrentOffset, getWidth(), topInset - mCurrentOffset);
						mStatusBarScrim.mutate().setAlpha(mScrimAlpha);
						mStatusBarScrim.draw(canvas);
					}
				}
			}
		} else {
			mContentScrim.mutate().setAlpha(mScrimAlpha);
			mContentScrim.draw(canvas);
			if (!mCollapsingTitleEnabled || !mDrawCollapsingTitle) {
				if (mStatusBarScrim == null || mScrimAlpha <= 0) {
				} else {
					if (mLastInsets == null) {
						topInset = mLastInsets.getSystemWindowInsetTop();
					} else {
						topInset = 0;
					}
					if (topInset <= 0) {
						mStatusBarScrim.setBounds(r1i, -mCurrentOffset, getWidth(), topInset - mCurrentOffset);
						mStatusBarScrim.mutate().setAlpha(mScrimAlpha);
						mStatusBarScrim.draw(canvas);
					}
				}
			} else {
				mCollapsingTextHelper.draw(canvas);
				if (mStatusBarScrim == null || mScrimAlpha <= 0) {
				} else {
					if (mLastInsets == null) {
						topInset = 0;
					} else {
						topInset = mLastInsets.getSystemWindowInsetTop();
					}
					if (topInset <= 0) {
					} else {
						mStatusBarScrim.setBounds(r1i, -mCurrentOffset, getWidth(), topInset - mCurrentOffset);
						mStatusBarScrim.mutate().setAlpha(mScrimAlpha);
						mStatusBarScrim.draw(canvas);
					}
				}
			}
		}
	}

	protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
		boolean invalidate = super.drawChild(canvas, child, drawingTime);
		if (mContentScrim == null || mScrimAlpha <= 0 || !isToolbarChildDrawnNext(child)) {
			return invalidate;
		} else {
			mContentScrim.mutate().setAlpha(mScrimAlpha);
			mContentScrim.draw(canvas);
			invalidate = true;
			return invalidate;
		}
	}

	protected void drawableStateChanged() {
		super.drawableStateChanged();
		int[] state = getDrawableState();
		boolean changed = false;
		Drawable d = mStatusBarScrim;
		if (d == null || !d.isStateful()) {
			d = mContentScrim;
			if (d == null || !d.isStateful()) {
				if (mCollapsingTextHelper == null) {
					changed |= mCollapsingTextHelper.setState(state);
				}
				if (!changed) {
					invalidate();
				}
			} else {
				changed |= d.setState(state);
				if (mCollapsingTextHelper == null) {
					if (!changed) {
					} else {
						invalidate();
					}
				} else {
					changed |= mCollapsingTextHelper.setState(state);
					if (!changed) {
						invalidate();
					}
				}
			}
		} else {
			changed |= d.setState(state);
			d = mContentScrim;
			if (d == null || !d.isStateful()) {
				if (mCollapsingTextHelper == null) {
					changed |= mCollapsingTextHelper.setState(state);
				}
				if (!changed) {
				} else {
					invalidate();
				}
			} else {
				changed |= d.setState(state);
				if (mCollapsingTextHelper == null) {
					if (!changed) {
						invalidate();
					}
				} else {
					changed |= mCollapsingTextHelper.setState(state);
					if (!changed) {
					} else {
						invalidate();
					}
				}
			}
		}
	}

	protected LayoutParams generateDefaultLayoutParams() {
		return new LayoutParams(-1, -1);
	}

	public android.widget.FrameLayout.LayoutParams generateLayoutParams(AttributeSet attrs) {
		return new LayoutParams(getContext(), attrs);
	}

	protected android.widget.FrameLayout.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams p) {
		return new LayoutParams(p);
	}

	public int getCollapsedTitleGravity() {
		return mCollapsingTextHelper.getCollapsedTextGravity();
	}

	@NonNull
	public Typeface getCollapsedTitleTypeface() {
		return mCollapsingTextHelper.getCollapsedTypeface();
	}

	@Nullable
	public Drawable getContentScrim() {
		return mContentScrim;
	}

	public int getExpandedTitleGravity() {
		return mCollapsingTextHelper.getExpandedTextGravity();
	}

	public int getExpandedTitleMarginBottom() {
		return mExpandedMarginBottom;
	}

	public int getExpandedTitleMarginEnd() {
		return mExpandedMarginEnd;
	}

	public int getExpandedTitleMarginStart() {
		return mExpandedMarginStart;
	}

	public int getExpandedTitleMarginTop() {
		return mExpandedMarginTop;
	}

	@NonNull
	public Typeface getExpandedTitleTypeface() {
		return mCollapsingTextHelper.getExpandedTypeface();
	}

	final int getMaxOffsetForPinChild(View child) {
		return ((getHeight() - getViewOffsetHelper(child).getLayoutTop()) - child.getHeight()) - ((LayoutParams) child.getLayoutParams()).bottomMargin;
	}

	public long getScrimAnimationDuration() {
		return mScrimAnimationDuration;
	}

	public int getScrimVisibleHeightTrigger() {
		if (mScrimVisibleHeightTrigger >= 0) {
			return mScrimVisibleHeightTrigger;
		} else {
			int insetTop;
			if (mLastInsets != null) {
				insetTop = mLastInsets.getSystemWindowInsetTop();
			} else {
				insetTop = 0;
			}
			int minHeight = ViewCompat.getMinimumHeight(this);
			if (minHeight > 0) {
				return Math.min((minHeight * 2) + insetTop, getHeight());
			} else {
				return getHeight() / 3;
			}
		}
	}

	@Nullable
	public Drawable getStatusBarScrim() {
		return mStatusBarScrim;
	}

	@Nullable
	public CharSequence getTitle() {
		if (mCollapsingTitleEnabled) {
			return mCollapsingTextHelper.getText();
		} else {
			return null;
		}
	}

	public boolean isTitleEnabled() {
		return mCollapsingTitleEnabled;
	}

	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		ViewParent parent = getParent();
		if (parent instanceof AppBarLayout) {
			ViewCompat.setFitsSystemWindows(this, ViewCompat.getFitsSystemWindows((View) parent));
			if (mOnOffsetChangedListener == null) {
				mOnOffsetChangedListener = new OffsetUpdateListener(this);
			}
			((AppBarLayout) parent).addOnOffsetChangedListener(mOnOffsetChangedListener);
			ViewCompat.requestApplyInsets(this);
		}
	}

	protected void onDetachedFromWindow() {
		ViewParent parent = getParent();
		if (mOnOffsetChangedListener == null || !(parent instanceof AppBarLayout)) {
			super.onDetachedFromWindow();
		} else {
			((AppBarLayout) parent).removeOnOffsetChangedListener(mOnOffsetChangedListener);
			super.onDetachedFromWindow();
		}
	}

	protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
		super.onLayout(changed, left, top, right, bottom);
		int i = 0;
		while (i < getChildCount()) {
			View child = getChildAt(i);
			if (mLastInsets == null || ViewCompat.getFitsSystemWindows(child)) {
				getViewOffsetHelper(child).onViewLayout();
				i++;
			} else {
				int insetTop = mLastInsets.getSystemWindowInsetTop();
				if (child.getTop() < insetTop) {
					ViewCompat.offsetTopAndBottom(child, insetTop);
				}
				getViewOffsetHelper(child).onViewLayout();
				i++;
			}
		}
		if (!mCollapsingTitleEnabled || mDummyView == null) {
			if (mToolbar == null) {
				if (!mCollapsingTitleEnabled || !TextUtils.isEmpty(mCollapsingTextHelper.getText())) {
					if (mToolbarDirectChild == null || mToolbarDirectChild == this) {
						setMinimumHeight(getHeightWithMargins(mToolbar));
						mToolbarDrawIndex = indexOfChild(mToolbar);
					} else {
						setMinimumHeight(getHeightWithMargins(mToolbarDirectChild));
						mToolbarDrawIndex = indexOfChild(mToolbarDirectChild);
					}
				} else {
					mCollapsingTextHelper.setText(mToolbar.getTitle());
					if (mToolbarDirectChild == null || mToolbarDirectChild == this) {
						setMinimumHeight(getHeightWithMargins(mToolbar));
						mToolbarDrawIndex = indexOfChild(mToolbar);
					} else {
						setMinimumHeight(getHeightWithMargins(mToolbarDirectChild));
						mToolbarDrawIndex = indexOfChild(mToolbarDirectChild);
					}
				}
			} else {
				mToolbarDrawIndex = -1;
			}
			updateScrimVisibility();
		} else {
			boolean r6z;
			if (!ViewCompat.isAttachedToWindow(mDummyView) || mDummyView.getVisibility() != 0) {
				r6z = false;
			} else {
				r6z = true;
			}
			mDrawCollapsingTitle = r6z;
			if (mDrawCollapsingTitle) {
				boolean isRtl;
				View r6_View;
				int r6i;
				int r7i;
				if (ViewCompat.getLayoutDirection(this) == 1) {
					isRtl = true;
				} else {
					isRtl = false;
				}
				if (mToolbarDirectChild != null) {
					r6_View = mToolbarDirectChild;
				} else {
					r6_View = mToolbar;
				}
				int maxOffset = getMaxOffsetForPinChild(r6_View);
				ViewGroupUtils.getDescendantRect(this, mDummyView, mTmpRect);
				CollapsingTextHelper r7_CollapsingTextHelper = mCollapsingTextHelper;
				int r8i = mTmpRect.left;
				if (isRtl) {
					r6i = mToolbar.getTitleMarginEnd();
				} else {
					r6i = mToolbar.getTitleMarginStart();
				}
				r8i += r6i;
				int r9i = mToolbar.getTitleMarginTop() + (mTmpRect.top + maxOffset);
				int r10i = mTmpRect.right;
				if (isRtl) {
					r6i = mToolbar.getTitleMarginStart();
				} else {
					r6i = mToolbar.getTitleMarginEnd();
				}
				r7_CollapsingTextHelper.setCollapsedBounds(r8i, r9i, r6i + r10i, (mTmpRect.bottom + maxOffset) - mToolbar.getTitleMarginBottom());
				CollapsingTextHelper r8_CollapsingTextHelper = mCollapsingTextHelper;
				if (isRtl) {
					r6i = mExpandedMarginEnd;
				} else {
					r6i = mExpandedMarginStart;
				}
				r9i = mExpandedMarginTop;
				r10i = right - left;
				if (isRtl) {
					r7i = mExpandedMarginStart;
				} else {
					r7i = mExpandedMarginEnd;
				}
				r8_CollapsingTextHelper.setExpandedBounds(r6i, r9i, r10i - r7i, (bottom - top) - mExpandedMarginBottom);
				mCollapsingTextHelper.recalculate();
			}
			if (mToolbar == null) {
				mToolbarDrawIndex = -1;
			} else if (!mCollapsingTitleEnabled || !TextUtils.isEmpty(mCollapsingTextHelper.getText())) {
				if (mToolbarDirectChild == null || mToolbarDirectChild == this) {
					setMinimumHeight(getHeightWithMargins(mToolbar));
					mToolbarDrawIndex = indexOfChild(mToolbar);
				} else {
					setMinimumHeight(getHeightWithMargins(mToolbarDirectChild));
					mToolbarDrawIndex = indexOfChild(mToolbarDirectChild);
				}
			} else {
				mCollapsingTextHelper.setText(mToolbar.getTitle());
				if (mToolbarDirectChild == null || mToolbarDirectChild == this) {
					setMinimumHeight(getHeightWithMargins(mToolbar));
					mToolbarDrawIndex = indexOfChild(mToolbar);
				} else {
					setMinimumHeight(getHeightWithMargins(mToolbarDirectChild));
					mToolbarDrawIndex = indexOfChild(mToolbarDirectChild);
				}
			}
			updateScrimVisibility();
		}
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		ensureToolbar();
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}

	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		if (mContentScrim != null) {
			mContentScrim.setBounds(0, 0, w, h);
		}
	}

	WindowInsetsCompat onWindowInsetChanged(WindowInsetsCompat insets) {
		WindowInsetsCompat newInsets = null;
		if (ViewCompat.getFitsSystemWindows(this)) {
			newInsets = insets;
		}
		if (!ViewUtils.objectEquals(mLastInsets, newInsets)) {
			mLastInsets = newInsets;
			requestLayout();
		}
		return insets.consumeSystemWindowInsets();
	}

	public void setCollapsedTitleGravity(int gravity) {
		mCollapsingTextHelper.setCollapsedTextGravity(gravity);
	}

	public void setCollapsedTitleTextAppearance(@StyleRes int resId) {
		mCollapsingTextHelper.setCollapsedTextAppearance(resId);
	}

	public void setCollapsedTitleTextColor(@ColorInt int color) {
		setCollapsedTitleTextColor(ColorStateList.valueOf(color));
	}

	public void setCollapsedTitleTextColor(@NonNull ColorStateList colors) {
		mCollapsingTextHelper.setCollapsedTextColor(colors);
	}

	public void setCollapsedTitleTypeface(@Nullable Typeface typeface) {
		mCollapsingTextHelper.setCollapsedTypeface(typeface);
	}

	public void setContentScrim(@Nullable Drawable drawable) {
		Drawable r0_Drawable = null;
		if (mContentScrim != drawable) {
			if (mContentScrim != null) {
				mContentScrim.setCallback(null);
			}
			if (drawable != null) {
				r0_Drawable = drawable.mutate();
			}
			mContentScrim = r0_Drawable;
			if (mContentScrim != null) {
				mContentScrim.setBounds(0, 0, getWidth(), getHeight());
				mContentScrim.setCallback(this);
				mContentScrim.setAlpha(mScrimAlpha);
			}
			ViewCompat.postInvalidateOnAnimation(this);
		}
	}

	public void setContentScrimColor(@ColorInt int color) {
		setContentScrim(new ColorDrawable(color));
	}

	public void setContentScrimResource(@DrawableRes int resId) {
		setContentScrim(ContextCompat.getDrawable(getContext(), resId));
	}

	public void setExpandedTitleColor(@ColorInt int color) {
		setExpandedTitleTextColor(ColorStateList.valueOf(color));
	}

	public void setExpandedTitleGravity(int gravity) {
		mCollapsingTextHelper.setExpandedTextGravity(gravity);
	}

	public void setExpandedTitleMargin(int start, int top, int end, int bottom) {
		mExpandedMarginStart = start;
		mExpandedMarginTop = top;
		mExpandedMarginEnd = end;
		mExpandedMarginBottom = bottom;
		requestLayout();
	}

	public void setExpandedTitleMarginBottom(int margin) {
		mExpandedMarginBottom = margin;
		requestLayout();
	}

	public void setExpandedTitleMarginEnd(int margin) {
		mExpandedMarginEnd = margin;
		requestLayout();
	}

	public void setExpandedTitleMarginStart(int margin) {
		mExpandedMarginStart = margin;
		requestLayout();
	}

	public void setExpandedTitleMarginTop(int margin) {
		mExpandedMarginTop = margin;
		requestLayout();
	}

	public void setExpandedTitleTextAppearance(@StyleRes int resId) {
		mCollapsingTextHelper.setExpandedTextAppearance(resId);
	}

	public void setExpandedTitleTextColor(@NonNull ColorStateList colors) {
		mCollapsingTextHelper.setExpandedTextColor(colors);
	}

	public void setExpandedTitleTypeface(@Nullable Typeface typeface) {
		mCollapsingTextHelper.setExpandedTypeface(typeface);
	}

	void setScrimAlpha(int alpha) {
		if (alpha != mScrimAlpha) {
			if (mContentScrim == null || mToolbar == null) {
				mScrimAlpha = alpha;
				ViewCompat.postInvalidateOnAnimation(this);
			} else {
				ViewCompat.postInvalidateOnAnimation(mToolbar);
				mScrimAlpha = alpha;
				ViewCompat.postInvalidateOnAnimation(this);
			}
		}
	}

	public void setScrimAnimationDuration(@IntRange(from = 0) long duration) {
		mScrimAnimationDuration = duration;
	}

	public void setScrimVisibleHeightTrigger(@IntRange(from = 0) int height) {
		if (mScrimVisibleHeightTrigger != height) {
			mScrimVisibleHeightTrigger = height;
			updateScrimVisibility();
		}
	}

	public void setScrimsShown(boolean shown) {
		boolean r0z;
		if (!ViewCompat.isLaidOut(this) || isInEditMode()) {
			r0z = false;
		} else {
			r0z = true;
		}
		setScrimsShown(shown, r0z);
	}

	public void setScrimsShown(boolean shown, boolean animate) {
		int r0i = Utils.SELECTED_ALPHA_THEME_DARK;
		if (mScrimsAreShown != shown) {
			if (animate) {
				if (shown) {
					animateScrim(r0i);
				} else {
					r0i = 0;
					animateScrim(r0i);
				}
			} else if (shown) {
				setScrimAlpha(r0i);
			} else {
				setScrimAlpha(r0i);
			}
			mScrimsAreShown = shown;
		}
	}

	public void setStatusBarScrim(@Nullable Drawable drawable) {
		Drawable r0_Drawable = null;
		boolean r1z = false;
		if (mStatusBarScrim != drawable) {
			if (mStatusBarScrim != null) {
				mStatusBarScrim.setCallback(null);
			}
			if (drawable != null) {
				r0_Drawable = drawable.mutate();
			}
			mStatusBarScrim = r0_Drawable;
			if (mStatusBarScrim != null) {
				boolean r0z;
				if (mStatusBarScrim.isStateful()) {
					mStatusBarScrim.setState(getDrawableState());
				}
				DrawableCompat.setLayoutDirection(mStatusBarScrim, ViewCompat.getLayoutDirection(this));
				Drawable r2_Drawable = mStatusBarScrim;
				if (getVisibility() == 0) {
					r0z = true;
				} else {
					r0z = false;
				}
				r2_Drawable.setVisible(r0z, r1z);
				mStatusBarScrim.setCallback(this);
				mStatusBarScrim.setAlpha(mScrimAlpha);
			}
			ViewCompat.postInvalidateOnAnimation(this);
		}
	}

	public void setStatusBarScrimColor(@ColorInt int color) {
		setStatusBarScrim(new ColorDrawable(color));
	}

	public void setStatusBarScrimResource(@DrawableRes int resId) {
		setStatusBarScrim(ContextCompat.getDrawable(getContext(), resId));
	}

	public void setTitle(@Nullable CharSequence title) {
		mCollapsingTextHelper.setText(title);
	}

	public void setTitleEnabled(boolean enabled) {
		if (enabled != mCollapsingTitleEnabled) {
			mCollapsingTitleEnabled = enabled;
			updateDummyView();
			requestLayout();
		}
	}

	public void setVisibility(int visibility) {
		boolean visible;
		super.setVisibility(visibility);
		if (visibility == 0) {
			visible = true;
		} else {
			visible = false;
		}
		if (mStatusBarScrim == null || mStatusBarScrim.isVisible() == visible) {
			if (mContentScrim == null || mContentScrim.isVisible() == visible) {
			} else {
				mContentScrim.setVisible(visible, false);
			}
		} else {
			mStatusBarScrim.setVisible(visible, false);
			if (mContentScrim == null || mContentScrim.isVisible() == visible) {
			} else {
				mContentScrim.setVisible(visible, false);
			}
		}
	}

	final void updateScrimVisibility() {
		if (mContentScrim != null || mStatusBarScrim != null) {
			boolean r0z;
			if (getHeight() + mCurrentOffset < getScrimVisibleHeightTrigger()) {
				r0z = true;
			} else {
				r0z = false;
			}
			setScrimsShown(r0z);
		}
	}

	protected boolean verifyDrawable(Drawable who) {
		if (super.verifyDrawable(who) || who == mContentScrim || who == mStatusBarScrim) {
			return true;
		} else {
			return false;
		}
	}
}
