package android.support.design.widget;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialogFragment;

public class BottomSheetDialogFragment extends AppCompatDialogFragment {
	public BottomSheetDialogFragment() {
		super();
	}

	public Dialog onCreateDialog(Bundle savedInstanceState) {
		return new BottomSheetDialog(getContext(), getTheme());
	}
}
