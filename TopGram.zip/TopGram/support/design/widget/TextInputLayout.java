package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.annotation.StyleRes;
import android.support.annotation.VisibleForTesting;
import android.support.design.R;
import android.support.design.widget.ValueAnimatorCompat.AnimatorUpdateListener;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.widget.Space;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.content.res.AppCompatResources;
import android.support.v7.widget.AppCompatDrawableManager;
import android.support.v7.widget.DrawableUtils;
import android.support.v7.widget.TintTypedArray;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AccelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.rey.material.widget.SnackBar;
import org.telegram.tgnet.TLRPC;

public class TextInputLayout extends LinearLayout {
	private static final int ANIMATION_DURATION = 200;
	private static final int INVALID_MAX_LENGTH = -1;
	private static final String LOG_TAG = "TextInputLayout";
	private ValueAnimatorCompat mAnimator;
	final CollapsingTextHelper mCollapsingTextHelper;
	boolean mCounterEnabled;
	private int mCounterMaxLength;
	private int mCounterOverflowTextAppearance;
	private boolean mCounterOverflowed;
	private int mCounterTextAppearance;
	private TextView mCounterView;
	private ColorStateList mDefaultTextColor;
	EditText mEditText;
	private CharSequence mError;
	private boolean mErrorEnabled;
	private boolean mErrorShown;
	private int mErrorTextAppearance;
	TextView mErrorView;
	private ColorStateList mFocusedTextColor;
	private boolean mHasPasswordToggleTintList;
	private boolean mHasPasswordToggleTintMode;
	private boolean mHasReconstructedEditTextBackground;
	private CharSequence mHint;
	private boolean mHintAnimationEnabled;
	private boolean mHintEnabled;
	private boolean mHintExpanded;
	private boolean mInDrawableStateChanged;
	private LinearLayout mIndicatorArea;
	private int mIndicatorsAdded;
	private final FrameLayout mInputFrame;
	private Drawable mOriginalEditTextEndDrawable;
	private CharSequence mPasswordToggleContentDesc;
	private Drawable mPasswordToggleDrawable;
	private Drawable mPasswordToggleDummyDrawable;
	private boolean mPasswordToggleEnabled;
	private ColorStateList mPasswordToggleTintList;
	private Mode mPasswordToggleTintMode;
	private CheckableImageButton mPasswordToggleView;
	private boolean mPasswordToggledVisible;
	private Paint mTmpPaint;
	private final Rect mTmpRect;

	class AnonymousClass_1 implements TextWatcher {
		final /* synthetic */ TextInputLayout this$0;

		AnonymousClass_1(TextInputLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public void afterTextChanged(Editable s) {
			this$0.updateLabelState(true);
			if (this$0.mCounterEnabled) {
				this$0.updateCounter(s.length());
			}
		}

		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}
	}

	class AnonymousClass_2 extends ViewPropertyAnimatorListenerAdapter {
		final /* synthetic */ TextInputLayout this$0;

		AnonymousClass_2(TextInputLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onAnimationStart(View view) {
			view.setVisibility(0);
		}
	}

	class AnonymousClass_3 extends ViewPropertyAnimatorListenerAdapter {
		final /* synthetic */ TextInputLayout this$0;
		final /* synthetic */ CharSequence val$error;

		AnonymousClass_3(TextInputLayout this$0, CharSequence r2_CharSequence) {
			super();
			this.this$0 = this$0;
			val$error = r2_CharSequence;
		}

		public void onAnimationEnd(View view) {
			this$0.mErrorView.setText(val$error);
			view.setVisibility(TLRPC.USER_FLAG_LAST_NAME);
		}
	}

	class AnonymousClass_4 implements OnClickListener {
		final /* synthetic */ TextInputLayout this$0;

		AnonymousClass_4(TextInputLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onClick(View view) {
			this$0.passwordVisibilityToggleRequested();
		}
	}

	class AnonymousClass_5 implements AnimatorUpdateListener {
		final /* synthetic */ TextInputLayout this$0;

		AnonymousClass_5(TextInputLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onAnimationUpdate(ValueAnimatorCompat animator) {
			this$0.mCollapsingTextHelper.setExpansionFraction(animator.getAnimatedFloatValue());
		}
	}

	static class SavedState extends AbsSavedState {
		public static final Creator<TextInputLayout.SavedState> CREATOR;
		CharSequence error;

		static class AnonymousClass_1 implements ParcelableCompatCreatorCallbacks<TextInputLayout.SavedState> {
			AnonymousClass_1() {
				super();
			}

			public TextInputLayout.SavedState createFromParcel(Parcel in, ClassLoader loader) {
				return new TextInputLayout.SavedState(in, loader);
			}

			public TextInputLayout.SavedState[] newArray(int size) {
				return new TextInputLayout.SavedState[size];
			}
		}


		static {
			CREATOR = ParcelableCompat.newCreator(new AnonymousClass_1());
		}

		public SavedState(Parcel source, ClassLoader loader) {
			super(source, loader);
			error = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(source);
		}

		SavedState(Parcelable superState) {
			super(superState);
		}

		public String toString() {
			return "TextInputLayout.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " error=" + error + "}";
		}

		public void writeToParcel(Parcel dest, int flags) {
			super.writeToParcel(dest, flags);
			TextUtils.writeToParcel(error, dest, flags);
		}
	}

	private class TextInputAccessibilityDelegate extends AccessibilityDelegateCompat {
		final /* synthetic */ TextInputLayout this$0;

		TextInputAccessibilityDelegate(TextInputLayout r1_TextInputLayout) {
			super();
			this$0 = r1_TextInputLayout;
		}

		public void onInitializeAccessibilityEvent(View host, AccessibilityEvent event) {
			super.onInitializeAccessibilityEvent(host, event);
			event.setClassName(TextInputLayout.class.getSimpleName());
		}

		public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfoCompat info) {
			CharSequence error;
			super.onInitializeAccessibilityNodeInfo(host, info);
			info.setClassName(TextInputLayout.class.getSimpleName());
			CharSequence text = this$0.mCollapsingTextHelper.getText();
			if (!TextUtils.isEmpty(text)) {
				info.setText(text);
			}
			if (this$0.mEditText != null) {
				info.setLabelFor(this$0.mEditText);
			}
			if (this$0.mErrorView != null) {
				error = this$0.mErrorView.getText();
			} else {
				error = null;
			}
			if (!TextUtils.isEmpty(error)) {
				info.setContentInvalid(true);
				info.setError(error);
			}
		}

		public void onPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
			super.onPopulateAccessibilityEvent(host, event);
			CharSequence text = this$0.mCollapsingTextHelper.getText();
			if (!TextUtils.isEmpty(text)) {
				event.getText().add(text);
			}
		}
	}


	public TextInputLayout(Context context) {
		this(context, null);
	}

	public TextInputLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public TextInputLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		boolean r4z;
		super(context, attrs);
		mTmpRect = new Rect();
		mCollapsingTextHelper = new CollapsingTextHelper(this);
		ThemeUtils.checkAppCompatTheme(context);
		setOrientation(1);
		setWillNotDraw(false);
		setAddStatesFromChildren(true);
		mInputFrame = new FrameLayout(context);
		mInputFrame.setAddStatesFromChildren(true);
		addView(mInputFrame);
		mCollapsingTextHelper.setTextSizeInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
		mCollapsingTextHelper.setPositionInterpolator(new AccelerateInterpolator());
		mCollapsingTextHelper.setCollapsedTextGravity(8388659);
		if (mCollapsingTextHelper.getExpansionFraction() == 1.0f) {
			r4z = true;
		} else {
			r4z = false;
		}
		mHintExpanded = r4z;
		TintTypedArray a = TintTypedArray.obtainStyledAttributes(context, attrs, R.styleable.TextInputLayout, defStyleAttr, R.style.Widget_Design_TextInputLayout);
		mHintEnabled = a.getBoolean(R.styleable.TextInputLayout_hintEnabled, true);
		setHint(a.getText(R.styleable.TextInputLayout_android_hint));
		mHintAnimationEnabled = a.getBoolean(R.styleable.TextInputLayout_hintAnimationEnabled, true);
		if (a.hasValue(R.styleable.TextInputLayout_android_textColorHint)) {
			ColorStateList r4_ColorStateList = a.getColorStateList(R.styleable.TextInputLayout_android_textColorHint);
			mFocusedTextColor = r4_ColorStateList;
			mDefaultTextColor = r4_ColorStateList;
		}
		if (a.getResourceId(R.styleable.TextInputLayout_hintTextAppearance, INVALID_MAX_LENGTH) != -1) {
			setHintTextAppearance(a.getResourceId(R.styleable.TextInputLayout_hintTextAppearance, 0));
		}
		mErrorTextAppearance = a.getResourceId(R.styleable.TextInputLayout_errorTextAppearance, 0);
		boolean errorEnabled = a.getBoolean(R.styleable.TextInputLayout_errorEnabled, false);
		boolean counterEnabled = a.getBoolean(R.styleable.TextInputLayout_counterEnabled, false);
		setCounterMaxLength(a.getInt(R.styleable.TextInputLayout_counterMaxLength, INVALID_MAX_LENGTH));
		mCounterTextAppearance = a.getResourceId(R.styleable.TextInputLayout_counterTextAppearance, 0);
		mCounterOverflowTextAppearance = a.getResourceId(R.styleable.TextInputLayout_counterOverflowTextAppearance, 0);
		mPasswordToggleEnabled = a.getBoolean(R.styleable.TextInputLayout_passwordToggleEnabled, true);
		mPasswordToggleDrawable = a.getDrawable(R.styleable.TextInputLayout_passwordToggleDrawable);
		mPasswordToggleContentDesc = a.getText(R.styleable.TextInputLayout_passwordToggleContentDescription);
		if (a.hasValue(R.styleable.TextInputLayout_passwordToggleTint)) {
			mHasPasswordToggleTintList = true;
			mPasswordToggleTintList = a.getColorStateList(R.styleable.TextInputLayout_passwordToggleTint);
		}
		if (a.hasValue(R.styleable.TextInputLayout_passwordToggleTintMode)) {
			mHasPasswordToggleTintMode = true;
			mPasswordToggleTintMode = ViewUtils.parseTintMode(a.getInt(R.styleable.TextInputLayout_passwordToggleTintMode, INVALID_MAX_LENGTH), null);
		}
		a.recycle();
		setErrorEnabled(errorEnabled);
		setCounterEnabled(counterEnabled);
		applyPasswordToggleTint();
		if (ViewCompat.getImportantForAccessibility(this) == 0) {
			ViewCompat.setImportantForAccessibility(this, 1);
		}
		ViewCompat.setAccessibilityDelegate(this, new TextInputAccessibilityDelegate(this));
	}

	private void addIndicator(TextView indicator, int index) {
		if (mIndicatorArea == null) {
			mIndicatorArea = new LinearLayout(getContext());
			mIndicatorArea.setOrientation(0);
			addView(mIndicatorArea, INVALID_MAX_LENGTH, SnackBar.WRAP_CONTENT);
			mIndicatorArea.addView(new Space(getContext()), new LayoutParams(0, 0, 1.0f));
			if (mEditText != null) {
				adjustIndicatorPadding();
			}
		}
		mIndicatorArea.setVisibility(0);
		mIndicatorArea.addView(indicator, index);
		mIndicatorsAdded++;
	}

	private void adjustIndicatorPadding() {
		ViewCompat.setPaddingRelative(mIndicatorArea, ViewCompat.getPaddingStart(mEditText), 0, ViewCompat.getPaddingEnd(mEditText), mEditText.getPaddingBottom());
	}

	private void animateToExpansionFraction(float target) {
		if (mCollapsingTextHelper.getExpansionFraction() == target) {
		} else {
			if (mAnimator == null) {
				mAnimator = ViewUtils.createAnimator();
				mAnimator.setInterpolator(AnimationUtils.LINEAR_INTERPOLATOR);
				mAnimator.setDuration(200);
				mAnimator.addUpdateListener(new AnonymousClass_5(this));
			}
			mAnimator.setFloatValues(mCollapsingTextHelper.getExpansionFraction(), target);
			mAnimator.start();
		}
	}

	private void applyPasswordToggleTint() {
		if (mPasswordToggleDrawable != null) {
			if (mHasPasswordToggleTintList || mHasPasswordToggleTintMode) {
				mPasswordToggleDrawable = DrawableCompat.wrap(mPasswordToggleDrawable).mutate();
				if (mHasPasswordToggleTintList) {
					DrawableCompat.setTintList(mPasswordToggleDrawable, mPasswordToggleTintList);
				}
				if (mHasPasswordToggleTintMode) {
					DrawableCompat.setTintMode(mPasswordToggleDrawable, mPasswordToggleTintMode);
				}
				if (mPasswordToggleView == null || mPasswordToggleView.getDrawable() == mPasswordToggleDrawable) {
				} else {
					mPasswordToggleView.setImageDrawable(mPasswordToggleDrawable);
				}
			}
		}
	}

	private static boolean arrayContains(int[] array, int value) {
		int r2i = 0;
		while (r2i < array.length) {
			if (array[r2i] == value) {
				return true;
			} else {
				r2i++;
			}
		}
		return false;
	}

	/* JADX WARNING: inconsistent code */
	/*
	private void collapseHint(boolean r3_animate) {
		r2_this = this;
		r1 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
		r0 = r2.mAnimator;
		if (r0 == 0) goto L_0x0013;
	L_0x0006:
		r0 = r2.mAnimator;
		r0 = r0.isRunning();
		if (r0 == 0) goto L_0x0013;
	L_0x000e:
		r0 = r2.mAnimator;
		r0.cancel();
	L_0x0013:
		if (r3_animate == 0) goto L_0x0020;
	L_0x0015:
		r0 = r2.mHintAnimationEnabled;
		if (r0 == 0) goto L_0x0020;
	L_0x0019:
		r2.animateToExpansionFraction(r1);
	L_0x001c:
		r0 = 0;
		r2.mHintExpanded = r0;
		return;
	L_0x0020:
		r0 = r2.mCollapsingTextHelper;
		r0.setExpansionFraction(r1);
		goto L_0x001c;
	}
	*/
	private void collapseHint(boolean animate) {
		if (mAnimator == null || !mAnimator.isRunning()) {
			mCollapsingTextHelper.setExpansionFraction(1.0f);
			mHintExpanded = false;
		} else {
			mAnimator.cancel();
			mCollapsingTextHelper.setExpansionFraction(1.0f);
			mHintExpanded = false;
		}
	}

	private void ensureBackgroundDrawableStateWorkaround() {
		int sdk = VERSION.SDK_INT;
		if (sdk == 21 || sdk == 22) {
			Drawable bg = mEditText.getBackground();
			if (bg == null || mHasReconstructedEditTextBackground) {
			} else {
				Drawable newBg = bg.getConstantState().newDrawable();
				if (bg instanceof DrawableContainer) {
					mHasReconstructedEditTextBackground = DrawableUtils.setContainerConstantState((DrawableContainer) bg, newBg.getConstantState());
				}
				if (!mHasReconstructedEditTextBackground) {
					mEditText.setBackgroundDrawable(newBg);
					mHasReconstructedEditTextBackground = true;
				}
			}
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	private void expandHint(boolean r3_animate) {
		r2_this = this;
		r1 = 0;
		r0 = r2.mAnimator;
		if (r0 == 0) goto L_0x0012;
	L_0x0005:
		r0 = r2.mAnimator;
		r0 = r0.isRunning();
		if (r0 == 0) goto L_0x0012;
	L_0x000d:
		r0 = r2.mAnimator;
		r0.cancel();
	L_0x0012:
		if (r3_animate == 0) goto L_0x001f;
	L_0x0014:
		r0 = r2.mHintAnimationEnabled;
		if (r0 == 0) goto L_0x001f;
	L_0x0018:
		r2.animateToExpansionFraction(r1);
	L_0x001b:
		r0 = 1;
		r2.mHintExpanded = r0;
		return;
	L_0x001f:
		r0 = r2.mCollapsingTextHelper;
		r0.setExpansionFraction(r1);
		goto L_0x001b;
	}
	*/
	private void expandHint(boolean animate) {
		if (mAnimator == null || !mAnimator.isRunning()) {
			mCollapsingTextHelper.setExpansionFraction(BitmapDescriptorFactory.HUE_RED);
			mHintExpanded = true;
		} else {
			mAnimator.cancel();
			mCollapsingTextHelper.setExpansionFraction(BitmapDescriptorFactory.HUE_RED);
			mHintExpanded = true;
		}
	}

	private boolean hasPasswordTransformation() {
		if (mEditText == null || !(mEditText.getTransformationMethod() instanceof PasswordTransformationMethod)) {
			return false;
		} else {
			return true;
		}
	}

	private static void recursiveSetEnabled(ViewGroup vg, boolean enabled) {
		int i = 0;
		while (i < vg.getChildCount()) {
			View child = vg.getChildAt(i);
			child.setEnabled(enabled);
			if (child instanceof ViewGroup) {
				recursiveSetEnabled((ViewGroup) child, enabled);
			}
			i++;
		}
	}

	private void removeIndicator(TextView indicator) {
		if (mIndicatorArea != null) {
			mIndicatorArea.removeView(indicator);
			int r0i = mIndicatorsAdded - 1;
			mIndicatorsAdded = r0i;
			if (r0i == 0) {
				mIndicatorArea.setVisibility(TLRPC.USER_FLAG_USERNAME);
			}
		}
	}

	private void setEditText(EditText editText) {
		if (mEditText != null) {
			throw new IllegalArgumentException("We already have an EditText, can only have one");
		} else {
			if (!(editText instanceof TextInputEditText)) {
				Log.i(LOG_TAG, "EditText added is not a TextInputEditText. Please switch to using that class instead.");
			}
			mEditText = editText;
			if (!hasPasswordTransformation()) {
				mCollapsingTextHelper.setTypefaces(mEditText.getTypeface());
			}
			mCollapsingTextHelper.setExpandedTextSize(mEditText.getTextSize());
			int editTextGravity = mEditText.getGravity();
			mCollapsingTextHelper.setCollapsedTextGravity((8388615 & editTextGravity) | 48);
			mCollapsingTextHelper.setExpandedTextGravity(editTextGravity);
			mEditText.addTextChangedListener(new AnonymousClass_1(this));
			if (mDefaultTextColor == null) {
				mDefaultTextColor = mEditText.getHintTextColors();
			}
			if (!mHintEnabled || !TextUtils.isEmpty(mHint)) {
				if (mCounterView == null) {
					updateCounter(mEditText.getText().length());
				}
				if (mIndicatorArea != null) {
					adjustIndicatorPadding();
				}
				updatePasswordToggleView();
				updateLabelState(false);
			} else {
				setHint(mEditText.getHint());
				mEditText.setHint(null);
				if (mCounterView == null) {
					if (mIndicatorArea != null) {
						updatePasswordToggleView();
						updateLabelState(false);
					} else {
						adjustIndicatorPadding();
						updatePasswordToggleView();
						updateLabelState(false);
					}
				} else {
					updateCounter(mEditText.getText().length());
					if (mIndicatorArea != null) {
						adjustIndicatorPadding();
					}
					updatePasswordToggleView();
					updateLabelState(false);
				}
			}
		}
	}

	private void setError(@Nullable CharSequence error, boolean animate) {
		boolean r0z = true;
		mError = error;
		if (!mErrorEnabled) {
			if (TextUtils.isEmpty(error)) {
			} else {
				setErrorEnabled(true);
			}
		}
		if (!TextUtils.isEmpty(error)) {
			mErrorShown = r0z;
			ViewCompat.animate(mErrorView).cancel();
			if (!mErrorShown) {
				mErrorView.setText(error);
				mErrorView.setVisibility(0);
				if (!animate) {
					if (ViewCompat.getAlpha(mErrorView) != 1.0f) {
						ViewCompat.setAlpha(mErrorView, BitmapDescriptorFactory.HUE_RED);
					}
					ViewCompat.animate(mErrorView).alpha(1.0f).setDuration(200).setInterpolator(AnimationUtils.LINEAR_OUT_SLOW_IN_INTERPOLATOR).setListener(new AnonymousClass_2(this)).start();
				} else {
					ViewCompat.setAlpha(mErrorView, 1.0f);
				}
			} else if (mErrorView.getVisibility() != 0) {
				if (!animate) {
					ViewCompat.animate(mErrorView).alpha(BitmapDescriptorFactory.HUE_RED).setDuration(200).setInterpolator(AnimationUtils.FAST_OUT_LINEAR_IN_INTERPOLATOR).setListener(new AnonymousClass_3(this, error)).start();
				} else {
					mErrorView.setText(error);
					mErrorView.setVisibility(TLRPC.USER_FLAG_LAST_NAME);
				}
			}
			updateEditTextBackground();
			updateLabelState(animate);
		} else {
			r0z = false;
			mErrorShown = r0z;
			ViewCompat.animate(mErrorView).cancel();
			if (!mErrorShown) {
				if (mErrorView.getVisibility() != 0) {
					updateEditTextBackground();
					updateLabelState(animate);
				} else if (!animate) {
					mErrorView.setText(error);
					mErrorView.setVisibility(TLRPC.USER_FLAG_LAST_NAME);
				} else {
					ViewCompat.animate(mErrorView).alpha(BitmapDescriptorFactory.HUE_RED).setDuration(200).setInterpolator(AnimationUtils.FAST_OUT_LINEAR_IN_INTERPOLATOR).setListener(new AnonymousClass_3(this, error)).start();
				}
			} else {
				mErrorView.setText(error);
				mErrorView.setVisibility(0);
				if (!animate) {
					ViewCompat.setAlpha(mErrorView, 1.0f);
				} else if (ViewCompat.getAlpha(mErrorView) != 1.0f) {
					ViewCompat.animate(mErrorView).alpha(1.0f).setDuration(200).setInterpolator(AnimationUtils.LINEAR_OUT_SLOW_IN_INTERPOLATOR).setListener(new AnonymousClass_2(this)).start();
				} else {
					ViewCompat.setAlpha(mErrorView, BitmapDescriptorFactory.HUE_RED);
					ViewCompat.animate(mErrorView).alpha(1.0f).setDuration(200).setInterpolator(AnimationUtils.LINEAR_OUT_SLOW_IN_INTERPOLATOR).setListener(new AnonymousClass_2(this)).start();
				}
			}
			updateEditTextBackground();
			updateLabelState(animate);
		}
	}

	private void setHintInternal(CharSequence hint) {
		mHint = hint;
		mCollapsingTextHelper.setText(hint);
	}

	private boolean shouldShowPasswordIcon() {
		if (mPasswordToggleEnabled) {
			if (hasPasswordTransformation() || mPasswordToggledVisible) {
				return true;
			}
		}
		return false;
	}

	private void updateEditTextBackground() {
		if (mEditText == null) {
		} else {
			Drawable editTextBackground = mEditText.getBackground();
			if (editTextBackground != null) {
				ensureBackgroundDrawableStateWorkaround();
				if (DrawableUtils.canSafelyMutateDrawable(editTextBackground)) {
					editTextBackground = editTextBackground.mutate();
				}
				if (!mErrorShown || mErrorView == null) {
					if (!mCounterOverflowed || mCounterView == null) {
						DrawableCompat.clearColorFilter(editTextBackground);
						mEditText.refreshDrawableState();
					} else {
						editTextBackground.setColorFilter(AppCompatDrawableManager.getPorterDuffColorFilter(mCounterView.getCurrentTextColor(), Mode.SRC_IN));
					}
				} else {
					editTextBackground.setColorFilter(AppCompatDrawableManager.getPorterDuffColorFilter(mErrorView.getCurrentTextColor(), Mode.SRC_IN));
				}
			}
		}
	}

	private void updateInputLayoutMargins() {
		int newTopMargin;
		LayoutParams lp = (LayoutParams) mInputFrame.getLayoutParams();
		if (mHintEnabled) {
			if (mTmpPaint == null) {
				mTmpPaint = new Paint();
			}
			mTmpPaint.setTypeface(mCollapsingTextHelper.getCollapsedTypeface());
			mTmpPaint.setTextSize(mCollapsingTextHelper.getCollapsedTextSize());
			newTopMargin = (int) (-mTmpPaint.ascent());
		} else {
			newTopMargin = 0;
		}
		if (newTopMargin != lp.topMargin) {
			lp.topMargin = newTopMargin;
			mInputFrame.requestLayout();
		}
	}

	private void updatePasswordToggleView() {
		int r5i = 1;
		boolean r4z = false;
		if (mEditText == null) {
		} else if (shouldShowPasswordIcon()) {
			if (mPasswordToggleView == null) {
				mPasswordToggleView = (CheckableImageButton) LayoutInflater.from(getContext()).inflate(R.layout.design_text_input_password_icon, mInputFrame, false);
				mPasswordToggleView.setImageDrawable(mPasswordToggleDrawable);
				mPasswordToggleView.setContentDescription(mPasswordToggleContentDesc);
				mInputFrame.addView(mPasswordToggleView);
				mPasswordToggleView.setOnClickListener(new AnonymousClass_4(this));
			}
			mPasswordToggleView.setVisibility(0);
			if (mPasswordToggleDummyDrawable == null) {
				mPasswordToggleDummyDrawable = new ColorDrawable();
			}
			mPasswordToggleDummyDrawable.setBounds(0, 0, mPasswordToggleView.getMeasuredWidth(), 1);
			compounds = TextViewCompat.getCompoundDrawablesRelative(mEditText);
			if (compounds[2] != mPasswordToggleDummyDrawable) {
				mOriginalEditTextEndDrawable = compounds[2];
			}
			TextViewCompat.setCompoundDrawablesRelative(mEditText, compounds[r4z], compounds[r5i], mPasswordToggleDummyDrawable, compounds[3]);
			mPasswordToggleView.setPadding(mEditText.getPaddingLeft(), mEditText.getPaddingTop(), mEditText.getPaddingRight(), mEditText.getPaddingBottom());
		} else if (mPasswordToggleView == null || mPasswordToggleView.getVisibility() != 0) {
			compounds = TextViewCompat.getCompoundDrawablesRelative(mEditText);
			if (compounds[2] != mPasswordToggleDummyDrawable) {
				TextViewCompat.setCompoundDrawablesRelative(mEditText, compounds[r4z], compounds[r5i], mOriginalEditTextEndDrawable, compounds[3]);
			}
		} else {
			mPasswordToggleView.setVisibility(TLRPC.USER_FLAG_USERNAME);
			compounds = TextViewCompat.getCompoundDrawablesRelative(mEditText);
			if (compounds[2] != mPasswordToggleDummyDrawable) {
			} else {
				TextViewCompat.setCompoundDrawablesRelative(mEditText, compounds[r4z], compounds[r5i], mOriginalEditTextEndDrawable, compounds[3]);
			}
		}
	}

	public void addView(View child, int index, android.view.ViewGroup.LayoutParams params) {
		if (child instanceof EditText) {
			mInputFrame.addView(child, new android.widget.FrameLayout.LayoutParams(params));
			mInputFrame.setLayoutParams(params);
			updateInputLayoutMargins();
			setEditText((EditText) child);
		} else {
			super.addView(child, index, params);
		}
	}

	public void draw(Canvas canvas) {
		super.draw(canvas);
		if (mHintEnabled) {
			mCollapsingTextHelper.draw(canvas);
		}
	}

	protected void drawableStateChanged() {
		boolean r2z = true;
		if (mInDrawableStateChanged) {
		} else {
			mInDrawableStateChanged = true;
			super.drawableStateChanged();
			int[] state = getDrawableState();
			boolean changed = false;
			if (!ViewCompat.isLaidOut(this) || !isEnabled()) {
				r2z = false;
			} else {
				updateLabelState(r2z);
				updateEditTextBackground();
			}
			updateLabelState(r2z);
			updateEditTextBackground();
			if (mCollapsingTextHelper != null) {
				changed |= mCollapsingTextHelper.setState(state);
			}
			if (changed) {
				invalidate();
			}
			mInDrawableStateChanged = false;
		}
	}

	public int getCounterMaxLength() {
		return mCounterMaxLength;
	}

	@Nullable
	public EditText getEditText() {
		return mEditText;
	}

	@Nullable
	public CharSequence getError() {
		if (mErrorEnabled) {
			return mError;
		} else {
			return null;
		}
	}

	@Nullable
	public CharSequence getHint() {
		if (mHintEnabled) {
			return mHint;
		} else {
			return null;
		}
	}

	@Nullable
	public CharSequence getPasswordVisibilityToggleContentDescription() {
		return mPasswordToggleContentDesc;
	}

	@Nullable
	public Drawable getPasswordVisibilityToggleDrawable() {
		return mPasswordToggleDrawable;
	}

	@NonNull
	public Typeface getTypeface() {
		return mCollapsingTextHelper.getCollapsedTypeface();
	}

	public boolean isCounterEnabled() {
		return mCounterEnabled;
	}

	public boolean isErrorEnabled() {
		return mErrorEnabled;
	}

	public boolean isHintAnimationEnabled() {
		return mHintAnimationEnabled;
	}

	public boolean isHintEnabled() {
		return mHintEnabled;
	}

	@VisibleForTesting
	final boolean isHintExpanded() {
		return mHintExpanded;
	}

	public boolean isPasswordVisibilityToggleEnabled() {
		return mPasswordToggleEnabled;
	}

	protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
		super.onLayout(changed, left, top, right, bottom);
		if (!mHintEnabled || mEditText == null) {
		} else {
			Rect rect = mTmpRect;
			ViewGroupUtils.getDescendantRect(this, mEditText, rect);
			int l = rect.left + mEditText.getCompoundPaddingLeft();
			int r = rect.right - mEditText.getCompoundPaddingRight();
			mCollapsingTextHelper.setExpandedBounds(l, rect.top + mEditText.getCompoundPaddingTop(), r, rect.bottom - mEditText.getCompoundPaddingBottom());
			mCollapsingTextHelper.setCollapsedBounds(l, getPaddingTop(), r, (bottom - top) - getPaddingBottom());
			mCollapsingTextHelper.recalculate();
		}
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		updatePasswordToggleView();
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}

	protected void onRestoreInstanceState(Parcelable state) {
		if (!(state instanceof SavedState)) {
			super.onRestoreInstanceState(state);
		} else {
			SavedState ss = (SavedState) state;
			super.onRestoreInstanceState(ss.getSuperState());
			setError(ss.error);
			requestLayout();
		}
	}

	public Parcelable onSaveInstanceState() {
		SavedState ss = new SavedState(super.onSaveInstanceState());
		if (mErrorShown) {
			ss.error = getError();
		}
		return ss;
	}

	void passwordVisibilityToggleRequested() {
		if (mPasswordToggleEnabled) {
			int selection = mEditText.getSelectionEnd();
			if (hasPasswordTransformation()) {
				mEditText.setTransformationMethod(null);
				mPasswordToggledVisible = true;
			} else {
				mEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
				mPasswordToggledVisible = false;
			}
			mPasswordToggleView.setChecked(mPasswordToggledVisible);
			mEditText.setSelection(selection);
		}
	}

	public void setCounterEnabled(boolean enabled) {
		if (mCounterEnabled != enabled) {
			if (enabled) {
				mCounterView = new TextView(getContext());
				mCounterView.setMaxLines(1);
				try {
					mCounterView.setTextAppearance(getContext(), mCounterTextAppearance);
				} catch (Exception e) {
					mCounterView.setTextAppearance(getContext(), android.support.v7.appcompat.R.style.TextAppearance_AppCompat_Caption);
					mCounterView.setTextColor(ContextCompat.getColor(getContext(), R.color.design_textinput_error_color_light));
				}
				addIndicator(mCounterView, INVALID_MAX_LENGTH);
				if (mEditText == null) {
					updateCounter(0);
				} else {
					updateCounter(mEditText.getText().length());
				}
			} else {
				removeIndicator(mCounterView);
				mCounterView = null;
			}
			mCounterEnabled = enabled;
		}
	}

	public void setCounterMaxLength(int maxLength) {
		if (mCounterMaxLength != maxLength) {
			if (maxLength > 0) {
				mCounterMaxLength = maxLength;
			} else {
				mCounterMaxLength = -1;
			}
			if (mCounterEnabled) {
				int r0i;
				if (mEditText == null) {
					r0i = 0;
				} else {
					r0i = mEditText.getText().length();
				}
				updateCounter(r0i);
			}
		}
	}

	public void setEnabled(boolean enabled) {
		recursiveSetEnabled(this, enabled);
		super.setEnabled(enabled);
	}

	public void setError(@Nullable CharSequence error) {
		boolean r0z;
		if (!ViewCompat.isLaidOut(this) || !isEnabled()) {
			r0z = false;
		} else if (mErrorView == null || !TextUtils.equals(mErrorView.getText(), error)) {
			r0z = true;
		} else {
			r0z = false;
		}
		setError(error, r0z);
	}

	/* JADX WARNING: inconsistent code */
	/*
	public void setErrorEnabled(boolean r7_enabled) {
		r6_this = this;
		r5 = 0;
		r2 = r6.mErrorEnabled;
		if (r2 == r7_enabled) goto L_0x0070;
	L_0x0005:
		r2 = r6.mErrorView;
		if (r2 == 0) goto L_0x0012;
	L_0x0009:
		r2 = r6.mErrorView;
		r2 = android.support.v4.view.ViewCompat.animate(r2);
		r2.cancel();
	L_0x0012:
		if (r7_enabled == 0) goto L_0x0074;
	L_0x0014:
		r2 = new android.widget.TextView;
		r3 = r6.getContext();
		r2.<init>(r3);
		r6.mErrorView = r2;
		r1 = 0;
		r2 = r6.mErrorView;	 //Catch:{ Exception -> 0x0071 }
		r3 = r6.getContext();	 //Catch:{ Exception -> 0x0071 }
		r4 = r6.mErrorTextAppearance;	 //Catch:{ Exception -> 0x0071 }
		r2.setTextAppearance(r3, r4);	 //Catch:{ Exception -> 0x0071 }
		r2 = android.os.Build.VERSION.SDK_INT;	 //Catch:{ Exception -> 0x0071 }
		r3 = 23;
		if (r2 < r3) goto L_0x0041;
	L_0x0031:
		r2 = r6.mErrorView;	 //Catch:{ Exception -> 0x0071 }
		r2 = r2.getTextColors();	 //Catch:{ Exception -> 0x0071 }
		r2 = r2.getDefaultColor();	 //Catch:{ Exception -> 0x0071 }
		r3 = -65281; // 0xffffffffffff00ff float:NaN double:NaN;
		if (r2 != r3) goto L_0x0041;
	L_0x0040:
		r1_useDefaultColor = 1;
	L_0x0041:
		if (r1_useDefaultColor == 0) goto L_0x005d;
	L_0x0043:
		r2 = r6.mErrorView;
		r3 = r6.getContext();
		r4 = android.support.v7.appcompat.R.style.TextAppearance_AppCompat_Caption;
		r2.setTextAppearance(r3, r4);
		r2 = r6.mErrorView;
		r3 = r6.getContext();
		r4 = android.support.design.R.color.design_textinput_error_color_light;
		r3 = android.support.v4.content.ContextCompat.getColor(r3, r4);
		r2.setTextColor(r3);
	L_0x005d:
		r2 = r6.mErrorView;
		r3 = 4;
		r2.setVisibility(r3);
		r2 = r6.mErrorView;
		r3 = 1;
		android.support.v4.view.ViewCompat.setAccessibilityLiveRegion(r2, r3);
		r2 = r6.mErrorView;
		r6.addIndicator(r2, r5);
	L_0x006e:
		r6.mErrorEnabled = r7_enabled;
	L_0x0070:
		return;
	L_0x0071:
		r0_e = move-exception;
		r1_useDefaultColor = 1;
		goto L_0x0041;
	L_0x0074:
		r6.mErrorShown = r5;
		r6.updateEditTextBackground();
		r2 = r6.mErrorView;
		r6.removeIndicator(r2);
		r2 = 0;
		r6.mErrorView = r2;
		goto L_0x006e;
	}
	*/
	public void setErrorEnabled(boolean enabled) {
		if (mErrorEnabled != enabled) {
			if (mErrorView != null) {
				ViewCompat.animate(mErrorView).cancel();
			}
			if (enabled) {
				mErrorView = new TextView(getContext());
				boolean useDefaultColor = false;
				try {
					mErrorView.setTextAppearance(getContext(), mErrorTextAppearance);
					if (VERSION.SDK_INT < com.rey.material.R.styleable.View_android_paddingStart || mErrorView.getTextColors().getDefaultColor() != -65281) {
						mErrorView.setVisibility(TLRPC.USER_FLAG_LAST_NAME);
						ViewCompat.setAccessibilityLiveRegion(mErrorView, 1);
						addIndicator(mErrorView, 0);
					} else {
						useDefaultColor = true;
						mErrorView.setVisibility(TLRPC.USER_FLAG_LAST_NAME);
						ViewCompat.setAccessibilityLiveRegion(mErrorView, 1);
						addIndicator(mErrorView, 0);
					}
				} catch (Exception e) {
					useDefaultColor = true;
				}
			} else {
				mErrorShown = false;
				updateEditTextBackground();
				removeIndicator(mErrorView);
				mErrorView = null;
			}
			mErrorEnabled = enabled;
		}
	}

	public void setHint(@Nullable CharSequence hint) {
		if (mHintEnabled) {
			setHintInternal(hint);
			sendAccessibilityEvent(TLRPC.MESSAGE_FLAG_HAS_BOT_ID);
		}
	}

	public void setHintAnimationEnabled(boolean enabled) {
		mHintAnimationEnabled = enabled;
	}

	public void setHintEnabled(boolean enabled) {
		if (enabled != mHintEnabled) {
			mHintEnabled = enabled;
			CharSequence editTextHint = mEditText.getHint();
			if (!mHintEnabled) {
				if (TextUtils.isEmpty(mHint) || !TextUtils.isEmpty(editTextHint)) {
					setHintInternal(null);
				} else {
					mEditText.setHint(mHint);
					setHintInternal(null);
				}
			} else if (!TextUtils.isEmpty(editTextHint)) {
				if (TextUtils.isEmpty(mHint)) {
					setHint(editTextHint);
				}
				mEditText.setHint(null);
			}
			if (mEditText != null) {
				updateInputLayoutMargins();
			}
		}
	}

	public void setHintTextAppearance(@StyleRes int resId) {
		mCollapsingTextHelper.setCollapsedTextAppearance(resId);
		mFocusedTextColor = mCollapsingTextHelper.getCollapsedTextColor();
		if (mEditText != null) {
			updateLabelState(false);
			updateInputLayoutMargins();
		}
	}

	public void setPasswordVisibilityToggleContentDescription(@StringRes int resId) {
		CharSequence r0_CharSequence;
		if (resId != 0) {
			r0_CharSequence = getResources().getText(resId);
		} else {
			r0_CharSequence = null;
		}
		setPasswordVisibilityToggleContentDescription(r0_CharSequence);
	}

	public void setPasswordVisibilityToggleContentDescription(@Nullable CharSequence description) {
		mPasswordToggleContentDesc = description;
		if (mPasswordToggleView != null) {
			mPasswordToggleView.setContentDescription(description);
		}
	}

	public void setPasswordVisibilityToggleDrawable(@DrawableRes int resId) {
		Drawable r0_Drawable;
		if (resId != 0) {
			r0_Drawable = AppCompatResources.getDrawable(getContext(), resId);
		} else {
			r0_Drawable = null;
		}
		setPasswordVisibilityToggleDrawable(r0_Drawable);
	}

	public void setPasswordVisibilityToggleDrawable(@Nullable Drawable icon) {
		mPasswordToggleDrawable = icon;
		if (mPasswordToggleView != null) {
			mPasswordToggleView.setImageDrawable(icon);
		}
	}

	public void setPasswordVisibilityToggleEnabled(boolean enabled) {
		if (mPasswordToggleEnabled != enabled) {
			mPasswordToggleEnabled = enabled;
			if (enabled || !mPasswordToggledVisible || mEditText == null) {
				mPasswordToggledVisible = false;
				updatePasswordToggleView();
			} else {
				mEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
				mPasswordToggledVisible = false;
				updatePasswordToggleView();
			}
		}
	}

	public void setPasswordVisibilityToggleTintList(@Nullable ColorStateList tintList) {
		mPasswordToggleTintList = tintList;
		mHasPasswordToggleTintList = true;
		applyPasswordToggleTint();
	}

	public void setPasswordVisibilityToggleTintMode(@Nullable Mode mode) {
		mPasswordToggleTintMode = mode;
		mHasPasswordToggleTintMode = true;
		applyPasswordToggleTint();
	}

	public void setTypeface(@Nullable Typeface typeface) {
		mCollapsingTextHelper.setTypefaces(typeface);
	}

	void updateCounter(int length) {
		int r2i = 1;
		boolean wasCounterOverflowed = mCounterOverflowed;
		if (mCounterMaxLength == -1) {
			mCounterView.setText(String.valueOf(length));
			mCounterOverflowed = false;
		} else {
			boolean r1z;
			if (length > mCounterMaxLength) {
				r1z = true;
			} else {
				r1z = false;
			}
			mCounterOverflowed = r1z;
			if (wasCounterOverflowed != mCounterOverflowed) {
				int r1i;
				TextView r4_TextView = mCounterView;
				Context r5_Context = getContext();
				if (mCounterOverflowed) {
					r1i = mCounterOverflowTextAppearance;
				} else {
					r1i = mCounterTextAppearance;
				}
				r4_TextView.setTextAppearance(r5_Context, r1i);
			}
			Object[] r6_Object_A = new Object[2];
			r6_Object_A[0] = Integer.valueOf(length);
			r6_Object_A[r2i] = Integer.valueOf(mCounterMaxLength);
			mCounterView.setText(getContext().getString(R.string.character_counter_pattern, r6_Object_A));
		}
		if (mEditText == null || wasCounterOverflowed == mCounterOverflowed) {
		} else {
			updateLabelState(false);
			updateEditTextBackground();
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	void updateLabelState(boolean r9_animate) {
		r8_this = this;
		r4 = 1;
		r5 = 0;
		r1 = r8.isEnabled();
		r6 = r8.mEditText;
		if (r6 == 0) goto L_0x005d;
	L_0x000a:
		r6 = r8.mEditText;
		r6 = r6.getText();
		r6 = android.text.TextUtils.isEmpty(r6);
		if (r6 != 0) goto L_0x005d;
	L_0x0016:
		r0 = r4;
	L_0x0017:
		r6 = r8.getDrawableState();
		r7 = 16842908; // 0x101009c float:2.3693995E-38 double:8.321502E-317;
		r3 = arrayContains(r6, r7);
		r6 = r8.getError();
		r6 = android.text.TextUtils.isEmpty(r6);
		if (r6 != 0) goto L_0x005f;
	L_0x002c:
		r2 = r4;
	L_0x002d:
		r4 = r8.mDefaultTextColor;
		if (r4 == 0) goto L_0x0038;
	L_0x0031:
		r4 = r8.mCollapsingTextHelper;
		r5 = r8.mDefaultTextColor;
		r4.setExpandedTextColor(r5);
	L_0x0038:
		if (r1_isEnabled == 0) goto L_0x0061;
	L_0x003a:
		r4 = r8.mCounterOverflowed;
		if (r4 == 0) goto L_0x0061;
	L_0x003e:
		r4 = r8.mCounterView;
		if (r4 == 0) goto L_0x0061;
	L_0x0042:
		r4 = r8.mCollapsingTextHelper;
		r5 = r8.mCounterView;
		r5 = r5.getTextColors();
		r4.setCollapsedTextColor(r5);
	L_0x004d:
		if (r0_hasText != 0) goto L_0x0059;
	L_0x004f:
		r4 = r8.isEnabled();
		if (r4 == 0) goto L_0x007d;
	L_0x0055:
		if (r3_isFocused != 0) goto L_0x0059;
	L_0x0057:
		if (r2_isErrorShowing == 0) goto L_0x007d;
	L_0x0059:
		r8.collapseHint(r9_animate);
	L_0x005c:
		return;
	L_0x005d:
		r0_hasText = r5;
		goto L_0x0017;
	L_0x005f:
		r2_isErrorShowing = r5;
		goto L_0x002d;
	L_0x0061:
		if (r1_isEnabled == 0) goto L_0x0071;
	L_0x0063:
		if (r3_isFocused == 0) goto L_0x0071;
	L_0x0065:
		r4 = r8.mFocusedTextColor;
		if (r4 == 0) goto L_0x0071;
	L_0x0069:
		r4 = r8.mCollapsingTextHelper;
		r5 = r8.mFocusedTextColor;
		r4.setCollapsedTextColor(r5);
		goto L_0x004d;
	L_0x0071:
		r4 = r8.mDefaultTextColor;
		if (r4 == 0) goto L_0x004d;
	L_0x0075:
		r4 = r8.mCollapsingTextHelper;
		r5 = r8.mDefaultTextColor;
		r4.setCollapsedTextColor(r5);
		goto L_0x004d;
	L_0x007d:
		r8.expandHint(r9_animate);
		goto L_0x005c;
	}
	*/
	void updateLabelState(boolean animate) {
		boolean hasText;
		boolean isEnabled = isEnabled();
		if (mEditText == null || TextUtils.isEmpty(mEditText.getText())) {
			hasText = false;
		} else {
			hasText = true;
		}
		boolean isFocused = arrayContains(getDrawableState(), 16842908);
		if (!TextUtils.isEmpty(getError())) {
			isErrorShowing = true;
		} else {
			isErrorShowing = false;
		}
		if (mDefaultTextColor != null) {
			mCollapsingTextHelper.setExpandedTextColor(mDefaultTextColor);
		}
		if (!isEnabled || !mCounterOverflowed || mCounterView == null) {
			if (mDefaultTextColor != null) {
				mCollapsingTextHelper.setCollapsedTextColor(mDefaultTextColor);
			}
		} else {
			mCollapsingTextHelper.setCollapsedTextColor(mCounterView.getTextColors());
		}
		if (!hasText) {
			if (isEnabled()) {
				if (isFocused || isErrorShowing) {
					collapseHint(animate);
				}
			}
			expandHint(animate);
		}
		collapseHint(animate);
	}
}
