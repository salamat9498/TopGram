package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.support.design.widget.ValueAnimatorCompat.Impl;
import android.support.design.widget.ValueAnimatorCompat.Impl.AnimatorListenerProxy;
import android.support.design.widget.ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy;
import android.view.animation.Interpolator;

class ValueAnimatorCompatImplHoneycombMr1 extends Impl {
	private final ValueAnimator mValueAnimator;

	class AnonymousClass_1 implements AnimatorUpdateListener {
		final /* synthetic */ ValueAnimatorCompatImplHoneycombMr1 this$0;
		final /* synthetic */ AnimatorUpdateListenerProxy val$updateListener;

		AnonymousClass_1(ValueAnimatorCompatImplHoneycombMr1 this$0, AnimatorUpdateListenerProxy r2_AnimatorUpdateListenerProxy) {
			super();
			this.this$0 = this$0;
			val$updateListener = r2_AnimatorUpdateListenerProxy;
		}

		public void onAnimationUpdate(ValueAnimator valueAnimator) {
			val$updateListener.onAnimationUpdate();
		}
	}

	class AnonymousClass_2 extends AnimatorListenerAdapter {
		final /* synthetic */ ValueAnimatorCompatImplHoneycombMr1 this$0;
		final /* synthetic */ AnimatorListenerProxy val$listener;

		AnonymousClass_2(ValueAnimatorCompatImplHoneycombMr1 this$0, AnimatorListenerProxy r2_AnimatorListenerProxy) {
			super();
			this.this$0 = this$0;
			val$listener = r2_AnimatorListenerProxy;
		}

		public void onAnimationCancel(Animator animator) {
			val$listener.onAnimationCancel();
		}

		public void onAnimationEnd(Animator animator) {
			val$listener.onAnimationEnd();
		}

		public void onAnimationStart(Animator animator) {
			val$listener.onAnimationStart();
		}
	}


	ValueAnimatorCompatImplHoneycombMr1() {
		super();
		mValueAnimator = new ValueAnimator();
	}

	public void addListener(AnimatorListenerProxy listener) {
		mValueAnimator.addListener(new AnonymousClass_2(this, listener));
	}

	public void addUpdateListener(AnimatorUpdateListenerProxy updateListener) {
		mValueAnimator.addUpdateListener(new AnonymousClass_1(this, updateListener));
	}

	public void cancel() {
		mValueAnimator.cancel();
	}

	public void end() {
		mValueAnimator.end();
	}

	public float getAnimatedFloatValue() {
		return ((Float) mValueAnimator.getAnimatedValue()).floatValue();
	}

	public float getAnimatedFraction() {
		return mValueAnimator.getAnimatedFraction();
	}

	public int getAnimatedIntValue() {
		return ((Integer) mValueAnimator.getAnimatedValue()).intValue();
	}

	public long getDuration() {
		return mValueAnimator.getDuration();
	}

	public boolean isRunning() {
		return mValueAnimator.isRunning();
	}

	public void setDuration(long duration) {
		mValueAnimator.setDuration(duration);
	}

	public void setFloatValues(float from, float to) {
		float[] r1_float_A = new float[2];
		r1_float_A[0] = from;
		r1_float_A[1] = to;
		mValueAnimator.setFloatValues(r1_float_A);
	}

	public void setIntValues(int from, int to) {
		int[] r1_int_A = new int[2];
		r1_int_A[0] = from;
		r1_int_A[1] = to;
		mValueAnimator.setIntValues(r1_int_A);
	}

	public void setInterpolator(Interpolator interpolator) {
		mValueAnimator.setInterpolator(interpolator);
	}

	public void start() {
		mValueAnimator.start();
	}
}
