package android.support.design.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region.Op;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.FloatRange;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;
import android.support.design.R;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.NestedScrollingParent;
import android.support.v4.view.NestedScrollingParentHelper;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewGroup.OnHierarchyChangeListener;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import com.wdullaer.materialdatetimepicker.Utils;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.telegram.SQLite.SQLiteCursor;
import org.telegram.tgnet.ConnectionsManager;
import org.telegram.tgnet.TLRPC;

public class CoordinatorLayout extends ViewGroup implements NestedScrollingParent {
	static final Class<?>[] CONSTRUCTOR_PARAMS;
	static final int EVENT_NESTED_SCROLL = 1;
	static final int EVENT_PRE_DRAW = 0;
	static final int EVENT_VIEW_REMOVED = 2;
	static final String TAG = "CoordinatorLayout";
	static final Comparator<View> TOP_SORTED_CHILDREN_COMPARATOR;
	private static final int TYPE_ON_INTERCEPT = 0;
	private static final int TYPE_ON_TOUCH = 1;
	static final String WIDGET_PACKAGE_NAME;
	static final ThreadLocal<Map<String, Constructor<Behavior>>> sConstructors;
	private OnApplyWindowInsetsListener mApplyWindowInsetsListener;
	private View mBehaviorTouchView;
	private final DirectedAcyclicGraph<View> mChildDag;
	private final List<View> mDependencySortedChildren;
	private boolean mDisallowInterceptReset;
	private boolean mDrawStatusBarBackground;
	private boolean mIsAttachedToWindow;
	private int[] mKeylines;
	private WindowInsetsCompat mLastInsets;
	private boolean mNeedsPreDrawListener;
	private View mNestedScrollingDirectChild;
	private final NestedScrollingParentHelper mNestedScrollingParentHelper;
	private View mNestedScrollingTarget;
	OnHierarchyChangeListener mOnHierarchyChangeListener;
	private OnPreDrawListener mOnPreDrawListener;
	private Paint mScrimPaint;
	private Drawable mStatusBarBackground;
	private final List<View> mTempDependenciesList;
	private final int[] mTempIntPair;
	private final List<View> mTempList1;
	private final Rect mTempRect1;
	private final Rect mTempRect2;
	private final Rect mTempRect3;
	private final Rect mTempRect4;

	public static abstract class Behavior<V extends View> {
		public Behavior() {
			super();
		}

		public Behavior(Context context, AttributeSet attrs) {
			super();
		}

		public static Object getTag(View child) {
			return ((CoordinatorLayout.LayoutParams) child.getLayoutParams()).mBehaviorTag;
		}

		public static void setTag(View child, Object tag) {
			((CoordinatorLayout.LayoutParams) child.getLayoutParams()).mBehaviorTag = tag;
		}

		public boolean blocksInteractionBelow(CoordinatorLayout parent, V child) {
			if (getScrimOpacity(parent, child) > 0.0f) {
				return true;
			} else {
				return false;
			}
		}

		public boolean getInsetDodgeRect(@NonNull CoordinatorLayout parent, @NonNull V child, @NonNull Rect rect) {
			return false;
		}

		@ColorInt
		public int getScrimColor(CoordinatorLayout parent, V child) {
			return ViewCompat.MEASURED_STATE_MASK;
		}

		@FloatRange(from = 0.0d, to = 1.0d)
		public float getScrimOpacity(CoordinatorLayout parent, V child) {
			return BitmapDescriptorFactory.HUE_RED;
		}

		@Deprecated
		public boolean isDirty(CoordinatorLayout parent, V child) {
			return false;
		}

		public boolean layoutDependsOn(CoordinatorLayout parent, V child, View dependency) {
			return false;
		}

		@NonNull
		public WindowInsetsCompat onApplyWindowInsets(CoordinatorLayout coordinatorLayout, V child, WindowInsetsCompat insets) {
			return insets;
		}

		public void onAttachedToLayoutParams(@NonNull CoordinatorLayout.LayoutParams params) {
		}

		public boolean onDependentViewChanged(CoordinatorLayout parent, V child, View dependency) {
			return false;
		}

		public void onDependentViewRemoved(CoordinatorLayout parent, V child, View dependency) {
		}

		public void onDetachedFromLayoutParams() {
		}

		public boolean onInterceptTouchEvent(CoordinatorLayout parent, V child, MotionEvent ev) {
			return false;
		}

		public boolean onLayoutChild(CoordinatorLayout parent, V child, int layoutDirection) {
			return false;
		}

		public boolean onMeasureChild(CoordinatorLayout parent, V child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed) {
			return false;
		}

		public boolean onNestedFling(CoordinatorLayout coordinatorLayout, V child, View target, float velocityX, float velocityY, boolean consumed) {
			return false;
		}

		public boolean onNestedPreFling(CoordinatorLayout coordinatorLayout, V child, View target, float velocityX, float velocityY) {
			return false;
		}

		public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V child, View target, int dx, int dy, int[] consumed) {
		}

		public void onNestedScroll(CoordinatorLayout coordinatorLayout, V child, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
		}

		public void onNestedScrollAccepted(CoordinatorLayout coordinatorLayout, V child, View directTargetChild, View target, int nestedScrollAxes) {
		}

		public boolean onRequestChildRectangleOnScreen(CoordinatorLayout coordinatorLayout, V child, Rect rectangle, boolean immediate) {
			return false;
		}

		public void onRestoreInstanceState(CoordinatorLayout parent, V child, Parcelable state) {
		}

		public Parcelable onSaveInstanceState(CoordinatorLayout parent, V child) {
			return BaseSavedState.EMPTY_STATE;
		}

		public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V child, View directTargetChild, View target, int nestedScrollAxes) {
			return false;
		}

		public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V child, View target) {
		}

		public boolean onTouchEvent(CoordinatorLayout parent, V child, MotionEvent ev) {
			return false;
		}
	}

	class AnonymousClass_1 implements OnApplyWindowInsetsListener {
		final /* synthetic */ CoordinatorLayout this$0;

		AnonymousClass_1(CoordinatorLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
			return this$0.setWindowInsets(insets);
		}
	}

	@Retention(RetentionPolicy.RUNTIME)
	public static @interface DefaultBehavior {
		Class<CoordinatorLayout.Behavior> value();
	}

	@Retention(RetentionPolicy.SOURCE)
	public static @interface DispatchChangeEvent {
	}

	private class HierarchyChangeListener implements OnHierarchyChangeListener {
		final /* synthetic */ CoordinatorLayout this$0;

		HierarchyChangeListener(CoordinatorLayout r1_CoordinatorLayout) {
			super();
			this$0 = r1_CoordinatorLayout;
		}

		public void onChildViewAdded(View parent, View child) {
			if (this$0.mOnHierarchyChangeListener != null) {
				this$0.mOnHierarchyChangeListener.onChildViewAdded(parent, child);
			}
		}

		public void onChildViewRemoved(View parent, View child) {
			this$0.onChildViewsChanged(EVENT_VIEW_REMOVED);
			if (this$0.mOnHierarchyChangeListener != null) {
				this$0.mOnHierarchyChangeListener.onChildViewRemoved(parent, child);
			}
		}
	}

	public static class LayoutParams extends MarginLayoutParams {
		public int anchorGravity;
		public int dodgeInsetEdges;
		public int gravity;
		public int insetEdge;
		public int keyline;
		View mAnchorDirectChild;
		int mAnchorId;
		View mAnchorView;
		CoordinatorLayout.Behavior mBehavior;
		boolean mBehaviorResolved;
		Object mBehaviorTag;
		private boolean mDidAcceptNestedScroll;
		private boolean mDidBlockInteraction;
		private boolean mDidChangeAfterNestedScroll;
		int mInsetOffsetX;
		int mInsetOffsetY;
		final Rect mLastChildRect;

		public LayoutParams(int width, int height) {
			super(width, height);
			mBehaviorResolved = false;
			gravity = 0;
			anchorGravity = 0;
			keyline = -1;
			mAnchorId = -1;
			insetEdge = 0;
			dodgeInsetEdges = 0;
			mLastChildRect = new Rect();
		}

		LayoutParams(Context context, AttributeSet attrs) {
			super(context, attrs);
			mBehaviorResolved = false;
			gravity = 0;
			anchorGravity = 0;
			keyline = -1;
			mAnchorId = -1;
			insetEdge = 0;
			dodgeInsetEdges = 0;
			mLastChildRect = new Rect();
			TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CoordinatorLayout_Layout);
			gravity = a.getInteger(R.styleable.CoordinatorLayout_Layout_android_layout_gravity, TYPE_ON_INTERCEPT);
			mAnchorId = a.getResourceId(R.styleable.CoordinatorLayout_Layout_layout_anchor, -1);
			anchorGravity = a.getInteger(R.styleable.CoordinatorLayout_Layout_layout_anchorGravity, TYPE_ON_INTERCEPT);
			keyline = a.getInteger(R.styleable.CoordinatorLayout_Layout_layout_keyline, -1);
			insetEdge = a.getInt(R.styleable.CoordinatorLayout_Layout_layout_insetEdge, TYPE_ON_INTERCEPT);
			dodgeInsetEdges = a.getInt(R.styleable.CoordinatorLayout_Layout_layout_dodgeInsetEdges, TYPE_ON_INTERCEPT);
			mBehaviorResolved = a.hasValue(R.styleable.CoordinatorLayout_Layout_layout_behavior);
			if (mBehaviorResolved) {
				mBehavior = CoordinatorLayout.parseBehavior(context, attrs, a.getString(R.styleable.CoordinatorLayout_Layout_layout_behavior));
			}
			a.recycle();
			if (mBehavior != null) {
				mBehavior.onAttachedToLayoutParams(this);
			}
		}

		public LayoutParams(CoordinatorLayout.LayoutParams p) {
			super(p);
			mBehaviorResolved = false;
			gravity = 0;
			anchorGravity = 0;
			keyline = -1;
			mAnchorId = -1;
			insetEdge = 0;
			dodgeInsetEdges = 0;
			mLastChildRect = new Rect();
		}

		public LayoutParams(android.view.ViewGroup.LayoutParams p) {
			super(p);
			mBehaviorResolved = false;
			gravity = 0;
			anchorGravity = 0;
			keyline = -1;
			mAnchorId = -1;
			insetEdge = 0;
			dodgeInsetEdges = 0;
			mLastChildRect = new Rect();
		}

		public LayoutParams(MarginLayoutParams p) {
			super(p);
			mBehaviorResolved = false;
			gravity = 0;
			anchorGravity = 0;
			keyline = -1;
			mAnchorId = -1;
			insetEdge = 0;
			dodgeInsetEdges = 0;
			mLastChildRect = new Rect();
		}

		private void resolveAnchorView(View forChild, CoordinatorLayout parent) {
			mAnchorView = parent.findViewById(mAnchorId);
			if (mAnchorView != null) {
				if (mAnchorView == parent) {
					if (parent.isInEditMode()) {
						mAnchorDirectChild = null;
						mAnchorView = null;
					} else {
						throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
					}
				} else {
					View directChild = mAnchorView;
					View p = mAnchorView.getParent();
					while (p != parent && p != null) {
						if (p == forChild) {
							if (parent.isInEditMode()) {
								mAnchorDirectChild = null;
								mAnchorView = null;
								return;
							} else {
								throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
							}
						} else {
							if (p instanceof View) {
								directChild = p;
							}
							p = p.getParent();
						}
					}
					mAnchorDirectChild = directChild;
				}
			} else if (parent.isInEditMode()) {
				mAnchorDirectChild = null;
				mAnchorView = null;
			} else {
				throw new IllegalStateException("Could not find CoordinatorLayout descendant view with id " + parent.getResources().getResourceName(mAnchorId) + " to anchor view " + forChild);
			}
		}

		private boolean shouldDodge(View other, int layoutDirection) {
			int absInset = GravityCompat.getAbsoluteGravity(((CoordinatorLayout.LayoutParams) other.getLayoutParams()).insetEdge, layoutDirection);
			if (absInset == 0 || (GravityCompat.getAbsoluteGravity(dodgeInsetEdges, layoutDirection) & absInset) != absInset) {
				return false;
			} else {
				return true;
			}
		}

		private boolean verifyAnchorView(View forChild, CoordinatorLayout parent) {
			if (mAnchorView.getId() != mAnchorId) {
				return false;
			} else {
				View directChild = mAnchorView;
				View p = mAnchorView.getParent();
				while (p != parent) {
					if (p == null || p == forChild) {
						mAnchorDirectChild = null;
						mAnchorView = null;
						return false;
					} else {
						if (p instanceof View) {
							directChild = p;
						}
						p = p.getParent();
					}
				}
				mAnchorDirectChild = directChild;
				return true;
			}
		}

		void acceptNestedScroll(boolean accept) {
			mDidAcceptNestedScroll = accept;
		}

		boolean checkAnchorChanged() {
			if (mAnchorView != null || mAnchorId == -1) {
				return false;
			} else {
				return true;
			}
		}

		boolean dependsOn(CoordinatorLayout parent, View child, View dependency) {
			if (dependency == mAnchorDirectChild || shouldDodge(dependency, ViewCompat.getLayoutDirection(parent))) {
				return true;
			} else if (mBehavior == null || !mBehavior.layoutDependsOn(parent, child, dependency)) {
				return false;
			} else {
				return true;
			}
		}

		boolean didBlockInteraction() {
			if (mBehavior == null) {
				mDidBlockInteraction = false;
			}
			return mDidBlockInteraction;
		}

		View findAnchorView(CoordinatorLayout parent, View forChild) {
			if (mAnchorId == -1) {
				mAnchorDirectChild = null;
				mAnchorView = null;
				return null;
			} else {
				if (mAnchorView == null || !verifyAnchorView(forChild, parent)) {
					resolveAnchorView(forChild, parent);
				} else {
					return mAnchorView;
				}
				return mAnchorView;
			}
		}

		@IdRes
		public int getAnchorId() {
			return mAnchorId;
		}

		@Nullable
		public CoordinatorLayout.Behavior getBehavior() {
			return mBehavior;
		}

		boolean getChangedAfterNestedScroll() {
			return mDidChangeAfterNestedScroll;
		}

		Rect getLastChildRect() {
			return mLastChildRect;
		}

		void invalidateAnchor() {
			mAnchorDirectChild = null;
			mAnchorView = null;
		}

		boolean isBlockingInteractionBelow(CoordinatorLayout parent, View child) {
			if (mDidBlockInteraction) {
				return true;
			} else {
				boolean r0z;
				boolean r1z = mDidBlockInteraction;
				if (mBehavior != null) {
					r0z = mBehavior.blocksInteractionBelow(parent, child);
				} else {
					r0z = false;
				}
				r0z |= r1z;
				mDidBlockInteraction = r0z;
				return r0z;
			}
		}

		boolean isNestedScrollAccepted() {
			return mDidAcceptNestedScroll;
		}

		void resetChangedAfterNestedScroll() {
			mDidChangeAfterNestedScroll = false;
		}

		void resetNestedScroll() {
			mDidAcceptNestedScroll = false;
		}

		void resetTouchBehaviorTracking() {
			mDidBlockInteraction = false;
		}

		public void setAnchorId(@IdRes int id) {
			invalidateAnchor();
			mAnchorId = id;
		}

		public void setBehavior(@Nullable CoordinatorLayout.Behavior behavior) {
			if (mBehavior != behavior) {
				if (mBehavior != null) {
					mBehavior.onDetachedFromLayoutParams();
				}
				mBehavior = behavior;
				mBehaviorTag = null;
				mBehaviorResolved = true;
				if (behavior != null) {
					behavior.onAttachedToLayoutParams(this);
				}
			}
		}

		void setChangedAfterNestedScroll(boolean changed) {
			mDidChangeAfterNestedScroll = changed;
		}

		void setLastChildRect(Rect r) {
			mLastChildRect.set(r);
		}
	}

	class OnPreDrawListener implements android.view.ViewTreeObserver.OnPreDrawListener {
		final /* synthetic */ CoordinatorLayout this$0;

		OnPreDrawListener(CoordinatorLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public boolean onPreDraw() {
			this$0.onChildViewsChanged(TYPE_ON_INTERCEPT);
			return true;
		}
	}

	protected static class SavedState extends AbsSavedState {
		public static final Creator<CoordinatorLayout.SavedState> CREATOR;
		SparseArray<Parcelable> behaviorStates;

		static class AnonymousClass_1 implements ParcelableCompatCreatorCallbacks<CoordinatorLayout.SavedState> {
			AnonymousClass_1() {
				super();
			}

			public CoordinatorLayout.SavedState createFromParcel(Parcel in, ClassLoader loader) {
				return new CoordinatorLayout.SavedState(in, loader);
			}

			public CoordinatorLayout.SavedState[] newArray(int size) {
				return new CoordinatorLayout.SavedState[size];
			}
		}


		static {
			CREATOR = ParcelableCompat.newCreator(new AnonymousClass_1());
		}

		public SavedState(Parcel source, ClassLoader loader) {
			super(source, loader);
			int size = source.readInt();
			int[] ids = new int[size];
			source.readIntArray(ids);
			Parcelable[] states = source.readParcelableArray(loader);
			behaviorStates = new SparseArray(size);
			int i = TYPE_ON_INTERCEPT;
			while (i < size) {
				behaviorStates.append(ids[i], states[i]);
				i++;
			}
		}

		public SavedState(Parcelable superState) {
			super(superState);
		}

		public void writeToParcel(Parcel dest, int flags) {
			int size;
			super.writeToParcel(dest, flags);
			if (behaviorStates != null) {
				size = behaviorStates.size();
			} else {
				size = TYPE_ON_INTERCEPT;
			}
			dest.writeInt(size);
			int[] ids = new int[size];
			Parcelable[] states = new Parcelable[size];
			int i = TYPE_ON_INTERCEPT;
			while (i < size) {
				ids[i] = behaviorStates.keyAt(i);
				states[i] = (Parcelable) behaviorStates.valueAt(i);
				i++;
			}
			dest.writeIntArray(ids);
			dest.writeParcelableArray(states, flags);
		}
	}

	static class ViewElevationComparator implements Comparator<View> {
		ViewElevationComparator() {
			super();
		}

		public int compare(View lhs, View rhs) {
			float lz = ViewCompat.getZ(lhs);
			float rz = ViewCompat.getZ(rhs);
			if (lz > rz) {
				return -1;
			} else if (lz < rz) {
				return TYPE_ON_TOUCH;
			} else {
				return TYPE_ON_INTERCEPT;
			}
		}
	}


	static {
		String r1_String;
		Package pkg = CoordinatorLayout.class.getPackage();
		if (pkg != null) {
			r1_String = pkg.getName();
		} else {
			r1_String = null;
		}
		WIDGET_PACKAGE_NAME = r1_String;
		if (VERSION.SDK_INT >= 21) {
			TOP_SORTED_CHILDREN_COMPARATOR = new ViewElevationComparator();
		} else {
			TOP_SORTED_CHILDREN_COMPARATOR = null;
		}
		Class[] r1_Class_A = new Class[2];
		r1_Class_A[0] = Context.class;
		r1_Class_A[1] = AttributeSet.class;
		CONSTRUCTOR_PARAMS = r1_Class_A;
		sConstructors = new ThreadLocal();
	}

	public CoordinatorLayout(Context context) {
		this(context, null);
	}

	public CoordinatorLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CoordinatorLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		mDependencySortedChildren = new ArrayList();
		mChildDag = new DirectedAcyclicGraph();
		mTempList1 = new ArrayList();
		mTempDependenciesList = new ArrayList();
		mTempRect1 = new Rect();
		mTempRect2 = new Rect();
		mTempRect3 = new Rect();
		mTempRect4 = new Rect();
		mTempIntPair = new int[2];
		mNestedScrollingParentHelper = new NestedScrollingParentHelper(this);
		ThemeUtils.checkAppCompatTheme(context);
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CoordinatorLayout, defStyleAttr, R.style.Widget_Design_CoordinatorLayout);
		int keylineArrayRes = a.getResourceId(R.styleable.CoordinatorLayout_keylines, TYPE_ON_INTERCEPT);
		if (keylineArrayRes != 0) {
			Resources res = context.getResources();
			mKeylines = res.getIntArray(keylineArrayRes);
			float density = res.getDisplayMetrics().density;
			int i = TYPE_ON_INTERCEPT;
			while (i < mKeylines.length) {
				int[] r6_int_A = mKeylines;
				r6_int_A[i] = (int) (((float) r6_int_A[i]) * density);
				i++;
			}
		}
		mStatusBarBackground = a.getDrawable(R.styleable.CoordinatorLayout_statusBarBackground);
		a.recycle();
		setupForInsets();
		super.setOnHierarchyChangeListener(new HierarchyChangeListener(this));
	}

	private void constrainChildRect(LayoutParams lp, Rect out, int childWidth, int childHeight) {
		int left = Math.max(getPaddingLeft() + lp.leftMargin, Math.min(out.left, ((getWidth() - getPaddingRight()) - childWidth) - lp.rightMargin));
		int top = Math.max(getPaddingTop() + lp.topMargin, Math.min(out.top, ((getHeight() - getPaddingBottom()) - childHeight) - lp.bottomMargin));
		out.set(left, top, left + childWidth, top + childHeight);
	}

	private WindowInsetsCompat dispatchApplyWindowInsetsToBehaviors(WindowInsetsCompat insets) {
		if (insets.isConsumed()) {
			return insets;
		} else {
			int i = TYPE_ON_INTERCEPT;
			while (i < getChildCount()) {
				View child = getChildAt(i);
				if (ViewCompat.getFitsSystemWindows(child)) {
					Behavior b = ((LayoutParams) child.getLayoutParams()).getBehavior();
					if (b != null) {
						insets = b.onApplyWindowInsets(this, child, insets);
						if (insets.isConsumed()) {
							return insets;
						}
					}
				}
				i++;
			}
			return insets;
		}
	}

	private void getDesiredAnchoredChildRectWithoutConstraints(View child, int layoutDirection, Rect anchorRect, Rect out, LayoutParams lp, int childWidth, int childHeight) {
		int left;
		int top;
		int absGravity = GravityCompat.getAbsoluteGravity(resolveAnchoredChildGravity(lp.gravity), layoutDirection);
		int absAnchorGravity = GravityCompat.getAbsoluteGravity(resolveGravity(lp.anchorGravity), layoutDirection);
		int hgrav = absGravity & 7;
		int vgrav = absGravity & 112;
		int anchorVgrav = absAnchorGravity & 112;
		switch((absAnchorGravity & 7)) {
		case TYPE_ON_TOUCH:
			left = anchorRect.left + (anchorRect.width() / 2);
			switch(anchorVgrav) {
			case TLRPC.USER_FLAG_PHONE:
				top = anchorRect.top + (anchorRect.height() / 2);
				switch(hgrav) {
				case TYPE_ON_TOUCH:
					left -= childWidth / 2;
					break;
				case SQLiteCursor.FIELD_TYPE_NULL:
					break;
				default:
					left -= childWidth;
					break;
				}
				switch(vgrav) {
				case TLRPC.USER_FLAG_PHONE:
					top -= childHeight / 2;
					break;
				case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
					break;
				default:
					top -= childHeight;
					break;
				}
				out.set(left, top, left + childWidth, top + childHeight);
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
				top = anchorRect.bottom;
				switch(hgrav) {
				case TYPE_ON_TOUCH:
					left -= childWidth / 2;
					break;
				case SQLiteCursor.FIELD_TYPE_NULL:
					break;
				default:
					left -= childWidth;
					break;
				}
				switch(vgrav) {
				case TLRPC.USER_FLAG_PHONE:
					top -= childHeight / 2;
					break;
				case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
					break;
				default:
					top -= childHeight;
					break;
				}
				out.set(left, top, left + childWidth, top + childHeight);
			}
			top = anchorRect.top;
			switch(hgrav) {
			case TYPE_ON_TOUCH:
				left -= childWidth / 2;
				break;
			case SQLiteCursor.FIELD_TYPE_NULL:
				break;
			default:
				left -= childWidth;
				break;
			}
			switch(vgrav) {
			case TLRPC.USER_FLAG_PHONE:
				top -= childHeight / 2;
				break;
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
				break;
			default:
				top -= childHeight;
				break;
			}
			out.set(left, top, left + childWidth, top + childHeight);
		case SQLiteCursor.FIELD_TYPE_NULL:
			left = anchorRect.right;
			switch(anchorVgrav) {
			case TLRPC.USER_FLAG_PHONE:
				top = anchorRect.top + (anchorRect.height() / 2);
				switch(hgrav) {
				case TYPE_ON_TOUCH:
					left -= childWidth / 2;
					break;
				case SQLiteCursor.FIELD_TYPE_NULL:
					break;
				default:
					left -= childWidth;
					break;
				}
				switch(vgrav) {
				case TLRPC.USER_FLAG_PHONE:
					top -= childHeight / 2;
					break;
				case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
					break;
				default:
					top -= childHeight;
					break;
				}
				out.set(left, top, left + childWidth, top + childHeight);
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
				top = anchorRect.bottom;
				switch(hgrav) {
				case TYPE_ON_TOUCH:
					left -= childWidth / 2;
					break;
				case SQLiteCursor.FIELD_TYPE_NULL:
					break;
				default:
					left -= childWidth;
					break;
				}
				switch(vgrav) {
				case TLRPC.USER_FLAG_PHONE:
					top -= childHeight / 2;
					break;
				case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
					break;
				default:
					top -= childHeight;
					break;
				}
				out.set(left, top, left + childWidth, top + childHeight);
			}
			top = anchorRect.top;
			switch(hgrav) {
			case TYPE_ON_TOUCH:
				left -= childWidth / 2;
				break;
			case SQLiteCursor.FIELD_TYPE_NULL:
				break;
			default:
				left -= childWidth;
				break;
			}
			switch(vgrav) {
			case TLRPC.USER_FLAG_PHONE:
				top -= childHeight / 2;
				break;
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
				break;
			default:
				top -= childHeight;
				break;
			}
			out.set(left, top, left + childWidth, top + childHeight);
		}
		left = anchorRect.left;
		switch(anchorVgrav) {
		case TLRPC.USER_FLAG_PHONE:
			top = anchorRect.top + (anchorRect.height() / 2);
			switch(hgrav) {
			case TYPE_ON_TOUCH:
				left -= childWidth / 2;
				break;
			case SQLiteCursor.FIELD_TYPE_NULL:
				break;
			default:
				left -= childWidth;
				break;
			}
			switch(vgrav) {
			case TLRPC.USER_FLAG_PHONE:
				top -= childHeight / 2;
				break;
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
				break;
			default:
				top -= childHeight;
				break;
			}
			out.set(left, top, left + childWidth, top + childHeight);
		case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
			top = anchorRect.bottom;
			switch(hgrav) {
			case TYPE_ON_TOUCH:
				left -= childWidth / 2;
				break;
			case SQLiteCursor.FIELD_TYPE_NULL:
				break;
			default:
				left -= childWidth;
				break;
			}
			switch(vgrav) {
			case TLRPC.USER_FLAG_PHONE:
				top -= childHeight / 2;
				break;
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
				break;
			default:
				top -= childHeight;
				break;
			}
			out.set(left, top, left + childWidth, top + childHeight);
		}
		top = anchorRect.top;
		switch(hgrav) {
		case TYPE_ON_TOUCH:
			left -= childWidth / 2;
			break;
		case SQLiteCursor.FIELD_TYPE_NULL:
			break;
		default:
			left -= childWidth;
			break;
		}
		switch(vgrav) {
		case TLRPC.USER_FLAG_PHONE:
			top -= childHeight / 2;
			break;
		case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
			break;
		default:
			top -= childHeight;
			break;
		}
		out.set(left, top, left + childWidth, top + childHeight);
	}

	private int getKeyline(int index) {
		if (mKeylines == null) {
			Log.e(TAG, "No keylines defined for " + this + " - attempted index lookup " + index);
			return TYPE_ON_INTERCEPT;
		} else if (index < 0 || index >= mKeylines.length) {
			Log.e(TAG, "Keyline index " + index + " out of range for " + this);
			return TYPE_ON_INTERCEPT;
		} else {
			return mKeylines[index];
		}
	}

	private void getTopSortedChildren(List<View> out) {
		out.clear();
		boolean useCustomOrder = isChildrenDrawingOrderEnabled();
		int childCount = getChildCount();
		int i = childCount - 1;
		while (i >= 0) {
			int childIndex;
			if (useCustomOrder) {
				childIndex = getChildDrawingOrder(childCount, i);
			} else {
				childIndex = i;
			}
			out.add(getChildAt(childIndex));
			i--;
		}
		if (TOP_SORTED_CHILDREN_COMPARATOR != null) {
			Collections.sort(out, TOP_SORTED_CHILDREN_COMPARATOR);
		}
	}

	private boolean hasDependencies(View child) {
		return mChildDag.hasOutgoingEdges(child);
	}

	private void layoutChild(View child, int layoutDirection) {
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		Rect parent = mTempRect1;
		parent.set(getPaddingLeft() + lp.leftMargin, getPaddingTop() + lp.topMargin, (getWidth() - getPaddingRight()) - lp.rightMargin, (getHeight() - getPaddingBottom()) - lp.bottomMargin);
		Rect out;
		if (mLastInsets == null || !ViewCompat.getFitsSystemWindows(this) || ViewCompat.getFitsSystemWindows(child)) {
			out = mTempRect2;
			GravityCompat.apply(resolveGravity(lp.gravity), child.getMeasuredWidth(), child.getMeasuredHeight(), parent, out, layoutDirection);
			child.layout(out.left, out.top, out.right, out.bottom);
		} else {
			parent.left += mLastInsets.getSystemWindowInsetLeft();
			parent.top += mLastInsets.getSystemWindowInsetTop();
			parent.right -= mLastInsets.getSystemWindowInsetRight();
			parent.bottom -= mLastInsets.getSystemWindowInsetBottom();
			out = mTempRect2;
			GravityCompat.apply(resolveGravity(lp.gravity), child.getMeasuredWidth(), child.getMeasuredHeight(), parent, out, layoutDirection);
			child.layout(out.left, out.top, out.right, out.bottom);
		}
	}

	private void layoutChildWithAnchor(View child, View anchor, int layoutDirection) {
		Rect anchorRect = mTempRect1;
		Rect childRect = mTempRect2;
		getDescendantRect(anchor, anchorRect);
		getDesiredAnchoredChildRect(child, layoutDirection, anchorRect, childRect);
		child.layout(childRect.left, childRect.top, childRect.right, childRect.bottom);
	}

	private void layoutChildWithKeyline(View child, int keyline, int layoutDirection) {
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		int absGravity = GravityCompat.getAbsoluteGravity(resolveKeylineGravity(lp.gravity), layoutDirection);
		int hgrav = absGravity & 7;
		int vgrav = absGravity & 112;
		int width = getWidth();
		int height = getHeight();
		int childWidth = child.getMeasuredWidth();
		int childHeight = child.getMeasuredHeight();
		if (layoutDirection == TYPE_ON_TOUCH) {
			keyline = width - keyline;
		}
		int left = getKeyline(keyline) - childWidth;
		int top = TYPE_ON_INTERCEPT;
		switch(hgrav) {
		case TYPE_ON_TOUCH:
			left += childWidth / 2;
			break;
		case SQLiteCursor.FIELD_TYPE_NULL:
			left += childWidth;
			break;
		}
		switch(vgrav) {
		case TLRPC.USER_FLAG_PHONE:
			top += childHeight / 2;
			break;
		case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
			top += childHeight;
			break;
		}
		left = Math.max(getPaddingLeft() + lp.leftMargin, Math.min(left, ((width - getPaddingRight()) - childWidth) - lp.rightMargin));
		top = Math.max(getPaddingTop() + lp.topMargin, Math.min(top, ((height - getPaddingBottom()) - childHeight) - lp.bottomMargin));
		child.layout(left, top, left + childWidth, top + childHeight);
	}

	private void offsetChildByInset(View child, Rect inset, int layoutDirection) {
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		int absDodgeInsetEdges = GravityCompat.getAbsoluteGravity(lp.dodgeInsetEdges, layoutDirection);
		Behavior behavior = lp.getBehavior();
		Rect rect = mTempRect3;
		if (behavior == null || !behavior.getInsetDodgeRect(this, child, rect)) {
			rect.set(child.getLeft(), child.getTop(), child.getRight(), child.getBottom());
		} else if (!rect.intersect(child.getLeft(), child.getTop(), child.getRight(), child.getBottom())) {
			throw new IllegalArgumentException("Rect should intersect with child's bounds.");
		}
		if (rect.isEmpty()) {
		} else {
			int distance;
			boolean offsetY = false;
			if ((absDodgeInsetEdges & 48) == 48) {
				distance = (rect.top - lp.topMargin) - lp.mInsetOffsetY;
				if (distance < inset.top) {
					setInsetOffsetY(child, inset.top - distance);
					offsetY = true;
				}
			}
			if ((absDodgeInsetEdges & 80) == 80) {
				distance = ((getHeight() - rect.bottom) - lp.bottomMargin) + lp.mInsetOffsetY;
				if (distance < inset.bottom) {
					setInsetOffsetY(child, distance - inset.bottom);
					offsetY = true;
				}
			}
			if (!offsetY) {
				setInsetOffsetY(child, TYPE_ON_INTERCEPT);
			}
			boolean offsetX = false;
			if ((absDodgeInsetEdges & 3) == 3) {
				distance = (rect.left - lp.leftMargin) - lp.mInsetOffsetX;
				if (distance < inset.left) {
					setInsetOffsetX(child, inset.left - distance);
					offsetX = true;
				}
			}
			if ((absDodgeInsetEdges & 5) == 5) {
				distance = ((getWidth() - rect.right) - lp.rightMargin) + lp.mInsetOffsetX;
				if (distance < inset.right) {
					setInsetOffsetX(child, distance - inset.right);
					offsetX = true;
				}
			}
			if (!offsetX) {
				setInsetOffsetX(child, TYPE_ON_INTERCEPT);
			}
		}
	}

	static Behavior parseBehavior(Context context, AttributeSet attrs, String name) {
		if (TextUtils.isEmpty(name)) {
			return null;
		} else {
			String fullName;
			Map<String, Constructor<Behavior>> constructors;
			Constructor<Behavior> c;
			if (name.startsWith(".")) {
				fullName = context.getPackageName() + name;
			} else if (name.indexOf(android.support.v7.appcompat.R.styleable.AppCompatTheme_actionDropDownStyle) >= 0) {
				fullName = name;
			} else if (!TextUtils.isEmpty(WIDGET_PACKAGE_NAME)) {
				fullName = WIDGET_PACKAGE_NAME + '.' + name;
			} else {
				fullName = name;
			}
			try {
				constructors = (Map) sConstructors.get();
				if (constructors == null) {
					constructors = new HashMap();
					sConstructors.set(constructors);
				}
				c = (Constructor) constructors.get(fullName);
				if (c == null) {
					c = Class.forName(fullName, true, context.getClassLoader()).getConstructor(CONSTRUCTOR_PARAMS);
					c.setAccessible(true);
					constructors.put(fullName, c);
				}
				Object[] r5_Object_A = new Object[2];
				r5_Object_A[0] = context;
				r5_Object_A[1] = attrs;
				return (Behavior) c.newInstance(r5_Object_A);
			} catch (Exception e) {
				throw new RuntimeException("Could not inflate Behavior subclass " + fullName, e);
			}
		}
	}

	private boolean performIntercept(MotionEvent ev, int type) {
		boolean intercepted = false;
		boolean newBlock = false;
		MotionEvent cancelEvent = null;
		int action = MotionEventCompat.getActionMasked(ev);
		List<View> topmostChildList = mTempList1;
		getTopSortedChildren(topmostChildList);
		int i = TYPE_ON_INTERCEPT;
		while (i < topmostChildList.size()) {
			View child = (View) topmostChildList.get(i);
			LayoutParams lp = (LayoutParams) child.getLayoutParams();
			Behavior b = lp.getBehavior();
			if ((intercepted || newBlock) && action != 0) {
				if (b != null) {
					if (cancelEvent == null) {
						long now = SystemClock.uptimeMillis();
						cancelEvent = MotionEvent.obtain(now, now, ConnectionsManager.ConnectionStateConnected, BitmapDescriptorFactory.HUE_RED, BitmapDescriptorFactory.HUE_RED, TYPE_ON_INTERCEPT);
					}
					switch(type) {
					case TYPE_ON_INTERCEPT:
						b.onInterceptTouchEvent(this, child, cancelEvent);
						break;
					case TYPE_ON_TOUCH:
						b.onTouchEvent(this, child, cancelEvent);
						break;
					}
				}
			} else if (intercepted || b == null) {
				wasBlocking = lp.didBlockInteraction();
				isBlocking = lp.isBlockingInteractionBelow(this, child);
				if (!isBlocking || wasBlocking) {
					newBlock = false;
				} else {
					newBlock = true;
				}
				if (!isBlocking || newBlock) {
					i++;
				}
			} else {
				switch(type) {
				case TYPE_ON_INTERCEPT:
					intercepted = b.onInterceptTouchEvent(this, child, ev);
					break;
				case TYPE_ON_TOUCH:
					intercepted = b.onTouchEvent(this, child, ev);
					break;
				}
				if (intercepted) {
					mBehaviorTouchView = child;
				}
				wasBlocking = lp.didBlockInteraction();
				isBlocking = lp.isBlockingInteractionBelow(this, child);
				if (!isBlocking || wasBlocking) {
					newBlock = false;
				} else {
					newBlock = true;
				}
				if (!isBlocking || newBlock) {
					i++;
				}
			}
		}
		topmostChildList.clear();
		return intercepted;
	}

	private void prepareChildren() {
		mDependencySortedChildren.clear();
		mChildDag.clear();
		int i = TYPE_ON_INTERCEPT;
		int count = getChildCount();
		while (i < count) {
			View view = getChildAt(i);
			getResolvedLayoutParams(view).findAnchorView(this, view);
			mChildDag.addNode(view);
			int j = TYPE_ON_INTERCEPT;
			while (j < count) {
				if (j == i) {
					j++;
				} else {
					View other = getChildAt(j);
					if (getResolvedLayoutParams(other).dependsOn(this, other, view)) {
						if (!mChildDag.contains(other)) {
							mChildDag.addNode(other);
						}
						mChildDag.addEdge(view, other);
					}
					j++;
				}
			}
			i++;
		}
		mDependencySortedChildren.addAll(mChildDag.getSortedList());
		Collections.reverse(mDependencySortedChildren);
	}

	private void resetTouchBehaviors() {
		if (mBehaviorTouchView != null) {
			Behavior b = ((LayoutParams) mBehaviorTouchView.getLayoutParams()).getBehavior();
			if (b != null) {
				long now = SystemClock.uptimeMillis();
				MotionEvent cancelEvent = MotionEvent.obtain(now, now, ConnectionsManager.ConnectionStateConnected, BitmapDescriptorFactory.HUE_RED, 0.0f, TYPE_ON_INTERCEPT);
				b.onTouchEvent(this, mBehaviorTouchView, cancelEvent);
				cancelEvent.recycle();
			}
			mBehaviorTouchView = null;
		}
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			((LayoutParams) getChildAt(i).getLayoutParams()).resetTouchBehaviorTracking();
			i++;
		}
		mDisallowInterceptReset = false;
	}

	private static int resolveAnchoredChildGravity(int gravity) {
		if (gravity == 0) {
			gravity = com.rey.material.R.styleable.View_android_scrollbarDefaultDelayBeforeFade;
		}
		return gravity;
	}

	private static int resolveGravity(int gravity) {
		if (gravity == 0) {
			gravity = 8388659;
		}
		return gravity;
	}

	private static int resolveKeylineGravity(int gravity) {
		if (gravity == 0) {
			gravity = 8388661;
		}
		return gravity;
	}

	private void setInsetOffsetX(View child, int offsetX) {
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		if (lp.mInsetOffsetX != offsetX) {
			ViewCompat.offsetLeftAndRight(child, offsetX - lp.mInsetOffsetX);
			lp.mInsetOffsetX = offsetX;
		}
	}

	private void setInsetOffsetY(View child, int offsetY) {
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		if (lp.mInsetOffsetY != offsetY) {
			ViewCompat.offsetTopAndBottom(child, offsetY - lp.mInsetOffsetY);
			lp.mInsetOffsetY = offsetY;
		}
	}

	private void setupForInsets() {
		if (VERSION.SDK_INT < 21) {
		} else if (ViewCompat.getFitsSystemWindows(this)) {
			if (mApplyWindowInsetsListener == null) {
				mApplyWindowInsetsListener = new AnonymousClass_1(this);
			}
			ViewCompat.setOnApplyWindowInsetsListener(this, mApplyWindowInsetsListener);
			setSystemUiVisibility(1280);
		} else {
			ViewCompat.setOnApplyWindowInsetsListener(this, null);
		}
	}

	void addPreDrawListener() {
		if (mIsAttachedToWindow) {
			if (mOnPreDrawListener == null) {
				mOnPreDrawListener = new OnPreDrawListener(this);
			}
			getViewTreeObserver().addOnPreDrawListener(mOnPreDrawListener);
		}
		mNeedsPreDrawListener = true;
	}

	protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams p) {
		if (!(p instanceof LayoutParams) || !super.checkLayoutParams(p)) {
			return false;
		} else {
			return true;
		}
	}

	public void dispatchDependentViewsChanged(View view) {
		List<View> dependents = mChildDag.getIncomingEdges(view);
		if (dependents == null || dependents.isEmpty()) {
		} else {
			int i = TYPE_ON_INTERCEPT;
			while (i < dependents.size()) {
				View child = (View) dependents.get(i);
				Behavior b = ((LayoutParams) child.getLayoutParams()).getBehavior();
				if (b != null) {
					b.onDependentViewChanged(this, child, view);
				}
				i++;
			}
		}
	}

	public boolean doViewsOverlap(View first, View second) {
		if (first.getVisibility() != 0 || second.getVisibility() != 0) {
			return false;
		} else {
			boolean r2z;
			Rect firstRect = mTempRect1;
			if (first.getParent() != this) {
				r2z = true;
			} else {
				r2z = false;
			}
			getChildRect(first, r2z, firstRect);
			Rect secondRect = mTempRect2;
			if (second.getParent() != this) {
				r2z = true;
			} else {
				r2z = false;
			}
			getChildRect(second, r2z, secondRect);
			if (firstRect.left > secondRect.right || firstRect.top > secondRect.bottom || firstRect.right < secondRect.left || firstRect.bottom < secondRect.top) {
				return false;
			} else {
				return true;
			}
		}
	}

	protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		if (lp.mBehavior != null) {
			float scrimAlpha = lp.mBehavior.getScrimOpacity(this, child);
			if (scrimAlpha > 0.0f) {
				if (mScrimPaint == null) {
					mScrimPaint = new Paint();
				}
				mScrimPaint.setColor(lp.mBehavior.getScrimColor(this, child));
				mScrimPaint.setAlpha(MathUtils.constrain(Math.round(255.0f * scrimAlpha), (int)TYPE_ON_INTERCEPT, (int)Utils.SELECTED_ALPHA_THEME_DARK));
				int saved = canvas.save();
				if (child.isOpaque()) {
					canvas.clipRect((float) child.getLeft(), (float) child.getTop(), (float) child.getRight(), (float) child.getBottom(), Op.DIFFERENCE);
				}
				canvas.drawRect((float) getPaddingLeft(), (float) getPaddingTop(), (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()), mScrimPaint);
				canvas.restoreToCount(saved);
			}
		}
		return super.drawChild(canvas, child, drawingTime);
	}

	/* JADX WARNING: inconsistent code */
	/*
	protected void drawableStateChanged() {
		r4_this = this;
		super.drawableStateChanged();
		r2 = r4.getDrawableState();
		r0 = 0;
		r1 = r4.mStatusBarBackground;
		if (r1_d == 0) goto L_0x0017;
	L_0x000c:
		r3 = r1_d.isStateful();
		if (r3 == 0) goto L_0x0017;
	L_0x0012:
		r3 = r1_d.setState(r2_state);
		r0_changed |= r3;
	L_0x0017:
		if (r0_changed == 0) goto L_0x001c;
	L_0x0019:
		r4.invalidate();
	L_0x001c:
		return;
	}
	*/
	protected void drawableStateChanged() {
		super.drawableStateChanged();
		int[] state = getDrawableState();
		boolean changed = false;
		Drawable d = mStatusBarBackground;
		if (d == null || !d.isStateful()) {
		} else {
			changed |= d.setState(state);
		}
	}

	void ensurePreDrawListener() {
		boolean hasDependencies = false;
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			if (hasDependencies(getChildAt(i))) {
				hasDependencies = true;
			} else {
				i++;
			}
		}
		if (hasDependencies != mNeedsPreDrawListener) {
			if (hasDependencies) {
				addPreDrawListener();
			} else {
				removePreDrawListener();
			}
		}
	}

	protected LayoutParams generateDefaultLayoutParams() {
		return new LayoutParams(-2, -2);
	}

	public LayoutParams generateLayoutParams(AttributeSet attrs) {
		return new LayoutParams(getContext(), attrs);
	}

	protected LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams p) {
		if (p instanceof LayoutParams) {
			return new LayoutParams((LayoutParams) p);
		} else if (p instanceof MarginLayoutParams) {
			return new LayoutParams((MarginLayoutParams) p);
		} else {
			return new LayoutParams(p);
		}
	}

	void getChildRect(View child, boolean transform, Rect out) {
		if (child.isLayoutRequested() || child.getVisibility() == 8) {
			out.setEmpty();
		} else if (transform) {
			getDescendantRect(child, out);
		} else {
			out.set(child.getLeft(), child.getTop(), child.getRight(), child.getBottom());
		}
	}

	@NonNull
	public List<View> getDependencies(@NonNull View child) {
		List<View> dependencies = mChildDag.getOutgoingEdges(child);
		mTempDependenciesList.clear();
		if (dependencies != null) {
			mTempDependenciesList.addAll(dependencies);
		}
		return mTempDependenciesList;
	}

	@VisibleForTesting
	final List<View> getDependencySortedChildren() {
		prepareChildren();
		return Collections.unmodifiableList(mDependencySortedChildren);
	}

	@NonNull
	public List<View> getDependents(@NonNull View child) {
		List<View> edges = mChildDag.getIncomingEdges(child);
		mTempDependenciesList.clear();
		if (edges != null) {
			mTempDependenciesList.addAll(edges);
		}
		return mTempDependenciesList;
	}

	void getDescendantRect(View descendant, Rect out) {
		ViewGroupUtils.getDescendantRect(this, descendant, out);
	}

	void getDesiredAnchoredChildRect(View child, int layoutDirection, Rect anchorRect, Rect out) {
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		int childWidth = child.getMeasuredWidth();
		int childHeight = child.getMeasuredHeight();
		getDesiredAnchoredChildRectWithoutConstraints(child, layoutDirection, anchorRect, out, lp, childWidth, childHeight);
		constrainChildRect(lp, out, childWidth, childHeight);
	}

	void getLastChildRect(View child, Rect out) {
		out.set(((LayoutParams) child.getLayoutParams()).getLastChildRect());
	}

	final WindowInsetsCompat getLastWindowInsets() {
		return mLastInsets;
	}

	public int getNestedScrollAxes() {
		return mNestedScrollingParentHelper.getNestedScrollAxes();
	}

	LayoutParams getResolvedLayoutParams(View child) {
		LayoutParams result = (LayoutParams) child.getLayoutParams();
		if (!result.mBehaviorResolved) {
			Class<?> childClass = child.getClass();
			DefaultBehavior defaultBehavior = null;
			while (childClass != null) {
				defaultBehavior = childClass.getAnnotation(DefaultBehavior.class);
				if (defaultBehavior == null) {
					childClass = childClass.getSuperclass();
				}
			}
			if (defaultBehavior != null) {
				try {
					result.setBehavior((Behavior) defaultBehavior.value().newInstance());
				} catch (Exception e) {
					Log.e(TAG, "Default behavior class " + defaultBehavior.value().getName() + " could not be instantiated. Did you forget a default constructor?", e);
				}
			}
			result.mBehaviorResolved = true;
			return result;
		} else {
			return result;
		}
	}

	@Nullable
	public Drawable getStatusBarBackground() {
		return mStatusBarBackground;
	}

	protected int getSuggestedMinimumHeight() {
		return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
	}

	protected int getSuggestedMinimumWidth() {
		return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
	}

	public boolean isPointInChildBounds(View child, int x, int y) {
		Rect r = mTempRect1;
		getDescendantRect(child, r);
		return r.contains(x, y);
	}

	void offsetChildToAnchor(View child, int layoutDirection) {
		boolean changed = false;
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		if (lp.mAnchorView != null) {
			int dx;
			int dy;
			Rect anchorRect = mTempRect1;
			Rect childRect = mTempRect2;
			Rect desiredChildRect = mTempRect3;
			getDescendantRect(lp.mAnchorView, anchorRect);
			getChildRect(child, false, childRect);
			int childWidth = child.getMeasuredWidth();
			int childHeight = child.getMeasuredHeight();
			getDesiredAnchoredChildRectWithoutConstraints(child, layoutDirection, anchorRect, desiredChildRect, lp, childWidth, childHeight);
			if (desiredChildRect.left != childRect.left || desiredChildRect.top != childRect.top) {
				changed = true;
			} else {
				constrainChildRect(lp, desiredChildRect, childWidth, childHeight);
				dx = desiredChildRect.left - childRect.left;
				dy = desiredChildRect.top - childRect.top;
			}
			constrainChildRect(lp, desiredChildRect, childWidth, childHeight);
			dx = desiredChildRect.left - childRect.left;
			dy = desiredChildRect.top - childRect.top;
			if (dx != 0) {
				ViewCompat.offsetLeftAndRight(child, dx);
			}
			if (dy != 0) {
				ViewCompat.offsetTopAndBottom(child, dy);
			}
			if (changed) {
				Behavior b = lp.getBehavior();
				if (b != null) {
					b.onDependentViewChanged(this, child, lp.mAnchorView);
				}
			}
		}
	}

	public void onAttachedToWindow() {
		super.onAttachedToWindow();
		resetTouchBehaviors();
		if (mNeedsPreDrawListener) {
			if (mOnPreDrawListener == null) {
				mOnPreDrawListener = new OnPreDrawListener(this);
			}
			getViewTreeObserver().addOnPreDrawListener(mOnPreDrawListener);
		}
		if (mLastInsets != null || !ViewCompat.getFitsSystemWindows(this)) {
			mIsAttachedToWindow = true;
		} else {
			ViewCompat.requestApplyInsets(this);
			mIsAttachedToWindow = true;
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	final void onChildViewsChanged(int r19_type) {
		r18_this = this;
		r13 = android.support.v4.view.ViewCompat.getLayoutDirection(r18);
		r0 = r18;
		r15 = r0.mDependencySortedChildren;
		r6 = r15.size();
		r0 = r18;
		r10 = r0.mTempRect4;
		r10_inset.setEmpty();
		r9 = 0;
	L_0x0014:
		if (r9_i >= r6_childCount) goto L_0x0114;
	L_0x0016:
		r0 = r18;
		r15 = r0.mDependencySortedChildren;
		r5 = r15.get(r9_i);
		r5 = (android.view.View) r5;
		r14 = r5_child.getLayoutParams();
		r14 = (android.support.design.widget.CoordinatorLayout.LayoutParams) r14;
		r11 = 0;
	L_0x0027:
		if (r11_j >= r9_i) goto L_0x003f;
	L_0x0029:
		r0 = r18;
		r15 = r0.mDependencySortedChildren;
		r3 = r15.get(r11_j);
		r3 = (android.view.View) r3;
		r15 = r14_lp.mAnchorDirectChild;
		if (r15 != r3_checkChild) goto L_0x003c;
	L_0x0037:
		r0 = r18;
		r0.offsetChildToAnchor(r5_child, r13_layoutDirection);
	L_0x003c:
		r11_j++;
		goto L_0x0027;
	L_0x003f:
		r0 = r18;
		r7 = r0.mTempRect1;
		r15 = 1;
		r0 = r18;
		r0.getChildRect(r5_child, r15, r7_drawRect);
		r15 = r14_lp.insetEdge;
		if (r15 == 0) goto L_0x0063;
	L_0x004d:
		r15 = r7_drawRect.isEmpty();
		if (r15 != 0) goto L_0x0063;
	L_0x0053:
		r15 = r14_lp.insetEdge;
		r1 = android.support.v4.view.GravityCompat.getAbsoluteGravity(r15, r13_layoutDirection);
		r15 = r1_absInsetEdge & 112;
		switch(r15) {
			case 48: goto L_0x0086;
			case 80: goto L_0x0093;
			default: goto L_0x005e;
		}
	L_0x005e:
		r15 = r1_absInsetEdge & 7;
		switch(r15) {
			case 3: goto L_0x00a6;
			case 4: goto L_0x0063;
			case 5: goto L_0x00b3;
			default: goto L_0x0063;
		}
	L_0x0063:
		r15 = r14_lp.dodgeInsetEdges;
		if (r15 == 0) goto L_0x0072;
	L_0x0067:
		r15 = r5_child.getVisibility();
		if (r15 != 0) goto L_0x0072;
	L_0x006d:
		r0 = r18;
		r0.offsetChildByInset(r5_child, r10_inset, r13_layoutDirection);
	L_0x0072:
		if (r19_type != 0) goto L_0x00cb;
	L_0x0074:
		r0 = r18;
		r12 = r0.mTempRect2;
		r0 = r18;
		r0.getLastChildRect(r5_child, r12_lastDrawRect);
		r15 = r12_lastDrawRect.equals(r7_drawRect);
		if (r15 == 0) goto L_0x00c6;
	L_0x0083:
		r9_i++;
		goto L_0x0014;
	L_0x0086:
		r15 = r10_inset.top;
		r0 = r7_drawRect.bottom;
		r16 = r0;
		r15 = java.lang.Math.max(r15, r16);
		r10_inset.top = r15;
		goto L_0x005e;
	L_0x0093:
		r15 = r10_inset.bottom;
		r16 = r18.getHeight();
		r0 = r7_drawRect.top;
		r17 = r0;
		r16 -= r17;
		r15 = java.lang.Math.max(r15, r16);
		r10_inset.bottom = r15;
		goto L_0x005e;
	L_0x00a6:
		r15 = r10_inset.left;
		r0 = r7_drawRect.right;
		r16 = r0;
		r15 = java.lang.Math.max(r15, r16);
		r10_inset.left = r15;
		goto L_0x0063;
	L_0x00b3:
		r15 = r10_inset.right;
		r16 = r18.getWidth();
		r0 = r7_drawRect.left;
		r17 = r0;
		r16 -= r17;
		r15 = java.lang.Math.max(r15, r16);
		r10_inset.right = r15;
		goto L_0x0063;
	L_0x00c6:
		r0 = r18;
		r0.recordLastChildRect(r5_child, r7_drawRect);
	L_0x00cb:
		r11_j = r9_i + 1;
	L_0x00cd:
		if (r11_j >= r6_childCount) goto L_0x0083;
	L_0x00cf:
		r0 = r18;
		r15 = r0.mDependencySortedChildren;
		r3_checkChild = r15.get(r11_j);
		r3_checkChild = (android.view.View) r3_checkChild;
		r4 = r3_checkChild.getLayoutParams();
		r4 = (android.support.design.widget.CoordinatorLayout.LayoutParams) r4;
		r2 = r4_checkLp.getBehavior();
		if (r2_b == 0) goto L_0x00f8;
	L_0x00e5:
		r0 = r18;
		r15 = r2_b.layoutDependsOn(r0, r3_checkChild, r5_child);
		if (r15 == 0) goto L_0x00f8;
	L_0x00ed:
		if (r19_type != 0) goto L_0x00fb;
	L_0x00ef:
		r15 = r4_checkLp.getChangedAfterNestedScroll();
		if (r15 == 0) goto L_0x00fb;
	L_0x00f5:
		r4_checkLp.resetChangedAfterNestedScroll();
	L_0x00f8:
		r11_j++;
		goto L_0x00cd;
	L_0x00fb:
		switch(r19_type) {
			case 2: goto L_0x010d;
			default: goto L_0x00fe;
		}
	L_0x00fe:
		r0 = r18;
		r8 = r2_b.onDependentViewChanged(r0, r3_checkChild, r5_child);
	L_0x0104:
		r15 = 1;
		r0 = r19_type;
		if (r0 != r15) goto L_0x00f8;
	L_0x0109:
		r4_checkLp.setChangedAfterNestedScroll(r8_handled);
		goto L_0x00f8;
	L_0x010d:
		r0 = r18;
		r2_b.onDependentViewRemoved(r0, r3_checkChild, r5_child);
		r8_handled = 1;
		goto L_0x0104;
	L_0x0114:
		return;
	}
	*/
	final void onChildViewsChanged(int type) {
		int layoutDirection = ViewCompat.getLayoutDirection(this);
		int childCount = mDependencySortedChildren.size();
		Rect inset = mTempRect4;
		inset.setEmpty();
		int i = TYPE_ON_INTERCEPT;
		while (i < childCount) {
			View child = (View) mDependencySortedChildren.get(i);
			LayoutParams lp = (LayoutParams) child.getLayoutParams();
			int j = TYPE_ON_INTERCEPT;
			while (j < i) {
				if (lp.mAnchorDirectChild == ((View) mDependencySortedChildren.get(j))) {
					offsetChildToAnchor(child, layoutDirection);
				}
				j++;
			}
			Rect drawRect = mTempRect1;
			getChildRect(child, true, drawRect);
			View checkChild;
			LayoutParams checkLp;
			Behavior b;
			boolean handled;
			if (lp.insetEdge == 0 || drawRect.isEmpty()) {
				if (lp.dodgeInsetEdges == 0 || child.getVisibility() != 0) {
					j = i + 1;
					while (j < childCount) {
						checkChild = mDependencySortedChildren.get(j);
						checkLp = (LayoutParams) checkChild.getLayoutParams();
						b = checkLp.getBehavior();
						if (b == null || !b.layoutDependsOn(this, checkChild, child)) {
							j++;
						} else if (type != 0 || !checkLp.getChangedAfterNestedScroll()) {
							switch(type) {
							case EVENT_VIEW_REMOVED:
								b.onDependentViewRemoved(this, checkChild, child);
								handled = true;
								if (type != 1) {
									checkLp.setChangedAfterNestedScroll(handled);
								}
								j++;
								break;
							}
							handled = b.onDependentViewChanged(this, checkChild, child);
							if (type != 1) {
								j++;
							} else {
								checkLp.setChangedAfterNestedScroll(handled);
								j++;
							}
						} else {
							checkLp.resetChangedAfterNestedScroll();
							j++;
						}
					}
					i++;
				} else {
					offsetChildByInset(child, inset, layoutDirection);
					j = i + 1;
					while (j < childCount) {
						checkChild = mDependencySortedChildren.get(j);
						checkLp = (LayoutParams) checkChild.getLayoutParams();
						b = checkLp.getBehavior();
						if (b == null || !b.layoutDependsOn(this, checkChild, child)) {
							j++;
						} else if (type != 0 || !checkLp.getChangedAfterNestedScroll()) {
							switch(type) {
							case EVENT_VIEW_REMOVED:
								b.onDependentViewRemoved(this, checkChild, child);
								handled = true;
								if (type != 1) {
									checkLp.setChangedAfterNestedScroll(handled);
								}
								j++;
								break;
							}
							handled = b.onDependentViewChanged(this, checkChild, child);
							if (type != 1) {
								j++;
							} else {
								checkLp.setChangedAfterNestedScroll(handled);
								j++;
							}
						} else {
							checkLp.resetChangedAfterNestedScroll();
							j++;
						}
					}
					i++;
				}
			} else {
				int absInsetEdge = GravityCompat.getAbsoluteGravity(lp.insetEdge, layoutDirection);
				switch((absInsetEdge & 112)) {
				case NalUnitTypes.NAL_TYPE_UNSPEC48:
					inset.top = Math.max(inset.top, drawRect.bottom);
					break;
				case android.support.v7.appcompat.R.styleable.AppCompatTheme_panelMenuListWidth:
					inset.bottom = Math.max(inset.bottom, getHeight() - drawRect.top);
					break;
				}
				switch((absInsetEdge & 7)) {
				case ConnectionsManager.ConnectionStateConnected:
					inset.left = Math.max(inset.left, drawRect.right);
					break;
				case SQLiteCursor.FIELD_TYPE_NULL:
					inset.right = Math.max(inset.right, getWidth() - drawRect.left);
					break;
				}
				if (lp.dodgeInsetEdges == 0 || child.getVisibility() != 0) {
					j = i + 1;
					while (j < childCount) {
						checkChild = mDependencySortedChildren.get(j);
						checkLp = (LayoutParams) checkChild.getLayoutParams();
						b = checkLp.getBehavior();
						if (b == null || !b.layoutDependsOn(this, checkChild, child)) {
							j++;
						} else if (type != 0 || !checkLp.getChangedAfterNestedScroll()) {
							switch(type) {
							case EVENT_VIEW_REMOVED:
								b.onDependentViewRemoved(this, checkChild, child);
								handled = true;
								if (type != 1) {
									checkLp.setChangedAfterNestedScroll(handled);
								}
								j++;
								break;
							}
							handled = b.onDependentViewChanged(this, checkChild, child);
							if (type != 1) {
								j++;
							} else {
								checkLp.setChangedAfterNestedScroll(handled);
								j++;
							}
						} else {
							checkLp.resetChangedAfterNestedScroll();
							j++;
						}
					}
					i++;
				} else {
					offsetChildByInset(child, inset, layoutDirection);
					j = i + 1;
					while (j < childCount) {
						checkChild = mDependencySortedChildren.get(j);
						checkLp = (LayoutParams) checkChild.getLayoutParams();
						b = checkLp.getBehavior();
						if (b == null || !b.layoutDependsOn(this, checkChild, child)) {
							j++;
						} else if (type != 0 || !checkLp.getChangedAfterNestedScroll()) {
							switch(type) {
							case EVENT_VIEW_REMOVED:
								b.onDependentViewRemoved(this, checkChild, child);
								handled = true;
								if (type != 1) {
									checkLp.setChangedAfterNestedScroll(handled);
								}
								j++;
								break;
							}
							handled = b.onDependentViewChanged(this, checkChild, child);
							if (type != 1) {
								j++;
							} else {
								checkLp.setChangedAfterNestedScroll(handled);
								j++;
							}
						} else {
							checkLp.resetChangedAfterNestedScroll();
							j++;
						}
					}
					i++;
				}
			}
		}
	}

	public void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		resetTouchBehaviors();
		if (!mNeedsPreDrawListener || mOnPreDrawListener == null) {
			if (mNestedScrollingTarget == null) {
				onStopNestedScroll(mNestedScrollingTarget);
			}
			mIsAttachedToWindow = false;
		} else {
			getViewTreeObserver().removeOnPreDrawListener(mOnPreDrawListener);
			if (mNestedScrollingTarget == null) {
				mIsAttachedToWindow = false;
			} else {
				onStopNestedScroll(mNestedScrollingTarget);
				mIsAttachedToWindow = false;
			}
		}
	}

	public void onDraw(Canvas c) {
		int r1i = TYPE_ON_INTERCEPT;
		super.onDraw(c);
		if (!mDrawStatusBarBackground || mStatusBarBackground == null) {
		} else {
			int inset;
			if (mLastInsets != null) {
				inset = mLastInsets.getSystemWindowInsetTop();
			} else {
				inset = 0;
			}
			if (inset > 0) {
				mStatusBarBackground.setBounds(r1i, r1i, getWidth(), inset);
				mStatusBarBackground.draw(c);
			}
		}
	}

	public boolean onInterceptTouchEvent(MotionEvent ev) {
		int action = MotionEventCompat.getActionMasked(ev);
		if (action == 0) {
			resetTouchBehaviors();
		}
		boolean intercepted = performIntercept(ev, TYPE_ON_INTERCEPT);
		if (false) {
			null.recycle();
		}
		if (action == 1 || action == 3) {
			resetTouchBehaviors();
		} else {
			return intercepted;
		}
		return intercepted;
	}

	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		int layoutDirection = ViewCompat.getLayoutDirection(this);
		int i = TYPE_ON_INTERCEPT;
		while (i < mDependencySortedChildren.size()) {
			View child = (View) mDependencySortedChildren.get(i);
			Behavior behavior = ((LayoutParams) child.getLayoutParams()).getBehavior();
			if (behavior == null || !behavior.onLayoutChild(this, child, layoutDirection)) {
				onLayoutChild(child, layoutDirection);
			} else {
				i++;
			}
			i++;
		}
	}

	public void onLayoutChild(View child, int layoutDirection) {
		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		if (lp.checkAnchorChanged()) {
			throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
		} else if (lp.mAnchorView != null) {
			layoutChildWithAnchor(child, lp.mAnchorView, layoutDirection);
		} else if (lp.keyline >= 0) {
			layoutChildWithKeyline(child, lp.keyline, layoutDirection);
		} else {
			layoutChild(child, layoutDirection);
		}
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		boolean applyInsets;
		prepareChildren();
		ensurePreDrawListener();
		int paddingLeft = getPaddingLeft();
		int paddingTop = getPaddingTop();
		int paddingRight = getPaddingRight();
		int paddingBottom = getPaddingBottom();
		int layoutDirection = ViewCompat.getLayoutDirection(this);
		if (layoutDirection == 1) {
			isRtl = true;
		} else {
			isRtl = false;
		}
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int widthSize = MeasureSpec.getSize(widthMeasureSpec);
		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		int heightSize = MeasureSpec.getSize(heightMeasureSpec);
		int widthPadding = paddingLeft + paddingRight;
		int heightPadding = paddingTop + paddingBottom;
		int widthUsed = getSuggestedMinimumWidth();
		int heightUsed = getSuggestedMinimumHeight();
		int childState = TYPE_ON_INTERCEPT;
		if (mLastInsets == null || !ViewCompat.getFitsSystemWindows(this)) {
			applyInsets = false;
		} else {
			applyInsets = true;
		}
		int childCount = mDependencySortedChildren.size();
		int i = TYPE_ON_INTERCEPT;
		while (i < childCount) {
			View child = (View) mDependencySortedChildren.get(i);
			LayoutParams lp = (LayoutParams) child.getLayoutParams();
			int keylineWidthUsed = TYPE_ON_INTERCEPT;
			int childWidthMeasureSpec;
			int childHeightMeasureSpec;
			Behavior b;
			if (lp.keyline < 0 || widthMode == 0) {
				childWidthMeasureSpec = widthMeasureSpec;
				childHeightMeasureSpec = heightMeasureSpec;
				if (!applyInsets || ViewCompat.getFitsSystemWindows(child)) {
					b = lp.getBehavior();
					if (b == null || !b.onMeasureChild(this, child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT)) {
						onMeasureChild(child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT);
					} else {
						widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
						heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
						childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
						i++;
					}
					widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
					heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
					childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
					i++;
				} else {
					childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(widthSize - (mLastInsets.getSystemWindowInsetLeft() + mLastInsets.getSystemWindowInsetRight()), widthMode);
					childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(heightSize - (mLastInsets.getSystemWindowInsetTop() + mLastInsets.getSystemWindowInsetBottom()), heightMode);
					b = lp.getBehavior();
					if (b == null || !b.onMeasureChild(this, child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT)) {
						onMeasureChild(child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT);
					} else {
						widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
						heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
						childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
						i++;
					}
					widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
					heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
					childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
					i++;
				}
			} else {
				int keylinePos = getKeyline(lp.keyline);
				int keylineGravity = GravityCompat.getAbsoluteGravity(resolveKeylineGravity(lp.gravity), layoutDirection) & 7;
				if (keylineGravity != ConnectionsManager.ConnectionStateConnected || isRtl) {
					if (keylineGravity != 5 || !isRtl) {
						if (keylineGravity != 5 || isRtl) {
							if (keylineGravity != 3 || !isRtl) {
								childWidthMeasureSpec = widthMeasureSpec;
								childHeightMeasureSpec = heightMeasureSpec;
								if (!applyInsets || ViewCompat.getFitsSystemWindows(child)) {
									b = lp.getBehavior();
									if (b == null || !b.onMeasureChild(this, child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT)) {
										onMeasureChild(child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT);
									} else {
										widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
										heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
										childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
										i++;
									}
									widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
									heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
									childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
									i++;
								} else {
									childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(widthSize - (mLastInsets.getSystemWindowInsetLeft() + mLastInsets.getSystemWindowInsetRight()), widthMode);
									childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(heightSize - (mLastInsets.getSystemWindowInsetTop() + mLastInsets.getSystemWindowInsetBottom()), heightMode);
									b = lp.getBehavior();
									if (b == null || !b.onMeasureChild(this, child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT)) {
										onMeasureChild(child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT);
									} else {
										widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
										heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
										childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
										i++;
									}
									widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
									heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
									childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
									i++;
								}
							}
						} else {
							keylineWidthUsed = Math.max(TYPE_ON_INTERCEPT, keylinePos - paddingLeft);
						}
						keylineWidthUsed = Math.max(TYPE_ON_INTERCEPT, keylinePos - paddingLeft);
						childWidthMeasureSpec = widthMeasureSpec;
						childHeightMeasureSpec = heightMeasureSpec;
						if (!applyInsets || ViewCompat.getFitsSystemWindows(child)) {
							b = lp.getBehavior();
							if (b == null || !b.onMeasureChild(this, child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT)) {
								onMeasureChild(child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT);
							} else {
								widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
								heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
								childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
								i++;
							}
							widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
							heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
							childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
							i++;
						} else {
							childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(widthSize - (mLastInsets.getSystemWindowInsetLeft() + mLastInsets.getSystemWindowInsetRight()), widthMode);
							childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(heightSize - (mLastInsets.getSystemWindowInsetTop() + mLastInsets.getSystemWindowInsetBottom()), heightMode);
							b = lp.getBehavior();
							if (b == null || !b.onMeasureChild(this, child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT)) {
								onMeasureChild(child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT);
							} else {
								widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
								heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
								childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
								i++;
							}
							widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
							heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
							childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
							i++;
						}
					}
				} else {
					keylineWidthUsed = Math.max(TYPE_ON_INTERCEPT, (widthSize - paddingRight) - keylinePos);
				}
				keylineWidthUsed = Math.max(TYPE_ON_INTERCEPT, (widthSize - paddingRight) - keylinePos);
				childWidthMeasureSpec = widthMeasureSpec;
				childHeightMeasureSpec = heightMeasureSpec;
				if (!applyInsets || ViewCompat.getFitsSystemWindows(child)) {
					b = lp.getBehavior();
					if (b == null || !b.onMeasureChild(this, child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT)) {
						onMeasureChild(child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT);
					} else {
						widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
						heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
						childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
						i++;
					}
					widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
					heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
					childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
					i++;
				} else {
					childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(widthSize - (mLastInsets.getSystemWindowInsetLeft() + mLastInsets.getSystemWindowInsetRight()), widthMode);
					childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(heightSize - (mLastInsets.getSystemWindowInsetTop() + mLastInsets.getSystemWindowInsetBottom()), heightMode);
					b = lp.getBehavior();
					if (b == null || !b.onMeasureChild(this, child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT)) {
						onMeasureChild(child, childWidthMeasureSpec, keylineWidthUsed, childHeightMeasureSpec, TYPE_ON_INTERCEPT);
					} else {
						widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
						heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
						childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
						i++;
					}
					widthUsed = Math.max(widthUsed, ((child.getMeasuredWidth() + widthPadding) + lp.leftMargin) + lp.rightMargin);
					heightUsed = Math.max(heightUsed, ((child.getMeasuredHeight() + heightPadding) + lp.topMargin) + lp.bottomMargin);
					childState = ViewCompat.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
					i++;
				}
			}
		}
		setMeasuredDimension(ViewCompat.resolveSizeAndState(widthUsed, widthMeasureSpec, -16777216 & childState), ViewCompat.resolveSizeAndState(heightUsed, heightMeasureSpec, childState << 16));
	}

	public void onMeasureChild(View child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed) {
		measureChildWithMargins(child, parentWidthMeasureSpec, widthUsed, parentHeightMeasureSpec, heightUsed);
	}

	public boolean onNestedFling(View target, float velocityX, float velocityY, boolean consumed) {
		boolean handled = false;
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			View view = getChildAt(i);
			LayoutParams lp = (LayoutParams) view.getLayoutParams();
			if (!lp.isNestedScrollAccepted()) {
				i++;
			} else {
				Behavior viewBehavior = lp.getBehavior();
				if (viewBehavior != null) {
					handled |= viewBehavior.onNestedFling(this, view, target, velocityX, velocityY, consumed);
				}
				i++;
			}
		}
		if (handled) {
			onChildViewsChanged(TYPE_ON_TOUCH);
		}
		return handled;
	}

	public boolean onNestedPreFling(View target, float velocityX, float velocityY) {
		boolean handled = false;
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			View view = getChildAt(i);
			LayoutParams lp = (LayoutParams) view.getLayoutParams();
			if (!lp.isNestedScrollAccepted()) {
				i++;
			} else {
				Behavior viewBehavior = lp.getBehavior();
				if (viewBehavior != null) {
					handled |= viewBehavior.onNestedPreFling(this, view, target, velocityX, velocityY);
				}
				i++;
			}
		}
		return handled;
	}

	public void onNestedPreScroll(View target, int dx, int dy, int[] consumed) {
		int xConsumed = TYPE_ON_INTERCEPT;
		int yConsumed = TYPE_ON_INTERCEPT;
		boolean accepted = false;
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			View view = getChildAt(i);
			LayoutParams lp = (LayoutParams) view.getLayoutParams();
			if (!lp.isNestedScrollAccepted()) {
				i++;
			} else {
				Behavior viewBehavior = lp.getBehavior();
				if (viewBehavior != null) {
					mTempIntPair[1] = 0;
					mTempIntPair[0] = 0;
					viewBehavior.onNestedPreScroll(this, view, target, dx, dy, mTempIntPair);
					if (dx > 0) {
						xConsumed = Math.max(xConsumed, mTempIntPair[0]);
					} else {
						xConsumed = Math.min(xConsumed, mTempIntPair[0]);
					}
					if (dy > 0) {
						yConsumed = Math.max(yConsumed, mTempIntPair[1]);
					} else {
						yConsumed = Math.min(yConsumed, mTempIntPair[1]);
					}
					accepted = true;
				}
				i++;
			}
		}
		consumed[0] = xConsumed;
		consumed[1] = yConsumed;
		if (accepted) {
			onChildViewsChanged(TYPE_ON_TOUCH);
		}
	}

	public void onNestedScroll(View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
		boolean accepted = false;
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			View view = getChildAt(i);
			LayoutParams lp = (LayoutParams) view.getLayoutParams();
			if (!lp.isNestedScrollAccepted()) {
				i++;
			} else {
				Behavior viewBehavior = lp.getBehavior();
				if (viewBehavior != null) {
					viewBehavior.onNestedScroll(this, view, target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
					accepted = true;
				}
				i++;
			}
		}
		if (accepted) {
			onChildViewsChanged(TYPE_ON_TOUCH);
		}
	}

	public void onNestedScrollAccepted(View child, View target, int nestedScrollAxes) {
		mNestedScrollingParentHelper.onNestedScrollAccepted(child, target, nestedScrollAxes);
		mNestedScrollingDirectChild = child;
		mNestedScrollingTarget = target;
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			View view = getChildAt(i);
			LayoutParams lp = (LayoutParams) view.getLayoutParams();
			if (!lp.isNestedScrollAccepted()) {
				i++;
			} else {
				Behavior viewBehavior = lp.getBehavior();
				if (viewBehavior != null) {
					viewBehavior.onNestedScrollAccepted(this, view, child, target, nestedScrollAxes);
				}
				i++;
			}
		}
	}

	protected void onRestoreInstanceState(Parcelable state) {
		if (!(state instanceof SavedState)) {
			super.onRestoreInstanceState(state);
		} else {
			SavedState ss = (SavedState) state;
			super.onRestoreInstanceState(ss.getSuperState());
			SparseArray<Parcelable> behaviorStates = ss.behaviorStates;
			int i = TYPE_ON_INTERCEPT;
			while (i < getChildCount()) {
				View child = getChildAt(i);
				int childId = child.getId();
				Behavior b = getResolvedLayoutParams(child).getBehavior();
				if (childId == -1 || b == null) {
					i++;
				} else {
					Parcelable savedState = (Parcelable) behaviorStates.get(childId);
					if (savedState != null) {
						b.onRestoreInstanceState(this, child, savedState);
					}
					i++;
				}
			}
		}
	}

	protected Parcelable onSaveInstanceState() {
		SavedState ss = new SavedState(super.onSaveInstanceState());
		SparseArray<Parcelable> behaviorStates = new SparseArray();
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			View child = getChildAt(i);
			int childId = child.getId();
			Behavior b = ((LayoutParams) child.getLayoutParams()).getBehavior();
			if (childId == -1 || b == null) {
				i++;
			} else {
				Parcelable state = b.onSaveInstanceState(this, child);
				if (state != null) {
					behaviorStates.append(childId, state);
				}
				i++;
			}
		}
		ss.behaviorStates = behaviorStates;
		return ss;
	}

	public boolean onStartNestedScroll(View child, View target, int nestedScrollAxes) {
		boolean handled = false;
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			View view = getChildAt(i);
			LayoutParams lp = (LayoutParams) view.getLayoutParams();
			Behavior viewBehavior = lp.getBehavior();
			if (viewBehavior != null) {
				boolean accepted = viewBehavior.onStartNestedScroll(this, view, child, target, nestedScrollAxes);
				handled |= accepted;
				lp.acceptNestedScroll(accepted);
			} else {
				lp.acceptNestedScroll(false);
			}
			i++;
		}
		return handled;
	}

	public void onStopNestedScroll(View target) {
		mNestedScrollingParentHelper.onStopNestedScroll(target);
		int i = TYPE_ON_INTERCEPT;
		while (i < getChildCount()) {
			View view = getChildAt(i);
			LayoutParams lp = (LayoutParams) view.getLayoutParams();
			if (!lp.isNestedScrollAccepted()) {
				i++;
			} else {
				Behavior viewBehavior = lp.getBehavior();
				if (viewBehavior != null) {
					viewBehavior.onStopNestedScroll(this, view, target);
				}
				lp.resetNestedScroll();
				lp.resetChangedAfterNestedScroll();
				i++;
			}
		}
		mNestedScrollingDirectChild = null;
		mNestedScrollingTarget = null;
	}

	/* JADX WARNING: inconsistent code */
	/*
	public boolean onTouchEvent(android.view.MotionEvent r15_ev) {
		r14_this = this;
		r12 = 0;
		r11 = 0;
		r10 = 0;
		r8 = android.support.v4.view.MotionEventCompat.getActionMasked(r15_ev);
		r2 = r14.mBehaviorTouchView;
		if (r2 != 0) goto L_0x0012;
	L_0x000b:
		r2 = 1;
		r11_cancelSuper = r14.performIntercept(r15_ev, r2);
		if (r11_cancelSuper == 0) goto L_0x0026;
	L_0x0012:
		r2 = r14.mBehaviorTouchView;
		r13 = r2.getLayoutParams();
		r13 = (android.support.design.widget.CoordinatorLayout.LayoutParams) r13;
		r9 = r13_lp.getBehavior();
		if (r9_b == 0) goto L_0x0026;
	L_0x0020:
		r2 = r14.mBehaviorTouchView;
		r12_handled = r9_b.onTouchEvent(r14, r2, r15_ev);
	L_0x0026:
		r2 = r14.mBehaviorTouchView;
		if (r2 != 0) goto L_0x0042;
	L_0x002a:
		r2 = super.onTouchEvent(r15_ev);
		r12_handled |= r2;
	L_0x002f:
		if (r12_handled != 0) goto L_0x0033;
	L_0x0031:
		if (r8_action != 0) goto L_0x0033;
	L_0x0033:
		if (r10_cancelEvent == 0) goto L_0x0038;
	L_0x0035:
		r10_cancelEvent.recycle();
	L_0x0038:
		r2 = 1;
		if (r8_action == r2) goto L_0x003e;
	L_0x003b:
		r2 = 3;
		if (r8_action != r2) goto L_0x0041;
	L_0x003e:
		r14.resetTouchBehaviors();
	L_0x0041:
		return r12_handled;
	L_0x0042:
		if (r11_cancelSuper == 0) goto L_0x002f;
	L_0x0044:
		if (r10_cancelEvent != 0) goto L_0x0053;
	L_0x0046:
		r0 = android.os.SystemClock.uptimeMillis();
		r4 = 3;
		r5 = 0;
		r6 = 0;
		r7 = 0;
		r2 = r0_now;
		r10_cancelEvent = android.view.MotionEvent.obtain(r0_now, r2, r4, r5, r6, r7);
	L_0x0053:
		super.onTouchEvent(r10_cancelEvent);
		goto L_0x002f;
	}
	*/
	public boolean onTouchEvent(MotionEvent ev) {
		boolean handled = false;
		boolean cancelSuper = false;
		MotionEvent cancelEvent = null;
		int action = MotionEventCompat.getActionMasked(ev);
		Behavior b;
		if (mBehaviorTouchView == null) {
			cancelSuper = performIntercept(ev, TYPE_ON_TOUCH);
			if (cancelSuper) {
				b = ((LayoutParams) mBehaviorTouchView.getLayoutParams()).getBehavior();
				if (b == null) {
					handled = b.onTouchEvent(this, mBehaviorTouchView, ev);
				}
			}
		} else {
			b = ((LayoutParams) mBehaviorTouchView.getLayoutParams()).getBehavior();
			if (b == null) {
			} else {
				handled = b.onTouchEvent(this, mBehaviorTouchView, ev);
			}
		}
		if (mBehaviorTouchView == null) {
			handled |= super.onTouchEvent(ev);
		} else if (cancelSuper) {
			if (!false) {
				long now = SystemClock.uptimeMillis();
				cancelEvent = MotionEvent.obtain(now, now, ConnectionsManager.ConnectionStateConnected, BitmapDescriptorFactory.HUE_RED, BitmapDescriptorFactory.HUE_RED, TYPE_ON_INTERCEPT);
			}
			super.onTouchEvent(cancelEvent);
		}
		if (handled || action != 0) {
			if (action == 1 || action == 3) {
				resetTouchBehaviors();
				return handled;
			} else {
				return handled;
			}
		} else if (action == 1 || action == 3) {
			resetTouchBehaviors();
			return handled;
		} else {
			return handled;
		}
	}

	void recordLastChildRect(View child, Rect r) {
		((LayoutParams) child.getLayoutParams()).setLastChildRect(r);
	}

	void removePreDrawListener() {
		if (!mIsAttachedToWindow || mOnPreDrawListener == null) {
			mNeedsPreDrawListener = false;
		} else {
			getViewTreeObserver().removeOnPreDrawListener(mOnPreDrawListener);
			mNeedsPreDrawListener = false;
		}
	}

	public boolean requestChildRectangleOnScreen(View child, Rect rectangle, boolean immediate) {
		Behavior behavior = ((LayoutParams) child.getLayoutParams()).getBehavior();
		if (behavior == null || !behavior.onRequestChildRectangleOnScreen(this, child, rectangle, immediate)) {
			return super.requestChildRectangleOnScreen(child, rectangle, immediate);
		} else {
			return true;
		}
	}

	public void requestDisallowInterceptTouchEvent(boolean disallowIntercept) {
		super.requestDisallowInterceptTouchEvent(disallowIntercept);
		if (!disallowIntercept || mDisallowInterceptReset) {
		} else {
			resetTouchBehaviors();
			mDisallowInterceptReset = true;
		}
	}

	public void setFitsSystemWindows(boolean fitSystemWindows) {
		super.setFitsSystemWindows(fitSystemWindows);
		setupForInsets();
	}

	public void setOnHierarchyChangeListener(OnHierarchyChangeListener onHierarchyChangeListener) {
		mOnHierarchyChangeListener = onHierarchyChangeListener;
	}

	public void setStatusBarBackground(@Nullable Drawable bg) {
		Drawable r0_Drawable = null;
		if (mStatusBarBackground != bg) {
			if (mStatusBarBackground != null) {
				mStatusBarBackground.setCallback(null);
			}
			if (bg != null) {
				r0_Drawable = bg.mutate();
			}
			mStatusBarBackground = r0_Drawable;
			if (mStatusBarBackground != null) {
				boolean r0z;
				if (mStatusBarBackground.isStateful()) {
					mStatusBarBackground.setState(getDrawableState());
				}
				DrawableCompat.setLayoutDirection(mStatusBarBackground, ViewCompat.getLayoutDirection(this));
				Drawable r2_Drawable = mStatusBarBackground;
				if (getVisibility() == 0) {
					r0z = true;
				} else {
					r0z = false;
				}
				r2_Drawable.setVisible(r0z, false);
				mStatusBarBackground.setCallback(this);
			}
			ViewCompat.postInvalidateOnAnimation(this);
		}
	}

	public void setStatusBarBackgroundColor(@ColorInt int color) {
		setStatusBarBackground(new ColorDrawable(color));
	}

	public void setStatusBarBackgroundResource(@DrawableRes int resId) {
		Drawable r0_Drawable;
		if (resId != 0) {
			r0_Drawable = ContextCompat.getDrawable(getContext(), resId);
		} else {
			r0_Drawable = null;
		}
		setStatusBarBackground(r0_Drawable);
	}

	public void setVisibility(int visibility) {
		boolean visible;
		super.setVisibility(visibility);
		if (visibility == 0) {
			visible = true;
		} else {
			visible = false;
		}
		if (mStatusBarBackground == null || mStatusBarBackground.isVisible() == visible) {
		} else {
			mStatusBarBackground.setVisible(visible, false);
		}
	}

	final WindowInsetsCompat setWindowInsets(WindowInsetsCompat insets) {
		boolean r1z = true;
		if (!ViewUtils.objectEquals(mLastInsets, insets)) {
			boolean r0z;
			mLastInsets = insets;
			if (insets == null || insets.getSystemWindowInsetTop() <= 0) {
				r0z = false;
			} else {
				r0z = true;
			}
			mDrawStatusBarBackground = r0z;
			if (mDrawStatusBarBackground || getBackground() != null) {
				r1z = false;
			} else {
				setWillNotDraw(r1z);
				requestLayout();
				return dispatchApplyWindowInsetsToBehaviors(insets);
			}
			setWillNotDraw(r1z);
			requestLayout();
			return dispatchApplyWindowInsetsToBehaviors(insets);
		} else {
			return insets;
		}
	}

	protected boolean verifyDrawable(Drawable who) {
		if (super.verifyDrawable(who) || who == mStatusBarBackground) {
			return true;
		} else {
			return false;
		}
	}
}
