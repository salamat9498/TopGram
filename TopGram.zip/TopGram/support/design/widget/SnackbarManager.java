package android.support.design.widget;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.lang.ref.WeakReference;
import org.telegram.tgnet.TLRPC;

class SnackbarManager {
	private static final int LONG_DURATION_MS = 2750;
	static final int MSG_TIMEOUT = 0;
	private static final int SHORT_DURATION_MS = 1500;
	private static SnackbarManager sSnackbarManager;
	private SnackbarRecord mCurrentSnackbar;
	private final Handler mHandler;
	private final Object mLock;
	private SnackbarRecord mNextSnackbar;

	static interface Callback {
		public void dismiss(int r1i);

		public void show();
	}

	class AnonymousClass_1 implements android.os.Handler.Callback {
		final /* synthetic */ SnackbarManager this$0;

		AnonymousClass_1(SnackbarManager this$0) {
			super();
			this.this$0 = this$0;
		}

		public boolean handleMessage(Message message) {
			switch(message.what) {
			case MSG_TIMEOUT:
				this$0.handleTimeout((SnackbarManager.SnackbarRecord) message.obj);
				return true;
			}
			return false;
		}
	}

	private static class SnackbarRecord {
		final WeakReference<SnackbarManager.Callback> callback;
		int duration;

		SnackbarRecord(int duration, SnackbarManager.Callback callback) {
			super();
			this.callback = new WeakReference(callback);
			this.duration = duration;
		}

		boolean isSnackbar(SnackbarManager.Callback callback) {
			if (callback == null || this.callback.get() != callback) {
				return false;
			} else {
				return true;
			}
		}
	}


	private SnackbarManager() {
		super();
		mLock = new Object();
		mHandler = new Handler(Looper.getMainLooper(), new AnonymousClass_1(this));
	}

	private boolean cancelSnackbarLocked(SnackbarRecord record, int event) {
		Callback callback = (Callback) record.callback.get();
		if (callback != null) {
			mHandler.removeCallbacksAndMessages(record);
			callback.dismiss(event);
			return true;
		} else {
			return false;
		}
	}

	static SnackbarManager getInstance() {
		if (sSnackbarManager == null) {
			sSnackbarManager = new SnackbarManager();
		}
		return sSnackbarManager;
	}

	private boolean isCurrentSnackbarLocked(Callback callback) {
		if (mCurrentSnackbar == null || !mCurrentSnackbar.isSnackbar(callback)) {
			return false;
		} else {
			return true;
		}
	}

	private boolean isNextSnackbarLocked(Callback callback) {
		if (mNextSnackbar == null || !mNextSnackbar.isSnackbar(callback)) {
			return false;
		} else {
			return true;
		}
	}

	private void scheduleTimeoutLocked(SnackbarRecord r) {
		if (r.duration == -2) {
		} else {
			int durationMs = LONG_DURATION_MS;
			if (r.duration > 0) {
				durationMs = r.duration;
			} else if (r.duration == -1) {
				durationMs = SHORT_DURATION_MS;
			}
			mHandler.removeCallbacksAndMessages(r);
			mHandler.sendMessageDelayed(Message.obtain(mHandler, MSG_TIMEOUT, r), (long) durationMs);
		}
	}

	private void showNextSnackbarLocked() {
		if (mNextSnackbar != null) {
			mCurrentSnackbar = mNextSnackbar;
			mNextSnackbar = null;
			Callback callback = (Callback) mCurrentSnackbar.callback.get();
			if (callback != null) {
				callback.show();
			} else {
				mCurrentSnackbar = null;
			}
		}
	}

	public void cancelTimeout(Callback callback) {
		synchronized(mLock) {
			if (isCurrentSnackbarLocked(callback)) {
				mHandler.removeCallbacksAndMessages(mCurrentSnackbar);
			}
		}
	}

	public void dismiss(Callback callback, int event) {
		synchronized(mLock) {
			if (isCurrentSnackbarLocked(callback)) {
				cancelSnackbarLocked(mCurrentSnackbar, event);
			} else if (isNextSnackbarLocked(callback)) {
				cancelSnackbarLocked(mNextSnackbar, event);
			}
		}
	}

	void handleTimeout(SnackbarRecord record) {
		synchronized(mLock) {
			if (mCurrentSnackbar == record || mNextSnackbar == record) {
				cancelSnackbarLocked(record, TLRPC.USER_FLAG_FIRST_NAME);
			}
		}
	}

	public boolean isCurrent(Callback callback) {
		boolean r0z;
		synchronized(mLock) {
			r0z = isCurrentSnackbarLocked(callback);
		}
		return r0z;
	}

	public boolean isCurrentOrNext(Callback callback) {
		boolean r0z;
		synchronized(mLock) {
			if (isCurrentSnackbarLocked(callback) || isNextSnackbarLocked(callback)) {
				r0z = true;
			} else {
				r0z = false;
			}
		}
		return r0z;
	}

	public void onDismissed(Callback callback) {
		synchronized(mLock) {
			if (isCurrentSnackbarLocked(callback)) {
				mCurrentSnackbar = null;
				if (mNextSnackbar != null) {
					showNextSnackbarLocked();
				}
			}
		}
	}

	public void onShown(Callback callback) {
		synchronized(mLock) {
			if (isCurrentSnackbarLocked(callback)) {
				scheduleTimeoutLocked(mCurrentSnackbar);
			}
		}
	}

	public void restoreTimeout(Callback callback) {
		synchronized(mLock) {
			if (isCurrentSnackbarLocked(callback)) {
				scheduleTimeoutLocked(mCurrentSnackbar);
			}
		}
	}

	public void show(int duration, Callback callback) {
		Object r1_Object = mLock;
		synchronized(r1_Object) {
			try {
				if (isCurrentSnackbarLocked(callback)) {
					mCurrentSnackbar.duration = duration;
					mHandler.removeCallbacksAndMessages(mCurrentSnackbar);
					scheduleTimeoutLocked(mCurrentSnackbar);
				} else {
					if (isNextSnackbarLocked(callback)) {
						mNextSnackbar.duration = duration;
					} else {
						mNextSnackbar = new SnackbarRecord(duration, callback);
					}
					if (mCurrentSnackbar == null || !cancelSnackbarLocked(mCurrentSnackbar, TLRPC.USER_FLAG_LAST_NAME)) {
						mCurrentSnackbar = null;
						showNextSnackbarLocked();
					}
				}
			} catch (Throwable th) {
				return th;
			}
		}
	}
}
