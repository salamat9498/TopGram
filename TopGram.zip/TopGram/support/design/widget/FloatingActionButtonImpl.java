package android.support.design.widget;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.Nullable;
import android.support.design.R;
import android.support.design.widget.ValueAnimatorCompat.Creator;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.animation.Interpolator;

abstract class FloatingActionButtonImpl {
	static final Interpolator ANIM_INTERPOLATOR;
	static final int ANIM_STATE_HIDING = 1;
	static final int ANIM_STATE_NONE = 0;
	static final int ANIM_STATE_SHOWING = 2;
	static final int[] EMPTY_STATE_SET;
	static final int[] ENABLED_STATE_SET;
	static final int[] FOCUSED_ENABLED_STATE_SET;
	static final long PRESSED_ANIM_DELAY = 100;
	static final long PRESSED_ANIM_DURATION = 100;
	static final int[] PRESSED_ENABLED_STATE_SET;
	static final int SHOW_HIDE_ANIM_DURATION = 200;
	int mAnimState;
	final Creator mAnimatorCreator;
	CircularBorderDrawable mBorderDrawable;
	Drawable mContentBackground;
	float mElevation;
	private OnPreDrawListener mPreDrawListener;
	float mPressedTranslationZ;
	Drawable mRippleDrawable;
	final ShadowViewDelegate mShadowViewDelegate;
	Drawable mShapeDrawable;
	private final Rect mTmpRect;
	final VisibilityAwareImageButton mView;

	static interface InternalVisibilityChangedListener {
		public void onHidden();

		public void onShown();
	}

	class AnonymousClass_1 implements OnPreDrawListener {
		final /* synthetic */ FloatingActionButtonImpl this$0;

		AnonymousClass_1(FloatingActionButtonImpl this$0) {
			super();
			this.this$0 = this$0;
		}

		public boolean onPreDraw() {
			this$0.onPreDraw();
			return true;
		}
	}


	static {
		ANIM_INTERPOLATOR = AnimationUtils.FAST_OUT_LINEAR_IN_INTERPOLATOR;
		PRESSED_ENABLED_STATE_SET = new int[]{16842919, 16842910};
		FOCUSED_ENABLED_STATE_SET = new int[]{16842908, 16842910};
		int[] r0_int_A = new int[1];
		r0_int_A[0] = 16842910;
		ENABLED_STATE_SET = r0_int_A;
		EMPTY_STATE_SET = new int[0];
	}

	FloatingActionButtonImpl(VisibilityAwareImageButton view, ShadowViewDelegate shadowViewDelegate, Creator animatorCreator) {
		super();
		mAnimState = 0;
		mTmpRect = new Rect();
		mView = view;
		mShadowViewDelegate = shadowViewDelegate;
		mAnimatorCreator = animatorCreator;
	}

	private void ensurePreDrawListener() {
		if (mPreDrawListener == null) {
			mPreDrawListener = new AnonymousClass_1(this);
		}
	}

	CircularBorderDrawable createBorderDrawable(int borderWidth, ColorStateList backgroundTint) {
		Resources resources = mView.getResources();
		CircularBorderDrawable borderDrawable = newCircularDrawable();
		borderDrawable.setGradientColors(resources.getColor(R.color.design_fab_stroke_top_outer_color), resources.getColor(R.color.design_fab_stroke_top_inner_color), resources.getColor(R.color.design_fab_stroke_end_inner_color), resources.getColor(R.color.design_fab_stroke_end_outer_color));
		borderDrawable.setBorderWidth((float) borderWidth);
		borderDrawable.setBorderTint(backgroundTint);
		return borderDrawable;
	}

	GradientDrawable createShapeDrawable() {
		GradientDrawable d = new GradientDrawable();
		d.setShape(ANIM_STATE_HIDING);
		d.setColor(-1);
		return d;
	}

	final Drawable getContentBackground() {
		return mContentBackground;
	}

	abstract float getElevation();

	abstract void getPadding(Rect r1_Rect);

	abstract void hide(@Nullable InternalVisibilityChangedListener r1_InternalVisibilityChangedListener, boolean r2z);

	boolean isOrWillBeHidden() {
		if (mView.getVisibility() == 0) {
			if (mAnimState == 1) {
				return true;
			} else {
				return false;
			}
		} else if (mAnimState == 2) {
			return false;
		} else {
			return true;
		}
	}

	boolean isOrWillBeShown() {
		if (mView.getVisibility() != 0) {
			if (mAnimState == 2) {
				return true;
			} else {
				return false;
			}
		} else if (mAnimState == 1) {
			return false;
		} else {
			return true;
		}
	}

	abstract void jumpDrawableToCurrentState();

	CircularBorderDrawable newCircularDrawable() {
		return new CircularBorderDrawable();
	}

	void onAttachedToWindow() {
		if (requirePreDrawListener()) {
			ensurePreDrawListener();
			mView.getViewTreeObserver().addOnPreDrawListener(mPreDrawListener);
		}
	}

	abstract void onCompatShadowChanged();

	void onDetachedFromWindow() {
		if (mPreDrawListener != null) {
			mView.getViewTreeObserver().removeOnPreDrawListener(mPreDrawListener);
			mPreDrawListener = null;
		}
	}

	abstract void onDrawableStateChanged(int[] r1_int_A);

	abstract void onElevationsChanged(float r1f, float r2f);

	void onPaddingUpdated(Rect padding) {
	}

	void onPreDraw() {
	}

	boolean requirePreDrawListener() {
		return false;
	}

	abstract void setBackgroundDrawable(ColorStateList r1_ColorStateList, Mode r2_Mode, int r3i, int r4i);

	abstract void setBackgroundTintList(ColorStateList r1_ColorStateList);

	abstract void setBackgroundTintMode(Mode r1_Mode);

	final void setElevation(float elevation) {
		if (mElevation != elevation) {
			mElevation = elevation;
			onElevationsChanged(elevation, mPressedTranslationZ);
		}
	}

	final void setPressedTranslationZ(float translationZ) {
		if (mPressedTranslationZ != translationZ) {
			mPressedTranslationZ = translationZ;
			onElevationsChanged(mElevation, translationZ);
		}
	}

	abstract void setRippleColor(int r1i);

	abstract void show(@Nullable InternalVisibilityChangedListener r1_InternalVisibilityChangedListener, boolean r2z);

	final void updatePadding() {
		Rect rect = mTmpRect;
		getPadding(rect);
		onPaddingUpdated(rect);
		mShadowViewDelegate.setShadowPadding(rect.left, rect.top, rect.right, rect.bottom);
	}
}
