package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.design.R;
import android.support.design.widget.ValueAnimatorCompat.AnimatorListenerAdapter;
import android.support.design.widget.ValueAnimatorCompat.AnimatorUpdateListener;
import android.support.v4.util.Pools.Pool;
import android.support.v4.util.Pools.SimplePool;
import android.support.v4.util.Pools.SynchronizedPool;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.DecorView;
import android.support.v4.view.ViewPager.OnAdapterChangeListener;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.appcompat.R;
import android.support.v7.content.res.AppCompatResources;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout.LayoutParams;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.rey.material.R;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import org.telegram.tgnet.TLRPC;

@DecorView
public class TabLayout extends HorizontalScrollView {
	private static final int ANIMATION_DURATION = 300;
	static final int DEFAULT_GAP_TEXT_ICON = 8;
	private static final int DEFAULT_HEIGHT = 48;
	private static final int DEFAULT_HEIGHT_WITH_TEXT_ICON = 72;
	static final int FIXED_WRAP_GUTTER_MIN = 16;
	public static final int GRAVITY_CENTER = 1;
	public static final int GRAVITY_FILL = 0;
	private static final int INVALID_WIDTH = -1;
	public static final int MODE_FIXED = 1;
	public static final int MODE_SCROLLABLE = 0;
	static final int MOTION_NON_ADJACENT_OFFSET = 24;
	private static final int TAB_MIN_WIDTH_MARGIN = 56;
	private static final Pool<Tab> sTabPool;
	private AdapterChangeListener mAdapterChangeListener;
	private int mContentInsetStart;
	private OnTabSelectedListener mCurrentVpSelectedListener;
	int mMode;
	private TabLayoutOnPageChangeListener mPageChangeListener;
	private PagerAdapter mPagerAdapter;
	private DataSetObserver mPagerAdapterObserver;
	private final int mRequestedTabMaxWidth;
	private final int mRequestedTabMinWidth;
	private ValueAnimatorCompat mScrollAnimator;
	private final int mScrollableTabMinWidth;
	private OnTabSelectedListener mSelectedListener;
	private final ArrayList<OnTabSelectedListener> mSelectedListeners;
	private Tab mSelectedTab;
	private boolean mSetupViewPagerImplicitly;
	final int mTabBackgroundResId;
	int mTabGravity;
	int mTabMaxWidth;
	int mTabPaddingBottom;
	int mTabPaddingEnd;
	int mTabPaddingStart;
	int mTabPaddingTop;
	private final SlidingTabStrip mTabStrip;
	int mTabTextAppearance;
	ColorStateList mTabTextColors;
	float mTabTextMultiLineSize;
	float mTabTextSize;
	private final Pool<TabView> mTabViewPool;
	private final ArrayList<Tab> mTabs;
	ViewPager mViewPager;

	class AnonymousClass_1 implements AnimatorUpdateListener {
		final /* synthetic */ TabLayout this$0;

		AnonymousClass_1(TabLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onAnimationUpdate(ValueAnimatorCompat animator) {
			this$0.scrollTo(animator.getAnimatedIntValue(), MODE_SCROLLABLE);
		}
	}

	private class AdapterChangeListener implements OnAdapterChangeListener {
		private boolean mAutoRefresh;
		final /* synthetic */ TabLayout this$0;

		AdapterChangeListener(TabLayout r1_TabLayout) {
			super();
			this$0 = r1_TabLayout;
		}

		public void onAdapterChanged(@NonNull ViewPager viewPager, @Nullable PagerAdapter oldAdapter, @Nullable PagerAdapter newAdapter) {
			if (this$0.mViewPager == viewPager) {
				this$0.setPagerAdapter(newAdapter, mAutoRefresh);
			}
		}

		void setAutoRefresh(boolean autoRefresh) {
			mAutoRefresh = autoRefresh;
		}
	}

	@Retention(RetentionPolicy.SOURCE)
	public static @interface Mode {
	}

	public static interface OnTabSelectedListener {
		public void onTabReselected(TabLayout.Tab r1_TabLayout_Tab);

		public void onTabSelected(TabLayout.Tab r1_TabLayout_Tab);

		public void onTabUnselected(TabLayout.Tab r1_TabLayout_Tab);
	}

	private class PagerAdapterObserver extends DataSetObserver {
		final /* synthetic */ TabLayout this$0;

		PagerAdapterObserver(TabLayout r1_TabLayout) {
			super();
			this$0 = r1_TabLayout;
		}

		public void onChanged() {
			this$0.populateFromPagerAdapter();
		}

		public void onInvalidated() {
			this$0.populateFromPagerAdapter();
		}
	}

	private class SlidingTabStrip extends LinearLayout {
		private ValueAnimatorCompat mIndicatorAnimator;
		private int mIndicatorLeft;
		private int mIndicatorRight;
		private int mSelectedIndicatorHeight;
		private final Paint mSelectedIndicatorPaint;
		int mSelectedPosition;
		float mSelectionOffset;
		final /* synthetic */ TabLayout this$0;

		class AnonymousClass_1 implements AnimatorUpdateListener {
			final /* synthetic */ TabLayout.SlidingTabStrip this$1;
			final /* synthetic */ int val$startLeft;
			final /* synthetic */ int val$startRight;
			final /* synthetic */ int val$targetLeft;
			final /* synthetic */ int val$targetRight;

			AnonymousClass_1(TabLayout.SlidingTabStrip this$1, int r2i, int r3i, int r4i, int r5i) {
				super();
				this.this$1 = this$1;
				val$startLeft = r2i;
				val$targetLeft = r3i;
				val$startRight = r4i;
				val$targetRight = r5i;
			}

			public void onAnimationUpdate(ValueAnimatorCompat animator) {
				float fraction = animator.getAnimatedFraction();
				this$1.setIndicatorPosition(AnimationUtils.lerp(val$startLeft, val$targetLeft, fraction), AnimationUtils.lerp(val$startRight, val$targetRight, fraction));
			}
		}

		class AnonymousClass_2 extends AnimatorListenerAdapter {
			final /* synthetic */ TabLayout.SlidingTabStrip this$1;
			final /* synthetic */ int val$position;

			AnonymousClass_2(TabLayout.SlidingTabStrip this$1, int r2i) {
				super();
				this.this$1 = this$1;
				val$position = r2i;
			}

			public void onAnimationEnd(ValueAnimatorCompat animator) {
				this$1.mSelectedPosition = val$position;
				this$1.mSelectionOffset = 0.0f;
			}
		}


		SlidingTabStrip(TabLayout r2_TabLayout, Context context) {
			super(context);
			this$0 = r2_TabLayout;
			mSelectedPosition = -1;
			mIndicatorLeft = -1;
			mIndicatorRight = -1;
			setWillNotDraw(false);
			mSelectedIndicatorPaint = new Paint();
		}

		private void updateIndicatorPosition() {
			int right;
			int left;
			View selectedTitle = getChildAt(mSelectedPosition);
			if (selectedTitle == null || selectedTitle.getWidth() <= 0) {
				right = INVALID_WIDTH;
				left = -1;
			} else {
				left = selectedTitle.getLeft();
				right = selectedTitle.getRight();
				if (mSelectionOffset <= 0.0f || mSelectedPosition >= getChildCount() - 1) {
					setIndicatorPosition(left, right);
				} else {
					View nextTitle = getChildAt(mSelectedPosition + 1);
					left = (int) ((mSelectionOffset * ((float) nextTitle.getLeft())) + ((1.0f - mSelectionOffset) * ((float) left)));
					right = (int) ((mSelectionOffset * ((float) nextTitle.getRight())) + ((1.0f - mSelectionOffset) * ((float) right)));
				}
			}
			setIndicatorPosition(left, right);
		}

		void animateIndicatorToPosition(int position, int duration) {
			boolean isRtl;
			View targetView;
			int targetLeft;
			int targetRight;
			int startLeft;
			int startRight;
			int offset;
			ValueAnimatorCompat animator;
			if (mIndicatorAnimator == null || !mIndicatorAnimator.isRunning()) {
				if (ViewCompat.getLayoutDirection(this) != 1) {
					isRtl = true;
				} else {
					isRtl = false;
				}
				targetView = getChildAt(position);
				if (targetView != null) {
					updateIndicatorPosition();
				} else {
					targetLeft = targetView.getLeft();
					targetRight = targetView.getRight();
					if (Math.abs(position - mSelectedPosition) > 1) {
						startLeft = mIndicatorLeft;
						startRight = mIndicatorRight;
					} else {
						offset = this$0.dpToPx(MOTION_NON_ADJACENT_OFFSET);
						if (position >= mSelectedPosition) {
							if (!isRtl) {
								startRight = targetLeft - offset;
								startLeft = startRight;
							} else {
								startRight = targetRight + offset;
								startLeft = startRight;
							}
						} else if (!isRtl) {
							startRight = targetRight + offset;
							startLeft = startRight;
						} else {
							startRight = targetLeft - offset;
							startLeft = startRight;
						}
					}
					if (startLeft != targetLeft || startRight != targetRight) {
						animator = ViewUtils.createAnimator();
						mIndicatorAnimator = animator;
						animator.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
						animator.setDuration((long) duration);
						animator.setFloatValues(BitmapDescriptorFactory.HUE_RED, 1.0f);
						animator.addUpdateListener(new AnonymousClass_1(this, startLeft, targetLeft, startRight, targetRight));
						animator.addListener(new AnonymousClass_2(this, position));
						animator.start();
					}
				}
			} else {
				mIndicatorAnimator.cancel();
				if (ViewCompat.getLayoutDirection(this) != 1) {
					isRtl = false;
				} else {
					isRtl = true;
				}
				targetView = getChildAt(position);
				if (targetView != null) {
					targetLeft = targetView.getLeft();
					targetRight = targetView.getRight();
					if (Math.abs(position - mSelectedPosition) > 1) {
						offset = this$0.dpToPx(MOTION_NON_ADJACENT_OFFSET);
						if (position >= mSelectedPosition) {
							if (!isRtl) {
								startRight = targetLeft - offset;
								startLeft = startRight;
							} else {
								startRight = targetRight + offset;
								startLeft = startRight;
							}
						} else if (!isRtl) {
							startRight = targetRight + offset;
							startLeft = startRight;
						} else {
							startRight = targetLeft - offset;
							startLeft = startRight;
						}
					} else {
						startLeft = mIndicatorLeft;
						startRight = mIndicatorRight;
					}
					if (startLeft != targetLeft || startRight != targetRight) {
						animator = ViewUtils.createAnimator();
						mIndicatorAnimator = animator;
						animator.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
						animator.setDuration((long) duration);
						animator.setFloatValues(BitmapDescriptorFactory.HUE_RED, 1.0f);
						animator.addUpdateListener(new AnonymousClass_1(this, startLeft, targetLeft, startRight, targetRight));
						animator.addListener(new AnonymousClass_2(this, position));
						animator.start();
					}
				} else {
					updateIndicatorPosition();
				}
			}
		}

		boolean childrenNeedLayout() {
			int i = MODE_SCROLLABLE;
			while (i < getChildCount()) {
				if (getChildAt(i).getWidth() <= 0) {
					return true;
				} else {
					i++;
				}
			}
			return false;
		}

		public void draw(Canvas canvas) {
			super.draw(canvas);
			if (mIndicatorLeft < 0 || mIndicatorRight <= mIndicatorLeft) {
			} else {
				canvas.drawRect((float) mIndicatorLeft, (float) (getHeight() - mSelectedIndicatorHeight), (float) mIndicatorRight, (float) getHeight(), mSelectedIndicatorPaint);
			}
		}

		float getIndicatorPosition() {
			return ((float) mSelectedPosition) + mSelectionOffset;
		}

		protected void onLayout(boolean changed, int l, int t, int r, int b) {
			super.onLayout(changed, l, t, r, b);
			if (mIndicatorAnimator == null || !mIndicatorAnimator.isRunning()) {
				updateIndicatorPosition();
			} else {
				mIndicatorAnimator.cancel();
				animateIndicatorToPosition(mSelectedPosition, Math.round((1.0f - mIndicatorAnimator.getAnimatedFraction()) * ((float) mIndicatorAnimator.getDuration())));
			}
		}

		/* JADX WARNING: inconsistent code */
		/*
		protected void onMeasure(int r14_widthMeasureSpec, int r15_heightMeasureSpec) {
			r13_this = this;
			r10 = 1;
			r12 = 0;
			r11 = 0;
			super.onMeasure(r14_widthMeasureSpec, r15_heightMeasureSpec);
			r8 = android.view.View.MeasureSpec.getMode(r14_widthMeasureSpec);
			r9 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
			if (r8 == r9) goto L_0x000f;
		L_0x000e:
			return;
		L_0x000f:
			r8 = r13.this$0;
			r8 = r8.mMode;
			if (r8 != r10) goto L_0x000e;
		L_0x0015:
			r8 = r13.this$0;
			r8 = r8.mTabGravity;
			if (r8 != r10) goto L_0x000e;
		L_0x001b:
			r1 = r13.getChildCount();
			r4 = 0;
			r3 = 0;
			r7 = r1_count;
		L_0x0022:
			if (r3_i >= r7_z) goto L_0x0039;
		L_0x0024:
			r0 = r13.getChildAt(r3_i);
			r8 = r0_child.getVisibility();
			if (r8 != 0) goto L_0x0036;
		L_0x002e:
			r8 = r0_child.getMeasuredWidth();
			r4_largestTabWidth = java.lang.Math.max(r4_largestTabWidth, r8);
		L_0x0036:
			r3_i++;
			goto L_0x0022;
		L_0x0039:
			if (r4_largestTabWidth <= 0) goto L_0x000e;
		L_0x003b:
			r8 = r13.this$0;
			r9 = 16;
			r2 = r8.dpToPx(r9);
			r6 = 0;
			r8 = r4_largestTabWidth * r1_count;
			r9 = r13.getMeasuredWidth();
			r10 = r2_gutter * 2;
			r9 -= r10;
			if (r8 > r9) goto L_0x006e;
		L_0x004f:
			r3_i = 0;
		L_0x0050:
			if (r3_i >= r1_count) goto L_0x0078;
		L_0x0052:
			r8 = r13.getChildAt(r3_i);
			r5 = r8.getLayoutParams();
			r5 = (android.widget.LinearLayout.LayoutParams) r5;
			r8 = r5_lp.width;
			if (r8 != r4_largestTabWidth) goto L_0x0066;
		L_0x0060:
			r8 = r5_lp.weight;
			r8 = (r8 > r11 ? 1 : (r8 == r11 ? 0 : -1));
			if (r8 == 0) goto L_0x006b;
		L_0x0066:
			r5_lp.width = r4_largestTabWidth;
			r5_lp.weight = r11;
			r6_remeasure = 1;
		L_0x006b:
			r3_i++;
			goto L_0x0050;
		L_0x006e:
			r8 = r13.this$0;
			r8.mTabGravity = r12;
			r8 = r13.this$0;
			r8.updateTabViews(r12);
			r6_remeasure = 1;
		L_0x0078:
			if (r6_remeasure == 0) goto L_0x000e;
		L_0x007a:
			super.onMeasure(r14_widthMeasureSpec, r15_heightMeasureSpec);
			goto L_0x000e;
		}
		*/
		protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
			super.onMeasure(widthMeasureSpec, heightMeasureSpec);
			if (MeasureSpec.getMode(widthMeasureSpec) == 1073741824 && this$0.mMode == 1 && this$0.mTabGravity == 1) {
				int count = getChildCount();
				int largestTabWidth = MODE_SCROLLABLE;
				int i = MODE_SCROLLABLE;
				while (i < count) {
					View child = getChildAt(i);
					if (child.getVisibility() == 0) {
						largestTabWidth = Math.max(largestTabWidth, child.getMeasuredWidth());
					}
					i++;
				}
				if (largestTabWidth > 0) {
					boolean remeasure = false;
					if (largestTabWidth * count <= getMeasuredWidth() - (this$0.dpToPx(FIXED_WRAP_GUTTER_MIN) * 2)) {
						i = MODE_SCROLLABLE;
						while (i < count) {
							LayoutParams lp = (LayoutParams) getChildAt(i).getLayoutParams();
							if (lp.width != largestTabWidth || lp.weight != 0.0f) {
								lp.width = largestTabWidth;
								lp.weight = 0.0f;
								remeasure = true;
							} else {
								i++;
							}
							i++;
						}
					} else {
						this$0.mTabGravity = 0;
						this$0.updateTabViews(false);
					}
					if (remeasure) {
						super.onMeasure(widthMeasureSpec, heightMeasureSpec);
					}
				}
			}
		}

		void setIndicatorPosition(int left, int right) {
			if (left != mIndicatorLeft || right != mIndicatorRight) {
				mIndicatorLeft = left;
				mIndicatorRight = right;
				ViewCompat.postInvalidateOnAnimation(this);
			}
		}

		void setIndicatorPositionFromTabPosition(int position, float positionOffset) {
			if (mIndicatorAnimator == null || !mIndicatorAnimator.isRunning()) {
				mSelectedPosition = position;
				mSelectionOffset = positionOffset;
				updateIndicatorPosition();
			} else {
				mIndicatorAnimator.cancel();
				mSelectedPosition = position;
				mSelectionOffset = positionOffset;
				updateIndicatorPosition();
			}
		}

		void setSelectedIndicatorColor(int color) {
			if (mSelectedIndicatorPaint.getColor() != color) {
				mSelectedIndicatorPaint.setColor(color);
				ViewCompat.postInvalidateOnAnimation(this);
			}
		}

		void setSelectedIndicatorHeight(int height) {
			if (mSelectedIndicatorHeight != height) {
				mSelectedIndicatorHeight = height;
				ViewCompat.postInvalidateOnAnimation(this);
			}
		}
	}

	public static final class Tab {
		public static final int INVALID_POSITION = -1;
		private CharSequence mContentDesc;
		private View mCustomView;
		private Drawable mIcon;
		TabLayout mParent;
		private int mPosition;
		private Object mTag;
		private CharSequence mText;
		TabLayout.TabView mView;

		Tab() {
			super();
			mPosition = -1;
		}

		@Nullable
		public CharSequence getContentDescription() {
			return mContentDesc;
		}

		@Nullable
		public View getCustomView() {
			return mCustomView;
		}

		@Nullable
		public Drawable getIcon() {
			return mIcon;
		}

		public int getPosition() {
			return mPosition;
		}

		@Nullable
		public Object getTag() {
			return mTag;
		}

		@Nullable
		public CharSequence getText() {
			return mText;
		}

		public boolean isSelected() {
			if (mParent == null) {
				throw new IllegalArgumentException("Tab not attached to a TabLayout");
			} else if (mParent.getSelectedTabPosition() == mPosition) {
				return true;
			} else {
				return false;
			}
		}

		void reset() {
			mParent = null;
			mView = null;
			mTag = null;
			mIcon = null;
			mText = null;
			mContentDesc = null;
			mPosition = -1;
			mCustomView = null;
		}

		public void select() {
			if (mParent == null) {
				throw new IllegalArgumentException("Tab not attached to a TabLayout");
			} else {
				mParent.selectTab(this);
			}
		}

		@NonNull
		public TabLayout.Tab setContentDescription(@StringRes int resId) {
			if (mParent == null) {
				throw new IllegalArgumentException("Tab not attached to a TabLayout");
			} else {
				return setContentDescription(mParent.getResources().getText(resId));
			}
		}

		@NonNull
		public TabLayout.Tab setContentDescription(@Nullable CharSequence contentDesc) {
			mContentDesc = contentDesc;
			updateView();
			return this;
		}

		@NonNull
		public TabLayout.Tab setCustomView(@LayoutRes int resId) {
			return setCustomView(LayoutInflater.from(mView.getContext()).inflate(resId, mView, false));
		}

		@NonNull
		public TabLayout.Tab setCustomView(@Nullable View view) {
			mCustomView = view;
			updateView();
			return this;
		}

		@NonNull
		public TabLayout.Tab setIcon(@DrawableRes int resId) {
			if (mParent == null) {
				throw new IllegalArgumentException("Tab not attached to a TabLayout");
			} else {
				return setIcon(AppCompatResources.getDrawable(mParent.getContext(), resId));
			}
		}

		@NonNull
		public TabLayout.Tab setIcon(@Nullable Drawable icon) {
			mIcon = icon;
			updateView();
			return this;
		}

		void setPosition(int position) {
			mPosition = position;
		}

		@NonNull
		public TabLayout.Tab setTag(@Nullable Object tag) {
			mTag = tag;
			return this;
		}

		@NonNull
		public TabLayout.Tab setText(@StringRes int resId) {
			if (mParent == null) {
				throw new IllegalArgumentException("Tab not attached to a TabLayout");
			} else {
				return setText(mParent.getResources().getText(resId));
			}
		}

		@NonNull
		public TabLayout.Tab setText(@Nullable CharSequence text) {
			mText = text;
			updateView();
			return this;
		}

		void updateView() {
			if (mView != null) {
				mView.update();
			}
		}
	}

	@Retention(RetentionPolicy.SOURCE)
	public static @interface TabGravity {
	}

	public static class TabLayoutOnPageChangeListener implements OnPageChangeListener {
		private int mPreviousScrollState;
		private int mScrollState;
		private final WeakReference<TabLayout> mTabLayoutRef;

		public TabLayoutOnPageChangeListener(TabLayout tabLayout) {
			super();
			mTabLayoutRef = new WeakReference(tabLayout);
		}

		public void onPageScrollStateChanged(int state) {
			mPreviousScrollState = mScrollState;
			mScrollState = state;
		}

		public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
			TabLayout tabLayout = (TabLayout) mTabLayoutRef.get();
			if (tabLayout != null) {
				boolean updateText;
				boolean updateIndicator;
				if (mScrollState != 2 || mPreviousScrollState == 1) {
					updateText = true;
				} else {
					updateText = false;
				}
				if (mScrollState != 2 || mPreviousScrollState != 0) {
					updateIndicator = true;
				} else {
					updateIndicator = false;
				}
				tabLayout.setScrollPosition(position, positionOffset, updateText, updateIndicator);
			}
		}

		public void onPageSelected(int position) {
			TabLayout tabLayout = (TabLayout) mTabLayoutRef.get();
			if (tabLayout == null || tabLayout.getSelectedTabPosition() == position || position >= tabLayout.getTabCount()) {
			} else {
				boolean updateIndicator;
				if (mScrollState != 0) {
					if (mScrollState != 2 || mPreviousScrollState != 0) {
						updateIndicator = false;
					} else {
						updateIndicator = true;
					}
				} else {
					updateIndicator = true;
				}
				tabLayout.selectTab(tabLayout.getTabAt(position), updateIndicator);
			}
		}

		void reset() {
			mScrollState = 0;
			mPreviousScrollState = 0;
		}
	}

	class TabView extends LinearLayout implements OnLongClickListener {
		private ImageView mCustomIconView;
		private TextView mCustomTextView;
		private View mCustomView;
		private int mDefaultMaxLines;
		private ImageView mIconView;
		private TabLayout.Tab mTab;
		private TextView mTextView;
		final /* synthetic */ TabLayout this$0;

		public TabView(TabLayout this$0, Context context) {
			super(context);
			this.this$0 = this$0;
			mDefaultMaxLines = 2;
			if (this$0.mTabBackgroundResId != 0) {
				setBackgroundDrawable(AppCompatResources.getDrawable(context, this$0.mTabBackgroundResId));
			}
			ViewCompat.setPaddingRelative(this, this$0.mTabPaddingStart, this$0.mTabPaddingTop, this$0.mTabPaddingEnd, this$0.mTabPaddingBottom);
			setGravity(R.styleable.View_android_scrollbarDefaultDelayBeforeFade);
			setOrientation(MODE_FIXED);
			setClickable(true);
		}

		private float approximateLineWidth(Layout layout, int line, float textSize) {
			return layout.getLineWidth(line) * (textSize / layout.getPaint().getTextSize());
		}

		private void updateTextAndIcon(@Nullable TextView textView, @Nullable ImageView iconView) {
			Drawable icon;
			CharSequence text;
			CharSequence contentDesc;
			boolean hasText;
			if (mTab != null) {
				icon = mTab.getIcon();
			} else {
				icon = null;
			}
			if (mTab != null) {
				text = mTab.getText();
			} else {
				text = null;
			}
			if (mTab != null) {
				contentDesc = mTab.getContentDescription();
			} else {
				contentDesc = null;
			}
			if (iconView != null) {
				if (icon != null) {
					iconView.setImageDrawable(icon);
					iconView.setVisibility(MODE_SCROLLABLE);
					setVisibility(MODE_SCROLLABLE);
				} else {
					iconView.setVisibility(DEFAULT_GAP_TEXT_ICON);
					iconView.setImageDrawable(null);
				}
				iconView.setContentDescription(contentDesc);
			}
			if (!TextUtils.isEmpty(text)) {
				hasText = true;
			} else {
				hasText = false;
			}
			if (textView != null) {
				if (hasText) {
					textView.setText(text);
					textView.setVisibility(MODE_SCROLLABLE);
					setVisibility(MODE_SCROLLABLE);
				} else {
					textView.setVisibility(DEFAULT_GAP_TEXT_ICON);
					textView.setText(null);
				}
				textView.setContentDescription(contentDesc);
			}
			if (iconView != null) {
				MarginLayoutParams lp = (MarginLayoutParams) iconView.getLayoutParams();
				int bottomMargin = MODE_SCROLLABLE;
				if (!hasText || iconView.getVisibility() != 0) {
					if (bottomMargin == lp.bottomMargin) {
						lp.bottomMargin = bottomMargin;
						iconView.requestLayout();
					}
				} else {
					bottomMargin = this$0.dpToPx(DEFAULT_GAP_TEXT_ICON);
					if (bottomMargin == lp.bottomMargin) {
						if (hasText || TextUtils.isEmpty(contentDesc)) {
							setOnLongClickListener(null);
							setLongClickable(false);
						} else {
							setOnLongClickListener(this);
						}
					} else {
						lp.bottomMargin = bottomMargin;
						iconView.requestLayout();
					}
				}
			}
			if (hasText || TextUtils.isEmpty(contentDesc)) {
				setOnLongClickListener(null);
				setLongClickable(false);
			} else {
				setOnLongClickListener(this);
			}
		}

		public TabLayout.Tab getTab() {
			return mTab;
		}

		@TargetApi(14)
		public void onInitializeAccessibilityEvent(AccessibilityEvent event) {
			super.onInitializeAccessibilityEvent(event);
			event.setClassName(android.support.v7.app.ActionBar.Tab.class.getName());
		}

		@TargetApi(14)
		public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
			super.onInitializeAccessibilityNodeInfo(info);
			info.setClassName(android.support.v7.app.ActionBar.Tab.class.getName());
		}

		public boolean onLongClick(View v) {
			int[] screenPos = new int[2];
			Rect displayFrame = new Rect();
			getLocationOnScreen(screenPos);
			getWindowVisibleDisplayFrame(displayFrame);
			Context context = getContext();
			int height = getHeight();
			int midy = screenPos[1] + (height / 2);
			int referenceX = screenPos[0] + (getWidth() / 2);
			if (ViewCompat.getLayoutDirection(v) == 0) {
				referenceX = context.getResources().getDisplayMetrics().widthPixels - referenceX;
			}
			Toast cheatSheet = Toast.makeText(context, mTab.getContentDescription(), MODE_SCROLLABLE);
			if (midy < displayFrame.height()) {
				cheatSheet.setGravity(8388661, referenceX, (screenPos[1] + height) - displayFrame.top);
			} else {
				cheatSheet.setGravity(R.styleable.AppCompatTheme_panelMenuListTheme, MODE_SCROLLABLE, height);
			}
			cheatSheet.show();
			return true;
		}

		/* JADX WARNING: inconsistent code */
		/*
		public void onMeasure(int r18_origWidthMeasureSpec, int r19_origHeightMeasureSpec) {
			r17_this = this;
			r10 = android.view.View.MeasureSpec.getSize(r18_origWidthMeasureSpec);
			r9 = android.view.View.MeasureSpec.getMode(r18_origWidthMeasureSpec);
			r0 = r17;
			r14 = r0.this$0;
			r7 = r14.getTabMaxWidth();
			r4 = r19_origHeightMeasureSpec;
			if (r7_maxWidth <= 0) goto L_0x00bd;
		L_0x0014:
			if (r9_specWidthMode == 0) goto L_0x0018;
		L_0x0016:
			if (r10_specWidthSize <= r7_maxWidth) goto L_0x00bd;
		L_0x0018:
			r0 = r17;
			r14 = r0.this$0;
			r14 = r14.mTabMaxWidth;
			r15 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
			r13 = android.view.View.MeasureSpec.makeMeasureSpec(r14, r15);
		L_0x0024:
			r0 = r17;
			super.onMeasure(r13_widthMeasureSpec, r4_heightMeasureSpec);
			r0 = r17;
			r14 = r0.mTextView;
			if (r14 == 0) goto L_0x00bc;
		L_0x002f:
			r8_res = r17.getResources();
			r0 = r17;
			r14 = r0.this$0;
			r11 = r14.mTabTextSize;
			r0 = r17;
			r6 = r0.mDefaultMaxLines;
			r0 = r17;
			r14 = r0.mIconView;
			if (r14 == 0) goto L_0x00c1;
		L_0x0043:
			r0 = r17;
			r14 = r0.mIconView;
			r14 = r14.getVisibility();
			if (r14 != 0) goto L_0x00c1;
		L_0x004d:
			r6_maxLines = 1;
		L_0x004e:
			r0 = r17;
			r14 = r0.mTextView;
			r3 = r14.getTextSize();
			r0 = r17;
			r14 = r0.mTextView;
			r1 = r14.getLineCount();
			r0 = r17;
			r14 = r0.mTextView;
			r2 = android.support.v4.widget.TextViewCompat.getMaxLines(r14);
			r14 = (r11_textSize > r3_curTextSize ? 1 : (r11_textSize == r3_curTextSize ? 0 : -1));
			if (r14 != 0) goto L_0x006e;
		L_0x006a:
			if (r2_curMaxLines < 0) goto L_0x00bc;
		L_0x006c:
			if (r6_maxLines == r2_curMaxLines) goto L_0x00bc;
		L_0x006e:
			r12 = 1;
			r0 = r17;
			r14 = r0.this$0;
			r14 = r14.mMode;
			r15 = 1;
			if (r14 != r15) goto L_0x00a6;
		L_0x0078:
			r14 = (r11_textSize > r3_curTextSize ? 1 : (r11_textSize == r3_curTextSize ? 0 : -1));
			if (r14 <= 0) goto L_0x00a6;
		L_0x007c:
			r14 = 1;
			if (r1_curLineCount != r14) goto L_0x00a6;
		L_0x007f:
			r0 = r17;
			r14 = r0.mTextView;
			r5 = r14.getLayout();
			if (r5_layout == 0) goto L_0x00a5;
		L_0x0089:
			r14 = 0;
			r0 = r17;
			r14 = r0.approximateLineWidth(r5_layout, r14, r11_textSize);
			r15 = r17.getMeasuredWidth();
			r16 = r17.getPaddingLeft();
			r15 -= r16;
			r16 = r17.getPaddingRight();
			r15 -= r16;
			r15 = (float) r15;
			r14 = (r14 > r15 ? 1 : (r14 == r15 ? 0 : -1));
			if (r14 <= 0) goto L_0x00a6;
		L_0x00a5:
			r12_updateTextView = 0;
		L_0x00a6:
			if (r12_updateTextView == 0) goto L_0x00bc;
		L_0x00a8:
			r0 = r17;
			r14 = r0.mTextView;
			r15 = 0;
			r14.setTextSize(r15, r11_textSize);
			r0 = r17;
			r14 = r0.mTextView;
			r14.setMaxLines(r6_maxLines);
			r0 = r17;
			super.onMeasure(r13_widthMeasureSpec, r4_heightMeasureSpec);
		L_0x00bc:
			return;
		L_0x00bd:
			r13_widthMeasureSpec = r18_origWidthMeasureSpec;
			goto L_0x0024;
		L_0x00c1:
			r0 = r17;
			r14 = r0.mTextView;
			if (r14 == 0) goto L_0x004e;
		L_0x00c7:
			r0 = r17;
			r14 = r0.mTextView;
			r14 = r14.getLineCount();
			r15 = 1;
			if (r14 <= r15) goto L_0x004e;
		L_0x00d2:
			r0 = r17;
			r14 = r0.this$0;
			r11 = r14.mTabTextMultiLineSize;
			goto L_0x004e;
		}
		*/
		public void onMeasure(int origWidthMeasureSpec, int origHeightMeasureSpec) {
			int widthMeasureSpec;
			int specWidthSize = MeasureSpec.getSize(origWidthMeasureSpec);
			int specWidthMode = MeasureSpec.getMode(origWidthMeasureSpec);
			int maxWidth = this$0.getTabMaxWidth();
			int heightMeasureSpec = origHeightMeasureSpec;
			if (maxWidth > 0) {
				if (specWidthMode == 0 || specWidthSize > maxWidth) {
					widthMeasureSpec = MeasureSpec.makeMeasureSpec(this$0.mTabMaxWidth, TLRPC.MESSAGE_FLAG_MEGAGROUP);
				} else {
					widthMeasureSpec = origWidthMeasureSpec;
				}
			} else {
				widthMeasureSpec = origWidthMeasureSpec;
			}
			super.onMeasure(widthMeasureSpec, heightMeasureSpec);
			if (mTextView != null) {
				float curTextSize;
				int curMaxLines;
				float textSize = this$0.mTabTextSize;
				int maxLines = mDefaultMaxLines;
				if (mIconView == null || mIconView.getVisibility() != 0) {
					if (mTextView == null || mTextView.getLineCount() <= 1) {
						curTextSize = mTextView.getTextSize();
						curLineCount = mTextView.getLineCount();
						curMaxLines = TextViewCompat.getMaxLines(mTextView);
					} else {
						textSize = this$0.mTabTextMultiLineSize;
					}
				} else {
					maxLines = MODE_FIXED;
				}
				curTextSize = mTextView.getTextSize();
				curLineCount = mTextView.getLineCount();
				curMaxLines = TextViewCompat.getMaxLines(mTextView);
				if (textSize == curTextSize) {
					if (curMaxLines < 0 || maxLines == curMaxLines) {
					}
				}
				boolean updateTextView = true;
				if (this$0.mMode != 1 || textSize <= curTextSize || curLineCount != 1) {
				} else {
					Layout layout = mTextView.getLayout();
					if (layout == null || approximateLineWidth(layout, MODE_SCROLLABLE, textSize) > ((float) ((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight()))) {
						updateTextView = false;
					}
				}
			}
		}

		public boolean performClick() {
			boolean value = super.performClick();
			if (mTab != null) {
				mTab.select();
				value = true;
			}
			return value;
		}

		void reset() {
			setTab(null);
			setSelected(false);
		}

		public void setSelected(boolean selected) {
			boolean changed;
			if (isSelected() != selected) {
				changed = true;
			} else {
				changed = false;
			}
			super.setSelected(selected);
			if (!changed || !selected || VERSION.SDK_INT >= 16) {
				if (mTextView == null) {
					mTextView.setSelected(selected);
				}
				if (mIconView != null) {
					mIconView.setSelected(selected);
				}
				if (mCustomView == null) {
					mCustomView.setSelected(selected);
				}
			} else {
				sendAccessibilityEvent(TLRPC.USER_FLAG_LAST_NAME);
				if (mTextView == null) {
					if (mIconView != null) {
						if (mCustomView == null) {
						} else {
							mCustomView.setSelected(selected);
						}
					} else {
						mIconView.setSelected(selected);
						if (mCustomView == null) {
							mCustomView.setSelected(selected);
						}
					}
				} else {
					mTextView.setSelected(selected);
					if (mIconView != null) {
						mIconView.setSelected(selected);
					}
					if (mCustomView == null) {
					} else {
						mCustomView.setSelected(selected);
					}
				}
			}
		}

		void setTab(@Nullable TabLayout.Tab tab) {
			if (tab != mTab) {
				mTab = tab;
				update();
			}
		}

		final void update() {
			View custom;
			boolean r5z;
			TabLayout.Tab tab = mTab;
			if (tab != null) {
				custom = tab.getCustomView();
			} else {
				custom = null;
			}
			if (custom != null) {
				TabLayout.TabView customParent = custom.getParent();
				if (customParent != this) {
					if (customParent != null) {
						customParent.removeView(custom);
					}
					addView(custom);
				}
				mCustomView = custom;
				if (mTextView != null) {
					mTextView.setVisibility(DEFAULT_GAP_TEXT_ICON);
				}
				if (mIconView != null) {
					mIconView.setVisibility(DEFAULT_GAP_TEXT_ICON);
					mIconView.setImageDrawable(null);
				}
				mCustomTextView = (TextView) custom.findViewById(16908308);
				if (mCustomTextView != null) {
					mDefaultMaxLines = TextViewCompat.getMaxLines(mCustomTextView);
				}
				mCustomIconView = (ImageView) custom.findViewById(16908294);
			} else {
				if (mCustomView != null) {
					removeView(mCustomView);
					mCustomView = null;
				}
				mCustomTextView = null;
				mCustomIconView = null;
			}
			if (mCustomView == null) {
				if (mIconView == null) {
					View iconView = (ImageView) LayoutInflater.from(getContext()).inflate(R.layout.design_layout_tab_icon, this, false);
					addView(iconView, MODE_SCROLLABLE);
					mIconView = iconView;
				}
				if (mTextView == null) {
					View textView = (TextView) LayoutInflater.from(getContext()).inflate(R.layout.design_layout_tab_text, this, false);
					addView(textView);
					mTextView = textView;
					mDefaultMaxLines = TextViewCompat.getMaxLines(mTextView);
				}
				mTextView.setTextAppearance(getContext(), this$0.mTabTextAppearance);
				if (this$0.mTabTextColors != null) {
					mTextView.setTextColor(this$0.mTabTextColors);
				}
				updateTextAndIcon(mTextView, mIconView);
			} else if (mCustomTextView != null || mCustomIconView != null) {
				updateTextAndIcon(mCustomTextView, mCustomIconView);
			}
			if (tab == null || !tab.isSelected()) {
				r5z = false;
			} else {
				r5z = true;
			}
			setSelected(r5z);
		}
	}

	public static class ViewPagerOnTabSelectedListener implements TabLayout.OnTabSelectedListener {
		private final ViewPager mViewPager;

		public ViewPagerOnTabSelectedListener(ViewPager viewPager) {
			super();
			mViewPager = viewPager;
		}

		public void onTabReselected(TabLayout.Tab tab) {
		}

		public void onTabSelected(TabLayout.Tab tab) {
			mViewPager.setCurrentItem(tab.getPosition());
		}

		public void onTabUnselected(TabLayout.Tab tab) {
		}
	}


	static {
		sTabPool = new SynchronizedPool(16);
	}

	public TabLayout(Context context) {
		this(context, null);
	}

	public TabLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public TabLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		mTabs = new ArrayList();
		mTabMaxWidth = 2147483647;
		mSelectedListeners = new ArrayList();
		mTabViewPool = new SimplePool(12);
		ThemeUtils.checkAppCompatTheme(context);
		setHorizontalScrollBarEnabled(false);
		mTabStrip = new SlidingTabStrip(this, context);
		super.addView(mTabStrip, MODE_SCROLLABLE, new LayoutParams(-2, -1));
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.TabLayout, defStyleAttr, R.style.Widget_Design_TabLayout);
		mTabStrip.setSelectedIndicatorHeight(a.getDimensionPixelSize(R.styleable.TabLayout_tabIndicatorHeight, MODE_SCROLLABLE));
		mTabStrip.setSelectedIndicatorColor(a.getColor(R.styleable.TabLayout_tabIndicatorColor, MODE_SCROLLABLE));
		int r4i = a.getDimensionPixelSize(R.styleable.TabLayout_tabPadding, MODE_SCROLLABLE);
		mTabPaddingBottom = r4i;
		mTabPaddingEnd = r4i;
		mTabPaddingTop = r4i;
		mTabPaddingStart = r4i;
		mTabPaddingStart = a.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingStart, mTabPaddingStart);
		mTabPaddingTop = a.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingTop, mTabPaddingTop);
		mTabPaddingEnd = a.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingEnd, mTabPaddingEnd);
		mTabPaddingBottom = a.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingBottom, mTabPaddingBottom);
		mTabTextAppearance = a.getResourceId(R.styleable.TabLayout_tabTextAppearance, R.style.TextAppearance_Design_Tab);
		TypedArray ta = context.obtainStyledAttributes(mTabTextAppearance, android.support.v7.appcompat.R.styleable.TextAppearance);
		mTabTextSize = (float) ta.getDimensionPixelSize(android.support.v7.appcompat.R.styleable.TextAppearance_android_textSize, MODE_SCROLLABLE);
		mTabTextColors = ta.getColorStateList(android.support.v7.appcompat.R.styleable.TextAppearance_android_textColor);
		ta.recycle();
		if (a.hasValue(R.styleable.TabLayout_tabTextColor)) {
			mTabTextColors = a.getColorStateList(R.styleable.TabLayout_tabTextColor);
		}
		if (a.hasValue(R.styleable.TabLayout_tabSelectedTextColor)) {
			mTabTextColors = createColorStateList(mTabTextColors.getDefaultColor(), a.getColor(R.styleable.TabLayout_tabSelectedTextColor, MODE_SCROLLABLE));
		}
		mRequestedTabMinWidth = a.getDimensionPixelSize(R.styleable.TabLayout_tabMinWidth, INVALID_WIDTH);
		mRequestedTabMaxWidth = a.getDimensionPixelSize(R.styleable.TabLayout_tabMaxWidth, INVALID_WIDTH);
		mTabBackgroundResId = a.getResourceId(R.styleable.TabLayout_tabBackground, MODE_SCROLLABLE);
		mContentInsetStart = a.getDimensionPixelSize(R.styleable.TabLayout_tabContentStart, MODE_SCROLLABLE);
		mMode = a.getInt(R.styleable.TabLayout_tabMode, MODE_FIXED);
		mTabGravity = a.getInt(R.styleable.TabLayout_tabGravity, MODE_SCROLLABLE);
		a.recycle();
		Resources res = getResources();
		mTabTextMultiLineSize = (float) res.getDimensionPixelSize(R.dimen.design_tab_text_size_2line);
		mScrollableTabMinWidth = res.getDimensionPixelSize(R.dimen.design_tab_scrollable_min_width);
		applyModeAndGravity();
	}

	private void addTabFromItemView(@NonNull TabItem item) {
		Tab tab = newTab();
		if (item.mText != null) {
			tab.setText(item.mText);
		}
		if (item.mIcon != null) {
			tab.setIcon(item.mIcon);
		}
		if (item.mCustomLayout != 0) {
			tab.setCustomView(item.mCustomLayout);
		}
		if (!TextUtils.isEmpty(item.getContentDescription())) {
			tab.setContentDescription(item.getContentDescription());
		}
		addTab(tab);
	}

	private void addTabView(Tab tab) {
		mTabStrip.addView(tab.mView, tab.getPosition(), createLayoutParamsForTabs());
	}

	private void addViewInternal(View child) {
		if (child instanceof TabItem) {
			addTabFromItemView((TabItem) child);
		} else {
			throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
		}
	}

	private void animateToTab(int newPosition) {
		if (newPosition == -1) {
		} else if (getWindowToken() == null || !ViewCompat.isLaidOut(this) || mTabStrip.childrenNeedLayout()) {
			setScrollPosition(newPosition, BitmapDescriptorFactory.HUE_RED, true);
		} else {
			int startScrollX = getScrollX();
			int targetScrollX = calculateScrollXForTab(newPosition, BitmapDescriptorFactory.HUE_RED);
			if (startScrollX != targetScrollX) {
				if (mScrollAnimator == null) {
					mScrollAnimator = ViewUtils.createAnimator();
					mScrollAnimator.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
					mScrollAnimator.setDuration(300);
					mScrollAnimator.addUpdateListener(new AnonymousClass_1(this));
				}
				mScrollAnimator.setIntValues(startScrollX, targetScrollX);
				mScrollAnimator.start();
			}
			mTabStrip.animateIndicatorToPosition(newPosition, ANIMATION_DURATION);
		}
	}

	private void applyModeAndGravity() {
		int paddingStart = MODE_SCROLLABLE;
		if (mMode == 0) {
			paddingStart = Math.max(MODE_SCROLLABLE, mContentInsetStart - mTabPaddingStart);
		}
		ViewCompat.setPaddingRelative(mTabStrip, paddingStart, MODE_SCROLLABLE, MODE_SCROLLABLE, MODE_SCROLLABLE);
		switch(mMode) {
		case MODE_SCROLLABLE:
			mTabStrip.setGravity(GravityCompat.START);
			break;
		case MODE_FIXED:
			mTabStrip.setGravity(MODE_FIXED);
			break;
		}
		updateTabViews(true);
	}

	private int calculateScrollXForTab(int position, float positionOffset) {
		int nextWidth = MODE_SCROLLABLE;
		if (mMode == 0) {
			View nextChild;
			int selectedWidth;
			View selectedChild = mTabStrip.getChildAt(position);
			if (position + 1 < mTabStrip.getChildCount()) {
				nextChild = mTabStrip.getChildAt(position + 1);
			} else {
				nextChild = null;
			}
			if (selectedChild != null) {
				selectedWidth = selectedChild.getWidth();
			} else {
				selectedWidth = 0;
			}
			if (nextChild != null) {
				nextWidth = nextChild.getWidth();
			}
			return ((selectedChild.getLeft() + ((int) ((((float) (selectedWidth + nextWidth)) * positionOffset) * 0.5f))) + (selectedChild.getWidth() / 2)) - (getWidth() / 2);
		} else {
			return MODE_SCROLLABLE;
		}
	}

	private void configureTab(Tab tab, int position) {
		tab.setPosition(position);
		mTabs.add(position, tab);
		int i = position + 1;
		while (i < mTabs.size()) {
			((Tab) mTabs.get(i)).setPosition(i);
			i++;
		}
	}

	private static ColorStateList createColorStateList(int defaultColor, int selectedColor) {
		int[][] states = new int[2][];
		int[] colors = new int[2];
		states[0] = SELECTED_STATE_SET;
		colors[0] = selectedColor;
		int i = 0 + 1;
		states[i] = EMPTY_STATE_SET;
		colors[i] = defaultColor;
		return new ColorStateList(states, colors);
	}

	private android.widget.LinearLayout.LayoutParams createLayoutParamsForTabs() {
		android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(-2, -1);
		updateTabViewLayoutParams(lp);
		return lp;
	}

	private TabView createTabView(@NonNull Tab tab) {
		TabView tabView;
		if (mTabViewPool != null) {
			tabView = (TabView) mTabViewPool.acquire();
		}
		if (tabView == null) {
			tabView = new TabView(this, getContext());
		}
		tabView.setTab(tab);
		tabView.setFocusable(true);
		tabView.setMinimumWidth(getTabMinWidth());
		return tabView;
	}

	private void dispatchTabReselected(@NonNull Tab tab) {
		int i = mSelectedListeners.size() - 1;
		while (i >= 0) {
			((OnTabSelectedListener) mSelectedListeners.get(i)).onTabReselected(tab);
			i--;
		}
	}

	private void dispatchTabSelected(@NonNull Tab tab) {
		int i = mSelectedListeners.size() - 1;
		while (i >= 0) {
			((OnTabSelectedListener) mSelectedListeners.get(i)).onTabSelected(tab);
			i--;
		}
	}

	private void dispatchTabUnselected(@NonNull Tab tab) {
		int i = mSelectedListeners.size() - 1;
		while (i >= 0) {
			((OnTabSelectedListener) mSelectedListeners.get(i)).onTabUnselected(tab);
			i--;
		}
	}

	private int getDefaultHeight() {
		boolean hasIconAndText = false;
		int i = MODE_SCROLLABLE;
		while (i < mTabs.size()) {
			Tab tab = (Tab) mTabs.get(i);
			if (tab == null || tab.getIcon() == null || TextUtils.isEmpty(tab.getText())) {
				i++;
			} else {
				hasIconAndText = true;
			}
		}
		if (hasIconAndText) {
			return DEFAULT_HEIGHT_WITH_TEXT_ICON;
		} else {
			return DEFAULT_HEIGHT;
		}
	}

	private float getScrollPosition() {
		return mTabStrip.getIndicatorPosition();
	}

	private int getTabMinWidth() {
		if (mRequestedTabMinWidth != -1) {
			return mRequestedTabMinWidth;
		} else if (mMode == 0) {
			return mScrollableTabMinWidth;
		} else {
			return MODE_SCROLLABLE;
		}
	}

	private int getTabScrollRange() {
		return Math.max(MODE_SCROLLABLE, ((mTabStrip.getWidth() - getWidth()) - getPaddingLeft()) - getPaddingRight());
	}

	private void removeTabViewAt(int position) {
		TabView view = (TabView) mTabStrip.getChildAt(position);
		mTabStrip.removeViewAt(position);
		if (view != null) {
			view.reset();
			mTabViewPool.release(view);
		}
		requestLayout();
	}

	private void setSelectedTabView(int position) {
		int tabCount = mTabStrip.getChildCount();
		if (position < tabCount) {
			int i = MODE_SCROLLABLE;
			while (i < tabCount) {
				boolean r3z;
				View child = mTabStrip.getChildAt(i);
				if (i == position) {
					r3z = true;
				} else {
					r3z = false;
				}
				child.setSelected(r3z);
				i++;
			}
		}
	}

	private void setupWithViewPager(@Nullable ViewPager viewPager, boolean autoRefresh, boolean implicitSetup) {
		if (mViewPager != null) {
			if (mPageChangeListener != null) {
				mViewPager.removeOnPageChangeListener(mPageChangeListener);
			}
			if (mAdapterChangeListener != null) {
				mViewPager.removeOnAdapterChangeListener(mAdapterChangeListener);
			}
		}
		if (mCurrentVpSelectedListener != null) {
			removeOnTabSelectedListener(mCurrentVpSelectedListener);
			mCurrentVpSelectedListener = null;
		}
		if (viewPager != null) {
			mViewPager = viewPager;
			if (mPageChangeListener == null) {
				mPageChangeListener = new TabLayoutOnPageChangeListener(this);
			}
			mPageChangeListener.reset();
			viewPager.addOnPageChangeListener(mPageChangeListener);
			mCurrentVpSelectedListener = new ViewPagerOnTabSelectedListener(viewPager);
			addOnTabSelectedListener(mCurrentVpSelectedListener);
			PagerAdapter adapter = viewPager.getAdapter();
			if (adapter != null) {
				setPagerAdapter(adapter, autoRefresh);
			}
			if (mAdapterChangeListener == null) {
				mAdapterChangeListener = new AdapterChangeListener(this);
			}
			mAdapterChangeListener.setAutoRefresh(autoRefresh);
			viewPager.addOnAdapterChangeListener(mAdapterChangeListener);
			setScrollPosition(viewPager.getCurrentItem(), BitmapDescriptorFactory.HUE_RED, true);
		} else {
			mViewPager = null;
			setPagerAdapter(null, false);
		}
		mSetupViewPagerImplicitly = implicitSetup;
	}

	private void updateAllTabs() {
		int i = MODE_SCROLLABLE;
		while (i < mTabs.size()) {
			((Tab) mTabs.get(i)).updateView();
			i++;
		}
	}

	private void updateTabViewLayoutParams(android.widget.LinearLayout.LayoutParams lp) {
		if (mMode != 1 || mTabGravity != 0) {
			lp.width = -2;
			lp.weight = 0.0f;
		} else {
			lp.width = 0;
			lp.weight = 1.0f;
		}
	}

	public void addOnTabSelectedListener(@NonNull OnTabSelectedListener listener) {
		if (!mSelectedListeners.contains(listener)) {
			mSelectedListeners.add(listener);
		}
	}

	public void addTab(@NonNull Tab tab) {
		addTab(tab, mTabs.isEmpty());
	}

	public void addTab(@NonNull Tab tab, int position) {
		addTab(tab, position, mTabs.isEmpty());
	}

	public void addTab(@NonNull Tab tab, int position, boolean setSelected) {
		if (tab.mParent != this) {
			throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
		} else {
			configureTab(tab, position);
			addTabView(tab);
			if (setSelected) {
				tab.select();
			}
		}
	}

	public void addTab(@NonNull Tab tab, boolean setSelected) {
		addTab(tab, mTabs.size(), setSelected);
	}

	public void addView(View child) {
		addViewInternal(child);
	}

	public void addView(View child, int index) {
		addViewInternal(child);
	}

	public void addView(View child, int index, android.view.ViewGroup.LayoutParams params) {
		addViewInternal(child);
	}

	public void addView(View child, android.view.ViewGroup.LayoutParams params) {
		addViewInternal(child);
	}

	public void clearOnTabSelectedListeners() {
		mSelectedListeners.clear();
	}

	int dpToPx(int dps) {
		return Math.round(getResources().getDisplayMetrics().density * ((float) dps));
	}

	public LayoutParams generateLayoutParams(AttributeSet attrs) {
		return generateDefaultLayoutParams();
	}

	public int getSelectedTabPosition() {
		if (mSelectedTab != null) {
			return mSelectedTab.getPosition();
		} else {
			return INVALID_WIDTH;
		}
	}

	@Nullable
	public Tab getTabAt(int index) {
		if (index < 0 || index >= getTabCount()) {
			return null;
		} else {
			return (Tab) mTabs.get(index);
		}
	}

	public int getTabCount() {
		return mTabs.size();
	}

	public int getTabGravity() {
		return mTabGravity;
	}

	int getTabMaxWidth() {
		return mTabMaxWidth;
	}

	public int getTabMode() {
		return mMode;
	}

	@Nullable
	public ColorStateList getTabTextColors() {
		return mTabTextColors;
	}

	@NonNull
	public Tab newTab() {
		Tab tab = (Tab) sTabPool.acquire();
		if (tab == null) {
			tab = new Tab();
		}
		tab.mParent = this;
		tab.mView = createTabView(tab);
		return tab;
	}

	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		if (mViewPager == null) {
			ViewParent vp = getParent();
			if (vp instanceof ViewPager) {
				setupWithViewPager((ViewPager) vp, true, true);
			}
		}
	}

	protected void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		if (mSetupViewPagerImplicitly) {
			setupWithViewPager(null);
			mSetupViewPagerImplicitly = false;
		}
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int idealHeight = (dpToPx(getDefaultHeight()) + getPaddingTop()) + getPaddingBottom();
		switch(MeasureSpec.getMode(heightMeasureSpec)) {
		case TLRPC.MESSAGE_FLAG_MEGAGROUP:
			heightMeasureSpec = MeasureSpec.makeMeasureSpec(Math.min(idealHeight, MeasureSpec.getSize(heightMeasureSpec)), 1073741824);
			break;
		case MODE_SCROLLABLE:
			heightMeasureSpec = MeasureSpec.makeMeasureSpec(idealHeight, 1073741824);
			break;
		}
		int specWidth = MeasureSpec.getSize(widthMeasureSpec);
		if (MeasureSpec.getMode(widthMeasureSpec) != 0) {
			int r6i;
			if (mRequestedTabMaxWidth > 0) {
				r6i = mRequestedTabMaxWidth;
			} else {
				r6i = specWidth - dpToPx(TAB_MIN_WIDTH_MARGIN);
			}
			mTabMaxWidth = r6i;
		}
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		if (getChildCount() == 1) {
			View child = getChildAt(MODE_SCROLLABLE);
			boolean remeasure = false;
			switch(mMode) {
			case MODE_SCROLLABLE:
				if (child.getMeasuredWidth() < getMeasuredWidth()) {
					remeasure = true;
				} else {
					remeasure = false;
				}
				break;
			case MODE_FIXED:
				if (child.getMeasuredWidth() != getMeasuredWidth()) {
					remeasure = true;
				} else {
					remeasure = false;
				}
				break;
			}
			if (remeasure) {
				child.measure(MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), getChildMeasureSpec(heightMeasureSpec, getPaddingTop() + getPaddingBottom(), child.getLayoutParams().height));
			}
		}
	}

	void populateFromPagerAdapter() {
		removeAllTabs();
		if (mPagerAdapter != null) {
			int adapterCount = mPagerAdapter.getCount();
			int i = MODE_SCROLLABLE;
			while (i < adapterCount) {
				addTab(newTab().setText(mPagerAdapter.getPageTitle(i)), false);
				i++;
			}
			if (mViewPager == null || adapterCount <= 0) {
			} else {
				int curItem = mViewPager.getCurrentItem();
				if (curItem == getSelectedTabPosition() || curItem >= getTabCount()) {
				} else {
					selectTab(getTabAt(curItem));
				}
			}
		}
	}

	public void removeAllTabs() {
		int i = mTabStrip.getChildCount() - 1;
		while (i >= 0) {
			removeTabViewAt(i);
			i--;
		}
		Iterator<Tab> i_2 = mTabs.iterator();
		while (i_2.hasNext()) {
			Tab tab = (Tab) i_2.next();
			i_2.remove();
			tab.reset();
			sTabPool.release(tab);
		}
		mSelectedTab = null;
	}

	public void removeOnTabSelectedListener(@NonNull OnTabSelectedListener listener) {
		mSelectedListeners.remove(listener);
	}

	public void removeTab(Tab tab) {
		if (tab.mParent != this) {
			throw new IllegalArgumentException("Tab does not belong to this TabLayout.");
		} else {
			removeTabAt(tab.getPosition());
		}
	}

	public void removeTabAt(int position) {
		int selectedTabPosition;
		int r5i = MODE_SCROLLABLE;
		if (mSelectedTab != null) {
			selectedTabPosition = mSelectedTab.getPosition();
		} else {
			selectedTabPosition = 0;
		}
		removeTabViewAt(position);
		Tab removedTab = (Tab) mTabs.remove(position);
		if (removedTab != null) {
			removedTab.reset();
			sTabPool.release(removedTab);
		}
		int i = position;
		while (i < mTabs.size()) {
			((Tab) mTabs.get(i)).setPosition(i);
			i++;
		}
		if (selectedTabPosition == position) {
			Tab r4_Tab;
			if (mTabs.isEmpty()) {
				r4_Tab = null;
			} else {
				r4_Tab = (Tab) mTabs.get(Math.max(r5i, position - 1));
			}
			selectTab(r4_Tab);
		}
	}

	void selectTab(Tab tab) {
		selectTab(tab, true);
	}

	void selectTab(Tab tab, boolean updateIndicator) {
		Tab currentTab = mSelectedTab;
		if (currentTab == tab) {
			if (currentTab != null) {
				dispatchTabReselected(tab);
				animateToTab(tab.getPosition());
			}
		} else {
			int newPosition;
			if (tab != null) {
				newPosition = tab.getPosition();
			} else {
				newPosition = -1;
			}
			if (updateIndicator) {
				if ((currentTab == null || currentTab.getPosition() == -1) && newPosition != -1) {
					setScrollPosition(newPosition, BitmapDescriptorFactory.HUE_RED, true);
				} else {
					animateToTab(newPosition);
				}
				if (newPosition != -1) {
					setSelectedTabView(newPosition);
				}
			}
			if (currentTab != null) {
				dispatchTabUnselected(currentTab);
			}
			mSelectedTab = tab;
			if (tab != null) {
				dispatchTabSelected(tab);
			}
		}
	}

	@Deprecated
	public void setOnTabSelectedListener(@Nullable OnTabSelectedListener listener) {
		if (mSelectedListener != null) {
			removeOnTabSelectedListener(mSelectedListener);
		}
		mSelectedListener = listener;
		if (listener != null) {
			addOnTabSelectedListener(listener);
		}
	}

	void setPagerAdapter(@Nullable PagerAdapter adapter, boolean addObserver) {
		if (mPagerAdapter == null || mPagerAdapterObserver == null) {
			mPagerAdapter = adapter;
			if (!addObserver || adapter == null) {
				populateFromPagerAdapter();
			} else {
				if (mPagerAdapterObserver != null) {
					mPagerAdapterObserver = new PagerAdapterObserver(this);
				}
				adapter.registerDataSetObserver(mPagerAdapterObserver);
				populateFromPagerAdapter();
			}
		} else {
			mPagerAdapter.unregisterDataSetObserver(mPagerAdapterObserver);
			mPagerAdapter = adapter;
			if (!addObserver || adapter == null) {
				populateFromPagerAdapter();
			} else if (mPagerAdapterObserver != null) {
				adapter.registerDataSetObserver(mPagerAdapterObserver);
				populateFromPagerAdapter();
			} else {
				mPagerAdapterObserver = new PagerAdapterObserver(this);
				adapter.registerDataSetObserver(mPagerAdapterObserver);
				populateFromPagerAdapter();
			}
		}
	}

	public void setScrollPosition(int position, float positionOffset, boolean updateSelectedText) {
		setScrollPosition(position, positionOffset, updateSelectedText, true);
	}

	void setScrollPosition(int position, float positionOffset, boolean updateSelectedText, boolean updateIndicatorPosition) {
		int roundedPosition = Math.round(((float) position) + positionOffset);
		if (roundedPosition < 0 || roundedPosition >= mTabStrip.getChildCount()) {
		} else {
			if (updateIndicatorPosition) {
				mTabStrip.setIndicatorPositionFromTabPosition(position, positionOffset);
			}
			if (mScrollAnimator == null || !mScrollAnimator.isRunning()) {
				scrollTo(calculateScrollXForTab(position, positionOffset), MODE_SCROLLABLE);
				if (!updateSelectedText) {
					setSelectedTabView(roundedPosition);
				}
			} else {
				mScrollAnimator.cancel();
				scrollTo(calculateScrollXForTab(position, positionOffset), MODE_SCROLLABLE);
				if (!updateSelectedText) {
				} else {
					setSelectedTabView(roundedPosition);
				}
			}
		}
	}

	public void setSelectedTabIndicatorColor(@ColorInt int color) {
		mTabStrip.setSelectedIndicatorColor(color);
	}

	public void setSelectedTabIndicatorHeight(int height) {
		mTabStrip.setSelectedIndicatorHeight(height);
	}

	public void setTabGravity(int gravity) {
		if (mTabGravity != gravity) {
			mTabGravity = gravity;
			applyModeAndGravity();
		}
	}

	public void setTabMode(int mode) {
		if (mode != mMode) {
			mMode = mode;
			applyModeAndGravity();
		}
	}

	public void setTabTextColors(int normalColor, int selectedColor) {
		setTabTextColors(createColorStateList(normalColor, selectedColor));
	}

	public void setTabTextColors(@Nullable ColorStateList textColor) {
		if (mTabTextColors != textColor) {
			mTabTextColors = textColor;
			updateAllTabs();
		}
	}

	@Deprecated
	public void setTabsFromPagerAdapter(@Nullable PagerAdapter adapter) {
		setPagerAdapter(adapter, false);
	}

	public void setupWithViewPager(@Nullable ViewPager viewPager) {
		setupWithViewPager(viewPager, true);
	}

	public void setupWithViewPager(@Nullable ViewPager viewPager, boolean autoRefresh) {
		setupWithViewPager(viewPager, autoRefresh, false);
	}

	public boolean shouldDelayChildPressedState() {
		if (getTabScrollRange() > 0) {
			return true;
		} else {
			return false;
		}
	}

	void updateTabViews(boolean requestLayout) {
		int i = MODE_SCROLLABLE;
		while (i < mTabStrip.getChildCount()) {
			View child = mTabStrip.getChildAt(i);
			child.setMinimumWidth(getTabMinWidth());
			updateTabViewLayoutParams((android.widget.LinearLayout.LayoutParams) child.getLayoutParams());
			if (requestLayout) {
				child.requestLayout();
			}
			i++;
		}
	}
}
