package android.support.design.widget;

import android.content.Context;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.PointerIconCompat;
import android.support.v4.view.VelocityTrackerCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ScrollerCompat;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import org.telegram.tgnet.ConnectionsManager;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.Components.Glow;

abstract class HeaderBehavior<V extends View> extends ViewOffsetBehavior<V> {
	private static final int INVALID_POINTER = -1;
	private int mActivePointerId;
	private Runnable mFlingRunnable;
	private boolean mIsBeingDragged;
	private int mLastMotionY;
	ScrollerCompat mScroller;
	private int mTouchSlop;
	private VelocityTracker mVelocityTracker;

	private class FlingRunnable implements Runnable {
		private final V mLayout;
		private final CoordinatorLayout mParent;
		final /* synthetic */ HeaderBehavior this$0;

		FlingRunnable(HeaderBehavior r1_HeaderBehavior, CoordinatorLayout parent, V layout) {
			super();
			this$0 = r1_HeaderBehavior;
			mParent = parent;
			mLayout = layout;
		}

		public void run() {
			if (mLayout == null || this$0.mScroller == null) {
			} else if (this$0.mScroller.computeScrollOffset()) {
				this$0.setHeaderTopBottomOffset(mParent, mLayout, this$0.mScroller.getCurrY());
				ViewCompat.postOnAnimation(mLayout, this);
			} else {
				this$0.onFlingFinished(mParent, mLayout);
			}
		}
	}


	public HeaderBehavior() {
		super();
		mActivePointerId = -1;
		mTouchSlop = -1;
	}

	public HeaderBehavior(Context context, AttributeSet attrs) {
		super(context, attrs);
		mActivePointerId = -1;
		mTouchSlop = -1;
	}

	private void ensureVelocityTracker() {
		if (mVelocityTracker == null) {
			mVelocityTracker = VelocityTracker.obtain();
		}
	}

	boolean canDragView(V view) {
		return false;
	}

	final boolean fling(CoordinatorLayout coordinatorLayout, V layout, int minOffset, int maxOffset, float velocityY) {
		if (mFlingRunnable != null) {
			layout.removeCallbacks(mFlingRunnable);
			mFlingRunnable = null;
		}
		if (mScroller == null) {
			mScroller = ScrollerCompat.create(layout.getContext());
		}
		mScroller.fling(0, getTopAndBottomOffset(), 0, Math.round(velocityY), 0, 0, minOffset, maxOffset);
		if (mScroller.computeScrollOffset()) {
			mFlingRunnable = new FlingRunnable(this, coordinatorLayout, layout);
			ViewCompat.postOnAnimation(layout, mFlingRunnable);
			return true;
		} else {
			onFlingFinished(coordinatorLayout, layout);
			return false;
		}
	}

	int getMaxDragOffset(V view) {
		return -view.getHeight();
	}

	int getScrollRangeForDragFling(V view) {
		return view.getHeight();
	}

	int getTopBottomOffsetForScrollingSibling() {
		return getTopAndBottomOffset();
	}

	void onFlingFinished(CoordinatorLayout parent, V layout) {
	}

	public boolean onInterceptTouchEvent(CoordinatorLayout parent, V child, MotionEvent ev) {
		if (mTouchSlop < 0) {
			mTouchSlop = ViewConfiguration.get(parent.getContext()).getScaledTouchSlop();
		}
		if (ev.getAction() != 2 || !mIsBeingDragged) {
			int y;
			switch(MotionEventCompat.getActionMasked(ev)) {
			case Glow.ALWAYS:
				mIsBeingDragged = false;
				int x = (int) ev.getX();
				y = (int) ev.getY();
				if (canDragView(child)) {
					if (parent.isPointInChildBounds(child, x, y)) {
						mLastMotionY = y;
						mActivePointerId = ev.getPointerId(0);
						ensureVelocityTracker();
					}
				}
				break;
			case TLRPC.USER_FLAG_ACCESS_HASH:
			case ConnectionsManager.ConnectionStateConnected:
				mIsBeingDragged = false;
				mActivePointerId = -1;
				if (mVelocityTracker != null) {
					mVelocityTracker.recycle();
					mVelocityTracker = null;
				}
				break;
			case TLRPC.USER_FLAG_FIRST_NAME:
				int activePointerId = mActivePointerId;
				if (activePointerId != -1) {
					int pointerIndex = ev.findPointerIndex(activePointerId);
					if (pointerIndex != -1) {
						y = (int) ev.getY(pointerIndex);
						if (Math.abs(y - mLastMotionY) > mTouchSlop) {
							mIsBeingDragged = true;
							mLastMotionY = y;
						}
					}
				}
				break;
			}
			if (mVelocityTracker != null) {
				mVelocityTracker.addMovement(ev);
			}
			return mIsBeingDragged;
		} else {
			return true;
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	public boolean onTouchEvent(android.support.design.widget.CoordinatorLayout r15_parent, V r16_child, android.view.MotionEvent r17_ev) {
		r14_this = this;
		r1 = mTouchSlop;
		if (r1 >= 0) goto L_0x0012;
	L_0x0004:
		r1 = r15_parent.getContext();
		r1 = android.view.ViewConfiguration.get(r1);
		r1 = r1.getScaledTouchSlop();
		mTouchSlop = r1;
	L_0x0012:
		r1 = android.support.v4.view.MotionEventCompat.getActionMasked(r17_ev);
		switch(r1) {
			case 0: goto L_0x0026;
			case 1: goto L_0x0096;
			case 2: goto L_0x0051;
			case 3: goto L_0x00bf;
			default: goto L_0x0019;
		}
	L_0x0019:
		r1 = mVelocityTracker;
		if (r1 == 0) goto L_0x0024;
	L_0x001d:
		r1 = mVelocityTracker;
		r0 = r17_ev;
		r1.addMovement(r0);
	L_0x0024:
		r1 = 1;
	L_0x0025:
		return r1;
	L_0x0026:
		r1 = r17_ev.getX();
		r12 = (int) r1;
		r1 = r17_ev.getY();
		r13 = (int) r1;
		r0 = r16_child;
		r1 = r15_parent.isPointInChildBounds(r0, r12_x, r13_y);
		if (r1 == 0) goto L_0x004f;
	L_0x0038:
		r0 = r16_child;
		r1 = canDragView(r0);
		if (r1 == 0) goto L_0x004f;
	L_0x0040:
		mLastMotionY = r13_y;
		r1 = 0;
		r0 = r17_ev;
		r1 = r0.getPointerId(r1);
		mActivePointerId = r1;
		ensureVelocityTracker();
		goto L_0x0019;
	L_0x004f:
		r1 = 0;
		goto L_0x0025;
	L_0x0051:
		r1 = mActivePointerId;
		r0 = r17_ev;
		r11 = r0.findPointerIndex(r1);
		r1 = -1;
		if (r11_activePointerIndex != r1) goto L_0x005e;
	L_0x005c:
		r1 = 0;
		goto L_0x0025;
	L_0x005e:
		r0 = r17_ev;
		r1 = r0.getY(r11_activePointerIndex);
		r13_y = (int) r1;
		r1 = mLastMotionY;
		r4 = r1 - r13_y;
		r1 = mIsBeingDragged;
		if (r1 != 0) goto L_0x007d;
	L_0x006d:
		r1 = java.lang.Math.abs(r4_dy);
		r2 = mTouchSlop;
		if (r1 <= r2) goto L_0x007d;
	L_0x0075:
		r1 = 1;
		mIsBeingDragged = r1;
		if (r4_dy <= 0) goto L_0x0092;
	L_0x007a:
		r1 = mTouchSlop;
		r4_dy -= r1;
	L_0x007d:
		r1 = mIsBeingDragged;
		if (r1 == 0) goto L_0x0019;
	L_0x0081:
		mLastMotionY = r13_y;
		r0 = r16_child;
		r5 = getMaxDragOffset(r0);
		r6 = 0;
		r1 = r14_this;
		r2 = r15_parent;
		r3 = r16_child;
		r1.scroll(r2, r3, r4_dy, r5, r6);
		goto L_0x0019;
	L_0x0092:
		r1 = mTouchSlop;
		r4_dy += r1;
		goto L_0x007d;
	L_0x0096:
		r1 = mVelocityTracker;
		if (r1 == 0) goto L_0x00bf;
	L_0x009a:
		r1 = mVelocityTracker;
		r0 = r17_ev;
		r1.addMovement(r0);
		r1 = mVelocityTracker;
		r2 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
		r1.computeCurrentVelocity(r2);
		r1 = mVelocityTracker;
		r2 = mActivePointerId;
		r10 = android.support.v4.view.VelocityTrackerCompat.getYVelocity(r1, r2);
		r0 = r16_child;
		r1 = getScrollRangeForDragFling(r0);
		r8 = -r1;
		r9 = 0;
		r5 = r14_this;
		r6 = r15_parent;
		r7 = r16_child;
		r5.fling(r6, r7, r8, r9, r10_yvel);
	L_0x00bf:
		r1 = 0;
		mIsBeingDragged = r1;
		r1 = -1;
		mActivePointerId = r1;
		r1 = mVelocityTracker;
		if (r1 == 0) goto L_0x0019;
	L_0x00c9:
		r1 = mVelocityTracker;
		r1.recycle();
		r1 = 0;
		mVelocityTracker = r1;
		goto L_0x0019;
	}
	*/
	public boolean onTouchEvent(CoordinatorLayout parent, V r16_V, MotionEvent ev) {
		if (mTouchSlop < 0) {
			mTouchSlop = ViewConfiguration.get(parent.getContext()).getScaledTouchSlop();
		}
		int y;
		switch(MotionEventCompat.getActionMasked(ev)) {
		case Glow.ALWAYS:
			y = (int) ev.getY();
			if (!parent.isPointInChildBounds(child, (int) ev.getX(), y) || !canDragView(child)) {
				return false;
			} else {
				mLastMotionY = y;
				mActivePointerId = ev.getPointerId(0);
				ensureVelocityTracker();
			}
			break;
		case TLRPC.USER_FLAG_ACCESS_HASH:
			if (mVelocityTracker != null) {
				mVelocityTracker.addMovement(ev);
				mVelocityTracker.computeCurrentVelocity(PointerIconCompat.TYPE_DEFAULT);
				fling(parent, child, -getScrollRangeForDragFling(child), 0, VelocityTrackerCompat.getYVelocity(mVelocityTracker, mActivePointerId));
			}
			break;
		case TLRPC.USER_FLAG_FIRST_NAME:
			int activePointerIndex = ev.findPointerIndex(mActivePointerId);
			if (activePointerIndex == INVALID_POINTER) {
				return false;
			} else {
				y = (int) ev.getY(activePointerIndex);
				int dy = mLastMotionY - y;
				if (mIsBeingDragged || Math.abs(dy) <= mTouchSlop) {
					if (mIsBeingDragged) {
						mLastMotionY = y;
						scroll(parent, child, dy, getMaxDragOffset(child), 0);
					}
				} else {
					mIsBeingDragged = true;
					if (dy > 0) {
						dy -= mTouchSlop;
						if (mIsBeingDragged) {
						} else {
							mLastMotionY = y;
							scroll(parent, child, dy, getMaxDragOffset(child), 0);
						}
					} else {
						dy += mTouchSlop;
						if (mIsBeingDragged) {
							mLastMotionY = y;
							scroll(parent, child, dy, getMaxDragOffset(child), 0);
						}
					}
				}
			}
			break;
		case ConnectionsManager.ConnectionStateConnected:
			break;
		}
	}

	final int scroll(CoordinatorLayout coordinatorLayout, V header, int dy, int minOffset, int maxOffset) {
		return setHeaderTopBottomOffset(coordinatorLayout, header, getTopBottomOffsetForScrollingSibling() - dy, minOffset, maxOffset);
	}

	int setHeaderTopBottomOffset(CoordinatorLayout parent, V header, int newOffset) {
		return setHeaderTopBottomOffset(parent, header, newOffset, TLRPC.MESSAGE_FLAG_MEGAGROUP, ConnectionsManager.DEFAULT_DATACENTER_ID);
	}

	int setHeaderTopBottomOffset(CoordinatorLayout parent, V header, int newOffset, int minOffset, int maxOffset) {
		int curOffset = getTopAndBottomOffset();
		int consumed = 0;
		if (minOffset == 0 || curOffset < minOffset || curOffset > maxOffset) {
			return consumed;
		} else {
			newOffset = MathUtils.constrain(newOffset, minOffset, maxOffset);
			if (curOffset != newOffset) {
				setTopAndBottomOffset(newOffset);
				consumed = curOffset - newOffset;
			}
			return consumed;
		}
	}
}
