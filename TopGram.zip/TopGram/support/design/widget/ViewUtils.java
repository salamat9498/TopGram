package android.support.design.widget;

import android.graphics.PorterDuff.Mode;
import android.os.Build.VERSION;
import android.support.design.widget.ValueAnimatorCompat.Creator;
import android.support.design.widget.ValueAnimatorCompat.Impl;
import com.rey.material.R;
import net.hockeyapp.android.BuildConfig;
import org.telegram.SQLite.SQLiteCursor;
import org.telegram.tgnet.ConnectionsManager;

class ViewUtils {
	static final Creator DEFAULT_ANIMATOR_CREATOR;

	static class AnonymousClass_1 implements Creator {
		AnonymousClass_1() {
			super();
		}

		public ValueAnimatorCompat createAnimator() {
			Impl r0_Impl;
			if (VERSION.SDK_INT >= 12) {
				r0_Impl = new ValueAnimatorCompatImplHoneycombMr1();
			} else {
				r0_Impl = new ValueAnimatorCompatImplGingerbread();
			}
			return new ValueAnimatorCompat(r0_Impl);
		}
	}


	static {
		DEFAULT_ANIMATOR_CREATOR = new AnonymousClass_1();
	}

	ViewUtils() {
		super();
	}

	static ValueAnimatorCompat createAnimator() {
		return DEFAULT_ANIMATOR_CREATOR.createAnimator();
	}

	static boolean objectEquals(Object a, Object b) {
		if (a != b) {
			if (a == null || !a.equals(b)) {
				return false;
			}
		}
		return true;
	}

	static Mode parseTintMode(int value, Mode defaultMode) {
		switch(value) {
		case ConnectionsManager.ConnectionStateConnected:
			return Mode.SRC_OVER;
		case SQLiteCursor.FIELD_TYPE_NULL:
			return Mode.SRC_IN;
		case BuildConfig.VERSION_CODE:
			return Mode.SRC_ATOP;
		case R.styleable.View_android_minHeight:
			return Mode.MULTIPLY;
		case R.styleable.View_android_soundEffectsEnabled:
			return Mode.SCREEN;
		}
		return defaultMode;
	}
}
