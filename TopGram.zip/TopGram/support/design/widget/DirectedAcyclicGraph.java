package android.support.design.widget;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.Pools.Pool;
import android.support.v4.util.Pools.SimplePool;
import android.support.v4.util.SimpleArrayMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

final class DirectedAcyclicGraph<T> {
	private final SimpleArrayMap<T, ArrayList<T>> mGraph;
	private final Pool<ArrayList<T>> mListPool;
	private final ArrayList<T> mSortResult;
	private final HashSet<T> mSortTmpMarked;

	DirectedAcyclicGraph() {
		super();
		mListPool = new SimplePool(10);
		mGraph = new SimpleArrayMap();
		mSortResult = new ArrayList();
		mSortTmpMarked = new HashSet();
	}

	private void dfs(T node, ArrayList<T> result, HashSet<T> tmpMarked) {
		if (result.contains(node)) {
		} else if (tmpMarked.contains(node)) {
			throw new RuntimeException("This graph contains cyclic dependencies");
		} else {
			tmpMarked.add(node);
			ArrayList<T> edges = (ArrayList) mGraph.get(node);
			if (edges != null) {
				int i = 0;
				while (i < edges.size()) {
					dfs(edges.get(i), result, tmpMarked);
					i++;
				}
			}
			tmpMarked.remove(node);
			result.add(node);
		}
	}

	@NonNull
	private ArrayList<T> getEmptyList() {
		ArrayList<T> list = (ArrayList) mListPool.acquire();
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	private void poolList(@NonNull ArrayList<T> list) {
		list.clear();
		mListPool.release(list);
	}

	void addEdge(@NonNull T node, @NonNull T incomingEdge) {
		if (!mGraph.containsKey(node) || !mGraph.containsKey(incomingEdge)) {
			throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
		} else {
			ArrayList<T> edges = (ArrayList) mGraph.get(node);
			if (edges == null) {
				edges = getEmptyList();
				mGraph.put(node, edges);
			}
			edges.add(incomingEdge);
		}
	}

	void addNode(@NonNull T node) {
		if (!mGraph.containsKey(node)) {
			mGraph.put(node, null);
		}
	}

	void clear() {
		int i = 0;
		while (i < mGraph.size()) {
			ArrayList<T> edges = (ArrayList) mGraph.valueAt(i);
			if (edges != null) {
				poolList(edges);
			}
			i++;
		}
		mGraph.clear();
	}

	boolean contains(@NonNull T node) {
		return mGraph.containsKey(node);
	}

	@Nullable
	List getIncomingEdges(@NonNull T node) {
		return (List) mGraph.get(node);
	}

	@Nullable
	List getOutgoingEdges(@NonNull T node) {
		ArrayList<T> result = null;
		int i = 0;
		while (i < mGraph.size()) {
			ArrayList<T> edges = (ArrayList) mGraph.valueAt(i);
			if (edges == null || !edges.contains(node)) {
				i++;
			} else {
				if (result == null) {
					result = new ArrayList();
				}
				result.add(mGraph.keyAt(i));
				i++;
			}
		}
		return result;
	}

	@NonNull
	ArrayList<T> getSortedList() {
		mSortResult.clear();
		mSortTmpMarked.clear();
		int i = 0;
		while (i < mGraph.size()) {
			dfs(mGraph.keyAt(i), mSortResult, mSortTmpMarked);
			i++;
		}
		return mSortResult;
	}

	/* JADX WARNING: inconsistent code */
	/*
	boolean hasOutgoingEdges(@android.support.annotation.NonNull T r5_node) {
		r4_this = this;
		r1 = 0;
		r3 = mGraph;
		r2 = r3.size();
	L_0x0007:
		if (r1_i >= r2_size) goto L_0x001e;
	L_0x0009:
		r3 = mGraph;
		r0 = r3.valueAt(r1_i);
		r0 = (java.util.ArrayList) r0;
		if (r0_edges == 0) goto L_0x001b;
	L_0x0013:
		r3 = r0_edges.contains(r5_node);
		if (r3 == 0) goto L_0x001b;
	L_0x0019:
		r3 = 1;
	L_0x001a:
		return r3;
	L_0x001b:
		r1_i++;
		goto L_0x0007;
	L_0x001e:
		r3 = 0;
		goto L_0x001a;
	}
	*/
	boolean hasOutgoingEdges(@NonNull T r5_T) {
		int i = 0;
		while (i < mGraph.size()) {
			ArrayList<T> edges = (ArrayList) mGraph.valueAt(i);
			if (edges == null || !edges.contains(node)) {
				i++;
			}
		}
		return false;
	}

	int size() {
		return mGraph.size();
	}
}
