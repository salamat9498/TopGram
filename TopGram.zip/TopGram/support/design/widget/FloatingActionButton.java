package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;
import android.support.design.R;
import android.support.design.widget.CoordinatorLayout.DefaultBehavior;
import android.support.design.widget.CoordinatorLayout.LayoutParams;
import android.support.design.widget.FloatingActionButtonImpl.InternalVisibilityChangedListener;
import android.support.v4.content.res.ConfigurationHelper;
import android.support.v4.view.ViewCompat;
import android.support.v7.widget.AppCompatImageHelper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.Components.Glow;

@DefaultBehavior(Behavior.class)
public class FloatingActionButton extends VisibilityAwareImageButton {
	private static final int AUTO_MINI_LARGEST_SCREEN_WIDTH = 470;
	private static final String LOG_TAG = "FloatingActionButton";
	public static final int SIZE_AUTO = -1;
	public static final int SIZE_MINI = 1;
	public static final int SIZE_NORMAL = 0;
	private ColorStateList mBackgroundTint;
	private Mode mBackgroundTintMode;
	private int mBorderWidth;
	boolean mCompatPadding;
	private AppCompatImageHelper mImageHelper;
	int mImagePadding;
	private FloatingActionButtonImpl mImpl;
	private int mMaxImageSize;
	private int mRippleColor;
	final Rect mShadowPadding;
	private int mSize;
	private final Rect mTouchArea;

	class AnonymousClass_1 implements InternalVisibilityChangedListener {
		final /* synthetic */ FloatingActionButton this$0;
		final /* synthetic */ FloatingActionButton.OnVisibilityChangedListener val$listener;

		AnonymousClass_1(FloatingActionButton this$0, FloatingActionButton.OnVisibilityChangedListener r2_FloatingActionButton_OnVisibilityChangedListener) {
			super();
			this.this$0 = this$0;
			val$listener = r2_FloatingActionButton_OnVisibilityChangedListener;
		}

		public void onHidden() {
			val$listener.onHidden(this$0);
		}

		public void onShown() {
			val$listener.onShown(this$0);
		}
	}

	public static class Behavior extends CoordinatorLayout.Behavior<FloatingActionButton> {
		private static final boolean AUTO_HIDE_DEFAULT = true;
		private boolean mAutoHideEnabled;
		private FloatingActionButton.OnVisibilityChangedListener mInternalAutoHideListener;
		private Rect mTmpRect;

		public Behavior() {
			super();
			mAutoHideEnabled = true;
		}

		public Behavior(Context context, AttributeSet attrs) {
			super(context, attrs);
			TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.FloatingActionButton_Behavior_Layout);
			mAutoHideEnabled = a.getBoolean(R.styleable.FloatingActionButton_Behavior_Layout_behavior_autoHide, AUTO_HIDE_DEFAULT);
			a.recycle();
		}

		private static boolean isBottomSheet(@NonNull View view) {
			LayoutParams lp = view.getLayoutParams();
			if (lp instanceof LayoutParams) {
				return ((LayoutParams) lp).getBehavior() instanceof BottomSheetBehavior;
			} else {
				return false;
			}
		}

		private void offsetIfNeeded(CoordinatorLayout parent, FloatingActionButton fab) {
			Rect padding = fab.mShadowPadding;
			if (padding == null || padding.centerX() <= 0 || padding.centerY() <= 0) {
			} else {
				LayoutParams lp = (LayoutParams) fab.getLayoutParams();
				int offsetTB = 0;
				int offsetLR = 0;
				if (fab.getRight() >= parent.getWidth() - lp.rightMargin) {
					offsetLR = padding.right;
				} else if (fab.getLeft() <= lp.leftMargin) {
					offsetLR = -padding.left;
				}
				if (fab.getBottom() >= parent.getHeight() - lp.bottomMargin) {
					offsetTB = padding.bottom;
				} else if (fab.getTop() <= lp.topMargin) {
					offsetTB = -padding.top;
				}
				if (offsetTB != 0) {
					ViewCompat.offsetTopAndBottom(fab, offsetTB);
				}
				if (offsetLR != 0) {
					ViewCompat.offsetLeftAndRight(fab, offsetLR);
				}
			}
		}

		private boolean shouldUpdateVisibility(View dependency, FloatingActionButton child) {
			LayoutParams lp = (LayoutParams) child.getLayoutParams();
			if (!mAutoHideEnabled) {
				return false;
			} else if (lp.getAnchorId() == dependency.getId()) {
				if (child.getUserSetVisibility() == 0) {
					return AUTO_HIDE_DEFAULT;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		private boolean updateFabVisibilityForAppBarLayout(CoordinatorLayout parent, AppBarLayout appBarLayout, FloatingActionButton child) {
			if (!shouldUpdateVisibility(appBarLayout, child)) {
				return false;
			} else {
				if (mTmpRect == null) {
					mTmpRect = new Rect();
				}
				Rect rect = mTmpRect;
				ViewGroupUtils.getDescendantRect(parent, appBarLayout, rect);
				if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
					child.hide(mInternalAutoHideListener, false);
				} else {
					child.show(mInternalAutoHideListener, false);
				}
				return AUTO_HIDE_DEFAULT;
			}
		}

		private boolean updateFabVisibilityForBottomSheet(View bottomSheet, FloatingActionButton child) {
			if (!shouldUpdateVisibility(bottomSheet, child)) {
				return false;
			} else {
				if (bottomSheet.getTop() < (child.getHeight() / 2) + ((LayoutParams) child.getLayoutParams()).topMargin) {
					child.hide(mInternalAutoHideListener, false);
				} else {
					child.show(mInternalAutoHideListener, false);
				}
				return AUTO_HIDE_DEFAULT;
			}
		}

		public boolean getInsetDodgeRect(@NonNull CoordinatorLayout parent, @NonNull FloatingActionButton child, @NonNull Rect rect) {
			Rect shadowPadding = child.mShadowPadding;
			rect.set(child.getLeft() + shadowPadding.left, child.getTop() + shadowPadding.top, child.getRight() - shadowPadding.right, child.getBottom() - shadowPadding.bottom);
			return AUTO_HIDE_DEFAULT;
		}

		public boolean isAutoHideEnabled() {
			return mAutoHideEnabled;
		}

		public void onAttachedToLayoutParams(@NonNull LayoutParams lp) {
			if (lp.dodgeInsetEdges == 0) {
				lp.dodgeInsetEdges = 80;
			}
		}

		public boolean onDependentViewChanged(CoordinatorLayout parent, FloatingActionButton child, View dependency) {
			if (dependency instanceof AppBarLayout) {
				updateFabVisibilityForAppBarLayout(parent, (AppBarLayout) dependency, child);
			} else if (isBottomSheet(dependency)) {
				updateFabVisibilityForBottomSheet(dependency, child);
			}
			return false;
		}

		public boolean onLayoutChild(CoordinatorLayout parent, FloatingActionButton child, int layoutDirection) {
			List<View> dependencies = parent.getDependencies(child);
			int i = 0;
			while (i < dependencies.size()) {
				View dependency = (View) dependencies.get(i);
				if (dependency instanceof AppBarLayout) {
					if (updateFabVisibilityForAppBarLayout(parent, (AppBarLayout) dependency, child)) {
						parent.onLayoutChild(child, layoutDirection);
						offsetIfNeeded(parent, child);
						return AUTO_HIDE_DEFAULT;
					}
				} else if (!isBottomSheet(dependency) || !updateFabVisibilityForBottomSheet(dependency, child)) {
					i++;
				}
				i++;
			}
			parent.onLayoutChild(child, layoutDirection);
			offsetIfNeeded(parent, child);
			return AUTO_HIDE_DEFAULT;
		}

		public void setAutoHideEnabled(boolean autoHide) {
			mAutoHideEnabled = autoHide;
		}

		@VisibleForTesting
		void setInternalAutoHideListener(FloatingActionButton.OnVisibilityChangedListener listener) {
			mInternalAutoHideListener = listener;
		}
	}

	public static abstract class OnVisibilityChangedListener {
		public OnVisibilityChangedListener() {
			super();
		}

		public void onHidden(FloatingActionButton fab) {
		}

		public void onShown(FloatingActionButton fab) {
		}
	}

	private class ShadowDelegateImpl implements ShadowViewDelegate {
		final /* synthetic */ FloatingActionButton this$0;

		ShadowDelegateImpl(FloatingActionButton r1_FloatingActionButton) {
			super();
			this$0 = r1_FloatingActionButton;
		}

		public float getRadius() {
			return ((float) this$0.getSizeDimension()) / 2.0f;
		}

		public boolean isCompatPaddingEnabled() {
			return this$0.mCompatPadding;
		}

		public void setBackgroundDrawable(Drawable background) {
			super.setBackgroundDrawable(background);
		}

		public void setShadowPadding(int left, int top, int right, int bottom) {
			this$0.mShadowPadding.set(left, top, right, bottom);
			this$0.setPadding(this$0.mImagePadding + left, this$0.mImagePadding + top, this$0.mImagePadding + right, this$0.mImagePadding + bottom);
		}
	}

	@Retention(RetentionPolicy.SOURCE)
	public static @interface Size {
	}


	public FloatingActionButton(Context context) {
		this(context, null);
	}

	public FloatingActionButton(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public FloatingActionButton(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		mShadowPadding = new Rect();
		mTouchArea = new Rect();
		ThemeUtils.checkAppCompatTheme(context);
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.FloatingActionButton, defStyleAttr, R.style.Widget_Design_FloatingActionButton);
		mBackgroundTint = a.getColorStateList(R.styleable.FloatingActionButton_backgroundTint);
		mBackgroundTintMode = ViewUtils.parseTintMode(a.getInt(R.styleable.FloatingActionButton_backgroundTintMode, SIZE_AUTO), null);
		mRippleColor = a.getColor(R.styleable.FloatingActionButton_rippleColor, 0);
		mSize = a.getInt(R.styleable.FloatingActionButton_fabSize, SIZE_AUTO);
		mBorderWidth = a.getDimensionPixelSize(R.styleable.FloatingActionButton_borderWidth, 0);
		mCompatPadding = a.getBoolean(R.styleable.FloatingActionButton_useCompatPadding, false);
		a.recycle();
		mImageHelper = new AppCompatImageHelper(this);
		mImageHelper.loadFromAttributes(attrs, defStyleAttr);
		mMaxImageSize = (int) getResources().getDimension(R.dimen.design_fab_image_size);
		getImpl().setBackgroundDrawable(mBackgroundTint, mBackgroundTintMode, mRippleColor, mBorderWidth);
		getImpl().setElevation(a.getDimension(R.styleable.FloatingActionButton_elevation, BitmapDescriptorFactory.HUE_RED));
		getImpl().setPressedTranslationZ(a.getDimension(R.styleable.FloatingActionButton_pressedTranslationZ, BitmapDescriptorFactory.HUE_RED));
	}

	private FloatingActionButtonImpl createImpl() {
		int sdk = VERSION.SDK_INT;
		if (sdk >= 21) {
			return new FloatingActionButtonLollipop(this, new ShadowDelegateImpl(this), ViewUtils.DEFAULT_ANIMATOR_CREATOR);
		} else if (sdk >= 14) {
			return new FloatingActionButtonIcs(this, new ShadowDelegateImpl(this), ViewUtils.DEFAULT_ANIMATOR_CREATOR);
		} else {
			return new FloatingActionButtonGingerbread(this, new ShadowDelegateImpl(this), ViewUtils.DEFAULT_ANIMATOR_CREATOR);
		}
	}

	private FloatingActionButtonImpl getImpl() {
		if (mImpl == null) {
			mImpl = createImpl();
		}
		return mImpl;
	}

	private int getSizeDimension(int size) {
		Resources res = getResources();
		switch(size) {
		case SIZE_AUTO:
			if (Math.max(ConfigurationHelper.getScreenWidthDp(res), ConfigurationHelper.getScreenHeightDp(res)) < 470) {
				return getSizeDimension(SIZE_MINI);
			} else {
				return getSizeDimension(0);
			}
		case SIZE_MINI:
			return res.getDimensionPixelSize(R.dimen.design_fab_size_mini);
		}
		return res.getDimensionPixelSize(R.dimen.design_fab_size_normal);
	}

	private static int resolveAdjustedSize(int desiredSize, int measureSpec) {
		int result = desiredSize;
		int specSize = MeasureSpec.getSize(measureSpec);
		switch(MeasureSpec.getMode(measureSpec)) {
		case TLRPC.MESSAGE_FLAG_MEGAGROUP:
			return Math.min(desiredSize, specSize);
		case Glow.ALWAYS:
			return desiredSize;
		case 1073741824:
			return specSize;
		}
		return result;
	}

	@Nullable
	private InternalVisibilityChangedListener wrapOnVisibilityChangedListener(@Nullable OnVisibilityChangedListener listener) {
		if (listener == null) {
			return null;
		} else {
			return new AnonymousClass_1(this, listener);
		}
	}

	protected void drawableStateChanged() {
		super.drawableStateChanged();
		getImpl().onDrawableStateChanged(getDrawableState());
	}

	@Nullable
	public ColorStateList getBackgroundTintList() {
		return mBackgroundTint;
	}

	@Nullable
	public Mode getBackgroundTintMode() {
		return mBackgroundTintMode;
	}

	public float getCompatElevation() {
		return getImpl().getElevation();
	}

	@NonNull
	public Drawable getContentBackground() {
		return getImpl().getContentBackground();
	}

	public boolean getContentRect(@NonNull Rect rect) {
		boolean r0z = false;
		if (ViewCompat.isLaidOut(this)) {
			rect.set(SIZE_MINI, SIZE_MINI, getWidth(), getHeight());
			rect.left += mShadowPadding.left;
			rect.top += mShadowPadding.top;
			rect.right -= mShadowPadding.right;
			rect.bottom -= mShadowPadding.bottom;
			r0z = true;
		}
		return r0z;
	}

	public int getSize() {
		return mSize;
	}

	int getSizeDimension() {
		return getSizeDimension(mSize);
	}

	public boolean getUseCompatPadding() {
		return mCompatPadding;
	}

	public void hide() {
		hide(null);
	}

	public void hide(@Nullable OnVisibilityChangedListener listener) {
		hide(listener, true);
	}

	void hide(@Nullable OnVisibilityChangedListener listener, boolean fromUser) {
		getImpl().hide(wrapOnVisibilityChangedListener(listener), fromUser);
	}

	@TargetApi(11)
	public void jumpDrawablesToCurrentState() {
		super.jumpDrawablesToCurrentState();
		getImpl().jumpDrawableToCurrentState();
	}

	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		getImpl().onAttachedToWindow();
	}

	protected void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		getImpl().onDetachedFromWindow();
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int preferredSize = getSizeDimension();
		mImagePadding = (preferredSize - mMaxImageSize) / 2;
		getImpl().updatePadding();
		int d = Math.min(resolveAdjustedSize(preferredSize, widthMeasureSpec), resolveAdjustedSize(preferredSize, heightMeasureSpec));
		setMeasuredDimension((mShadowPadding.left + d) + mShadowPadding.right, (mShadowPadding.top + d) + mShadowPadding.bottom);
	}

	public boolean onTouchEvent(MotionEvent ev) {
		if (!getContentRect(mTouchArea) || mTouchArea.contains((int) ev.getX(), (int) ev.getY())) {
			return super.onTouchEvent(ev);
		} else {
			return false;
		}
	}

	public void setBackgroundColor(int color) {
		Log.i(LOG_TAG, "Setting a custom background is not supported.");
	}

	public void setBackgroundDrawable(Drawable background) {
		Log.i(LOG_TAG, "Setting a custom background is not supported.");
	}

	public void setBackgroundResource(int resid) {
		Log.i(LOG_TAG, "Setting a custom background is not supported.");
	}

	public void setBackgroundTintList(@Nullable ColorStateList tint) {
		if (mBackgroundTint != tint) {
			mBackgroundTint = tint;
			getImpl().setBackgroundTintList(tint);
		}
	}

	public void setBackgroundTintMode(@Nullable Mode tintMode) {
		if (mBackgroundTintMode != tintMode) {
			mBackgroundTintMode = tintMode;
			getImpl().setBackgroundTintMode(tintMode);
		}
	}

	public void setCompatElevation(float elevation) {
		getImpl().setElevation(elevation);
	}

	public void setImageResource(@DrawableRes int resId) {
		mImageHelper.setImageResource(resId);
	}

	public void setRippleColor(@ColorInt int color) {
		if (mRippleColor != color) {
			mRippleColor = color;
			getImpl().setRippleColor(color);
		}
	}

	public void setSize(int size) {
		if (size != mSize) {
			mSize = size;
			requestLayout();
		}
	}

	public void setUseCompatPadding(boolean useCompatPadding) {
		if (mCompatPadding != useCompatPadding) {
			mCompatPadding = useCompatPadding;
			getImpl().onCompatShadowChanged();
		}
	}

	public /* bridge */ /* synthetic */ void setVisibility(int r1i) {
		super.setVisibility(r1i);
	}

	public void show() {
		show(null);
	}

	public void show(@Nullable OnVisibilityChangedListener listener) {
		show(listener, true);
	}

	void show(OnVisibilityChangedListener listener, boolean fromUser) {
		getImpl().show(wrapOnVisibilityChangedListener(listener), fromUser);
	}
}
