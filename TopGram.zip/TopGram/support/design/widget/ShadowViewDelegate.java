package android.support.design.widget;

import android.graphics.drawable.Drawable;

interface ShadowViewDelegate {
	public float getRadius();

	public boolean isCompatPaddingEnabled();

	public void setBackgroundDrawable(Drawable r1_Drawable);

	public void setShadowPadding(int r1i, int r2i, int r3i, int r4i);
}
