package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.ColorInt;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.StringRes;
import android.support.design.R;
import android.support.design.widget.Snackbar.SnackbarLayout.OnAttachStateChangeListener;
import android.support.design.widget.Snackbar.SnackbarLayout.OnLayoutChangeListener;
import android.support.design.widget.SwipeDismissBehavior.OnDismissListener;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v7.appcompat.R;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import org.telegram.tgnet.ConnectionsManager;
import org.telegram.tgnet.TLRPC;

public final class Snackbar {
	static final int ANIMATION_DURATION = 250;
	static final int ANIMATION_FADE_DURATION = 180;
	public static final int LENGTH_INDEFINITE = -2;
	public static final int LENGTH_LONG = 0;
	public static final int LENGTH_SHORT = -1;
	static final int MSG_DISMISS = 1;
	static final int MSG_SHOW = 0;
	static final Handler sHandler;
	private final AccessibilityManager mAccessibilityManager;
	private Callback mCallback;
	private final Context mContext;
	private int mDuration;
	final SnackbarManager.Callback mManagerCallback;
	private final ViewGroup mTargetParent;
	final SnackbarLayout mView;

	class AnonymousClass_10 implements AnimationListener {
		final /* synthetic */ Snackbar this$0;
		final /* synthetic */ int val$event;

		AnonymousClass_10(Snackbar this$0, int r2i) {
			super();
			this.this$0 = this$0;
			val$event = r2i;
		}

		public void onAnimationEnd(Animation animation) {
			this$0.onViewHidden(val$event);
		}

		public void onAnimationRepeat(Animation animation) {
		}

		public void onAnimationStart(Animation animation) {
		}
	}

	static class AnonymousClass_1 implements android.os.Handler.Callback {
		AnonymousClass_1() {
			super();
		}

		public boolean handleMessage(Message message) {
			switch(message.what) {
			case LENGTH_LONG:
				((Snackbar) message.obj).showView();
				return true;
			case MSG_DISMISS:
				((Snackbar) message.obj).hideView(message.arg1);
				return true;
			}
			return false;
		}
	}

	class AnonymousClass_2 implements OnClickListener {
		final /* synthetic */ Snackbar this$0;
		final /* synthetic */ OnClickListener val$listener;

		AnonymousClass_2(Snackbar this$0, OnClickListener r2_OnClickListener) {
			super();
			this.this$0 = this$0;
			val$listener = r2_OnClickListener;
		}

		public void onClick(View view) {
			val$listener.onClick(view);
			this$0.dispatchDismiss(MSG_DISMISS);
		}
	}

	class AnonymousClass_3 implements SnackbarManager.Callback {
		final /* synthetic */ Snackbar this$0;

		AnonymousClass_3(Snackbar this$0) {
			super();
			this.this$0 = this$0;
		}

		public void dismiss(int event) {
			sHandler.sendMessage(sHandler.obtainMessage(MSG_DISMISS, event, LENGTH_LONG, this$0));
		}

		public void show() {
			sHandler.sendMessage(sHandler.obtainMessage(LENGTH_LONG, this$0));
		}
	}

	class AnonymousClass_4 implements OnDismissListener {
		final /* synthetic */ Snackbar this$0;

		AnonymousClass_4(Snackbar this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onDismiss(View view) {
			view.setVisibility(TLRPC.USER_FLAG_USERNAME);
			this$0.dispatchDismiss(LENGTH_LONG);
		}

		public void onDragStateChanged(int state) {
			switch(state) {
			case LENGTH_LONG:
				SnackbarManager.getInstance().restoreTimeout(this$0.mManagerCallback);
			case MSG_DISMISS:
			case TLRPC.USER_FLAG_FIRST_NAME:
				SnackbarManager.getInstance().cancelTimeout(this$0.mManagerCallback);
			}
		}
	}

	class AnonymousClass_5 implements OnAttachStateChangeListener {
		final /* synthetic */ Snackbar this$0;

		class AnonymousClass_1 implements Runnable {
			final /* synthetic */ Snackbar.AnonymousClass_5 this$1;

			AnonymousClass_1(Snackbar.AnonymousClass_5 this$1) {
				super();
				this.this$1 = this$1;
			}

			public void run() {
				this$1.this$0.onViewHidden(ConnectionsManager.ConnectionStateConnected);
			}
		}


		AnonymousClass_5(Snackbar this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onViewAttachedToWindow(View v) {
		}

		public void onViewDetachedFromWindow(View v) {
			if (this$0.isShownOrQueued()) {
				sHandler.post(new AnonymousClass_1(this));
			}
		}
	}

	class AnonymousClass_6 implements OnLayoutChangeListener {
		final /* synthetic */ Snackbar this$0;

		AnonymousClass_6(Snackbar this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onLayoutChange(View view, int left, int top, int right, int bottom) {
			this$0.mView.setOnLayoutChangeListener(null);
			if (this$0.shouldAnimate()) {
				this$0.animateViewIn();
			} else {
				this$0.onViewShown();
			}
		}
	}

	class AnonymousClass_7 extends ViewPropertyAnimatorListenerAdapter {
		final /* synthetic */ Snackbar this$0;

		AnonymousClass_7(Snackbar this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onAnimationEnd(View view) {
			this$0.onViewShown();
		}

		public void onAnimationStart(View view) {
			this$0.mView.animateChildrenIn(R.styleable.AppCompatTheme_listPreferredItemHeight, ANIMATION_FADE_DURATION);
		}
	}

	class AnonymousClass_8 implements AnimationListener {
		final /* synthetic */ Snackbar this$0;

		AnonymousClass_8(Snackbar this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onAnimationEnd(Animation animation) {
			this$0.onViewShown();
		}

		public void onAnimationRepeat(Animation animation) {
		}

		public void onAnimationStart(Animation animation) {
		}
	}

	class AnonymousClass_9 extends ViewPropertyAnimatorListenerAdapter {
		final /* synthetic */ Snackbar this$0;
		final /* synthetic */ int val$event;

		AnonymousClass_9(Snackbar this$0, int r2i) {
			super();
			this.this$0 = this$0;
			val$event = r2i;
		}

		public void onAnimationEnd(View view) {
			this$0.onViewHidden(val$event);
		}

		public void onAnimationStart(View view) {
			this$0.mView.animateChildrenOut(LENGTH_LONG, ANIMATION_FADE_DURATION);
		}
	}

	final class Behavior extends SwipeDismissBehavior<Snackbar.SnackbarLayout> {
		final /* synthetic */ Snackbar this$0;

		Behavior(Snackbar this$0) {
			super();
			this.this$0 = this$0;
		}

		public boolean canSwipeDismissView(View child) {
			return child instanceof Snackbar.SnackbarLayout;
		}

		public boolean onInterceptTouchEvent(CoordinatorLayout parent, Snackbar.SnackbarLayout child, MotionEvent event) {
			if (parent.isPointInChildBounds(child, (int) event.getX(), (int) event.getY())) {
				switch(event.getActionMasked()) {
				case LENGTH_LONG:
					SnackbarManager.getInstance().cancelTimeout(this$0.mManagerCallback);
					break;
				case MSG_DISMISS:
				case ConnectionsManager.ConnectionStateConnected:
					SnackbarManager.getInstance().restoreTimeout(this$0.mManagerCallback);
					break;
				}
			}
			return super.onInterceptTouchEvent(parent, child, event);
		}
	}

	public static abstract class Callback {
		public static final int DISMISS_EVENT_ACTION = 1;
		public static final int DISMISS_EVENT_CONSECUTIVE = 4;
		public static final int DISMISS_EVENT_MANUAL = 3;
		public static final int DISMISS_EVENT_SWIPE = 0;
		public static final int DISMISS_EVENT_TIMEOUT = 2;

		@Retention(RetentionPolicy.SOURCE)
		public static @interface DismissEvent {
		}


		public Callback() {
			super();
		}

		public void onDismissed(Snackbar snackbar, int event) {
		}

		public void onShown(Snackbar snackbar) {
		}
	}

	@Retention(RetentionPolicy.SOURCE)
	@IntRange(from = 1)
	public static @interface Duration {
	}

	public static class SnackbarLayout extends LinearLayout {
		private Button mActionView;
		private int mMaxInlineActionWidth;
		private int mMaxWidth;
		private TextView mMessageView;
		private OnAttachStateChangeListener mOnAttachStateChangeListener;
		private OnLayoutChangeListener mOnLayoutChangeListener;

		static interface OnAttachStateChangeListener {
			public void onViewAttachedToWindow(View r1_View);

			public void onViewDetachedFromWindow(View r1_View);
		}

		static interface OnLayoutChangeListener {
			public void onLayoutChange(View r1_View, int r2i, int r3i, int r4i, int r5i);
		}

		class AnonymousClass_1 implements OnApplyWindowInsetsListener {
			final /* synthetic */ Snackbar.SnackbarLayout this$0;

			AnonymousClass_1(Snackbar.SnackbarLayout this$0) {
				super();
				this.this$0 = this$0;
			}

			public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
				v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), insets.getSystemWindowInsetBottom());
				return insets;
			}
		}


		public SnackbarLayout(Context context) {
			this(context, null);
		}

		public SnackbarLayout(Context context, AttributeSet attrs) {
			super(context, attrs);
			TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.SnackbarLayout);
			mMaxWidth = a.getDimensionPixelSize(R.styleable.SnackbarLayout_android_maxWidth, LENGTH_SHORT);
			mMaxInlineActionWidth = a.getDimensionPixelSize(R.styleable.SnackbarLayout_maxActionInlineWidth, LENGTH_SHORT);
			if (a.hasValue(R.styleable.SnackbarLayout_elevation)) {
				ViewCompat.setElevation(this, (float) a.getDimensionPixelSize(R.styleable.SnackbarLayout_elevation, LENGTH_LONG));
			}
			a.recycle();
			setClickable(true);
			LayoutInflater.from(context).inflate(R.layout.design_layout_snackbar_include, this);
			ViewCompat.setAccessibilityLiveRegion(this, MSG_DISMISS);
			ViewCompat.setImportantForAccessibility(this, MSG_DISMISS);
			ViewCompat.setFitsSystemWindows(this, true);
			ViewCompat.setOnApplyWindowInsetsListener(this, new AnonymousClass_1(this));
		}

		private static void updateTopBottomPadding(View view, int topPadding, int bottomPadding) {
			if (ViewCompat.isPaddingRelative(view)) {
				ViewCompat.setPaddingRelative(view, ViewCompat.getPaddingStart(view), topPadding, ViewCompat.getPaddingEnd(view), bottomPadding);
			} else {
				view.setPadding(view.getPaddingLeft(), topPadding, view.getPaddingRight(), bottomPadding);
			}
		}

		private boolean updateViewsWithinLayout(int orientation, int messagePadTop, int messagePadBottom) {
			boolean changed = false;
			if (orientation != getOrientation()) {
				setOrientation(orientation);
				changed = true;
			}
			if (mMessageView.getPaddingTop() != messagePadTop || mMessageView.getPaddingBottom() != messagePadBottom) {
				updateTopBottomPadding(mMessageView, messagePadTop, messagePadBottom);
				changed = true;
			} else {
				return changed;
			}
			return changed;
		}

		void animateChildrenIn(int delay, int duration) {
			ViewCompat.setAlpha(mMessageView, BitmapDescriptorFactory.HUE_RED);
			ViewCompat.animate(mMessageView).alpha(1.0f).setDuration((long) duration).setStartDelay((long) delay).start();
			if (mActionView.getVisibility() == 0) {
				ViewCompat.setAlpha(mActionView, BitmapDescriptorFactory.HUE_RED);
				ViewCompat.animate(mActionView).alpha(1.0f).setDuration((long) duration).setStartDelay((long) delay).start();
			}
		}

		void animateChildrenOut(int delay, int duration) {
			ViewCompat.setAlpha(mMessageView, 1.0f);
			ViewCompat.animate(mMessageView).alpha(BitmapDescriptorFactory.HUE_RED).setDuration((long) duration).setStartDelay((long) delay).start();
			if (mActionView.getVisibility() == 0) {
				ViewCompat.setAlpha(mActionView, 1.0f);
				ViewCompat.animate(mActionView).alpha(BitmapDescriptorFactory.HUE_RED).setDuration((long) duration).setStartDelay((long) delay).start();
			}
		}

		Button getActionView() {
			return mActionView;
		}

		TextView getMessageView() {
			return mMessageView;
		}

		protected void onAttachedToWindow() {
			super.onAttachedToWindow();
			if (mOnAttachStateChangeListener != null) {
				mOnAttachStateChangeListener.onViewAttachedToWindow(this);
			}
			ViewCompat.requestApplyInsets(this);
		}

		protected void onDetachedFromWindow() {
			super.onDetachedFromWindow();
			if (mOnAttachStateChangeListener != null) {
				mOnAttachStateChangeListener.onViewDetachedFromWindow(this);
			}
		}

		protected void onFinishInflate() {
			super.onFinishInflate();
			mMessageView = (TextView) findViewById(R.id.snackbar_text);
			mActionView = (Button) findViewById(R.id.snackbar_action);
		}

		protected void onLayout(boolean changed, int l, int t, int r, int b) {
			super.onLayout(changed, l, t, r, b);
			if (mOnLayoutChangeListener != null) {
				mOnLayoutChangeListener.onLayoutChange(this, l, t, r, b);
			}
		}

		/* JADX WARNING: inconsistent code */
		/*
		protected void onMeasure(int r10_widthMeasureSpec, int r11_heightMeasureSpec) {
			r9_this = this;
			r6 = 0;
			r5 = 1;
			super.onMeasure(r10_widthMeasureSpec, r11_heightMeasureSpec);
			r7 = r9.mMaxWidth;
			if (r7 <= 0) goto L_0x001c;
		L_0x0009:
			r7 = r9.getMeasuredWidth();
			r8 = r9.mMaxWidth;
			if (r7 <= r8) goto L_0x001c;
		L_0x0011:
			r7 = r9.mMaxWidth;
			r8 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
			r10_widthMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec(r7, r8);
			super.onMeasure(r10_widthMeasureSpec, r11_heightMeasureSpec);
		L_0x001c:
			r7 = r9.getResources();
			r8 = android.support.design.R.dimen.design_snackbar_padding_vertical_2lines;
			r2 = r7.getDimensionPixelSize(r8);
			r7 = r9.getResources();
			r8 = android.support.design.R.dimen.design_snackbar_padding_vertical;
			r4 = r7.getDimensionPixelSize(r8);
			r7 = r9.mMessageView;
			r7 = r7.getLayout();
			r7 = r7.getLineCount();
			if (r7 <= r5) goto L_0x005d;
		L_0x003c:
			r0 = r5;
		L_0x003d:
			r3 = 0;
			if (r0_isMultiLine == 0) goto L_0x005f;
		L_0x0040:
			r7 = r9.mMaxInlineActionWidth;
			if (r7 <= 0) goto L_0x005f;
		L_0x0044:
			r7 = r9.mActionView;
			r7 = r7.getMeasuredWidth();
			r8 = r9.mMaxInlineActionWidth;
			if (r7 <= r8) goto L_0x005f;
		L_0x004e:
			r6 = r2_multiLineVPadding - r4_singleLineVPadding;
			r5 = r9.updateViewsWithinLayout(r5, r2_multiLineVPadding, r6);
			if (r5 == 0) goto L_0x0057;
		L_0x0056:
			r3_remeasure = 1;
		L_0x0057:
			if (r3_remeasure == 0) goto L_0x005c;
		L_0x0059:
			super.onMeasure(r10_widthMeasureSpec, r11_heightMeasureSpec);
		L_0x005c:
			return;
		L_0x005d:
			r0_isMultiLine = r6;
			goto L_0x003d;
		L_0x005f:
			if (r0_isMultiLine == 0) goto L_0x006a;
		L_0x0061:
			r1 = r2_multiLineVPadding;
		L_0x0062:
			r5 = r9.updateViewsWithinLayout(r6, r1_messagePadding, r1_messagePadding);
			if (r5 == 0) goto L_0x0057;
		L_0x0068:
			r3_remeasure = 1;
			goto L_0x0057;
		L_0x006a:
			r1_messagePadding = r4_singleLineVPadding;
			goto L_0x0062;
		}
		*/
		protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
			int r5i = MSG_DISMISS;
			super.onMeasure(widthMeasureSpec, heightMeasureSpec);
			int multiLineVPadding;
			int singleLineVPadding;
			boolean isMultiLine;
			boolean remeasure;
			int messagePadding;
			if (mMaxWidth <= 0 || getMeasuredWidth() <= mMaxWidth) {
				multiLineVPadding = getResources().getDimensionPixelSize(R.dimen.design_snackbar_padding_vertical_2lines);
				singleLineVPadding = getResources().getDimensionPixelSize(R.dimen.design_snackbar_padding_vertical);
				if (mMessageView.getLayout().getLineCount() <= 1) {
					isMultiLine = true;
				} else {
					isMultiLine = false;
				}
				remeasure = false;
				if (!isMultiLine || mMaxInlineActionWidth <= 0 || mActionView.getMeasuredWidth() <= mMaxInlineActionWidth) {
					messagePadding = singleLineVPadding;
					if (!updateViewsWithinLayout(LENGTH_LONG, messagePadding, messagePadding)) {
						remeasure = true;
					}
				} else if (!updateViewsWithinLayout(r5i, multiLineVPadding, multiLineVPadding - singleLineVPadding)) {
					remeasure = true;
				}
				if (!remeasure) {
					super.onMeasure(widthMeasureSpec, heightMeasureSpec);
				}
			} else {
				widthMeasureSpec = MeasureSpec.makeMeasureSpec(mMaxWidth, 1073741824);
				super.onMeasure(widthMeasureSpec, heightMeasureSpec);
				multiLineVPadding = getResources().getDimensionPixelSize(R.dimen.design_snackbar_padding_vertical_2lines);
				singleLineVPadding = getResources().getDimensionPixelSize(R.dimen.design_snackbar_padding_vertical);
				if (mMessageView.getLayout().getLineCount() <= 1) {
					isMultiLine = false;
				} else {
					isMultiLine = true;
				}
				remeasure = false;
				if (!isMultiLine || mMaxInlineActionWidth <= 0 || mActionView.getMeasuredWidth() <= mMaxInlineActionWidth) {
					messagePadding = singleLineVPadding;
					if (!updateViewsWithinLayout(LENGTH_LONG, messagePadding, messagePadding)) {
						if (!remeasure) {
						} else {
							super.onMeasure(widthMeasureSpec, heightMeasureSpec);
						}
					} else {
						remeasure = true;
					}
				} else if (!updateViewsWithinLayout(r5i, multiLineVPadding, multiLineVPadding - singleLineVPadding)) {
					if (!remeasure) {
						super.onMeasure(widthMeasureSpec, heightMeasureSpec);
					}
				} else {
					remeasure = true;
				}
				if (!remeasure) {
				} else {
					super.onMeasure(widthMeasureSpec, heightMeasureSpec);
				}
			}
		}

		void setOnAttachStateChangeListener(OnAttachStateChangeListener listener) {
			mOnAttachStateChangeListener = listener;
		}

		void setOnLayoutChangeListener(OnLayoutChangeListener onLayoutChangeListener) {
			mOnLayoutChangeListener = onLayoutChangeListener;
		}
	}


	static {
		sHandler = new Handler(Looper.getMainLooper(), new AnonymousClass_1());
	}

	private Snackbar(ViewGroup parent) {
		super();
		mManagerCallback = new AnonymousClass_3(this);
		mTargetParent = parent;
		mContext = parent.getContext();
		ThemeUtils.checkAppCompatTheme(mContext);
		mView = (SnackbarLayout) LayoutInflater.from(mContext).inflate(R.layout.design_layout_snackbar, mTargetParent, false);
		mAccessibilityManager = (AccessibilityManager) mContext.getSystemService("accessibility");
	}

	private void animateViewOut(int event) {
		if (VERSION.SDK_INT >= 14) {
			ViewCompat.animate(mView).translationY((float) mView.getHeight()).setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR).setDuration(250).setListener(new AnonymousClass_9(this, event)).start();
		} else {
			Animation anim = AnimationUtils.loadAnimation(mView.getContext(), R.anim.design_snackbar_out);
			anim.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
			anim.setDuration(250);
			anim.setAnimationListener(new AnonymousClass_10(this, event));
			mView.startAnimation(anim);
		}
	}

	private static ViewGroup findSuitableParent(View view) {
		View fallback = null;
		while (!(view instanceof CoordinatorLayout)) {
			if (view instanceof FrameLayout) {
				if (view.getId() == 16908290) {
					return (ViewGroup) view;
				} else {
					fallback = (ViewGroup) view;
				}
			}
			if (view != null) {
				ViewParent parent = view.getParent();
				if (parent instanceof View) {
					view = (View) parent;
				} else {
					view = null;
				}
			}
			if (view == null) {
				return fallback;
			}
		}
		return (ViewGroup) view;
	}

	@NonNull
	public static Snackbar make(@NonNull View view, @StringRes int resId, int duration) {
		return make(view, view.getResources().getText(resId), duration);
	}

	@NonNull
	public static Snackbar make(@NonNull View view, @NonNull CharSequence text, int duration) {
		Snackbar snackbar = new Snackbar(findSuitableParent(view));
		snackbar.setText(text);
		snackbar.setDuration(duration);
		return snackbar;
	}

	void animateViewIn() {
		if (VERSION.SDK_INT >= 14) {
			ViewCompat.setTranslationY(mView, (float) mView.getHeight());
			ViewCompat.animate(mView).translationY(BitmapDescriptorFactory.HUE_RED).setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR).setDuration(250).setListener(new AnonymousClass_7(this)).start();
		} else {
			Animation anim = AnimationUtils.loadAnimation(mView.getContext(), R.anim.design_snackbar_in);
			anim.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
			anim.setDuration(250);
			anim.setAnimationListener(new AnonymousClass_8(this));
			mView.startAnimation(anim);
		}
	}

	public void dismiss() {
		dispatchDismiss(ConnectionsManager.ConnectionStateConnected);
	}

	void dispatchDismiss(int event) {
		SnackbarManager.getInstance().dismiss(mManagerCallback, event);
	}

	public int getDuration() {
		return mDuration;
	}

	@NonNull
	public View getView() {
		return mView;
	}

	final void hideView(int event) {
		if (!shouldAnimate() || mView.getVisibility() != 0) {
			onViewHidden(event);
		} else {
			animateViewOut(event);
		}
	}

	public boolean isShown() {
		return SnackbarManager.getInstance().isCurrent(mManagerCallback);
	}

	public boolean isShownOrQueued() {
		return SnackbarManager.getInstance().isCurrentOrNext(mManagerCallback);
	}

	void onViewHidden(int event) {
		SnackbarManager.getInstance().onDismissed(mManagerCallback);
		if (mCallback != null) {
			mCallback.onDismissed(this, event);
		}
		if (VERSION.SDK_INT < 11) {
			mView.setVisibility(TLRPC.USER_FLAG_USERNAME);
		}
		ViewParent parent = mView.getParent();
		if (parent instanceof ViewGroup) {
			((ViewGroup) parent).removeView(mView);
		}
	}

	void onViewShown() {
		SnackbarManager.getInstance().onShown(mManagerCallback);
		if (mCallback != null) {
			mCallback.onShown(this);
		}
	}

	@NonNull
	public Snackbar setAction(@StringRes int resId, OnClickListener listener) {
		return setAction(mContext.getText(resId), listener);
	}

	@NonNull
	public Snackbar setAction(CharSequence text, OnClickListener listener) {
		TextView tv = mView.getActionView();
		if (TextUtils.isEmpty(text) || listener == null) {
			tv.setVisibility(TLRPC.USER_FLAG_USERNAME);
			tv.setOnClickListener(null);
			return this;
		} else {
			tv.setVisibility(LENGTH_LONG);
			tv.setText(text);
			tv.setOnClickListener(new AnonymousClass_2(this, listener));
			return this;
		}
	}

	@NonNull
	public Snackbar setActionTextColor(@ColorInt int color) {
		mView.getActionView().setTextColor(color);
		return this;
	}

	@NonNull
	public Snackbar setActionTextColor(ColorStateList colors) {
		mView.getActionView().setTextColor(colors);
		return this;
	}

	@NonNull
	public Snackbar setCallback(Callback callback) {
		mCallback = callback;
		return this;
	}

	@NonNull
	public Snackbar setDuration(int duration) {
		mDuration = duration;
		return this;
	}

	@NonNull
	public Snackbar setText(@StringRes int resId) {
		return setText(mContext.getText(resId));
	}

	@NonNull
	public Snackbar setText(@NonNull CharSequence message) {
		mView.getMessageView().setText(message);
		return this;
	}

	boolean shouldAnimate() {
		if (!mAccessibilityManager.isEnabled()) {
			return true;
		} else {
			return false;
		}
	}

	public void show() {
		SnackbarManager.getInstance().show(mDuration, mManagerCallback);
	}

	final void showView() {
		if (mView.getParent() == null) {
			LayoutParams lp = mView.getLayoutParams();
			if (lp instanceof CoordinatorLayout.LayoutParams) {
				CoordinatorLayout.LayoutParams clp = (CoordinatorLayout.LayoutParams) lp;
				CoordinatorLayout.Behavior behavior = new Behavior(this);
				behavior.setStartAlphaSwipeDistance(0.1f);
				behavior.setEndAlphaSwipeDistance(0.6f);
				behavior.setSwipeDirection(LENGTH_LONG);
				behavior.setListener(new AnonymousClass_4(this));
				clp.setBehavior(behavior);
				clp.insetEdge = 80;
			}
			mTargetParent.addView(mView);
		}
		mView.setOnAttachStateChangeListener(new AnonymousClass_5(this));
		if (ViewCompat.isLaidOut(mView)) {
			if (shouldAnimate()) {
				animateViewIn();
			} else {
				onViewShown();
			}
		} else {
			mView.setOnLayoutChangeListener(new AnonymousClass_6(this));
		}
	}
}
