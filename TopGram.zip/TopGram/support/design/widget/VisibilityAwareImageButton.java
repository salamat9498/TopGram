package android.support.design.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageButton;

class VisibilityAwareImageButton extends ImageButton {
	private int mUserSetVisibility;

	public VisibilityAwareImageButton(Context context) {
		this(context, null);
	}

	public VisibilityAwareImageButton(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public VisibilityAwareImageButton(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		mUserSetVisibility = getVisibility();
	}

	final int getUserSetVisibility() {
		return mUserSetVisibility;
	}

	final void internalSetVisibility(int visibility, boolean fromUser) {
		super.setVisibility(visibility);
		if (fromUser) {
			mUserSetVisibility = visibility;
		}
	}

	public void setVisibility(int visibility) {
		internalSetVisibility(visibility, true);
	}
}
