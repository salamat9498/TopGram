package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;
import android.support.design.R;
import android.support.design.widget.CoordinatorLayout.DefaultBehavior;
import android.support.design.widget.ValueAnimatorCompat.AnimatorUpdateListener;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import org.telegram.SQLite.SQLiteCursor;

@DefaultBehavior(Behavior.class)
public class AppBarLayout extends LinearLayout {
	private static final int INVALID_SCROLL_RANGE = -1;
	static final int PENDING_ACTION_ANIMATE_ENABLED = 4;
	static final int PENDING_ACTION_COLLAPSED = 2;
	static final int PENDING_ACTION_EXPANDED = 1;
	static final int PENDING_ACTION_NONE = 0;
	private boolean mCollapsed;
	private boolean mCollapsible;
	private int mDownPreScrollRange;
	private int mDownScrollRange;
	private boolean mHaveChildWithInterpolator;
	private WindowInsetsCompat mLastInsets;
	private List<OnOffsetChangedListener> mListeners;
	private int mPendingAction;
	private final int[] mTmpStatesArray;
	private int mTotalScrollRange;

	class AnonymousClass_1 implements OnApplyWindowInsetsListener {
		final /* synthetic */ AppBarLayout this$0;

		AnonymousClass_1(AppBarLayout this$0) {
			super();
			this.this$0 = this$0;
		}

		public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
			return this$0.onWindowInsetChanged(insets);
		}
	}

	public static class Behavior extends HeaderBehavior<AppBarLayout> {
		private static final int INVALID_POSITION = -1;
		private static final int MAX_OFFSET_ANIMATION_DURATION = 600;
		private WeakReference<View> mLastNestedScrollingChildRef;
		private ValueAnimatorCompat mOffsetAnimator;
		private int mOffsetDelta;
		private int mOffsetToChildIndexOnLayout;
		private boolean mOffsetToChildIndexOnLayoutIsMinHeight;
		private float mOffsetToChildIndexOnLayoutPerc;
		private DragCallback mOnDragCallback;
		private boolean mSkipNestedPreScroll;
		private boolean mWasNestedFlung;

		class AnonymousClass_1 implements AnimatorUpdateListener {
			final /* synthetic */ AppBarLayout.Behavior this$0;
			final /* synthetic */ AppBarLayout val$child;
			final /* synthetic */ CoordinatorLayout val$coordinatorLayout;

			AnonymousClass_1(AppBarLayout.Behavior this$0, CoordinatorLayout r2_CoordinatorLayout, AppBarLayout r3_AppBarLayout) {
				super();
				this.this$0 = this$0;
				val$coordinatorLayout = r2_CoordinatorLayout;
				val$child = r3_AppBarLayout;
			}

			public void onAnimationUpdate(ValueAnimatorCompat animator) {
				this$0.setHeaderTopBottomOffset(val$coordinatorLayout, val$child, animator.getAnimatedIntValue());
			}
		}

		public static abstract class DragCallback {
			public DragCallback() {
				super();
			}

			public abstract boolean canDrag(@NonNull AppBarLayout r1_AppBarLayout);
		}

		protected static class SavedState extends AbsSavedState {
			public static final Creator<AppBarLayout.Behavior.SavedState> CREATOR;
			boolean firstVisibleChildAtMinimumHeight;
			int firstVisibleChildIndex;
			float firstVisibleChildPercentageShown;

			static class AnonymousClass_1 implements ParcelableCompatCreatorCallbacks<AppBarLayout.Behavior.SavedState> {
				AnonymousClass_1() {
					super();
				}

				public AppBarLayout.Behavior.SavedState createFromParcel(Parcel source, ClassLoader loader) {
					return new AppBarLayout.Behavior.SavedState(source, loader);
				}

				public AppBarLayout.Behavior.SavedState[] newArray(int size) {
					return new AppBarLayout.Behavior.SavedState[size];
				}
			}


			static {
				CREATOR = ParcelableCompat.newCreator(new AnonymousClass_1());
			}

			public SavedState(Parcel source, ClassLoader loader) {
				boolean r0z;
				super(source, loader);
				firstVisibleChildIndex = source.readInt();
				firstVisibleChildPercentageShown = source.readFloat();
				if (source.readByte() != (byte) 0) {
					r0z = true;
				} else {
					r0z = false;
				}
				firstVisibleChildAtMinimumHeight = r0z;
			}

			public SavedState(Parcelable superState) {
				super(superState);
			}

			public void writeToParcel(Parcel dest, int flags) {
				int r0i;
				super.writeToParcel(dest, flags);
				dest.writeInt(firstVisibleChildIndex);
				dest.writeFloat(firstVisibleChildPercentageShown);
				if (firstVisibleChildAtMinimumHeight) {
					r0i = PENDING_ACTION_EXPANDED;
				} else {
					r0i = 0;
				}
				dest.writeByte((byte) r0i);
			}
		}


		public Behavior() {
			super();
			mOffsetToChildIndexOnLayout = -1;
		}

		public Behavior(Context context, AttributeSet attrs) {
			super(context, attrs);
			mOffsetToChildIndexOnLayout = -1;
		}

		private void animateOffsetTo(CoordinatorLayout coordinatorLayout, AppBarLayout child, int offset, float velocity) {
			int duration;
			int distance = Math.abs(getTopBottomOffsetForScrollingSibling() - offset);
			velocity = Math.abs(velocity);
			if (velocity > 0.0f) {
				duration = Math.round(1000.0f * (((float) distance) / velocity)) * 3;
			} else {
				duration = (int) ((1.0f + (((float) distance) / ((float) child.getHeight()))) * 150.0f);
			}
			animateOffsetWithDuration(coordinatorLayout, child, offset, duration);
		}

		private void animateOffsetWithDuration(CoordinatorLayout coordinatorLayout, AppBarLayout child, int offset, int duration) {
			int currentOffset = getTopBottomOffsetForScrollingSibling();
			if (currentOffset == offset) {
				if (mOffsetAnimator == null || !mOffsetAnimator.isRunning()) {
				} else {
					mOffsetAnimator.cancel();
				}
			} else {
				if (mOffsetAnimator == null) {
					mOffsetAnimator = ViewUtils.createAnimator();
					mOffsetAnimator.setInterpolator(AnimationUtils.DECELERATE_INTERPOLATOR);
					mOffsetAnimator.addUpdateListener(new AnonymousClass_1(this, coordinatorLayout, child));
				} else {
					mOffsetAnimator.cancel();
				}
				mOffsetAnimator.setDuration((long) Math.min(duration, MAX_OFFSET_ANIMATION_DURATION));
				mOffsetAnimator.setIntValues(currentOffset, offset);
				mOffsetAnimator.start();
			}
		}

		private static boolean checkFlag(int flags, int check) {
			if ((flags & check) == check) {
				return true;
			} else {
				return false;
			}
		}

		/* JADX WARNING: inconsistent code */
		/*
		private static android.view.View getAppBarChildOnOffset(android.support.design.widget.AppBarLayout r5_layout, int r6_offset) {
			r0 = java.lang.Math.abs(r6_offset);
			r2 = 0;
			r3 = r5_layout.getChildCount();
		L_0x0009:
			if (r2_i >= r3_z) goto L_0x001f;
		L_0x000b:
			r1 = r5_layout.getChildAt(r2_i);
			r4 = r1_child.getTop();
			if (r0_absOffset < r4) goto L_0x001c;
		L_0x0015:
			r4 = r1_child.getBottom();
			if (r0_absOffset > r4) goto L_0x001c;
		L_0x001b:
			return r1_child;
		L_0x001c:
			r2_i++;
			goto L_0x0009;
		L_0x001f:
			r1_child = 0;
			goto L_0x001b;
		}
		*/
		private static View getAppBarChildOnOffset(AppBarLayout layout, int offset) {
			int absOffset = Math.abs(offset);
			int i = 0;
			while (i < layout.getChildCount()) {
				View child = layout.getChildAt(i);
				if (absOffset < child.getTop() || absOffset > child.getBottom()) {
					i++;
				}
			}
			return null;
		}

		/* JADX WARNING: inconsistent code */
		/*
		private int getChildIndexOnOffset(android.support.design.widget.AppBarLayout r6_abl, int r7_offset) {
			r5_this = this;
			r2 = 0;
			r1 = r6_abl.getChildCount();
		L_0x0005:
			if (r2_i >= r1_count) goto L_0x001d;
		L_0x0007:
			r0 = r6_abl.getChildAt(r2_i);
			r3 = r0_child.getTop();
			r4 = -r7_offset;
			if (r3 > r4) goto L_0x001a;
		L_0x0012:
			r3 = r0_child.getBottom();
			r4 = -r7_offset;
			if (r3 < r4) goto L_0x001a;
		L_0x0019:
			return r2_i;
		L_0x001a:
			r2_i++;
			goto L_0x0005;
		L_0x001d:
			r2_i = -1;
			goto L_0x0019;
		}
		*/
		private int getChildIndexOnOffset(AppBarLayout abl, int offset) {
			int i = 0;
			while (i < abl.getChildCount()) {
				View child = abl.getChildAt(i);
				if (child.getTop() > (-offset) || child.getBottom() < (-offset)) {
					i++;
				}
			}
			return INVALID_POSITION;
		}

		/* JADX WARNING: inconsistent code */
		/*
		private int interpolateOffset(android.support.design.widget.AppBarLayout r14_layout, int r15_offset) {
			r13_this = this;
			r0 = java.lang.Math.abs(r15_offset);
			r5 = 0;
			r9 = r14_layout.getChildCount();
		L_0x0009:
			if (r5_i >= r9_z) goto L_0x006f;
		L_0x000b:
			r1 = r14_layout.getChildAt(r5_i);
			r2 = r1_child.getLayoutParams();
			r2 = (android.support.design.widget.AppBarLayout.LayoutParams) r2;
			r7 = r2_childLp.getScrollInterpolator();
			r10 = r1_child.getTop();
			if (r0_absOffset < r10) goto L_0x0070;
		L_0x001f:
			r10 = r1_child.getBottom();
			if (r0_absOffset > r10) goto L_0x0070;
		L_0x0025:
			if (r7_interpolator == 0) goto L_0x006f;
		L_0x0027:
			r3 = 0;
			r4 = r2_childLp.getScrollFlags();
			r10 = r4_flags & 1;
			if (r10 == 0) goto L_0x0044;
		L_0x0030:
			r10 = r1_child.getHeight();
			r11 = r2_childLp.topMargin;
			r10 += r11;
			r11 = r2_childLp.bottomMargin;
			r10 += r11;
			r3_childScrollableHeight += r10;
			r10 = r4_flags & 2;
			if (r10 == 0) goto L_0x0044;
		L_0x003f:
			r10 = android.support.v4.view.ViewCompat.getMinimumHeight(r1_child);
			r3_childScrollableHeight -= r10;
		L_0x0044:
			r10 = android.support.v4.view.ViewCompat.getFitsSystemWindows(r1_child);
			if (r10 == 0) goto L_0x004f;
		L_0x004a:
			r10 = r14_layout.getTopInset();
			r3_childScrollableHeight -= r10;
		L_0x004f:
			if (r3_childScrollableHeight <= 0) goto L_0x006f;
		L_0x0051:
			r10 = r1_child.getTop();
			r8 = r0_absOffset - r10;
			r10 = (float) r3_childScrollableHeight;
			r11 = (float) r8_offsetForView;
			r12 = (float) r3_childScrollableHeight;
			r11 /= r12;
			r11 = r7_interpolator.getInterpolation(r11);
			r10 *= r11;
			r6 = java.lang.Math.round(r10);
			r10 = java.lang.Integer.signum(r15_offset);
			r11 = r1_child.getTop();
			r11 += r6_interpolatedDiff;
			r15_offset = r10 * r11;
		L_0x006f:
			return r15_offset;
		L_0x0070:
			r5_i++;
			goto L_0x0009;
		}
		*/
		private int interpolateOffset(AppBarLayout layout, int offset) {
			int absOffset = Math.abs(offset);
			int i = 0;
			while (i < layout.getChildCount()) {
				View child = layout.getChildAt(i);
				AppBarLayout.LayoutParams childLp = (AppBarLayout.LayoutParams) child.getLayoutParams();
				Interpolator interpolator = childLp.getScrollInterpolator();
				if (absOffset < child.getTop() || absOffset > child.getBottom()) {
					i++;
				}
			}
			return offset;
		}

		private boolean shouldJumpElevationState(CoordinatorLayout parent, AppBarLayout layout) {
			List<View> dependencies = parent.getDependents(layout);
			int i = 0;
			while (i < dependencies.size()) {
				CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams) ((View) dependencies.get(i)).getLayoutParams()).getBehavior();
				if (behavior instanceof AppBarLayout.ScrollingViewBehavior) {
					if (((AppBarLayout.ScrollingViewBehavior) behavior).getOverlayTop() != 0) {
						return true;
					} else {
						return false;
					}
				} else {
					i++;
				}
			}
			return false;
		}

		private void snapToChildIfNeeded(CoordinatorLayout coordinatorLayout, AppBarLayout abl) {
			int offset = getTopBottomOffsetForScrollingSibling();
			int offsetChildIndex = getChildIndexOnOffset(abl, offset);
			if (offsetChildIndex >= 0) {
				View offsetChild = abl.getChildAt(offsetChildIndex);
				int flags = ((AppBarLayout.LayoutParams) offsetChild.getLayoutParams()).getScrollFlags();
				if ((flags & 17) == 17) {
					int newOffset;
					int snapTop = -offsetChild.getTop();
					int snapBottom = -offsetChild.getBottom();
					if (offsetChildIndex == abl.getChildCount() - 1) {
						snapBottom += abl.getTopInset();
					}
					if (checkFlag(flags, PENDING_ACTION_COLLAPSED)) {
						snapBottom += ViewCompat.getMinimumHeight(offsetChild);
					} else if (checkFlag(flags, SQLiteCursor.FIELD_TYPE_NULL)) {
						int seam = snapBottom + ViewCompat.getMinimumHeight(offsetChild);
						if (offset < seam) {
							snapTop = seam;
						} else {
							snapBottom = seam;
						}
					}
					if (offset < (snapBottom + snapTop) / 2) {
						newOffset = snapBottom;
					} else {
						newOffset = snapTop;
					}
					animateOffsetTo(coordinatorLayout, abl, MathUtils.constrain(newOffset, -abl.getTotalScrollRange(), 0), BitmapDescriptorFactory.HUE_RED);
				}
			}
		}

		private void updateAppBarLayoutDrawableState(CoordinatorLayout parent, AppBarLayout layout, int offset, int direction) {
			View child = getAppBarChildOnOffset(layout, offset);
			if (child != null) {
				int flags = ((AppBarLayout.LayoutParams) child.getLayoutParams()).getScrollFlags();
				boolean collapsed = false;
				if ((flags & 1) != 0) {
					int minHeight = ViewCompat.getMinimumHeight(child);
					if (direction <= 0 || (flags & 12) == 0) {
						if ((flags & 2) != 0) {
							if ((-offset) >= (child.getBottom() - minHeight) - layout.getTopInset()) {
								collapsed = true;
							} else {
								collapsed = false;
							}
						}
					} else if ((-offset) >= (child.getBottom() - minHeight) - layout.getTopInset()) {
						collapsed = true;
					} else {
						collapsed = false;
					}
				}
				if (!layout.setCollapsedState(collapsed) || VERSION.SDK_INT < 11 || !shouldJumpElevationState(parent, layout)) {
				} else {
					layout.jumpDrawablesToCurrentState();
				}
			}
		}

		boolean canDragView(AppBarLayout view) {
			if (mOnDragCallback != null) {
				return mOnDragCallback.canDrag(view);
			} else if (mLastNestedScrollingChildRef != null) {
				View scrollingView = (View) mLastNestedScrollingChildRef.get();
				if (scrollingView == null || !scrollingView.isShown() || ViewCompat.canScrollVertically(scrollingView, INVALID_POSITION)) {
					return false;
				} else {
					return true;
				}
			} else {
				return true;
			}
		}

		public /* bridge */ /* synthetic */ int getLeftAndRightOffset() {
			return super.getLeftAndRightOffset();
		}

		int getMaxDragOffset(AppBarLayout view) {
			return -view.getDownNestedScrollRange();
		}

		int getScrollRangeForDragFling(AppBarLayout view) {
			return view.getTotalScrollRange();
		}

		public /* bridge */ /* synthetic */ int getTopAndBottomOffset() {
			return super.getTopAndBottomOffset();
		}

		int getTopBottomOffsetForScrollingSibling() {
			return getTopAndBottomOffset() + mOffsetDelta;
		}

		@VisibleForTesting
		boolean isOffsetAnimatorRunning() {
			if (mOffsetAnimator == null || !mOffsetAnimator.isRunning()) {
				return false;
			} else {
				return true;
			}
		}

		void onFlingFinished(CoordinatorLayout parent, AppBarLayout layout) {
			snapToChildIfNeeded(parent, layout);
		}

		public boolean onLayoutChild(CoordinatorLayout parent, AppBarLayout abl, int layoutDirection) {
			int r5i = 0;
			boolean handled = super.onLayoutChild(parent, abl, layoutDirection);
			int pendingAction = abl.getPendingAction();
			int offset;
			if (pendingAction != 0) {
				boolean animate;
				if ((pendingAction & 4) != 0) {
					animate = true;
				} else {
					animate = false;
				}
				if ((pendingAction & 2) != 0) {
					offset = -abl.getUpNestedPreScrollRange();
					if (animate) {
						animateOffsetTo(parent, abl, offset, BitmapDescriptorFactory.HUE_RED);
					} else {
						setHeaderTopBottomOffset(parent, abl, offset);
					}
				} else if ((pendingAction & 1) != 0) {
					if (animate) {
						animateOffsetTo(parent, abl, 0, BitmapDescriptorFactory.HUE_RED);
					} else {
						setHeaderTopBottomOffset(parent, abl, 0);
					}
				}
			} else if (mOffsetToChildIndexOnLayout >= 0) {
				View child = abl.getChildAt(mOffsetToChildIndexOnLayout);
				offset = -child.getBottom();
				if (mOffsetToChildIndexOnLayoutIsMinHeight) {
					offset += ViewCompat.getMinimumHeight(child);
				} else {
					offset += Math.round(((float) child.getHeight()) * mOffsetToChildIndexOnLayoutPerc);
				}
				setTopAndBottomOffset(offset);
			}
			abl.resetPendingAction();
			mOffsetToChildIndexOnLayout = -1;
			setTopAndBottomOffset(MathUtils.constrain(getTopAndBottomOffset(), -abl.getTotalScrollRange(), r5i));
			abl.dispatchOffsetUpdates(getTopAndBottomOffset());
			return handled;
		}

		public boolean onMeasureChild(CoordinatorLayout parent, AppBarLayout child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed) {
			int r2i = 0;
			if (((CoordinatorLayout.LayoutParams) child.getLayoutParams()).height == -2) {
				parent.onMeasureChild(child, parentWidthMeasureSpec, widthUsed, MeasureSpec.makeMeasureSpec(r2i, r2i), heightUsed);
				return true;
			} else {
				return super.onMeasureChild(parent, child, parentWidthMeasureSpec, widthUsed, parentHeightMeasureSpec, heightUsed);
			}
		}

		public boolean onNestedFling(CoordinatorLayout coordinatorLayout, AppBarLayout child, View target, float velocityX, float velocityY, boolean consumed) {
			boolean flung = false;
			if (!consumed) {
				flung = fling(coordinatorLayout, child, -child.getTotalScrollRange(), 0, -velocityY);
			} else if (velocityY < 0.0f) {
				targetScroll = (-child.getTotalScrollRange()) + child.getDownNestedPreScrollRange();
				if (getTopBottomOffsetForScrollingSibling() < targetScroll) {
					animateOffsetTo(coordinatorLayout, child, targetScroll, velocityY);
					flung = true;
				}
			} else {
				targetScroll = -child.getUpNestedPreScrollRange();
				if (getTopBottomOffsetForScrollingSibling() > targetScroll) {
					animateOffsetTo(coordinatorLayout, child, targetScroll, velocityY);
					flung = true;
				}
			}
			mWasNestedFlung = flung;
			return flung;
		}

		public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, AppBarLayout child, View target, int dx, int dy, int[] consumed) {
			if (dy == 0 || mSkipNestedPreScroll) {
			} else {
				int min;
				int max;
				if (dy < 0) {
					min = -child.getTotalScrollRange();
					max = min + child.getDownNestedPreScrollRange();
				} else {
					min = -child.getUpNestedPreScrollRange();
					max = 0;
				}
				consumed[1] = scroll(coordinatorLayout, child, dy, min, max);
			}
		}

		public void onNestedScroll(CoordinatorLayout coordinatorLayout, AppBarLayout child, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
			if (dyUnconsumed < 0) {
				scroll(coordinatorLayout, child, dyUnconsumed, -child.getDownNestedScrollRange(), 0);
				mSkipNestedPreScroll = true;
			} else {
				mSkipNestedPreScroll = false;
			}
		}

		public void onRestoreInstanceState(CoordinatorLayout parent, AppBarLayout appBarLayout, Parcelable state) {
			if (state instanceof SavedState) {
				SavedState ss = (SavedState) state;
				super.onRestoreInstanceState(parent, appBarLayout, ss.getSuperState());
				mOffsetToChildIndexOnLayout = ss.firstVisibleChildIndex;
				mOffsetToChildIndexOnLayoutPerc = ss.firstVisibleChildPercentageShown;
				mOffsetToChildIndexOnLayoutIsMinHeight = ss.firstVisibleChildAtMinimumHeight;
			} else {
				super.onRestoreInstanceState(parent, appBarLayout, state);
				mOffsetToChildIndexOnLayout = -1;
			}
		}

		public Parcelable onSaveInstanceState(CoordinatorLayout parent, AppBarLayout appBarLayout) {
			Parcelable superState = super.onSaveInstanceState(parent, appBarLayout);
			int offset = getTopAndBottomOffset();
			int i = 0;
			while (i < appBarLayout.getChildCount()) {
				View child = appBarLayout.getChildAt(i);
				int visBottom = child.getBottom() + offset;
				if (child.getTop() + offset > 0 || visBottom < 0) {
					i++;
				} else {
					boolean r7z;
					SavedState ss = new SavedState(superState);
					ss.firstVisibleChildIndex = i;
					if (visBottom == ViewCompat.getMinimumHeight(child)) {
						r7z = true;
					} else {
						r7z = false;
					}
					ss.firstVisibleChildAtMinimumHeight = r7z;
					ss.firstVisibleChildPercentageShown = ((float) visBottom) / ((float) child.getHeight());
					return ss;
				}
			}
			return superState;
		}

		public boolean onStartNestedScroll(CoordinatorLayout parent, AppBarLayout child, View directTargetChild, View target, int nestedScrollAxes) {
			boolean started;
			if ((nestedScrollAxes & 2) == 0 || !child.hasScrollableChildren() || parent.getHeight() - directTargetChild.getHeight() > child.getHeight()) {
				started = false;
			} else {
				started = true;
			}
			if (!started || mOffsetAnimator == null) {
				mLastNestedScrollingChildRef = null;
				return started;
			} else {
				mOffsetAnimator.cancel();
				mLastNestedScrollingChildRef = null;
				return started;
			}
		}

		public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, AppBarLayout abl, View target) {
			if (!mWasNestedFlung) {
				snapToChildIfNeeded(coordinatorLayout, abl);
			}
			mSkipNestedPreScroll = false;
			mWasNestedFlung = false;
			mLastNestedScrollingChildRef = new WeakReference(target);
		}

		public void setDragCallback(@Nullable DragCallback callback) {
			mOnDragCallback = callback;
		}

		int setHeaderTopBottomOffset(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int newOffset, int minOffset, int maxOffset) {
			int curOffset = getTopBottomOffsetForScrollingSibling();
			if (minOffset == 0 || curOffset < minOffset || curOffset > maxOffset) {
				mOffsetDelta = 0;
				return 0;
			} else {
				newOffset = MathUtils.constrain(newOffset, minOffset, maxOffset);
				if (curOffset != newOffset) {
					int interpolatedOffset;
					if (appBarLayout.hasChildWithInterpolator()) {
						interpolatedOffset = interpolateOffset(appBarLayout, newOffset);
					} else {
						interpolatedOffset = newOffset;
					}
					int consumed = curOffset - newOffset;
					mOffsetDelta = newOffset - interpolatedOffset;
					int r4i;
					if (setTopAndBottomOffset(interpolatedOffset) || !appBarLayout.hasChildWithInterpolator()) {
						appBarLayout.dispatchOffsetUpdates(getTopAndBottomOffset());
						if (newOffset >= curOffset) {
							r4i = INVALID_POSITION;
						} else {
							r4i = PENDING_ACTION_EXPANDED;
						}
						updateAppBarLayoutDrawableState(coordinatorLayout, appBarLayout, newOffset, r4i);
						return consumed;
					} else {
						coordinatorLayout.dispatchDependentViewsChanged(appBarLayout);
						appBarLayout.dispatchOffsetUpdates(getTopAndBottomOffset());
						if (newOffset >= curOffset) {
							r4i = PENDING_ACTION_EXPANDED;
						} else {
							r4i = INVALID_POSITION;
						}
						updateAppBarLayoutDrawableState(coordinatorLayout, appBarLayout, newOffset, r4i);
						return consumed;
					}
				} else {
					return 0;
				}
			}
		}

		public /* bridge */ /* synthetic */ boolean setLeftAndRightOffset(int r2i) {
			return super.setLeftAndRightOffset(r2i);
		}

		public /* bridge */ /* synthetic */ boolean setTopAndBottomOffset(int r2i) {
			return super.setTopAndBottomOffset(r2i);
		}
	}

	public static class LayoutParams extends android.widget.LinearLayout.LayoutParams {
		static final int COLLAPSIBLE_FLAGS = 10;
		static final int FLAG_QUICK_RETURN = 5;
		static final int FLAG_SNAP = 17;
		public static final int SCROLL_FLAG_ENTER_ALWAYS = 4;
		public static final int SCROLL_FLAG_ENTER_ALWAYS_COLLAPSED = 8;
		public static final int SCROLL_FLAG_EXIT_UNTIL_COLLAPSED = 2;
		public static final int SCROLL_FLAG_SCROLL = 1;
		public static final int SCROLL_FLAG_SNAP = 16;
		int mScrollFlags;
		Interpolator mScrollInterpolator;

		@Retention(RetentionPolicy.SOURCE)
		public static @interface ScrollFlags {
		}


		public LayoutParams(int width, int height) {
			super(width, height);
			mScrollFlags = 1;
		}

		public LayoutParams(int width, int height, float weight) {
			super(width, height, weight);
			mScrollFlags = 1;
		}

		public LayoutParams(Context c, AttributeSet attrs) {
			super(c, attrs);
			mScrollFlags = 1;
			TypedArray a = c.obtainStyledAttributes(attrs, R.styleable.AppBarLayout_Layout);
			mScrollFlags = a.getInt(R.styleable.AppBarLayout_Layout_layout_scrollFlags, 0);
			if (a.hasValue(R.styleable.AppBarLayout_Layout_layout_scrollInterpolator)) {
				mScrollInterpolator = AnimationUtils.loadInterpolator(c, a.getResourceId(R.styleable.AppBarLayout_Layout_layout_scrollInterpolator, 0));
			}
			a.recycle();
		}

		public LayoutParams(AppBarLayout.LayoutParams source) {
			super(source);
			mScrollFlags = 1;
			mScrollFlags = source.mScrollFlags;
			mScrollInterpolator = source.mScrollInterpolator;
		}

		public LayoutParams(android.view.ViewGroup.LayoutParams p) {
			super(p);
			mScrollFlags = 1;
		}

		public LayoutParams(MarginLayoutParams source) {
			super(source);
			mScrollFlags = 1;
		}

		public LayoutParams(android.widget.LinearLayout.LayoutParams source) {
			super(source);
			mScrollFlags = 1;
		}

		public int getScrollFlags() {
			return mScrollFlags;
		}

		public Interpolator getScrollInterpolator() {
			return mScrollInterpolator;
		}

		boolean isCollapsible() {
			if ((mScrollFlags & 1) != 1 || (mScrollFlags & 10) == 0) {
				return false;
			} else {
				return true;
			}
		}

		public void setScrollFlags(int flags) {
			mScrollFlags = flags;
		}

		public void setScrollInterpolator(Interpolator interpolator) {
			mScrollInterpolator = interpolator;
		}
	}

	public static interface OnOffsetChangedListener {
		public void onOffsetChanged(AppBarLayout r1_AppBarLayout, int r2i);
	}

	public static class ScrollingViewBehavior extends HeaderScrollingViewBehavior {
		public ScrollingViewBehavior() {
			super();
		}

		public ScrollingViewBehavior(Context context, AttributeSet attrs) {
			super(context, attrs);
			TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ScrollingViewBehavior_Layout);
			setOverlayTop(a.getDimensionPixelSize(R.styleable.ScrollingViewBehavior_Layout_behavior_overlapTop, 0));
			a.recycle();
		}

		private static int getAppBarLayoutOffset(AppBarLayout abl) {
			CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams) abl.getLayoutParams()).getBehavior();
			if (behavior instanceof AppBarLayout.Behavior) {
				return ((AppBarLayout.Behavior) behavior).getTopBottomOffsetForScrollingSibling();
			} else {
				return 0;
			}
		}

		private void offsetChildAsNeeded(CoordinatorLayout parent, View child, View dependency) {
			CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams) dependency.getLayoutParams()).getBehavior();
			if (behavior instanceof AppBarLayout.Behavior) {
				ViewCompat.offsetTopAndBottom(child, (((dependency.getBottom() - child.getTop()) + ((AppBarLayout.Behavior) behavior).mOffsetDelta) + getVerticalLayoutGap()) - getOverlapPixelsForOffset(dependency));
			}
		}

		AppBarLayout findFirstDependency(List<View> views) {
			int i = 0;
			while (i < views.size()) {
				View view = (View) views.get(i);
				if (view instanceof AppBarLayout) {
					return (AppBarLayout) view;
				} else {
					i++;
				}
			}
			return null;
		}

		public /* bridge */ /* synthetic */ int getLeftAndRightOffset() {
			return super.getLeftAndRightOffset();
		}

		float getOverlapRatioForOffset(View header) {
			if (header instanceof AppBarLayout) {
				AppBarLayout abl = (AppBarLayout) header;
				int totalScrollRange = abl.getTotalScrollRange();
				int preScrollDown = abl.getDownNestedPreScrollRange();
				int offset = getAppBarLayoutOffset(abl);
				if (preScrollDown == 0 || totalScrollRange + offset > preScrollDown) {
					int availScrollRange = totalScrollRange - preScrollDown;
					if (availScrollRange != 0) {
						return 1.0f + (((float) offset) / ((float) availScrollRange));
					} else {
						return BitmapDescriptorFactory.HUE_RED;
					}
				} else {
					return BitmapDescriptorFactory.HUE_RED;
				}
			} else {
				return BitmapDescriptorFactory.HUE_RED;
			}
		}

		int getScrollRange(View v) {
			if (v instanceof AppBarLayout) {
				return ((AppBarLayout) v).getTotalScrollRange();
			} else {
				return super.getScrollRange(v);
			}
		}

		public /* bridge */ /* synthetic */ int getTopAndBottomOffset() {
			return super.getTopAndBottomOffset();
		}

		public boolean layoutDependsOn(CoordinatorLayout parent, View child, View dependency) {
			return dependency instanceof AppBarLayout;
		}

		public boolean onDependentViewChanged(CoordinatorLayout parent, View child, View dependency) {
			offsetChildAsNeeded(parent, child, dependency);
			return false;
		}

		public /* bridge */ /* synthetic */ boolean onLayoutChild(CoordinatorLayout r2_CoordinatorLayout, View r3_View, int r4i) {
			return super.onLayoutChild(r2_CoordinatorLayout, r3_View, r4i);
		}

		public /* bridge */ /* synthetic */ boolean onMeasureChild(CoordinatorLayout r2_CoordinatorLayout, View r3_View, int r4i, int r5i, int r6i, int r7i) {
			return super.onMeasureChild(r2_CoordinatorLayout, r3_View, r4i, r5i, r6i, r7i);
		}

		public boolean onRequestChildRectangleOnScreen(CoordinatorLayout parent, View child, Rect rectangle, boolean immediate) {
			AppBarLayout header = findFirstDependency(parent.getDependencies(child));
			if (header != null) {
				rectangle.offset(child.getLeft(), child.getTop());
				Rect parentRect = mTempRect1;
				parentRect.set(0, 0, parent.getWidth(), parent.getHeight());
				if (!parentRect.contains(rectangle)) {
					boolean r2z;
					if (!immediate) {
						r2z = true;
					} else {
						r2z = false;
					}
					header.setExpanded(false, r2z);
					return true;
				}
			}
			return false;
		}

		public /* bridge */ /* synthetic */ boolean setLeftAndRightOffset(int r2i) {
			return super.setLeftAndRightOffset(r2i);
		}

		public /* bridge */ /* synthetic */ boolean setTopAndBottomOffset(int r2i) {
			return super.setTopAndBottomOffset(r2i);
		}
	}


	public AppBarLayout(Context context) {
		this(context, null);
	}

	public AppBarLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		mTotalScrollRange = -1;
		mDownPreScrollRange = -1;
		mDownScrollRange = -1;
		mPendingAction = 0;
		mTmpStatesArray = new int[2];
		setOrientation(PENDING_ACTION_EXPANDED);
		ThemeUtils.checkAppCompatTheme(context);
		if (VERSION.SDK_INT >= 21) {
			ViewUtilsLollipop.setBoundsViewOutlineProvider(this);
			ViewUtilsLollipop.setStateListAnimatorFromAttrs(this, attrs, 0, R.style.Widget_Design_AppBarLayout);
		}
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.AppBarLayout, 0, R.style.Widget_Design_AppBarLayout);
		setBackgroundDrawable(a.getDrawable(R.styleable.AppBarLayout_android_background));
		if (a.hasValue(R.styleable.AppBarLayout_expanded)) {
			setExpanded(a.getBoolean(R.styleable.AppBarLayout_expanded, false));
		}
		if (VERSION.SDK_INT < 21 || !a.hasValue(R.styleable.AppBarLayout_elevation)) {
			a.recycle();
			ViewCompat.setOnApplyWindowInsetsListener(this, new AnonymousClass_1(this));
		} else {
			ViewUtilsLollipop.setDefaultAppBarLayoutStateListAnimator(this, (float) a.getDimensionPixelSize(R.styleable.AppBarLayout_elevation, 0));
			a.recycle();
			ViewCompat.setOnApplyWindowInsetsListener(this, new AnonymousClass_1(this));
		}
	}

	private void invalidateScrollRanges() {
		mTotalScrollRange = -1;
		mDownPreScrollRange = -1;
		mDownScrollRange = -1;
	}

	private boolean setCollapsibleState(boolean collapsible) {
		if (mCollapsible != collapsible) {
			mCollapsible = collapsible;
			refreshDrawableState();
			return true;
		} else {
			return false;
		}
	}

	private void updateCollapsible() {
		boolean haveCollapsibleChild = false;
		int i = 0;
		while (i < getChildCount()) {
			if (((LayoutParams) getChildAt(i).getLayoutParams()).isCollapsible()) {
				haveCollapsibleChild = true;
			} else {
				i++;
			}
		}
		setCollapsibleState(haveCollapsibleChild);
	}

	public void addOnOffsetChangedListener(OnOffsetChangedListener listener) {
		if (mListeners == null) {
			mListeners = new ArrayList();
		}
		if (listener == null || mListeners.contains(listener)) {
		} else {
			mListeners.add(listener);
		}
	}

	protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams p) {
		return p instanceof LayoutParams;
	}

	void dispatchOffsetUpdates(int offset) {
		if (mListeners != null) {
			int i = 0;
			while (i < mListeners.size()) {
				OnOffsetChangedListener listener = (OnOffsetChangedListener) mListeners.get(i);
				if (listener != null) {
					listener.onOffsetChanged(this, offset);
				}
				i++;
			}
		}
	}

	protected LayoutParams generateDefaultLayoutParams() {
		return new LayoutParams(-1, -2);
	}

	public LayoutParams generateLayoutParams(AttributeSet attrs) {
		return new LayoutParams(getContext(), attrs);
	}

	protected LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams p) {
		if (p instanceof android.widget.LinearLayout.LayoutParams) {
			return new LayoutParams((android.widget.LinearLayout.LayoutParams) p);
		} else if (p instanceof MarginLayoutParams) {
			return new LayoutParams((MarginLayoutParams) p);
		} else {
			return new LayoutParams(p);
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	int getDownNestedPreScrollRange() {
		r8_this = this;
		r6 = r8.mDownPreScrollRange;
		r7 = -1;
		if (r6 == r7) goto L_0x0008;
	L_0x0005:
		r6 = r8.mDownPreScrollRange;
	L_0x0007:
		return r6;
	L_0x0008:
		r5 = 0;
		r6 = r8.getChildCount();
		r3 = r6 + -1;
	L_0x000f:
		if (r3_i < 0) goto L_0x0048;
	L_0x0011:
		r0 = r8.getChildAt(r3_i);
		r4 = r0_child.getLayoutParams();
		r4 = (android.support.design.widget.AppBarLayout.LayoutParams) r4;
		r1 = r0_child.getMeasuredHeight();
		r2 = r4_lp.mScrollFlags;
		r6 = r2_flags & 5;
		r7 = 5;
		if (r6 != r7) goto L_0x0046;
	L_0x0026:
		r6 = r4_lp.topMargin;
		r7 = r4_lp.bottomMargin;
		r6 += r7;
		r5_range += r6;
		r6 = r2_flags & 8;
		if (r6 == 0) goto L_0x0038;
	L_0x0030:
		r6 = android.support.v4.view.ViewCompat.getMinimumHeight(r0_child);
		r5_range += r6;
	L_0x0035:
		r3_i++;
		goto L_0x000f;
	L_0x0038:
		r6 = r2_flags & 2;
		if (r6 == 0) goto L_0x0044;
	L_0x003c:
		r6 = android.support.v4.view.ViewCompat.getMinimumHeight(r0_child);
		r6 = r1_childHeight - r6;
		r5_range += r6;
		goto L_0x0035;
	L_0x0044:
		r5_range += r1_childHeight;
		goto L_0x0035;
	L_0x0046:
		if (r5_range <= 0) goto L_0x0035;
	L_0x0048:
		r6 = 0;
		r6 = java.lang.Math.max(r6, r5);
		r8.mDownPreScrollRange = r6;
		goto L_0x0007;
	}
	*/
	int getDownNestedPreScrollRange() {
		if (mDownPreScrollRange != -1) {
			return mDownPreScrollRange;
		} else {
			int r6i;
			int range = 0;
			int i = getChildCount() - 1;
			while (i >= 0) {
				View child = getChildAt(i);
				LayoutParams lp = (LayoutParams) child.getLayoutParams();
				int childHeight = child.getMeasuredHeight();
				int flags = lp.mScrollFlags;
				if ((flags & 5) == 5) {
					range += lp.topMargin + lp.bottomMargin;
					if ((flags & 8) != 0) {
						range += ViewCompat.getMinimumHeight(child);
					} else if ((flags & 2) != 0) {
						range += childHeight - ViewCompat.getMinimumHeight(child);
					} else {
						range += childHeight;
					}
				} else if (range > 0) {
					r6i = Math.max(0, range);
					mDownPreScrollRange = r6i;
					return r6i;
				}
			}
			r6i = Math.max(0, range);
			mDownPreScrollRange = r6i;
			return r6i;
		}
	}

	int getDownNestedScrollRange() {
		if (mDownScrollRange != -1) {
			return mDownScrollRange;
		} else {
			int range = 0;
			int i = 0;
			while (i < getChildCount()) {
				View child = getChildAt(i);
				LayoutParams lp = (LayoutParams) child.getLayoutParams();
				int childHeight = child.getMeasuredHeight() + (lp.topMargin + lp.bottomMargin);
				int flags = lp.mScrollFlags;
				if ((flags & 1) != 0) {
					range += childHeight;
					if ((flags & 2) != 0) {
						range -= ViewCompat.getMinimumHeight(child) + getTopInset();
					} else {
						i++;
					}
				}
			}
			int r7i = Math.max(0, range);
			mDownScrollRange = r7i;
			return r7i;
		}
	}

	final int getMinimumHeightForVisibleOverlappingContent() {
		int topInset = getTopInset();
		int minHeight = ViewCompat.getMinimumHeight(this);
		if (minHeight != 0) {
			return (minHeight * 2) + topInset;
		} else {
			int lastChildMinHeight;
			int childCount = getChildCount();
			if (childCount >= 1) {
				lastChildMinHeight = ViewCompat.getMinimumHeight(getChildAt(childCount - 1));
			} else {
				lastChildMinHeight = 0;
			}
			if (lastChildMinHeight != 0) {
				return (lastChildMinHeight * 2) + topInset;
			} else {
				return getHeight() / 3;
			}
		}
	}

	int getPendingAction() {
		return mPendingAction;
	}

	@Deprecated
	public float getTargetElevation() {
		return BitmapDescriptorFactory.HUE_RED;
	}

	@VisibleForTesting
	final int getTopInset() {
		if (mLastInsets != null) {
			return mLastInsets.getSystemWindowInsetTop();
		} else {
			return 0;
		}
	}

	public final int getTotalScrollRange() {
		if (mTotalScrollRange != -1) {
			return mTotalScrollRange;
		} else {
			int range = 0;
			int i = 0;
			while (i < getChildCount()) {
				View child = getChildAt(i);
				LayoutParams lp = (LayoutParams) child.getLayoutParams();
				int childHeight = child.getMeasuredHeight();
				int flags = lp.mScrollFlags;
				if ((flags & 1) != 0) {
					range += (lp.topMargin + childHeight) + lp.bottomMargin;
					if ((flags & 2) != 0) {
						range -= ViewCompat.getMinimumHeight(child);
					} else {
						i++;
					}
				}
			}
			int r7i = Math.max(0, range - getTopInset());
			mTotalScrollRange = r7i;
			return r7i;
		}
	}

	int getUpNestedPreScrollRange() {
		return getTotalScrollRange();
	}

	boolean hasChildWithInterpolator() {
		return mHaveChildWithInterpolator;
	}

	boolean hasScrollableChildren() {
		if (getTotalScrollRange() != 0) {
			return true;
		} else {
			return false;
		}
	}

	protected int[] onCreateDrawableState(int extraSpace) {
		int r2i;
		int[] extraStates = mTmpStatesArray;
		int[] states = super.onCreateDrawableState(extraStates.length + extraSpace);
		int r3i = 0;
		if (mCollapsible) {
			r2i = R.attr.state_collapsible;
		} else {
			r2i = -R.attr.state_collapsible;
		}
		extraStates[r3i] = r2i;
		if (!mCollapsible || !mCollapsed) {
			r2i = -R.attr.state_collapsed;
		} else {
			r2i = R.attr.state_collapsed;
		}
		extraStates[1] = r2i;
		return mergeDrawableStates(states, extraStates);
	}

	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		super.onLayout(changed, l, t, r, b);
		invalidateScrollRanges();
		mHaveChildWithInterpolator = false;
		int i = 0;
		while (i < getChildCount()) {
			if (((LayoutParams) getChildAt(i).getLayoutParams()).getScrollInterpolator() != null) {
				mHaveChildWithInterpolator = true;
			} else {
				i++;
			}
		}
		updateCollapsible();
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		invalidateScrollRanges();
	}

	WindowInsetsCompat onWindowInsetChanged(WindowInsetsCompat insets) {
		WindowInsetsCompat newInsets = null;
		if (ViewCompat.getFitsSystemWindows(this)) {
			newInsets = insets;
		}
		if (!ViewUtils.objectEquals(mLastInsets, newInsets)) {
			mLastInsets = newInsets;
			invalidateScrollRanges();
		}
		return insets;
	}

	public void removeOnOffsetChangedListener(OnOffsetChangedListener listener) {
		if (mListeners == null || listener == null) {
		} else {
			mListeners.remove(listener);
		}
	}

	void resetPendingAction() {
		mPendingAction = 0;
	}

	boolean setCollapsedState(boolean collapsed) {
		if (mCollapsed != collapsed) {
			mCollapsed = collapsed;
			refreshDrawableState();
			return true;
		} else {
			return false;
		}
	}

	public void setExpanded(boolean expanded) {
		setExpanded(expanded, ViewCompat.isLaidOut(this));
	}

	public void setExpanded(boolean expanded, boolean animate) {
		int r1i;
		int r0i;
		if (expanded) {
			r1i = 1;
		} else {
			r1i = 2;
		}
		if (animate) {
			r0i = PENDING_ACTION_ANIMATE_ENABLED;
		} else {
			r0i = 0;
		}
		mPendingAction = r0i | r1i;
		requestLayout();
	}

	public void setOrientation(int orientation) {
		if (orientation != 1) {
			throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
		} else {
			super.setOrientation(orientation);
		}
	}

	@Deprecated
	public void setTargetElevation(float elevation) {
		if (VERSION.SDK_INT >= 21) {
			ViewUtilsLollipop.setDefaultAppBarLayoutStateListAnimator(this, elevation);
		}
	}
}
