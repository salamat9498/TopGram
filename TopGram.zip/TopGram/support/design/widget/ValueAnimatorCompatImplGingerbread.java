package android.support.design.widget;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.support.design.widget.ValueAnimatorCompat.Impl;
import android.support.design.widget.ValueAnimatorCompat.Impl.AnimatorListenerProxy;
import android.support.design.widget.ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.util.ArrayList;

class ValueAnimatorCompatImplGingerbread extends Impl {
	private static final int DEFAULT_DURATION = 200;
	private static final int HANDLER_DELAY = 10;
	private static final Handler sHandler;
	private float mAnimatedFraction;
	private long mDuration;
	private final float[] mFloatValues;
	private final int[] mIntValues;
	private Interpolator mInterpolator;
	private boolean mIsRunning;
	private ArrayList<AnimatorListenerProxy> mListeners;
	private final Runnable mRunnable;
	private long mStartTime;
	private ArrayList<AnimatorUpdateListenerProxy> mUpdateListeners;

	class AnonymousClass_1 implements Runnable {
		final /* synthetic */ ValueAnimatorCompatImplGingerbread this$0;

		AnonymousClass_1(ValueAnimatorCompatImplGingerbread this$0) {
			super();
			this.this$0 = this$0;
		}

		public void run() {
			this$0.update();
		}
	}


	static {
		sHandler = new Handler(Looper.getMainLooper());
	}

	ValueAnimatorCompatImplGingerbread() {
		super();
		mIntValues = new int[2];
		mFloatValues = new float[2];
		mDuration = 200;
		mRunnable = new AnonymousClass_1(this);
	}

	private void dispatchAnimationCancel() {
		if (mListeners != null) {
			int i = 0;
			while (i < mListeners.size()) {
				((AnimatorListenerProxy) mListeners.get(i)).onAnimationCancel();
				i++;
			}
		}
	}

	private void dispatchAnimationEnd() {
		if (mListeners != null) {
			int i = 0;
			while (i < mListeners.size()) {
				((AnimatorListenerProxy) mListeners.get(i)).onAnimationEnd();
				i++;
			}
		}
	}

	private void dispatchAnimationStart() {
		if (mListeners != null) {
			int i = 0;
			while (i < mListeners.size()) {
				((AnimatorListenerProxy) mListeners.get(i)).onAnimationStart();
				i++;
			}
		}
	}

	private void dispatchAnimationUpdate() {
		if (mUpdateListeners != null) {
			int i = 0;
			while (i < mUpdateListeners.size()) {
				((AnimatorUpdateListenerProxy) mUpdateListeners.get(i)).onAnimationUpdate();
				i++;
			}
		}
	}

	public void addListener(AnimatorListenerProxy listener) {
		if (mListeners == null) {
			mListeners = new ArrayList();
		}
		mListeners.add(listener);
	}

	public void addUpdateListener(AnimatorUpdateListenerProxy updateListener) {
		if (mUpdateListeners == null) {
			mUpdateListeners = new ArrayList();
		}
		mUpdateListeners.add(updateListener);
	}

	public void cancel() {
		mIsRunning = false;
		sHandler.removeCallbacks(mRunnable);
		dispatchAnimationCancel();
		dispatchAnimationEnd();
	}

	public void end() {
		if (mIsRunning) {
			mIsRunning = false;
			sHandler.removeCallbacks(mRunnable);
			mAnimatedFraction = 1.0f;
			dispatchAnimationUpdate();
			dispatchAnimationEnd();
		}
	}

	public float getAnimatedFloatValue() {
		return AnimationUtils.lerp(mFloatValues[0], mFloatValues[1], getAnimatedFraction());
	}

	public float getAnimatedFraction() {
		return mAnimatedFraction;
	}

	public int getAnimatedIntValue() {
		return AnimationUtils.lerp(mIntValues[0], mIntValues[1], getAnimatedFraction());
	}

	public long getDuration() {
		return mDuration;
	}

	public boolean isRunning() {
		return mIsRunning;
	}

	public void setDuration(long duration) {
		mDuration = duration;
	}

	public void setFloatValues(float from, float to) {
		mFloatValues[0] = from;
		mFloatValues[1] = to;
	}

	public void setIntValues(int from, int to) {
		mIntValues[0] = from;
		mIntValues[1] = to;
	}

	public void setInterpolator(Interpolator interpolator) {
		mInterpolator = interpolator;
	}

	public void start() {
		if (mIsRunning) {
		} else {
			if (mInterpolator == null) {
				mInterpolator = new AccelerateDecelerateInterpolator();
			}
			mIsRunning = true;
			mAnimatedFraction = 0.0f;
			startInternal();
		}
	}

	final void startInternal() {
		mStartTime = SystemClock.uptimeMillis();
		dispatchAnimationUpdate();
		dispatchAnimationStart();
		sHandler.postDelayed(mRunnable, 10);
	}

	final void update() {
		if (mIsRunning) {
			float linearFraction = MathUtils.constrain(((float) (SystemClock.uptimeMillis() - mStartTime)) / ((float) mDuration), (float)BitmapDescriptorFactory.HUE_RED, 1.0f);
			if (mInterpolator != null) {
				linearFraction = mInterpolator.getInterpolation(linearFraction);
			}
			mAnimatedFraction = linearFraction;
			dispatchAnimationUpdate();
			if (SystemClock.uptimeMillis() >= mStartTime + mDuration) {
				mIsRunning = false;
				dispatchAnimationEnd();
			}
		}
		if (mIsRunning) {
			sHandler.postDelayed(mRunnable, 10);
		}
	}
}
