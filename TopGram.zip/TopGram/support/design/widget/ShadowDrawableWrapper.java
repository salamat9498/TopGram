package android.support.design.widget;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.support.design.R;
import android.support.v7.graphics.drawable.DrawableWrapper;
import com.androidquery.util.Constants;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;

class ShadowDrawableWrapper extends DrawableWrapper {
	static final double COS_45;
	static final float SHADOW_BOTTOM_SCALE = 1.0f;
	static final float SHADOW_HORIZ_SCALE = 0.5f;
	static final float SHADOW_MULTIPLIER = 1.5f;
	static final float SHADOW_TOP_SCALE = 0.25f;
	private boolean mAddPaddingForCorners;
	final RectF mContentBounds;
	float mCornerRadius;
	final Paint mCornerShadowPaint;
	Path mCornerShadowPath;
	private boolean mDirty;
	final Paint mEdgeShadowPaint;
	float mMaxShadowSize;
	private boolean mPrintedShadowClipWarning;
	float mRawMaxShadowSize;
	float mRawShadowSize;
	private float mRotation;
	private final int mShadowEndColor;
	private final int mShadowMiddleColor;
	float mShadowSize;
	private final int mShadowStartColor;

	static {
		COS_45 = Math.cos(Math.toRadians(45.0d));
	}

	public ShadowDrawableWrapper(Resources resources, Drawable content, float radius, float shadowSize, float maxShadowSize) {
		super(content);
		mDirty = true;
		mAddPaddingForCorners = true;
		mPrintedShadowClipWarning = false;
		mShadowStartColor = resources.getColor(R.color.design_fab_shadow_start_color);
		mShadowMiddleColor = resources.getColor(R.color.design_fab_shadow_mid_color);
		mShadowEndColor = resources.getColor(R.color.design_fab_shadow_end_color);
		mCornerShadowPaint = new Paint(5);
		mCornerShadowPaint.setStyle(Style.FILL);
		mCornerRadius = (float) Math.round(radius);
		mContentBounds = new RectF();
		mEdgeShadowPaint = new Paint(mCornerShadowPaint);
		mEdgeShadowPaint.setAntiAlias(false);
		setShadowSize(shadowSize, maxShadowSize);
	}

	private void buildComponents(Rect bounds) {
		float verticalOffset = mRawMaxShadowSize * 1.5f;
		mContentBounds.set(((float) bounds.left) + mRawMaxShadowSize, ((float) bounds.top) + verticalOffset, ((float) bounds.right) - mRawMaxShadowSize, ((float) bounds.bottom) - verticalOffset);
		getWrappedDrawable().setBounds((int) mContentBounds.left, (int) mContentBounds.top, (int) mContentBounds.right, (int) mContentBounds.bottom);
		buildShadowCorners();
	}

	private void buildShadowCorners() {
		RectF innerBounds = new RectF(-mCornerRadius, -mCornerRadius, mCornerRadius, mCornerRadius);
		RectF outerBounds = new RectF(innerBounds);
		outerBounds.inset(-mShadowSize, -mShadowSize);
		if (mCornerShadowPath == null) {
			mCornerShadowPath = new Path();
		} else {
			mCornerShadowPath.reset();
		}
		mCornerShadowPath.setFillType(FillType.EVEN_ODD);
		mCornerShadowPath.moveTo(-mCornerRadius, BitmapDescriptorFactory.HUE_RED);
		mCornerShadowPath.rLineTo(-mShadowSize, BitmapDescriptorFactory.HUE_RED);
		mCornerShadowPath.arcTo(outerBounds, BitmapDescriptorFactory.HUE_CYAN, 90.0f, false);
		mCornerShadowPath.arcTo(innerBounds, BitmapDescriptorFactory.HUE_VIOLET, -90.0f, false);
		mCornerShadowPath.close();
		float shadowRadius = -outerBounds.top;
		if (shadowRadius > 0.0f) {
			float startRatio = mCornerRadius / shadowRadius;
			int[] r5_int_A = new int[4];
			r5_int_A[0] = 0;
			r5_int_A[1] = mShadowStartColor;
			r5_int_A[2] = mShadowMiddleColor;
			r5_int_A[3] = mShadowEndColor;
			float[] r6_float_A = new float[4];
			r6_float_A[0] = 0.0f;
			r6_float_A[1] = startRatio;
			r6_float_A[2] = startRatio + ((1.0f - startRatio) / 2.0f);
			r6_float_A[3] = 1.0f;
			mCornerShadowPaint.setShader(new RadialGradient(0.0f, 0.0f, shadowRadius, r5_int_A, r6_float_A, TileMode.CLAMP));
		}
		int[] r10_int_A = new int[3];
		r10_int_A[0] = mShadowStartColor;
		r10_int_A[1] = mShadowMiddleColor;
		r10_int_A[2] = mShadowEndColor;
		mEdgeShadowPaint.setShader(new LinearGradient(0.0f, innerBounds.top, 0.0f, outerBounds.top, r10_int_A, new float[]{0.0f, 0.5f, 1.0f}, TileMode.CLAMP));
		mEdgeShadowPaint.setAntiAlias(false);
	}

	public static float calculateHorizontalPadding(float maxShadowSize, float cornerRadius, boolean addPaddingForCorners) {
		if (addPaddingForCorners) {
			maxShadowSize = (float) (((double) maxShadowSize) + ((1.0d - COS_45) * ((double) cornerRadius)));
		}
		return maxShadowSize;
	}

	public static float calculateVerticalPadding(float maxShadowSize, float cornerRadius, boolean addPaddingForCorners) {
		float r0f = SHADOW_MULTIPLIER;
		if (addPaddingForCorners) {
			return (float) (((double) (r0f * maxShadowSize)) + ((1.0d - COS_45) * ((double) cornerRadius)));
		} else {
			return r0f * maxShadowSize;
		}
	}

	private void drawShadow(Canvas canvas) {
		boolean drawHorizontalEdges;
		boolean drawVerticalEdges;
		int rotateSaved = canvas.save();
		canvas.rotate(mRotation, mContentBounds.centerX(), mContentBounds.centerY());
		float edgeShadowTop = (-mCornerRadius) - mShadowSize;
		float shadowOffset = mCornerRadius;
		if (mContentBounds.width() - (2.0f * shadowOffset) > 0.0f) {
			drawHorizontalEdges = true;
		} else {
			drawHorizontalEdges = false;
		}
		if (mContentBounds.height() - (2.0f * shadowOffset) > 0.0f) {
			drawVerticalEdges = true;
		} else {
			drawVerticalEdges = false;
		}
		float shadowScaleHorizontal = shadowOffset / (shadowOffset + (mRawShadowSize - (mRawShadowSize * 0.5f)));
		float shadowScaleTop = shadowOffset / (shadowOffset + (mRawShadowSize - (mRawShadowSize * 0.25f)));
		float shadowScaleBottom = shadowOffset / (shadowOffset + (mRawShadowSize - (mRawShadowSize * 1.0f)));
		int saved = canvas.save();
		canvas.translate(mContentBounds.left + shadowOffset, mContentBounds.top + shadowOffset);
		canvas.scale(shadowScaleHorizontal, shadowScaleTop);
		canvas.drawPath(mCornerShadowPath, mCornerShadowPaint);
		if (drawHorizontalEdges) {
			canvas.scale(1.0f / shadowScaleHorizontal, SHADOW_BOTTOM_SCALE);
			canvas.drawRect(BitmapDescriptorFactory.HUE_RED, edgeShadowTop, mContentBounds.width() - (2.0f * shadowOffset), -mCornerRadius, mEdgeShadowPaint);
		}
		canvas.restoreToCount(saved);
		saved = canvas.save();
		canvas.translate(mContentBounds.right - shadowOffset, mContentBounds.bottom - shadowOffset);
		canvas.scale(shadowScaleHorizontal, shadowScaleBottom);
		canvas.rotate(BitmapDescriptorFactory.HUE_CYAN);
		canvas.drawPath(mCornerShadowPath, mCornerShadowPaint);
		if (drawHorizontalEdges) {
			canvas.scale(1.0f / shadowScaleHorizontal, SHADOW_BOTTOM_SCALE);
			canvas.drawRect(BitmapDescriptorFactory.HUE_RED, edgeShadowTop, mContentBounds.width() - (2.0f * shadowOffset), mShadowSize + (-mCornerRadius), mEdgeShadowPaint);
		}
		canvas.restoreToCount(saved);
		saved = canvas.save();
		canvas.translate(mContentBounds.left + shadowOffset, mContentBounds.bottom - shadowOffset);
		canvas.scale(shadowScaleHorizontal, shadowScaleBottom);
		canvas.rotate(BitmapDescriptorFactory.HUE_VIOLET);
		canvas.drawPath(mCornerShadowPath, mCornerShadowPaint);
		if (drawVerticalEdges) {
			canvas.scale(1.0f / shadowScaleBottom, SHADOW_BOTTOM_SCALE);
			canvas.drawRect(BitmapDescriptorFactory.HUE_RED, edgeShadowTop, mContentBounds.height() - (2.0f * shadowOffset), -mCornerRadius, mEdgeShadowPaint);
		}
		canvas.restoreToCount(saved);
		saved = canvas.save();
		canvas.translate(mContentBounds.right - shadowOffset, mContentBounds.top + shadowOffset);
		canvas.scale(shadowScaleHorizontal, shadowScaleTop);
		canvas.rotate(90.0f);
		canvas.drawPath(mCornerShadowPath, mCornerShadowPaint);
		if (drawVerticalEdges) {
			canvas.scale(1.0f / shadowScaleTop, SHADOW_BOTTOM_SCALE);
			canvas.drawRect(BitmapDescriptorFactory.HUE_RED, edgeShadowTop, mContentBounds.height() - (2.0f * shadowOffset), -mCornerRadius, mEdgeShadowPaint);
		}
		canvas.restoreToCount(saved);
		canvas.restoreToCount(rotateSaved);
	}

	private static int toEven(float value) {
		int i = Math.round(value);
		if (i % 2 == 1) {
			i--;
		}
		return i;
	}

	public void draw(Canvas canvas) {
		if (mDirty) {
			buildComponents(getBounds());
			mDirty = false;
		}
		drawShadow(canvas);
		super.draw(canvas);
	}

	public float getCornerRadius() {
		return mCornerRadius;
	}

	public float getMaxShadowSize() {
		return mRawMaxShadowSize;
	}

	public float getMinHeight() {
		return ((mRawMaxShadowSize * 1.5f) * 2.0f) + (2.0f * Math.max(mRawMaxShadowSize, mCornerRadius + ((mRawMaxShadowSize * 1.5f) / 2.0f)));
	}

	public float getMinWidth() {
		return (mRawMaxShadowSize * 2.0f) + (2.0f * Math.max(mRawMaxShadowSize, mCornerRadius + (mRawMaxShadowSize / 2.0f)));
	}

	public int getOpacity() {
		return Constants.PRESET;
	}

	public boolean getPadding(Rect padding) {
		int vOffset = (int) Math.ceil((double) calculateVerticalPadding(mRawMaxShadowSize, mCornerRadius, mAddPaddingForCorners));
		int hOffset = (int) Math.ceil((double) calculateHorizontalPadding(mRawMaxShadowSize, mCornerRadius, mAddPaddingForCorners));
		padding.set(hOffset, vOffset, hOffset, vOffset);
		return true;
	}

	public float getShadowSize() {
		return mRawShadowSize;
	}

	protected void onBoundsChange(Rect bounds) {
		mDirty = true;
	}

	public void setAddPaddingForCorners(boolean addPaddingForCorners) {
		mAddPaddingForCorners = addPaddingForCorners;
		invalidateSelf();
	}

	public void setAlpha(int alpha) {
		super.setAlpha(alpha);
		mCornerShadowPaint.setAlpha(alpha);
		mEdgeShadowPaint.setAlpha(alpha);
	}

	public void setCornerRadius(float radius) {
		radius = (float) Math.round(radius);
		if (mCornerRadius == radius) {
		} else {
			mCornerRadius = radius;
			mDirty = true;
			invalidateSelf();
		}
	}

	public void setMaxShadowSize(float size) {
		setShadowSize(mRawShadowSize, size);
	}

	final void setRotation(float rotation) {
		if (mRotation != rotation) {
			mRotation = rotation;
			invalidateSelf();
		}
	}

	public void setShadowSize(float size) {
		setShadowSize(size, mRawMaxShadowSize);
	}

	void setShadowSize(float shadowSize, float maxShadowSize) {
		if (shadowSize < 0.0f || maxShadowSize < 0.0f) {
			throw new IllegalArgumentException("invalid shadow size");
		} else {
			shadowSize = (float) toEven(shadowSize);
			maxShadowSize = (float) toEven(maxShadowSize);
			if (shadowSize > maxShadowSize) {
				shadowSize = maxShadowSize;
				if (!mPrintedShadowClipWarning) {
					mPrintedShadowClipWarning = true;
				}
			}
			if (mRawShadowSize != shadowSize || mRawMaxShadowSize != maxShadowSize) {
				mRawShadowSize = shadowSize;
				mRawMaxShadowSize = maxShadowSize;
				mShadowSize = (float) Math.round(1.5f * shadowSize);
				mMaxShadowSize = maxShadowSize;
				mDirty = true;
				invalidateSelf();
			}
		}
	}
}
