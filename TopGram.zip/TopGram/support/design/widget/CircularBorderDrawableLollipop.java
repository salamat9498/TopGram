package android.support.design.widget;

import android.graphics.Outline;

class CircularBorderDrawableLollipop extends CircularBorderDrawable {
	CircularBorderDrawableLollipop() {
		super();
	}

	public void getOutline(Outline outline) {
		copyBounds(mRect);
		outline.setOval(mRect);
	}
}
