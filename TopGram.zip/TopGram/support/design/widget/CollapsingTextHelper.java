package android.support.design.widget;

import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.support.annotation.ColorInt;
import android.support.v4.text.TextDirectionHeuristicCompat;
import android.support.v4.text.TextDirectionHeuristicsCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R;
import android.support.v7.widget.TintTypedArray;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.view.View;
import android.view.animation.Interpolator;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import org.telegram.SQLite.SQLiteCursor;
import org.telegram.tgnet.TLRPC;

final class CollapsingTextHelper {
	private static final boolean DEBUG_DRAW = false;
	private static final Paint DEBUG_DRAW_PAINT;
	private static final boolean USE_SCALING_TEXTURE;
	private boolean mBoundsChanged;
	private final Rect mCollapsedBounds;
	private float mCollapsedDrawX;
	private float mCollapsedDrawY;
	private int mCollapsedShadowColor;
	private float mCollapsedShadowDx;
	private float mCollapsedShadowDy;
	private float mCollapsedShadowRadius;
	private ColorStateList mCollapsedTextColor;
	private int mCollapsedTextGravity;
	private float mCollapsedTextSize;
	private Typeface mCollapsedTypeface;
	private final RectF mCurrentBounds;
	private float mCurrentDrawX;
	private float mCurrentDrawY;
	private float mCurrentTextSize;
	private Typeface mCurrentTypeface;
	private boolean mDrawTitle;
	private final Rect mExpandedBounds;
	private float mExpandedDrawX;
	private float mExpandedDrawY;
	private float mExpandedFraction;
	private int mExpandedShadowColor;
	private float mExpandedShadowDx;
	private float mExpandedShadowDy;
	private float mExpandedShadowRadius;
	private ColorStateList mExpandedTextColor;
	private int mExpandedTextGravity;
	private float mExpandedTextSize;
	private Bitmap mExpandedTitleTexture;
	private Typeface mExpandedTypeface;
	private boolean mIsRtl;
	private Interpolator mPositionInterpolator;
	private float mScale;
	private int[] mState;
	private CharSequence mText;
	private final TextPaint mTextPaint;
	private Interpolator mTextSizeInterpolator;
	private CharSequence mTextToDraw;
	private float mTextureAscent;
	private float mTextureDescent;
	private Paint mTexturePaint;
	private boolean mUseTexture;
	private final View mView;

	static {
		boolean r0z;
		boolean r1z = true;
		if (VERSION.SDK_INT < 18) {
			r0z = true;
		} else {
			r0z = false;
		}
		USE_SCALING_TEXTURE = r0z;
		DEBUG_DRAW_PAINT = null;
		if (DEBUG_DRAW_PAINT != null) {
			DEBUG_DRAW_PAINT.setAntiAlias(r1z);
			DEBUG_DRAW_PAINT.setColor(-65281);
		}
	}

	public CollapsingTextHelper(View view) {
		super();
		mExpandedTextGravity = 16;
		mCollapsedTextGravity = 16;
		mExpandedTextSize = 15.0f;
		mCollapsedTextSize = 15.0f;
		mView = view;
		mTextPaint = new TextPaint(129);
		mCollapsedBounds = new Rect();
		mExpandedBounds = new Rect();
		mCurrentBounds = new RectF();
	}

	private static int blendColors(int color1, int color2, float ratio) {
		float inverseRatio = 1.0f - ratio;
		return Color.argb((int) ((((float) Color.alpha(color1)) * inverseRatio) + (((float) Color.alpha(color2)) * ratio)), (int) ((((float) Color.red(color1)) * inverseRatio) + (((float) Color.red(color2)) * ratio)), (int) ((((float) Color.green(color1)) * inverseRatio) + (((float) Color.green(color2)) * ratio)), (int) ((((float) Color.blue(color1)) * inverseRatio) + (((float) Color.blue(color2)) * ratio)));
	}

	private void calculateBaseOffsets() {
		float width;
		int r7i;
		int r6i;
		int expandedAbsGravity;
		int r8i = 1;
		float currentTextSize = mCurrentTextSize;
		calculateUsingTextSize(mCollapsedTextSize);
		if (mTextToDraw != null) {
			width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
		} else {
			width = 0.0f;
		}
		int r10i = mCollapsedTextGravity;
		if (mIsRtl) {
			r7i = 1;
		} else {
			r7i = 0;
		}
		int collapsedAbsGravity = GravityCompat.getAbsoluteGravity(r10i, r7i);
		switch((collapsedAbsGravity & 112)) {
		case NalUnitTypes.NAL_TYPE_UNSPEC48:
			mCollapsedDrawY = ((float) mCollapsedBounds.top) - mTextPaint.ascent();
			switch((collapsedAbsGravity & 8388615)) {
			case TLRPC.USER_FLAG_ACCESS_HASH:
				mCollapsedDrawX = ((float) mCollapsedBounds.centerX()) - (width / 2.0f);
				calculateUsingTextSize(mExpandedTextSize);
				if (mTextToDraw != null) {
					width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
				} else {
					width = 0.0f;
				}
				r6i = mExpandedTextGravity;
				if (mIsRtl) {
					expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
					switch((expandedAbsGravity & 112)) {
					case NalUnitTypes.NAL_TYPE_UNSPEC48:
						mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
						switch((expandedAbsGravity & 8388615)) {
						case TLRPC.USER_FLAG_ACCESS_HASH:
							mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						case SQLiteCursor.FIELD_TYPE_NULL:
							mExpandedDrawX = ((float) mExpandedBounds.right) - width;
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						}
						mExpandedDrawX = (float) mExpandedBounds.left;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case R.styleable.AppCompatTheme_panelMenuListWidth:
						mExpandedDrawY = (float) mExpandedBounds.bottom;
						switch((expandedAbsGravity & 8388615)) {
						case TLRPC.USER_FLAG_ACCESS_HASH:
							mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						case SQLiteCursor.FIELD_TYPE_NULL:
							mExpandedDrawX = ((float) mExpandedBounds.right) - width;
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						}
						mExpandedDrawX = (float) mExpandedBounds.left;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				} else {
					r8i = 0;
					expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
					switch((expandedAbsGravity & 112)) {
					case NalUnitTypes.NAL_TYPE_UNSPEC48:
						mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
						switch((expandedAbsGravity & 8388615)) {
						case TLRPC.USER_FLAG_ACCESS_HASH:
							mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						case SQLiteCursor.FIELD_TYPE_NULL:
							mExpandedDrawX = ((float) mExpandedBounds.right) - width;
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						}
						mExpandedDrawX = (float) mExpandedBounds.left;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case R.styleable.AppCompatTheme_panelMenuListWidth:
						mExpandedDrawY = (float) mExpandedBounds.bottom;
						switch((expandedAbsGravity & 8388615)) {
						case TLRPC.USER_FLAG_ACCESS_HASH:
							mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						case SQLiteCursor.FIELD_TYPE_NULL:
							mExpandedDrawX = ((float) mExpandedBounds.right) - width;
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						}
						mExpandedDrawX = (float) mExpandedBounds.left;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
			case SQLiteCursor.FIELD_TYPE_NULL:
				mCollapsedDrawX = ((float) mCollapsedBounds.right) - width;
				calculateUsingTextSize(mExpandedTextSize);
				if (mTextToDraw != null) {
					width = 0.0f;
				} else {
					width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
				}
				r6i = mExpandedTextGravity;
				if (mIsRtl) {
					r8i = 0;
				}
				expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
				switch((expandedAbsGravity & 112)) {
				case NalUnitTypes.NAL_TYPE_UNSPEC48:
					mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case R.styleable.AppCompatTheme_panelMenuListWidth:
					mExpandedDrawY = (float) mExpandedBounds.bottom;
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mCollapsedDrawX = (float) mCollapsedBounds.left;
			calculateUsingTextSize(mExpandedTextSize);
			if (mTextToDraw != null) {
				width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
			} else {
				width = 0.0f;
			}
			r6i = mExpandedTextGravity;
			if (mIsRtl) {
				expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
				switch((expandedAbsGravity & 112)) {
				case NalUnitTypes.NAL_TYPE_UNSPEC48:
					mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case R.styleable.AppCompatTheme_panelMenuListWidth:
					mExpandedDrawY = (float) mExpandedBounds.bottom;
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			} else {
				r8i = 0;
				expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
				switch((expandedAbsGravity & 112)) {
				case NalUnitTypes.NAL_TYPE_UNSPEC48:
					mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case R.styleable.AppCompatTheme_panelMenuListWidth:
					mExpandedDrawY = (float) mExpandedBounds.bottom;
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
		case R.styleable.AppCompatTheme_panelMenuListWidth:
			mCollapsedDrawY = (float) mCollapsedBounds.bottom;
			switch((collapsedAbsGravity & 8388615)) {
			case TLRPC.USER_FLAG_ACCESS_HASH:
				mCollapsedDrawX = ((float) mCollapsedBounds.centerX()) - (width / 2.0f);
				calculateUsingTextSize(mExpandedTextSize);
				if (mTextToDraw != null) {
					width = 0.0f;
				} else {
					width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
				}
				r6i = mExpandedTextGravity;
				if (mIsRtl) {
					r8i = 0;
				}
				expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
				switch((expandedAbsGravity & 112)) {
				case NalUnitTypes.NAL_TYPE_UNSPEC48:
					mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case R.styleable.AppCompatTheme_panelMenuListWidth:
					mExpandedDrawY = (float) mExpandedBounds.bottom;
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case SQLiteCursor.FIELD_TYPE_NULL:
				mCollapsedDrawX = ((float) mCollapsedBounds.right) - width;
				calculateUsingTextSize(mExpandedTextSize);
				if (mTextToDraw != null) {
					width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
				} else {
					width = 0.0f;
				}
				r6i = mExpandedTextGravity;
				if (mIsRtl) {
					expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
					switch((expandedAbsGravity & 112)) {
					case NalUnitTypes.NAL_TYPE_UNSPEC48:
						mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
						switch((expandedAbsGravity & 8388615)) {
						case TLRPC.USER_FLAG_ACCESS_HASH:
							mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						case SQLiteCursor.FIELD_TYPE_NULL:
							mExpandedDrawX = ((float) mExpandedBounds.right) - width;
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						}
						mExpandedDrawX = (float) mExpandedBounds.left;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case R.styleable.AppCompatTheme_panelMenuListWidth:
						mExpandedDrawY = (float) mExpandedBounds.bottom;
						switch((expandedAbsGravity & 8388615)) {
						case TLRPC.USER_FLAG_ACCESS_HASH:
							mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						case SQLiteCursor.FIELD_TYPE_NULL:
							mExpandedDrawX = ((float) mExpandedBounds.right) - width;
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						}
						mExpandedDrawX = (float) mExpandedBounds.left;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				} else {
					r8i = 0;
					expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
					switch((expandedAbsGravity & 112)) {
					case NalUnitTypes.NAL_TYPE_UNSPEC48:
						mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
						switch((expandedAbsGravity & 8388615)) {
						case TLRPC.USER_FLAG_ACCESS_HASH:
							mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						case SQLiteCursor.FIELD_TYPE_NULL:
							mExpandedDrawX = ((float) mExpandedBounds.right) - width;
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						}
						mExpandedDrawX = (float) mExpandedBounds.left;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case R.styleable.AppCompatTheme_panelMenuListWidth:
						mExpandedDrawY = (float) mExpandedBounds.bottom;
						switch((expandedAbsGravity & 8388615)) {
						case TLRPC.USER_FLAG_ACCESS_HASH:
							mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						case SQLiteCursor.FIELD_TYPE_NULL:
							mExpandedDrawX = ((float) mExpandedBounds.right) - width;
							clearTexture();
							setInterpolatedTextSize(currentTextSize);
						}
						mExpandedDrawX = (float) mExpandedBounds.left;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
			}
			mCollapsedDrawX = (float) mCollapsedBounds.left;
			calculateUsingTextSize(mExpandedTextSize);
			if (mTextToDraw != null) {
				width = 0.0f;
			} else {
				width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
			}
			r6i = mExpandedTextGravity;
			if (mIsRtl) {
				r8i = 0;
			}
			expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
			switch((expandedAbsGravity & 112)) {
			case NalUnitTypes.NAL_TYPE_UNSPEC48:
				mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case R.styleable.AppCompatTheme_panelMenuListWidth:
				mExpandedDrawY = (float) mExpandedBounds.bottom;
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
			switch((expandedAbsGravity & 8388615)) {
			case TLRPC.USER_FLAG_ACCESS_HASH:
				mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case SQLiteCursor.FIELD_TYPE_NULL:
				mExpandedDrawX = ((float) mExpandedBounds.right) - width;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mExpandedDrawX = (float) mExpandedBounds.left;
			clearTexture();
			setInterpolatedTextSize(currentTextSize);
		}
		mCollapsedDrawY = ((float) mCollapsedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
		switch((collapsedAbsGravity & 8388615)) {
		case TLRPC.USER_FLAG_ACCESS_HASH:
			mCollapsedDrawX = ((float) mCollapsedBounds.centerX()) - (width / 2.0f);
			calculateUsingTextSize(mExpandedTextSize);
			if (mTextToDraw != null) {
				width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
			} else {
				width = 0.0f;
			}
			r6i = mExpandedTextGravity;
			if (mIsRtl) {
				expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
				switch((expandedAbsGravity & 112)) {
				case NalUnitTypes.NAL_TYPE_UNSPEC48:
					mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case R.styleable.AppCompatTheme_panelMenuListWidth:
					mExpandedDrawY = (float) mExpandedBounds.bottom;
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			} else {
				r8i = 0;
				expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
				switch((expandedAbsGravity & 112)) {
				case NalUnitTypes.NAL_TYPE_UNSPEC48:
					mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case R.styleable.AppCompatTheme_panelMenuListWidth:
					mExpandedDrawY = (float) mExpandedBounds.bottom;
					switch((expandedAbsGravity & 8388615)) {
					case TLRPC.USER_FLAG_ACCESS_HASH:
						mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					case SQLiteCursor.FIELD_TYPE_NULL:
						mExpandedDrawX = ((float) mExpandedBounds.right) - width;
						clearTexture();
						setInterpolatedTextSize(currentTextSize);
					}
					mExpandedDrawX = (float) mExpandedBounds.left;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
		case SQLiteCursor.FIELD_TYPE_NULL:
			mCollapsedDrawX = ((float) mCollapsedBounds.right) - width;
			calculateUsingTextSize(mExpandedTextSize);
			if (mTextToDraw != null) {
				width = 0.0f;
			} else {
				width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
			}
			r6i = mExpandedTextGravity;
			if (mIsRtl) {
				r8i = 0;
			}
			expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
			switch((expandedAbsGravity & 112)) {
			case NalUnitTypes.NAL_TYPE_UNSPEC48:
				mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case R.styleable.AppCompatTheme_panelMenuListWidth:
				mExpandedDrawY = (float) mExpandedBounds.bottom;
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
			switch((expandedAbsGravity & 8388615)) {
			case TLRPC.USER_FLAG_ACCESS_HASH:
				mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case SQLiteCursor.FIELD_TYPE_NULL:
				mExpandedDrawX = ((float) mExpandedBounds.right) - width;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mExpandedDrawX = (float) mExpandedBounds.left;
			clearTexture();
			setInterpolatedTextSize(currentTextSize);
		}
		mCollapsedDrawX = (float) mCollapsedBounds.left;
		calculateUsingTextSize(mExpandedTextSize);
		if (mTextToDraw != null) {
			width = mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length());
		} else {
			width = 0.0f;
		}
		r6i = mExpandedTextGravity;
		if (mIsRtl) {
			expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
			switch((expandedAbsGravity & 112)) {
			case NalUnitTypes.NAL_TYPE_UNSPEC48:
				mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case R.styleable.AppCompatTheme_panelMenuListWidth:
				mExpandedDrawY = (float) mExpandedBounds.bottom;
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
			switch((expandedAbsGravity & 8388615)) {
			case TLRPC.USER_FLAG_ACCESS_HASH:
				mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case SQLiteCursor.FIELD_TYPE_NULL:
				mExpandedDrawX = ((float) mExpandedBounds.right) - width;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mExpandedDrawX = (float) mExpandedBounds.left;
			clearTexture();
			setInterpolatedTextSize(currentTextSize);
		} else {
			r8i = 0;
			expandedAbsGravity = GravityCompat.getAbsoluteGravity(r6i, r8i);
			switch((expandedAbsGravity & 112)) {
			case NalUnitTypes.NAL_TYPE_UNSPEC48:
				mExpandedDrawY = ((float) mExpandedBounds.top) - mTextPaint.ascent();
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case R.styleable.AppCompatTheme_panelMenuListWidth:
				mExpandedDrawY = (float) mExpandedBounds.bottom;
				switch((expandedAbsGravity & 8388615)) {
				case TLRPC.USER_FLAG_ACCESS_HASH:
					mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				case SQLiteCursor.FIELD_TYPE_NULL:
					mExpandedDrawX = ((float) mExpandedBounds.right) - width;
					clearTexture();
					setInterpolatedTextSize(currentTextSize);
				}
				mExpandedDrawX = (float) mExpandedBounds.left;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mExpandedDrawY = ((float) mExpandedBounds.centerY()) + (((mTextPaint.descent() - mTextPaint.ascent()) / 2.0f) - mTextPaint.descent());
			switch((expandedAbsGravity & 8388615)) {
			case TLRPC.USER_FLAG_ACCESS_HASH:
				mExpandedDrawX = ((float) mExpandedBounds.centerX()) - (width / 2.0f);
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			case SQLiteCursor.FIELD_TYPE_NULL:
				mExpandedDrawX = ((float) mExpandedBounds.right) - width;
				clearTexture();
				setInterpolatedTextSize(currentTextSize);
			}
			mExpandedDrawX = (float) mExpandedBounds.left;
			clearTexture();
			setInterpolatedTextSize(currentTextSize);
		}
	}

	private void calculateCurrentOffsets() {
		calculateOffsets(mExpandedFraction);
	}

	private boolean calculateIsRtl(CharSequence text) {
		boolean defaultIsRtl = true;
		TextDirectionHeuristicCompat r1_TextDirectionHeuristicCompat;
		if (ViewCompat.getLayoutDirection(mView) == 1) {
			if (!defaultIsRtl) {
				r1_TextDirectionHeuristicCompat = TextDirectionHeuristicsCompat.FIRSTSTRONG_RTL;
			} else {
				r1_TextDirectionHeuristicCompat = TextDirectionHeuristicsCompat.FIRSTSTRONG_LTR;
			}
			return r1_TextDirectionHeuristicCompat.isRtl(text, 0, text.length());
		} else {
			defaultIsRtl = false;
			if (!defaultIsRtl) {
				r1_TextDirectionHeuristicCompat = TextDirectionHeuristicsCompat.FIRSTSTRONG_LTR;
			} else {
				r1_TextDirectionHeuristicCompat = TextDirectionHeuristicsCompat.FIRSTSTRONG_RTL;
			}
			return r1_TextDirectionHeuristicCompat.isRtl(text, 0, text.length());
		}
	}

	private void calculateOffsets(float fraction) {
		Interpolator r5_Interpolator = null;
		interpolateBounds(fraction);
		mCurrentDrawX = lerp(mExpandedDrawX, mCollapsedDrawX, fraction, mPositionInterpolator);
		mCurrentDrawY = lerp(mExpandedDrawY, mCollapsedDrawY, fraction, mPositionInterpolator);
		setInterpolatedTextSize(lerp(mExpandedTextSize, mCollapsedTextSize, fraction, mTextSizeInterpolator));
		if (mCollapsedTextColor != mExpandedTextColor) {
			mTextPaint.setColor(blendColors(getCurrentExpandedTextColor(), getCurrentCollapsedTextColor(), fraction));
		} else {
			mTextPaint.setColor(getCurrentCollapsedTextColor());
		}
		mTextPaint.setShadowLayer(lerp(mExpandedShadowRadius, mCollapsedShadowRadius, fraction, r5_Interpolator), lerp(mExpandedShadowDx, mCollapsedShadowDx, fraction, r5_Interpolator), lerp(mExpandedShadowDy, mCollapsedShadowDy, fraction, r5_Interpolator), blendColors(mExpandedShadowColor, mCollapsedShadowColor, fraction));
		ViewCompat.postInvalidateOnAnimation(mView);
	}

	private void calculateUsingTextSize(float textSize) {
		boolean r9z = true;
		if (mText == null) {
		} else {
			float newTextSize;
			float availableWidth;
			float collapsedWidth = (float) mCollapsedBounds.width();
			float expandedWidth = (float) mExpandedBounds.width();
			boolean updateDrawText = false;
			if (isClose(textSize, mCollapsedTextSize)) {
				newTextSize = mCollapsedTextSize;
				mScale = 1.0f;
				if (mCurrentTypeface != mCollapsedTypeface) {
					mCurrentTypeface = mCollapsedTypeface;
					updateDrawText = true;
				}
				availableWidth = collapsedWidth;
			} else {
				newTextSize = mExpandedTextSize;
				if (mCurrentTypeface != mExpandedTypeface) {
					mCurrentTypeface = mExpandedTypeface;
				}
				if (isClose(textSize, mExpandedTextSize)) {
					mScale = 1.0f;
				} else {
					mScale = textSize / mExpandedTextSize;
				}
				float textSizeRatio = mCollapsedTextSize / mExpandedTextSize;
				if (expandedWidth * textSizeRatio > collapsedWidth) {
					availableWidth = Math.min(collapsedWidth / textSizeRatio, expandedWidth);
				} else {
					availableWidth = expandedWidth;
				}
			}
			if (availableWidth > 0.0f) {
				if (mCurrentTextSize != newTextSize || mBoundsChanged || updateDrawText) {
					updateDrawText = true;
				} else {
					updateDrawText = false;
				}
				mCurrentTextSize = newTextSize;
				mBoundsChanged = false;
			}
			if (mTextToDraw == null || updateDrawText) {
				mTextPaint.setTextSize(mCurrentTextSize);
				mTextPaint.setTypeface(mCurrentTypeface);
				TextPaint r10_TextPaint = mTextPaint;
				CharSequence title;
				if (mScale != 1.0f) {
					r10_TextPaint.setLinearText(r9z);
					title = TextUtils.ellipsize(mText, mTextPaint, availableWidth, TruncateAt.END);
					if (TextUtils.equals(title, mTextToDraw)) {
						mTextToDraw = title;
						mIsRtl = calculateIsRtl(mTextToDraw);
					}
				} else {
					r9z = false;
					r10_TextPaint.setLinearText(r9z);
					title = TextUtils.ellipsize(mText, mTextPaint, availableWidth, TruncateAt.END);
					if (TextUtils.equals(title, mTextToDraw)) {
					} else {
						mTextToDraw = title;
						mIsRtl = calculateIsRtl(mTextToDraw);
					}
				}
			}
		}
	}

	private void clearTexture() {
		if (mExpandedTitleTexture != null) {
			mExpandedTitleTexture.recycle();
			mExpandedTitleTexture = null;
		}
	}

	private void ensureExpandedTexture() {
		if (mExpandedTitleTexture != null || mExpandedBounds.isEmpty() || TextUtils.isEmpty(mTextToDraw)) {
		} else {
			calculateOffsets(BitmapDescriptorFactory.HUE_RED);
			mTextureAscent = mTextPaint.ascent();
			mTextureDescent = mTextPaint.descent();
			int w = Math.round(mTextPaint.measureText(mTextToDraw, 0, mTextToDraw.length()));
			int h = Math.round(mTextureDescent - mTextureAscent);
			if (w <= 0 || h <= 0) {
			} else {
				mExpandedTitleTexture = Bitmap.createBitmap(w, h, Config.ARGB_8888);
				new Canvas(mExpandedTitleTexture).drawText(mTextToDraw, 0, mTextToDraw.length(), BitmapDescriptorFactory.HUE_RED, ((float) h) - mTextPaint.descent(), mTextPaint);
				if (mTexturePaint == null) {
					mTexturePaint = new Paint(3);
				}
			}
		}
	}

	@ColorInt
	private int getCurrentCollapsedTextColor() {
		if (mState != null) {
			return mCollapsedTextColor.getColorForState(mState, 0);
		} else {
			return mCollapsedTextColor.getDefaultColor();
		}
	}

	@ColorInt
	private int getCurrentExpandedTextColor() {
		if (mState != null) {
			return mExpandedTextColor.getColorForState(mState, 0);
		} else {
			return mExpandedTextColor.getDefaultColor();
		}
	}

	private void interpolateBounds(float fraction) {
		mCurrentBounds.left = lerp((float) mExpandedBounds.left, (float) mCollapsedBounds.left, fraction, mPositionInterpolator);
		mCurrentBounds.top = lerp(mExpandedDrawY, mCollapsedDrawY, fraction, mPositionInterpolator);
		mCurrentBounds.right = lerp((float) mExpandedBounds.right, (float) mCollapsedBounds.right, fraction, mPositionInterpolator);
		mCurrentBounds.bottom = lerp((float) mExpandedBounds.bottom, (float) mCollapsedBounds.bottom, fraction, mPositionInterpolator);
	}

	private static boolean isClose(float value, float targetValue) {
		if (Math.abs(value - targetValue) < 0.001f) {
			return true;
		} else {
			return false;
		}
	}

	private static float lerp(float startValue, float endValue, float fraction, Interpolator interpolator) {
		if (interpolator != null) {
			fraction = interpolator.getInterpolation(fraction);
		}
		return AnimationUtils.lerp(startValue, endValue, fraction);
	}

	private Typeface readFontFamilyTypeface(int resId) {
		int[] r3_int_A = new int[1];
		r3_int_A[0] = 16843692;
		TypedArray a = mView.getContext().obtainStyledAttributes(resId, r3_int_A);
		int r2i = 0;
		String family = a.getString(r2i);
		if (family != null) {
			a.recycle();
			return Typeface.create(family, 0);
		} else {
			a.recycle();
			return null;
		}
	}

	private static boolean rectEquals(Rect r, int left, int top, int right, int bottom) {
		if (r.left != left || r.top != top || r.right != right || r.bottom != bottom) {
			return false;
		} else {
			return true;
		}
	}

	private void setInterpolatedTextSize(float textSize) {
		boolean r0z;
		calculateUsingTextSize(textSize);
		if (!USE_SCALING_TEXTURE || mScale == 1.0f) {
			r0z = false;
		} else {
			r0z = true;
		}
		mUseTexture = r0z;
		if (mUseTexture) {
			ensureExpandedTexture();
		}
		ViewCompat.postInvalidateOnAnimation(mView);
	}

	public void draw(Canvas canvas) {
		int saveCount = canvas.save();
		if (mTextToDraw == null || !mDrawTitle) {
			canvas.restoreToCount(saveCount);
		} else {
			boolean drawTexture;
			float ascent;
			float x = mCurrentDrawX;
			float y = mCurrentDrawY;
			if (!mUseTexture || mExpandedTitleTexture == null) {
				drawTexture = false;
			} else {
				drawTexture = true;
			}
			if (drawTexture) {
				ascent = mTextureAscent * mScale;
			} else {
				ascent = mTextPaint.ascent() * mScale;
			}
			if (drawTexture) {
				y += ascent;
			}
			if (mScale != 1.0f) {
				canvas.scale(mScale, mScale, x, y);
			}
			if (drawTexture) {
				canvas.drawBitmap(mExpandedTitleTexture, x, y, mTexturePaint);
				canvas.restoreToCount(saveCount);
			} else {
				canvas.drawText(mTextToDraw, 0, mTextToDraw.length(), x, y, mTextPaint);
				canvas.restoreToCount(saveCount);
			}
		}
	}

	ColorStateList getCollapsedTextColor() {
		return mCollapsedTextColor;
	}

	int getCollapsedTextGravity() {
		return mCollapsedTextGravity;
	}

	float getCollapsedTextSize() {
		return mCollapsedTextSize;
	}

	Typeface getCollapsedTypeface() {
		if (mCollapsedTypeface != null) {
			return mCollapsedTypeface;
		} else {
			return Typeface.DEFAULT;
		}
	}

	ColorStateList getExpandedTextColor() {
		return mExpandedTextColor;
	}

	int getExpandedTextGravity() {
		return mExpandedTextGravity;
	}

	float getExpandedTextSize() {
		return mExpandedTextSize;
	}

	Typeface getExpandedTypeface() {
		if (mExpandedTypeface != null) {
			return mExpandedTypeface;
		} else {
			return Typeface.DEFAULT;
		}
	}

	float getExpansionFraction() {
		return mExpandedFraction;
	}

	CharSequence getText() {
		return mText;
	}

	final boolean isStateful() {
		if (mCollapsedTextColor == null || !mCollapsedTextColor.isStateful()) {
			if (mExpandedTextColor == null || !mExpandedTextColor.isStateful()) {
				return false;
			}
		} else {
			return true;
		}
		return true;
	}

	void onBoundsChanged() {
		boolean r0z;
		if (mCollapsedBounds.width() <= 0 || mCollapsedBounds.height() <= 0 || mExpandedBounds.width() <= 0 || mExpandedBounds.height() <= 0) {
			r0z = false;
		} else {
			r0z = true;
		}
		mDrawTitle = r0z;
	}

	public void recalculate() {
		if (mView.getHeight() <= 0 || mView.getWidth() <= 0) {
		} else {
			calculateBaseOffsets();
			calculateCurrentOffsets();
		}
	}

	void setCollapsedBounds(int left, int top, int right, int bottom) {
		if (!rectEquals(mCollapsedBounds, left, top, right, bottom)) {
			mCollapsedBounds.set(left, top, right, bottom);
			mBoundsChanged = true;
			onBoundsChanged();
		}
	}

	void setCollapsedTextAppearance(int resId) {
		TintTypedArray a = TintTypedArray.obtainStyledAttributes(mView.getContext(), resId, R.styleable.TextAppearance);
		if (a.hasValue(R.styleable.TextAppearance_android_textColor)) {
			mCollapsedTextColor = a.getColorStateList(R.styleable.TextAppearance_android_textColor);
		}
		if (a.hasValue(R.styleable.TextAppearance_android_textSize)) {
			mCollapsedTextSize = (float) a.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, (int) mCollapsedTextSize);
		}
		mCollapsedShadowColor = a.getInt(R.styleable.TextAppearance_android_shadowColor, 0);
		mCollapsedShadowDx = a.getFloat(R.styleable.TextAppearance_android_shadowDx, BitmapDescriptorFactory.HUE_RED);
		mCollapsedShadowDy = a.getFloat(R.styleable.TextAppearance_android_shadowDy, BitmapDescriptorFactory.HUE_RED);
		mCollapsedShadowRadius = a.getFloat(R.styleable.TextAppearance_android_shadowRadius, BitmapDescriptorFactory.HUE_RED);
		a.recycle();
		if (VERSION.SDK_INT >= 16) {
			mCollapsedTypeface = readFontFamilyTypeface(resId);
		}
		recalculate();
	}

	void setCollapsedTextColor(ColorStateList textColor) {
		if (mCollapsedTextColor != textColor) {
			mCollapsedTextColor = textColor;
			recalculate();
		}
	}

	void setCollapsedTextGravity(int gravity) {
		if (mCollapsedTextGravity != gravity) {
			mCollapsedTextGravity = gravity;
			recalculate();
		}
	}

	void setCollapsedTextSize(float textSize) {
		if (mCollapsedTextSize != textSize) {
			mCollapsedTextSize = textSize;
			recalculate();
		}
	}

	void setCollapsedTypeface(Typeface typeface) {
		if (mCollapsedTypeface != typeface) {
			mCollapsedTypeface = typeface;
			recalculate();
		}
	}

	void setExpandedBounds(int left, int top, int right, int bottom) {
		if (!rectEquals(mExpandedBounds, left, top, right, bottom)) {
			mExpandedBounds.set(left, top, right, bottom);
			mBoundsChanged = true;
			onBoundsChanged();
		}
	}

	void setExpandedTextAppearance(int resId) {
		TintTypedArray a = TintTypedArray.obtainStyledAttributes(mView.getContext(), resId, R.styleable.TextAppearance);
		if (a.hasValue(R.styleable.TextAppearance_android_textColor)) {
			mExpandedTextColor = a.getColorStateList(R.styleable.TextAppearance_android_textColor);
		}
		if (a.hasValue(R.styleable.TextAppearance_android_textSize)) {
			mExpandedTextSize = (float) a.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, (int) mExpandedTextSize);
		}
		mExpandedShadowColor = a.getInt(R.styleable.TextAppearance_android_shadowColor, 0);
		mExpandedShadowDx = a.getFloat(R.styleable.TextAppearance_android_shadowDx, BitmapDescriptorFactory.HUE_RED);
		mExpandedShadowDy = a.getFloat(R.styleable.TextAppearance_android_shadowDy, BitmapDescriptorFactory.HUE_RED);
		mExpandedShadowRadius = a.getFloat(R.styleable.TextAppearance_android_shadowRadius, BitmapDescriptorFactory.HUE_RED);
		a.recycle();
		if (VERSION.SDK_INT >= 16) {
			mExpandedTypeface = readFontFamilyTypeface(resId);
		}
		recalculate();
	}

	void setExpandedTextColor(ColorStateList textColor) {
		if (mExpandedTextColor != textColor) {
			mExpandedTextColor = textColor;
			recalculate();
		}
	}

	void setExpandedTextGravity(int gravity) {
		if (mExpandedTextGravity != gravity) {
			mExpandedTextGravity = gravity;
			recalculate();
		}
	}

	void setExpandedTextSize(float textSize) {
		if (mExpandedTextSize != textSize) {
			mExpandedTextSize = textSize;
			recalculate();
		}
	}

	void setExpandedTypeface(Typeface typeface) {
		if (mExpandedTypeface != typeface) {
			mExpandedTypeface = typeface;
			recalculate();
		}
	}

	void setExpansionFraction(float fraction) {
		fraction = MathUtils.constrain(fraction, (float)BitmapDescriptorFactory.HUE_RED, 1.0f);
		if (fraction != mExpandedFraction) {
			mExpandedFraction = fraction;
			calculateCurrentOffsets();
		}
	}

	void setPositionInterpolator(Interpolator interpolator) {
		mPositionInterpolator = interpolator;
		recalculate();
	}

	final boolean setState(int[] state) {
		mState = state;
		if (isStateful()) {
			recalculate();
			return true;
		} else {
			return false;
		}
	}

	void setText(CharSequence text) {
		if (text == null || !text.equals(mText)) {
			mText = text;
			mTextToDraw = null;
			clearTexture();
			recalculate();
		}
	}

	void setTextSizeInterpolator(Interpolator interpolator) {
		mTextSizeInterpolator = interpolator;
		recalculate();
	}

	void setTypefaces(Typeface typeface) {
		mExpandedTypeface = typeface;
		mCollapsedTypeface = typeface;
		recalculate();
	}
}
