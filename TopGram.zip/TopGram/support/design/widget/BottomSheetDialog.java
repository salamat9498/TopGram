package android.support.design.widget;

import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.StyleRes;
import android.support.design.R;
import android.support.design.widget.BottomSheetBehavior.BottomSheetCallback;
import android.support.v7.app.AppCompatDialog;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;

public class BottomSheetDialog extends AppCompatDialog {
	private BottomSheetBehavior<FrameLayout> mBehavior;
	private BottomSheetCallback mBottomSheetCallback;
	boolean mCancelable;
	private boolean mCanceledOnTouchOutside;
	private boolean mCanceledOnTouchOutsideSet;

	class AnonymousClass_1 implements OnClickListener {
		final /* synthetic */ BottomSheetDialog this$0;

		AnonymousClass_1(BottomSheetDialog this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onClick(View view) {
			if (!this$0.mCancelable || !this$0.isShowing() || !this$0.shouldWindowCloseOnTouchOutside()) {
			} else {
				this$0.cancel();
			}
		}
	}

	class AnonymousClass_2 extends BottomSheetCallback {
		final /* synthetic */ BottomSheetDialog this$0;

		AnonymousClass_2(BottomSheetDialog this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onSlide(@NonNull View bottomSheet, float slideOffset) {
		}

		public void onStateChanged(@NonNull View bottomSheet, int newState) {
			if (newState == 5) {
				this$0.dismiss();
			}
		}
	}


	public BottomSheetDialog(@NonNull Context context) {
		this(context, 0);
	}

	public BottomSheetDialog(@NonNull Context context, @StyleRes int theme) {
		super(context, getThemeResId(context, theme));
		mCancelable = true;
		mCanceledOnTouchOutside = true;
		mBottomSheetCallback = new AnonymousClass_2(this);
		supportRequestWindowFeature(1);
	}

	protected BottomSheetDialog(@NonNull Context context, boolean cancelable, OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
		mCancelable = true;
		mCanceledOnTouchOutside = true;
		mBottomSheetCallback = new AnonymousClass_2(this);
		supportRequestWindowFeature(1);
		mCancelable = cancelable;
	}

	private static int getThemeResId(Context context, int themeId) {
		if (themeId == 0) {
			TypedValue outValue = new TypedValue();
			if (context.getTheme().resolveAttribute(R.attr.bottomSheetDialogTheme, outValue, true)) {
				return outValue.resourceId;
			} else {
				return R.style.Theme_Design_Light_BottomSheetDialog;
			}
		} else {
			return themeId;
		}
	}

	private View wrapInBottomSheet(int layoutResId, View view, LayoutParams params) {
		View coordinator = (CoordinatorLayout) View.inflate(getContext(), R.layout.design_bottom_sheet_dialog, null);
		View bottomSheet;
		if (layoutResId == 0 || view != null) {
			bottomSheet = (FrameLayout) coordinator.findViewById(R.id.design_bottom_sheet);
			mBehavior = BottomSheetBehavior.from(bottomSheet);
			mBehavior.setBottomSheetCallback(mBottomSheetCallback);
			mBehavior.setHideable(mCancelable);
			if (params != null) {
				bottomSheet.addView(view);
			} else {
				bottomSheet.addView(view, params);
			}
			coordinator.findViewById(R.id.touch_outside).setOnClickListener(new AnonymousClass_1(this));
			return coordinator;
		} else {
			view = getLayoutInflater().inflate(layoutResId, coordinator, false);
			bottomSheet = (FrameLayout) coordinator.findViewById(R.id.design_bottom_sheet);
			mBehavior = BottomSheetBehavior.from(bottomSheet);
			mBehavior.setBottomSheetCallback(mBottomSheetCallback);
			mBehavior.setHideable(mCancelable);
			if (params != null) {
				bottomSheet.addView(view, params);
			} else {
				bottomSheet.addView(view);
			}
			coordinator.findViewById(R.id.touch_outside).setOnClickListener(new AnonymousClass_1(this));
			return coordinator;
		}
	}

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setLayout(-1, -1);
	}

	public void setCancelable(boolean cancelable) {
		super.setCancelable(cancelable);
		if (mCancelable != cancelable) {
			mCancelable = cancelable;
			if (mBehavior != null) {
				mBehavior.setHideable(cancelable);
			}
		}
	}

	public void setCanceledOnTouchOutside(boolean cancel) {
		super.setCanceledOnTouchOutside(cancel);
		if (!cancel || mCancelable) {
			mCanceledOnTouchOutside = cancel;
			mCanceledOnTouchOutsideSet = true;
		} else {
			mCancelable = true;
			mCanceledOnTouchOutside = cancel;
			mCanceledOnTouchOutsideSet = true;
		}
	}

	public void setContentView(@LayoutRes int layoutResId) {
		super.setContentView(wrapInBottomSheet(layoutResId, null, null));
	}

	public void setContentView(View view) {
		super.setContentView(wrapInBottomSheet(0, view, null));
	}

	public void setContentView(View view, LayoutParams params) {
		super.setContentView(wrapInBottomSheet(0, view, params));
	}

	boolean shouldWindowCloseOnTouchOutside() {
		if (!mCanceledOnTouchOutsideSet) {
			if (VERSION.SDK_INT < 11) {
				mCanceledOnTouchOutside = true;
			} else {
				int[] r2_int_A = new int[1];
				r2_int_A[0] = 16843611;
				TypedArray a = getContext().obtainStyledAttributes(r2_int_A);
				mCanceledOnTouchOutside = a.getBoolean(0, true);
				a.recycle();
			}
			mCanceledOnTouchOutsideSet = true;
		}
		return mCanceledOnTouchOutside;
	}
}
