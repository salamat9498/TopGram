package android.support.design.widget;

import android.support.design.widget.ValueAnimatorCompat.AnimatorListener;
import android.support.design.widget.ValueAnimatorCompat.AnimatorListenerAdapter;
import android.util.StateSet;
import java.util.ArrayList;

final class StateListAnimator {
	private final AnimatorListener mAnimationListener;
	private Tuple mLastMatch;
	ValueAnimatorCompat mRunningAnimator;
	private final ArrayList<Tuple> mTuples;

	class AnonymousClass_1 extends AnimatorListenerAdapter {
		final /* synthetic */ StateListAnimator this$0;

		AnonymousClass_1(StateListAnimator this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onAnimationEnd(ValueAnimatorCompat animator) {
			if (this$0.mRunningAnimator == animator) {
				this$0.mRunningAnimator = null;
			}
		}
	}

	static class Tuple {
		final ValueAnimatorCompat mAnimator;
		final int[] mSpecs;

		Tuple(int[] specs, ValueAnimatorCompat animator) {
			super();
			mSpecs = specs;
			mAnimator = animator;
		}
	}


	StateListAnimator() {
		super();
		mTuples = new ArrayList();
		mLastMatch = null;
		mRunningAnimator = null;
		mAnimationListener = new AnonymousClass_1(this);
	}

	private void cancel() {
		if (mRunningAnimator != null) {
			mRunningAnimator.cancel();
			mRunningAnimator = null;
		}
	}

	private void start(Tuple match) {
		mRunningAnimator = match.mAnimator;
		mRunningAnimator.start();
	}

	public void addState(int[] specs, ValueAnimatorCompat animator) {
		animator.addListener(mAnimationListener);
		mTuples.add(new Tuple(specs, animator));
	}

	public void jumpToCurrentState() {
		if (mRunningAnimator != null) {
			mRunningAnimator.end();
			mRunningAnimator = null;
		}
	}

	void setState(int[] state) {
		Tuple match = null;
		int i = 0;
		while (i < mTuples.size()) {
			Tuple tuple = (Tuple) mTuples.get(i);
			if (StateSet.stateSetMatches(tuple.mSpecs, state)) {
				match = tuple;
			} else {
				i++;
			}
		}
		if (match == mLastMatch) {
		} else {
			if (mLastMatch != null) {
				cancel();
			}
			mLastMatch = match;
			if (match != null) {
				start(match);
			}
		}
	}
}
