package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Build.VERSION;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButtonImpl.InternalVisibilityChangedListener;
import android.support.design.widget.ValueAnimatorCompat.Creator;
import android.support.v4.view.ViewCompat;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import org.telegram.tgnet.TLRPC;

class FloatingActionButtonIcs extends FloatingActionButtonGingerbread {
	private float mRotation;

	class AnonymousClass_1 extends AnimatorListenerAdapter {
		private boolean mCancelled;
		final /* synthetic */ FloatingActionButtonIcs this$0;
		final /* synthetic */ boolean val$fromUser;
		final /* synthetic */ InternalVisibilityChangedListener val$listener;

		AnonymousClass_1(FloatingActionButtonIcs this$0, boolean r2z, InternalVisibilityChangedListener r3_InternalVisibilityChangedListener) {
			super();
			this.this$0 = this$0;
			val$fromUser = r2z;
			val$listener = r3_InternalVisibilityChangedListener;
		}

		public void onAnimationCancel(Animator animation) {
			mCancelled = true;
		}

		public void onAnimationEnd(Animator animation) {
			this$0.mAnimState = 0;
			if (!mCancelled) {
				this$0.mView.internalSetVisibility(TLRPC.USER_FLAG_USERNAME, val$fromUser);
				if (val$listener != null) {
					val$listener.onHidden();
				}
			}
		}

		public void onAnimationStart(Animator animation) {
			this$0.mView.internalSetVisibility(0, val$fromUser);
			mCancelled = false;
		}
	}

	class AnonymousClass_2 extends AnimatorListenerAdapter {
		final /* synthetic */ FloatingActionButtonIcs this$0;
		final /* synthetic */ boolean val$fromUser;
		final /* synthetic */ InternalVisibilityChangedListener val$listener;

		AnonymousClass_2(FloatingActionButtonIcs this$0, boolean r2z, InternalVisibilityChangedListener r3_InternalVisibilityChangedListener) {
			super();
			this.this$0 = this$0;
			val$fromUser = r2z;
			val$listener = r3_InternalVisibilityChangedListener;
		}

		public void onAnimationEnd(Animator animation) {
			this$0.mAnimState = 0;
			if (val$listener != null) {
				val$listener.onShown();
			}
		}

		public void onAnimationStart(Animator animation) {
			this$0.mView.internalSetVisibility(0, val$fromUser);
		}
	}


	FloatingActionButtonIcs(VisibilityAwareImageButton view, ShadowViewDelegate shadowViewDelegate, Creator animatorCreator) {
		super(view, shadowViewDelegate, animatorCreator);
		mRotation = mView.getRotation();
	}

	private boolean shouldAnimateVisibilityChange() {
		if (!ViewCompat.isLaidOut(mView) || mView.isInEditMode()) {
			return false;
		} else {
			return true;
		}
	}

	private void updateFromViewRotation() {
		if (VERSION.SDK_INT == 19) {
			if (mRotation % 90.0f != 0.0f) {
				if (mView.getLayerType() != 1) {
					mView.setLayerType(1, null);
				}
			} else if (mView.getLayerType() != 0) {
				mView.setLayerType(0, null);
			}
		}
		if (mShadowDrawable != null) {
			mShadowDrawable.setRotation(-mRotation);
		}
		if (mBorderDrawable != null) {
			mBorderDrawable.setRotation(-mRotation);
		}
	}

	void hide(@Nullable InternalVisibilityChangedListener listener, boolean fromUser) {
		float r1f = BitmapDescriptorFactory.HUE_RED;
		if (isOrWillBeHidden()) {
		} else {
			mView.animate().cancel();
			if (shouldAnimateVisibilityChange()) {
				mAnimState = 1;
				mView.animate().scaleX(r1f).scaleY(r1f).alpha(r1f).setDuration(200).setInterpolator(AnimationUtils.FAST_OUT_LINEAR_IN_INTERPOLATOR).setListener(new AnonymousClass_1(this, fromUser, listener));
			} else {
				mView.internalSetVisibility(TLRPC.USER_FLAG_USERNAME, fromUser);
				if (listener != null) {
					listener.onHidden();
				}
			}
		}
	}

	void onPreDraw() {
		float rotation = mView.getRotation();
		if (mRotation != rotation) {
			mRotation = rotation;
			updateFromViewRotation();
		}
	}

	boolean requirePreDrawListener() {
		return true;
	}

	void show(@Nullable InternalVisibilityChangedListener listener, boolean fromUser) {
		float r2f = 1.0f;
		if (isOrWillBeShown()) {
		} else {
			mView.animate().cancel();
			if (shouldAnimateVisibilityChange()) {
				mAnimState = 2;
				if (mView.getVisibility() != 0) {
					mView.setAlpha(BitmapDescriptorFactory.HUE_RED);
					mView.setScaleY(BitmapDescriptorFactory.HUE_RED);
					mView.setScaleX(BitmapDescriptorFactory.HUE_RED);
				}
				mView.animate().scaleX(r2f).scaleY(r2f).alpha(r2f).setDuration(200).setInterpolator(AnimationUtils.LINEAR_OUT_SLOW_IN_INTERPOLATOR).setListener(new AnonymousClass_2(this, fromUser, listener));
			} else {
				mView.internalSetVisibility(0, fromUser);
				mView.setAlpha(1.0f);
				mView.setScaleY(1.0f);
				mView.setScaleX(1.0f);
				if (listener != null) {
					listener.onShown();
				}
			}
		}
	}
}
