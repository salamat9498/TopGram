package android.support.design.widget;

import android.content.Context;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v7.appcompat.R;
import android.support.v7.widget.AppCompatImageButton;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Checkable;
import org.telegram.tgnet.TLRPC;

public class CheckableImageButton extends AppCompatImageButton implements Checkable {
	private static final int[] DRAWABLE_STATE_CHECKED;
	private boolean mChecked;

	class AnonymousClass_1 extends AccessibilityDelegateCompat {
		final /* synthetic */ CheckableImageButton this$0;

		AnonymousClass_1(CheckableImageButton this$0) {
			super();
			this.this$0 = this$0;
		}

		public void onInitializeAccessibilityEvent(View host, AccessibilityEvent event) {
			super.onInitializeAccessibilityEvent(host, event);
			event.setChecked(this$0.isChecked());
		}

		public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfoCompat info) {
			super.onInitializeAccessibilityNodeInfo(host, info);
			info.setCheckable(true);
			info.setChecked(this$0.isChecked());
		}
	}


	static {
		int[] r0_int_A = new int[1];
		r0_int_A[0] = 16842912;
		DRAWABLE_STATE_CHECKED = r0_int_A;
	}

	public CheckableImageButton(Context context) {
		this(context, null);
	}

	public CheckableImageButton(Context context, AttributeSet attrs) {
		this(context, attrs, R.attr.imageButtonStyle);
	}

	public CheckableImageButton(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		ViewCompat.setAccessibilityDelegate(this, new AnonymousClass_1(this));
	}

	public boolean isChecked() {
		return mChecked;
	}

	public int[] onCreateDrawableState(int extraSpace) {
		if (mChecked) {
			return mergeDrawableStates(super.onCreateDrawableState(DRAWABLE_STATE_CHECKED.length + extraSpace), DRAWABLE_STATE_CHECKED);
		} else {
			return super.onCreateDrawableState(extraSpace);
		}
	}

	public void setChecked(boolean checked) {
		if (mChecked != checked) {
			mChecked = checked;
			refreshDrawableState();
			sendAccessibilityEvent(TLRPC.MESSAGE_FLAG_HAS_BOT_ID);
		}
	}

	public void toggle() {
		boolean r0z;
		if (!mChecked) {
			r0z = true;
		} else {
			r0z = false;
		}
		setChecked(r0z);
	}
}
