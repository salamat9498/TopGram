package android.support.design.widget;

class MathUtils {
	MathUtils() {
		super();
	}

	static float constrain(float amount, float low, float high) {
		if (amount < low) {
			return low;
		} else if (amount > high) {
			return high;
		} else {
			return amount;
		}
	}

	static int constrain(int amount, int low, int high) {
		if (amount < low) {
			return low;
		} else if (amount > high) {
			return high;
		} else {
			return amount;
		}
	}
}
