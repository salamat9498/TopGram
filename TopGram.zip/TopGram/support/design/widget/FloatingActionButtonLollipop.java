package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.support.design.widget.ValueAnimatorCompat.Creator;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.view.View;

@TargetApi(21)
class FloatingActionButtonLollipop extends FloatingActionButtonIcs {
	private InsetDrawable mInsetDrawable;

	FloatingActionButtonLollipop(VisibilityAwareImageButton view, ShadowViewDelegate shadowViewDelegate, Creator animatorCreator) {
		super(view, shadowViewDelegate, animatorCreator);
	}

	public float getElevation() {
		return mView.getElevation();
	}

	void getPadding(Rect rect) {
		if (mShadowViewDelegate.isCompatPaddingEnabled()) {
			float radius = mShadowViewDelegate.getRadius();
			float maxShadowSize = getElevation() + mPressedTranslationZ;
			int hPadding = (int) Math.ceil((double) ShadowDrawableWrapper.calculateHorizontalPadding(maxShadowSize, radius, false));
			int vPadding = (int) Math.ceil((double) ShadowDrawableWrapper.calculateVerticalPadding(maxShadowSize, radius, false));
			rect.set(hPadding, vPadding, hPadding, vPadding);
		} else {
			rect.set(0, 0, 0, 0);
		}
	}

	void jumpDrawableToCurrentState() {
	}

	CircularBorderDrawable newCircularDrawable() {
		return new CircularBorderDrawableLollipop();
	}

	void onCompatShadowChanged() {
		updatePadding();
	}

	void onDrawableStateChanged(int[] state) {
	}

	void onElevationsChanged(float elevation, float pressedTranslationZ) {
		StateListAnimator stateListAnimator = new StateListAnimator();
		Animator set = new AnimatorSet();
		float[] r5_float_A = new float[1];
		r5_float_A[0] = elevation;
		float[] r6_float_A = new float[1];
		r6_float_A[0] = pressedTranslationZ;
		set.play(ObjectAnimator.ofFloat(mView, "elevation", r5_float_A).setDuration(0)).with(ObjectAnimator.ofFloat(mView, View.TRANSLATION_Z, r6_float_A).setDuration(100));
		set.setInterpolator(ANIM_INTERPOLATOR);
		stateListAnimator.addState(PRESSED_ENABLED_STATE_SET, set);
		set = new AnimatorSet();
		r5_float_A = new float[1];
		r5_float_A[0] = elevation;
		r6_float_A = new float[1];
		r6_float_A[0] = pressedTranslationZ;
		set.play(ObjectAnimator.ofFloat(mView, "elevation", r5_float_A).setDuration(0)).with(ObjectAnimator.ofFloat(mView, View.TRANSLATION_Z, r6_float_A).setDuration(100));
		set.setInterpolator(ANIM_INTERPOLATOR);
		stateListAnimator.addState(FOCUSED_ENABLED_STATE_SET, set);
		set = new AnimatorSet();
		Animator anim = new AnimatorSet();
		r5_float_A = new float[1];
		r5_float_A[0] = 0.0f;
		anim.play(ObjectAnimator.ofFloat(mView, View.TRANSLATION_Z, r5_float_A).setDuration(100)).after(100);
		r5_float_A = new float[1];
		r5_float_A[0] = elevation;
		set.play(ObjectAnimator.ofFloat(mView, "elevation", r5_float_A).setDuration(0)).with(anim);
		set.setInterpolator(ANIM_INTERPOLATOR);
		stateListAnimator.addState(ENABLED_STATE_SET, set);
		set = new AnimatorSet();
		r5_float_A = new float[1];
		r5_float_A[0] = 0.0f;
		r6_float_A = new float[1];
		r6_float_A[0] = 0.0f;
		set.play(ObjectAnimator.ofFloat(mView, "elevation", r5_float_A).setDuration(0)).with(ObjectAnimator.ofFloat(mView, View.TRANSLATION_Z, r6_float_A).setDuration(0));
		set.setInterpolator(ANIM_INTERPOLATOR);
		stateListAnimator.addState(EMPTY_STATE_SET, set);
		mView.setStateListAnimator(stateListAnimator);
		if (mShadowViewDelegate.isCompatPaddingEnabled()) {
			updatePadding();
		}
	}

	void onPaddingUpdated(Rect padding) {
		if (mShadowViewDelegate.isCompatPaddingEnabled()) {
			mInsetDrawable = new InsetDrawable(mRippleDrawable, padding.left, padding.top, padding.right, padding.bottom);
			mShadowViewDelegate.setBackgroundDrawable(mInsetDrawable);
		} else {
			mShadowViewDelegate.setBackgroundDrawable(mRippleDrawable);
		}
	}

	boolean requirePreDrawListener() {
		return false;
	}

	void setBackgroundDrawable(ColorStateList backgroundTint, Mode backgroundTintMode, int rippleColor, int borderWidth) {
		Drawable rippleContent;
		mShapeDrawable = DrawableCompat.wrap(createShapeDrawable());
		DrawableCompat.setTintList(mShapeDrawable, backgroundTint);
		if (backgroundTintMode != null) {
			DrawableCompat.setTintMode(mShapeDrawable, backgroundTintMode);
		}
		if (borderWidth > 0) {
			mBorderDrawable = createBorderDrawable(borderWidth, backgroundTint);
			Drawable[] r1_Drawable_A = new Drawable[2];
			r1_Drawable_A[0] = mBorderDrawable;
			r1_Drawable_A[1] = mShapeDrawable;
			rippleContent = new LayerDrawable(r1_Drawable_A);
		} else {
			mBorderDrawable = null;
			rippleContent = mShapeDrawable;
		}
		mRippleDrawable = new RippleDrawable(ColorStateList.valueOf(rippleColor), rippleContent, null);
		mContentBackground = mRippleDrawable;
		mShadowViewDelegate.setBackgroundDrawable(mRippleDrawable);
	}

	void setRippleColor(int rippleColor) {
		if (mRippleDrawable instanceof RippleDrawable) {
			((RippleDrawable) mRippleDrawable).setColor(ColorStateList.valueOf(rippleColor));
		} else {
			super.setRippleColor(rippleColor);
		}
	}
}
