package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import android.support.design.R;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.NestedScrollingChild;
import android.support.v4.view.PointerIconCompat;
import android.support.v4.view.VelocityTrackerCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ViewDragHelper;
import android.support.v4.widget.ViewDragHelper.Callback;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import org.telegram.ui.Components.Glow;

public class BottomSheetBehavior<V extends View> extends Behavior<V> {
	private static final float HIDE_FRICTION = 0.1f;
	private static final float HIDE_THRESHOLD = 0.5f;
	public static final int PEEK_HEIGHT_AUTO = -1;
	public static final int STATE_COLLAPSED = 4;
	public static final int STATE_DRAGGING = 1;
	public static final int STATE_EXPANDED = 3;
	public static final int STATE_HIDDEN = 5;
	public static final int STATE_SETTLING = 2;
	int mActivePointerId;
	private BottomSheetCallback mCallback;
	private final Callback mDragCallback;
	boolean mHideable;
	private boolean mIgnoreEvents;
	private int mInitialY;
	private int mLastNestedScrollDy;
	int mMaxOffset;
	private float mMaximumVelocity;
	int mMinOffset;
	private boolean mNestedScrolled;
	WeakReference<View> mNestedScrollingChildRef;
	int mParentHeight;
	private int mPeekHeight;
	private boolean mPeekHeightAuto;
	private int mPeekHeightMin;
	private boolean mSkipCollapsed;
	int mState;
	boolean mTouchingScrollingChild;
	private VelocityTracker mVelocityTracker;
	ViewDragHelper mViewDragHelper;
	WeakReference<V> mViewRef;

	class AnonymousClass_1 implements Runnable {
		final /* synthetic */ BottomSheetBehavior this$0;
		final /* synthetic */ View val$child;
		final /* synthetic */ int val$state;

		AnonymousClass_1(BottomSheetBehavior this$0, View r2_View, int r3i) {
			super();
			this.this$0 = this$0;
			val$child = r2_View;
			val$state = r3i;
		}

		public void run() {
			this$0.startSettlingAnimation(val$child, val$state);
		}
	}

	class AnonymousClass_2 extends Callback {
		final /* synthetic */ BottomSheetBehavior this$0;

		AnonymousClass_2(BottomSheetBehavior this$0) {
			super();
			this.this$0 = this$0;
		}

		public int clampViewPositionHorizontal(View child, int left, int dx) {
			return child.getLeft();
		}

		public int clampViewPositionVertical(View child, int top, int dy) {
			int r0i;
			int r1i = this$0.mMinOffset;
			if (this$0.mHideable) {
				r0i = this$0.mParentHeight;
			} else {
				r0i = this$0.mMaxOffset;
			}
			return MathUtils.constrain(top, r1i, r0i);
		}

		public int getViewVerticalDragRange(View child) {
			if (this$0.mHideable) {
				return this$0.mParentHeight - this$0.mMinOffset;
			} else {
				return this$0.mMaxOffset - this$0.mMinOffset;
			}
		}

		public void onViewDragStateChanged(int state) {
			if (state == 1) {
				this$0.setStateInternal(STATE_DRAGGING);
			}
		}

		public void onViewPositionChanged(View changedView, int left, int top, int dx, int dy) {
			this$0.dispatchOnSlide(top);
		}

		public void onViewReleased(View releasedChild, float xvel, float yvel) {
			int top;
			int targetState;
			if (yvel < 0.0f) {
				top = this$0.mMinOffset;
				targetState = STATE_EXPANDED;
			} else if (!this$0.mHideable || !this$0.shouldHide(releasedChild, yvel)) {
				if (yvel == 0.0f) {
					int currentTop = releasedChild.getTop();
					if (Math.abs(currentTop - this$0.mMinOffset) < Math.abs(currentTop - this$0.mMaxOffset)) {
						top = this$0.mMinOffset;
						targetState = STATE_EXPANDED;
					} else {
						top = this$0.mMaxOffset;
						targetState = STATE_COLLAPSED;
					}
				} else {
					top = this$0.mMaxOffset;
					targetState = STATE_COLLAPSED;
				}
			} else {
				top = this$0.mParentHeight;
				targetState = STATE_HIDDEN;
			}
			if (this$0.mViewDragHelper.settleCapturedViewAt(releasedChild.getLeft(), top)) {
				this$0.setStateInternal(STATE_SETTLING);
				ViewCompat.postOnAnimation(releasedChild, new BottomSheetBehavior.SettleRunnable(this$0, releasedChild, targetState));
			} else {
				this$0.setStateInternal(targetState);
			}
		}

		public boolean tryCaptureView(View child, int pointerId) {
			boolean r1z = true;
			if (this$0.mState == 1) {
				return false;
			} else if (!this$0.mTouchingScrollingChild) {
				if (this$0.mState != 3 || this$0.mActivePointerId != pointerId) {
					if (this$0.mViewRef == null || this$0.mViewRef.get() != child) {
						r1z = false;
					} else {
						return r1z;
					}
					return r1z;
				} else {
					View scroll = (View) this$0.mNestedScrollingChildRef.get();
					if (scroll == null || !ViewCompat.canScrollVertically(scroll, PEEK_HEIGHT_AUTO)) {
						if (this$0.mViewRef == null || this$0.mViewRef.get() != child) {
							r1z = false;
						} else {
							return r1z;
						}
						return r1z;
					} else {
						return false;
					}
				}
			} else {
				return false;
			}
		}
	}

	public static abstract class BottomSheetCallback {
		public BottomSheetCallback() {
			super();
		}

		public abstract void onSlide(@NonNull View r1_View, float r2f);

		public abstract void onStateChanged(@NonNull View r1_View, int r2i);
	}

	protected static class SavedState extends AbsSavedState {
		public static final Creator<BottomSheetBehavior.SavedState> CREATOR;
		final int state;

		static class AnonymousClass_1 implements ParcelableCompatCreatorCallbacks<BottomSheetBehavior.SavedState> {
			AnonymousClass_1() {
				super();
			}

			public BottomSheetBehavior.SavedState createFromParcel(Parcel in, ClassLoader loader) {
				return new BottomSheetBehavior.SavedState(in, loader);
			}

			public BottomSheetBehavior.SavedState[] newArray(int size) {
				return new BottomSheetBehavior.SavedState[size];
			}
		}


		static {
			CREATOR = ParcelableCompat.newCreator(new AnonymousClass_1());
		}

		public SavedState(Parcel source) {
			this(source, null);
		}

		public SavedState(Parcel source, ClassLoader loader) {
			super(source, loader);
			state = source.readInt();
		}

		public SavedState(Parcelable superState, int state) {
			super(superState);
			this.state = state;
		}

		public void writeToParcel(Parcel out, int flags) {
			super.writeToParcel(out, flags);
			out.writeInt(state);
		}
	}

	private class SettleRunnable implements Runnable {
		private final int mTargetState;
		private final View mView;
		final /* synthetic */ BottomSheetBehavior this$0;

		SettleRunnable(BottomSheetBehavior r1_BottomSheetBehavior, View view, int targetState) {
			super();
			this$0 = r1_BottomSheetBehavior;
			mView = view;
			mTargetState = targetState;
		}

		public void run() {
			if (this$0.mViewDragHelper == null || !this$0.mViewDragHelper.continueSettling(true)) {
				this$0.setStateInternal(mTargetState);
			} else {
				ViewCompat.postOnAnimation(mView, this);
			}
		}
	}

	@Retention(RetentionPolicy.SOURCE)
	public static @interface State {
	}


	public BottomSheetBehavior() {
		super();
		mState = 4;
		mDragCallback = new AnonymousClass_2(this);
	}

	public BottomSheetBehavior(Context context, AttributeSet attrs) {
		super(context, attrs);
		mState = 4;
		mDragCallback = new AnonymousClass_2(this);
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.BottomSheetBehavior_Layout);
		TypedValue value = a.peekValue(R.styleable.BottomSheetBehavior_Layout_behavior_peekHeight);
		if (value == null || value.data != -1) {
			setPeekHeight(a.getDimensionPixelSize(R.styleable.BottomSheetBehavior_Layout_behavior_peekHeight, PEEK_HEIGHT_AUTO));
		} else {
			setPeekHeight(value.data);
		}
		setHideable(a.getBoolean(R.styleable.BottomSheetBehavior_Layout_behavior_hideable, false));
		setSkipCollapsed(a.getBoolean(R.styleable.BottomSheetBehavior_Layout_behavior_skipCollapsed, false));
		a.recycle();
		mMaximumVelocity = (float) ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
	}

	private View findScrollingChild(View view) {
		if (view instanceof NestedScrollingChild) {
			return view;
		} else {
			if (view instanceof ViewGroup) {
				ViewGroup group = (ViewGroup) view;
				int i = 0;
				while (i < group.getChildCount()) {
					View scrollingChild = findScrollingChild(group.getChildAt(i));
					if (scrollingChild != null) {
						return scrollingChild;
					} else {
						i++;
					}
				}
			}
			return null;
		}
	}

	public static <V extends View> BottomSheetBehavior<V> from(V view) {
		LayoutParams params = view.getLayoutParams();
		if (!(params instanceof CoordinatorLayout.LayoutParams)) {
			throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
		} else {
			Behavior behavior = ((CoordinatorLayout.LayoutParams) params).getBehavior();
			if (!(behavior instanceof BottomSheetBehavior)) {
				throw new IllegalArgumentException("The view is not associated with BottomSheetBehavior");
			} else {
				return (BottomSheetBehavior) behavior;
			}
		}
	}

	private float getYVelocity() {
		mVelocityTracker.computeCurrentVelocity(PointerIconCompat.TYPE_DEFAULT, mMaximumVelocity);
		return VelocityTrackerCompat.getYVelocity(mVelocityTracker, mActivePointerId);
	}

	private void reset() {
		mActivePointerId = -1;
		if (mVelocityTracker != null) {
			mVelocityTracker.recycle();
			mVelocityTracker = null;
		}
	}

	void dispatchOnSlide(int top) {
		View bottomSheet = (View) mViewRef.get();
		if (bottomSheet == null || mCallback == null) {
		} else if (top > mMaxOffset) {
			mCallback.onSlide(bottomSheet, ((float) (mMaxOffset - top)) / ((float) (mParentHeight - mMaxOffset)));
		} else {
			mCallback.onSlide(bottomSheet, ((float) (mMaxOffset - top)) / ((float) (mMaxOffset - mMinOffset)));
		}
	}

	public final int getPeekHeight() {
		if (mPeekHeightAuto) {
			return PEEK_HEIGHT_AUTO;
		} else {
			return mPeekHeight;
		}
	}

	public boolean getSkipCollapsed() {
		return mSkipCollapsed;
	}

	public final int getState() {
		return mState;
	}

	public boolean isHideable() {
		return mHideable;
	}

	public boolean onInterceptTouchEvent(CoordinatorLayout parent, V child, MotionEvent event) {
		boolean r4z = true;
		if (!child.isShown()) {
			mIgnoreEvents = true;
			return false;
		} else {
			View scroll;
			int action = MotionEventCompat.getActionMasked(event);
			if (action == 0) {
				reset();
			}
			if (mVelocityTracker == null) {
				mVelocityTracker = VelocityTracker.obtain();
			}
			mVelocityTracker.addMovement(event);
			switch(action) {
			case Glow.ALWAYS:
				int initialX = (int) event.getX();
				mInitialY = (int) event.getY();
				scroll = (View) mNestedScrollingChildRef.get();
				boolean r3z;
				if (scroll == null || !parent.isPointInChildBounds(scroll, initialX, mInitialY)) {
					if (mActivePointerId != -1 || parent.isPointInChildBounds(child, initialX, mInitialY)) {
						r3z = false;
					} else {
						r3z = true;
					}
					mIgnoreEvents = r3z;
				} else {
					mActivePointerId = event.getPointerId(event.getActionIndex());
					mTouchingScrollingChild = true;
					if (mActivePointerId != -1 || parent.isPointInChildBounds(child, initialX, mInitialY)) {
						r3z = false;
					} else {
						r3z = true;
					}
					mIgnoreEvents = r3z;
				}
				break;
			case STATE_DRAGGING:
			case STATE_EXPANDED:
				mTouchingScrollingChild = false;
				mActivePointerId = -1;
				if (mIgnoreEvents) {
					mIgnoreEvents = false;
					return false;
				}
			}
			if (mIgnoreEvents || !mViewDragHelper.shouldInterceptTouchEvent(event)) {
				scroll = mNestedScrollingChildRef.get();
				if (action != STATE_SETTLING || scroll == null || mIgnoreEvents || mState == 1 || parent.isPointInChildBounds(scroll, (int) event.getX(), (int) event.getY()) || Math.abs(((float) mInitialY) - event.getY()) <= ((float) mViewDragHelper.getTouchSlop())) {
					r4z = false;
				} else {
					return r4z;
				}
				return r4z;
			} else {
				return true;
			}
		}
	}

	public boolean onLayoutChild(CoordinatorLayout parent, V child, int layoutDirection) {
		int savedTop;
		int peekHeight;
		if (!ViewCompat.getFitsSystemWindows(parent) || ViewCompat.getFitsSystemWindows(child)) {
			savedTop = child.getTop();
			parent.onLayoutChild(child, layoutDirection);
			mParentHeight = parent.getHeight();
			if (!mPeekHeightAuto) {
				if (mPeekHeightMin != 0) {
					mPeekHeightMin = parent.getResources().getDimensionPixelSize(R.dimen.design_bottom_sheet_peek_height_min);
				}
				peekHeight = Math.max(mPeekHeightMin, mParentHeight - ((parent.getWidth() * 9) / 16));
			} else {
				peekHeight = mPeekHeight;
			}
			mMinOffset = Math.max(0, mParentHeight - child.getHeight());
			mMaxOffset = Math.max(mParentHeight - peekHeight, mMinOffset);
			if (mState != STATE_EXPANDED) {
				ViewCompat.offsetTopAndBottom(child, mMinOffset);
			} else if (!mHideable || mState != 5) {
				if (mState != 4) {
					ViewCompat.offsetTopAndBottom(child, mMaxOffset);
				} else if (mState == 1 || mState == 2) {
					ViewCompat.offsetTopAndBottom(child, savedTop - child.getTop());
				}
			} else {
				ViewCompat.offsetTopAndBottom(child, mParentHeight);
			}
			if (mViewDragHelper != null) {
				mViewDragHelper = ViewDragHelper.create(parent, mDragCallback);
			}
			mViewRef = new WeakReference(child);
			mNestedScrollingChildRef = new WeakReference(findScrollingChild(child));
			return true;
		} else {
			ViewCompat.setFitsSystemWindows(child, true);
			savedTop = child.getTop();
			parent.onLayoutChild(child, layoutDirection);
			mParentHeight = parent.getHeight();
			if (!mPeekHeightAuto) {
				peekHeight = mPeekHeight;
			} else if (mPeekHeightMin != 0) {
				peekHeight = Math.max(mPeekHeightMin, mParentHeight - ((parent.getWidth() * 9) / 16));
			} else {
				mPeekHeightMin = parent.getResources().getDimensionPixelSize(R.dimen.design_bottom_sheet_peek_height_min);
				peekHeight = Math.max(mPeekHeightMin, mParentHeight - ((parent.getWidth() * 9) / 16));
			}
			mMinOffset = Math.max(0, mParentHeight - child.getHeight());
			mMaxOffset = Math.max(mParentHeight - peekHeight, mMinOffset);
			if (mState != STATE_EXPANDED) {
				if (!mHideable || mState != 5) {
					if (mState != 4) {
						if (mState == 1 || mState == 2) {
							ViewCompat.offsetTopAndBottom(child, savedTop - child.getTop());
						}
					} else {
						ViewCompat.offsetTopAndBottom(child, mMaxOffset);
					}
				} else {
					ViewCompat.offsetTopAndBottom(child, mParentHeight);
				}
			} else {
				ViewCompat.offsetTopAndBottom(child, mMinOffset);
			}
			if (mViewDragHelper != null) {
				mViewRef = new WeakReference(child);
				mNestedScrollingChildRef = new WeakReference(findScrollingChild(child));
				return true;
			} else {
				mViewDragHelper = ViewDragHelper.create(parent, mDragCallback);
				mViewRef = new WeakReference(child);
				mNestedScrollingChildRef = new WeakReference(findScrollingChild(child));
				return true;
			}
		}
	}

	public boolean onNestedPreFling(CoordinatorLayout coordinatorLayout, V child, View target, float velocityX, float velocityY) {
		if (target == mNestedScrollingChildRef.get()) {
			if (mState != 3 || super.onNestedPreFling(coordinatorLayout, child, target, velocityX, velocityY)) {
				return true;
			}
		}
		return false;
	}

	public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V child, View target, int dx, int dy, int[] consumed) {
		if (target != ((View) mNestedScrollingChildRef.get())) {
		} else {
			int currentTop = child.getTop();
			int newTop = currentTop - dy;
			if (dy > 0) {
				if (newTop < mMinOffset) {
					consumed[1] = currentTop - mMinOffset;
					ViewCompat.offsetTopAndBottom(child, -consumed[1]);
					setStateInternal(STATE_EXPANDED);
				} else {
					consumed[1] = dy;
					ViewCompat.offsetTopAndBottom(child, -dy);
					setStateInternal(STATE_DRAGGING);
				}
			} else if (dy >= 0 || ViewCompat.canScrollVertically(target, PEEK_HEIGHT_AUTO)) {
				dispatchOnSlide(child.getTop());
				mLastNestedScrollDy = dy;
				mNestedScrolled = true;
			} else if (newTop <= mMaxOffset || mHideable) {
				consumed[1] = dy;
				ViewCompat.offsetTopAndBottom(child, -dy);
				setStateInternal(STATE_DRAGGING);
			} else {
				consumed[1] = currentTop - mMaxOffset;
				ViewCompat.offsetTopAndBottom(child, -consumed[1]);
				setStateInternal(STATE_COLLAPSED);
			}
			dispatchOnSlide(child.getTop());
			mLastNestedScrollDy = dy;
			mNestedScrolled = true;
		}
	}

	public void onRestoreInstanceState(CoordinatorLayout parent, V child, Parcelable state) {
		SavedState ss = (SavedState) state;
		super.onRestoreInstanceState(parent, child, ss.getSuperState());
		if (ss.state == 1 || ss.state == 2) {
			mState = 4;
		} else {
			mState = ss.state;
		}
	}

	public Parcelable onSaveInstanceState(CoordinatorLayout parent, V child) {
		return new SavedState(super.onSaveInstanceState(parent, child), mState);
	}

	public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V child, View directTargetChild, View target, int nestedScrollAxes) {
		boolean r0z = false;
		mLastNestedScrollDy = 0;
		mNestedScrolled = false;
		if ((nestedScrollAxes & 2) != 0) {
			r0z = true;
		}
		return r0z;
	}

	public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V child, View target) {
		if (child.getTop() == mMinOffset) {
			setStateInternal(STATE_EXPANDED);
		} else if (target != mNestedScrollingChildRef.get() || !mNestedScrolled) {
		} else {
			int top;
			int targetState;
			if (mLastNestedScrollDy > 0) {
				top = mMinOffset;
				targetState = STATE_EXPANDED;
			} else if (!mHideable || !shouldHide(child, getYVelocity())) {
				if (mLastNestedScrollDy == 0) {
					int currentTop = child.getTop();
					if (Math.abs(currentTop - mMinOffset) < Math.abs(currentTop - mMaxOffset)) {
						top = mMinOffset;
						targetState = STATE_EXPANDED;
					} else {
						top = mMaxOffset;
						targetState = STATE_COLLAPSED;
					}
				} else {
					top = mMaxOffset;
					targetState = STATE_COLLAPSED;
				}
			} else {
				top = mParentHeight;
				targetState = STATE_HIDDEN;
			}
			if (mViewDragHelper.smoothSlideViewTo(child, child.getLeft(), top)) {
				setStateInternal(STATE_SETTLING);
				ViewCompat.postOnAnimation(child, new SettleRunnable(this, child, targetState));
			} else {
				setStateInternal(targetState);
			}
			mNestedScrolled = false;
		}
	}

	public boolean onTouchEvent(CoordinatorLayout parent, V child, MotionEvent event) {
		if (!child.isShown()) {
			return false;
		} else {
			int action = MotionEventCompat.getActionMasked(event);
			if (mState != 1 || action != 0) {
				mViewDragHelper.processTouchEvent(event);
				if (action == 0) {
					reset();
				}
				if (mVelocityTracker == null) {
					mVelocityTracker = VelocityTracker.obtain();
				}
				mVelocityTracker.addMovement(event);
				if (action != STATE_SETTLING || mIgnoreEvents || Math.abs(((float) mInitialY) - event.getY()) <= ((float) mViewDragHelper.getTouchSlop())) {
					if (!mIgnoreEvents) {
						return false;
					} else {
						return true;
					}
				} else {
					mViewDragHelper.captureChildView(child, event.getPointerId(event.getActionIndex()));
					if (!mIgnoreEvents) {
						return true;
					} else {
						return false;
					}
				}
			} else {
				return true;
			}
		}
	}

	public void setBottomSheetCallback(BottomSheetCallback callback) {
		mCallback = callback;
	}

	public void setHideable(boolean hideable) {
		mHideable = hideable;
	}

	public final void setPeekHeight(int peekHeight) {
		boolean layout = false;
		if (peekHeight == -1) {
			if (!mPeekHeightAuto) {
				mPeekHeightAuto = true;
				layout = true;
			}
		} else if (mPeekHeightAuto || mPeekHeight != peekHeight) {
			mPeekHeightAuto = false;
			mPeekHeight = Math.max(0, peekHeight);
			mMaxOffset = mParentHeight - peekHeight;
			layout = true;
		}
		if (!layout || mState != 4 || mViewRef == null) {
		} else {
			V view = (View) mViewRef.get();
			if (view != null) {
				view.requestLayout();
			}
		}
	}

	public void setSkipCollapsed(boolean skipCollapsed) {
		mSkipCollapsed = skipCollapsed;
	}

	public final void setState(int state) {
		if (state == mState) {
		} else if (mViewRef == null) {
			if (state == 4 || state == 3) {
				mState = state;
			} else if (!mHideable || state != 5) {
			} else {
				mState = state;
			}
		} else {
			V child = (View) mViewRef.get();
			if (child != null) {
				ViewParent parent = child.getParent();
				if (parent == null || !parent.isLayoutRequested() || !ViewCompat.isAttachedToWindow(child)) {
					startSettlingAnimation(child, state);
				} else {
					child.post(new AnonymousClass_1(this, child, state));
				}
			}
		}
	}

	void setStateInternal(int state) {
		if (mState == state) {
		} else {
			mState = state;
			View bottomSheet = (View) mViewRef.get();
			if (bottomSheet == null || mCallback == null) {
			} else {
				mCallback.onStateChanged(bottomSheet, state);
			}
		}
	}

	boolean shouldHide(View child, float yvel) {
		if (mSkipCollapsed) {
			return true;
		} else if (child.getTop() < mMaxOffset) {
			return false;
		} else if (Math.abs((((float) child.getTop()) + (0.1f * yvel)) - ((float) mMaxOffset)) / ((float) mPeekHeight) <= 0.5f) {
			return false;
		} else {
			return true;
		}
	}

	void startSettlingAnimation(View child, int state) {
		int top;
		if (state == 4) {
			top = mMaxOffset;
		} else if (state == 3) {
			top = mMinOffset;
		} else if (!mHideable || state != 5) {
			throw new IllegalArgumentException("Illegal state argument: " + state);
		} else {
			top = mParentHeight;
		}
		setStateInternal(STATE_SETTLING);
		if (mViewDragHelper.smoothSlideViewTo(child, child.getLeft(), top)) {
			ViewCompat.postOnAnimation(child, new SettleRunnable(this, child, state));
		}
	}
}
