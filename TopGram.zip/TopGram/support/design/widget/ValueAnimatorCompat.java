package android.support.design.widget;

import android.support.annotation.NonNull;
import android.support.design.widget.ValueAnimatorCompat.Impl.AnimatorListenerProxy;
import android.support.design.widget.ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy;
import android.view.animation.Interpolator;

class ValueAnimatorCompat {
	private final Impl mImpl;

	static interface AnimatorUpdateListener {
		public void onAnimationUpdate(ValueAnimatorCompat r1_ValueAnimatorCompat);
	}

	static interface AnimatorListener {
		public void onAnimationCancel(ValueAnimatorCompat r1_ValueAnimatorCompat);

		public void onAnimationEnd(ValueAnimatorCompat r1_ValueAnimatorCompat);

		public void onAnimationStart(ValueAnimatorCompat r1_ValueAnimatorCompat);
	}

	static class AnimatorListenerAdapter implements ValueAnimatorCompat.AnimatorListener {
		AnimatorListenerAdapter() {
			super();
		}

		public void onAnimationCancel(ValueAnimatorCompat animator) {
		}

		public void onAnimationEnd(ValueAnimatorCompat animator) {
		}

		public void onAnimationStart(ValueAnimatorCompat animator) {
		}
	}

	class AnonymousClass_1 implements AnimatorUpdateListenerProxy {
		final /* synthetic */ ValueAnimatorCompat this$0;
		final /* synthetic */ ValueAnimatorCompat.AnimatorUpdateListener val$updateListener;

		AnonymousClass_1(ValueAnimatorCompat this$0, ValueAnimatorCompat.AnimatorUpdateListener r2_ValueAnimatorCompat_AnimatorUpdateListener) {
			super();
			this.this$0 = this$0;
			val$updateListener = r2_ValueAnimatorCompat_AnimatorUpdateListener;
		}

		public void onAnimationUpdate() {
			val$updateListener.onAnimationUpdate(this$0);
		}
	}

	class AnonymousClass_2 implements AnimatorListenerProxy {
		final /* synthetic */ ValueAnimatorCompat this$0;
		final /* synthetic */ ValueAnimatorCompat.AnimatorListener val$listener;

		AnonymousClass_2(ValueAnimatorCompat this$0, ValueAnimatorCompat.AnimatorListener r2_ValueAnimatorCompat_AnimatorListener) {
			super();
			this.this$0 = this$0;
			val$listener = r2_ValueAnimatorCompat_AnimatorListener;
		}

		public void onAnimationCancel() {
			val$listener.onAnimationCancel(this$0);
		}

		public void onAnimationEnd() {
			val$listener.onAnimationEnd(this$0);
		}

		public void onAnimationStart() {
			val$listener.onAnimationStart(this$0);
		}
	}

	static interface Creator {
		@NonNull
		public ValueAnimatorCompat createAnimator();
	}

	static abstract class Impl {
		static interface AnimatorUpdateListenerProxy {
			public void onAnimationUpdate();
		}

		static interface AnimatorListenerProxy {
			public void onAnimationCancel();

			public void onAnimationEnd();

			public void onAnimationStart();
		}


		Impl() {
			super();
		}

		abstract void addListener(AnimatorListenerProxy r1_AnimatorListenerProxy);

		abstract void addUpdateListener(AnimatorUpdateListenerProxy r1_AnimatorUpdateListenerProxy);

		abstract void cancel();

		abstract void end();

		abstract float getAnimatedFloatValue();

		abstract float getAnimatedFraction();

		abstract int getAnimatedIntValue();

		abstract long getDuration();

		abstract boolean isRunning();

		abstract void setDuration(long r1j);

		abstract void setFloatValues(float r1f, float r2f);

		abstract void setIntValues(int r1i, int r2i);

		abstract void setInterpolator(Interpolator r1_Interpolator);

		abstract void start();
	}


	ValueAnimatorCompat(Impl impl) {
		super();
		mImpl = impl;
	}

	public void addListener(AnimatorListener listener) {
		if (listener != null) {
			mImpl.addListener(new AnonymousClass_2(this, listener));
		} else {
			mImpl.addListener(null);
		}
	}

	public void addUpdateListener(AnimatorUpdateListener updateListener) {
		if (updateListener != null) {
			mImpl.addUpdateListener(new AnonymousClass_1(this, updateListener));
		} else {
			mImpl.addUpdateListener(null);
		}
	}

	public void cancel() {
		mImpl.cancel();
	}

	public void end() {
		mImpl.end();
	}

	public float getAnimatedFloatValue() {
		return mImpl.getAnimatedFloatValue();
	}

	public float getAnimatedFraction() {
		return mImpl.getAnimatedFraction();
	}

	public int getAnimatedIntValue() {
		return mImpl.getAnimatedIntValue();
	}

	public long getDuration() {
		return mImpl.getDuration();
	}

	public boolean isRunning() {
		return mImpl.isRunning();
	}

	public void setDuration(long duration) {
		mImpl.setDuration(duration);
	}

	public void setFloatValues(float from, float to) {
		mImpl.setFloatValues(from, to);
	}

	public void setIntValues(int from, int to) {
		mImpl.setIntValues(from, to);
	}

	public void setInterpolator(Interpolator interpolator) {
		mImpl.setInterpolator(interpolator);
	}

	public void start() {
		mImpl.start();
	}
}
