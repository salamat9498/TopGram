package android.support.design.widget;

import android.animation.AnimatorInflater;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.support.design.R;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;

class ViewUtilsLollipop {
	private static final int[] STATE_LIST_ANIM_ATTRS;

	static {
		int[] r0_int_A = new int[1];
		r0_int_A[0] = 16843848;
		STATE_LIST_ANIM_ATTRS = r0_int_A;
	}

	ViewUtilsLollipop() {
		super();
	}

	static void setBoundsViewOutlineProvider(View view) {
		view.setOutlineProvider(ViewOutlineProvider.BOUNDS);
	}

	static void setDefaultAppBarLayoutStateListAnimator(View view, float elevation) {
		int dur = view.getResources().getInteger(R.integer.app_bar_elevation_anim_duration);
		StateListAnimator sla = new StateListAnimator();
		int[] r2_int_A = new int[3];
		r2_int_A[0] = 16842766;
		r2_int_A[1] = R.attr.state_collapsible;
		r2_int_A[2] = -R.attr.state_collapsed;
		float[] r4_float_A = new float[1];
		r4_float_A[0] = 0.0f;
		sla.addState(r2_int_A, ObjectAnimator.ofFloat(view, "elevation", r4_float_A).setDuration((long) dur));
		r2_int_A = new int[1];
		r2_int_A[0] = 16842766;
		r4_float_A = new float[1];
		r4_float_A[0] = elevation;
		sla.addState(r2_int_A, ObjectAnimator.ofFloat(view, "elevation", r4_float_A).setDuration((long) dur));
		r4_float_A = new float[1];
		r4_float_A[0] = 0.0f;
		sla.addState(new int[0], ObjectAnimator.ofFloat(view, "elevation", r4_float_A).setDuration(0));
		view.setStateListAnimator(sla);
	}

	static void setStateListAnimatorFromAttrs(View view, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
		Context context = view.getContext();
		TypedArray a = context.obtainStyledAttributes(attrs, STATE_LIST_ANIM_ATTRS, defStyleAttr, defStyleRes);
		int r3i = 0;
		if (a.hasValue(r3i)) {
			view.setStateListAnimator(AnimatorInflater.loadStateListAnimator(context, a.getResourceId(0, 0)));
		}
		a.recycle();
	}
}
