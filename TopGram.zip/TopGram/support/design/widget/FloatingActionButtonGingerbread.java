package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.R;
import android.support.design.widget.AnimationUtils.AnimationListenerAdapter;
import android.support.design.widget.FloatingActionButtonImpl.InternalVisibilityChangedListener;
import android.support.design.widget.ValueAnimatorCompat.AnimatorListenerAdapter;
import android.support.design.widget.ValueAnimatorCompat.AnimatorUpdateListener;
import android.support.design.widget.ValueAnimatorCompat.Creator;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import org.telegram.tgnet.TLRPC;

class FloatingActionButtonGingerbread extends FloatingActionButtonImpl {
	ShadowDrawableWrapper mShadowDrawable;
	private final StateListAnimator mStateListAnimator;

	class AnonymousClass_1 extends AnimationListenerAdapter {
		final /* synthetic */ FloatingActionButtonGingerbread this$0;
		final /* synthetic */ boolean val$fromUser;
		final /* synthetic */ InternalVisibilityChangedListener val$listener;

		AnonymousClass_1(FloatingActionButtonGingerbread this$0, boolean r2z, InternalVisibilityChangedListener r3_InternalVisibilityChangedListener) {
			super();
			this.this$0 = this$0;
			val$fromUser = r2z;
			val$listener = r3_InternalVisibilityChangedListener;
		}

		public void onAnimationEnd(Animation animation) {
			this$0.mAnimState = 0;
			this$0.mView.internalSetVisibility(TLRPC.USER_FLAG_USERNAME, val$fromUser);
			if (val$listener != null) {
				val$listener.onHidden();
			}
		}
	}

	class AnonymousClass_2 extends AnimationListenerAdapter {
		final /* synthetic */ FloatingActionButtonGingerbread this$0;
		final /* synthetic */ InternalVisibilityChangedListener val$listener;

		AnonymousClass_2(FloatingActionButtonGingerbread this$0, InternalVisibilityChangedListener r2_InternalVisibilityChangedListener) {
			super();
			this.this$0 = this$0;
			val$listener = r2_InternalVisibilityChangedListener;
		}

		public void onAnimationEnd(Animation animation) {
			this$0.mAnimState = 0;
			if (val$listener != null) {
				val$listener.onShown();
			}
		}
	}

	private abstract class ShadowAnimatorImpl extends AnimatorListenerAdapter implements AnimatorUpdateListener {
		private float mShadowSizeEnd;
		private float mShadowSizeStart;
		private boolean mValidValues;
		final /* synthetic */ FloatingActionButtonGingerbread this$0;

		private ShadowAnimatorImpl(FloatingActionButtonGingerbread r1_FloatingActionButtonGingerbread) {
			super();
			this$0 = r1_FloatingActionButtonGingerbread;
		}

		/* synthetic */ ShadowAnimatorImpl(FloatingActionButtonGingerbread x0, FloatingActionButtonGingerbread.AnonymousClass_1 x1) {
			this(x0);
		}

		protected abstract float getTargetShadowSize();

		public void onAnimationEnd(ValueAnimatorCompat animator) {
			this$0.mShadowDrawable.setShadowSize(mShadowSizeEnd);
			mValidValues = false;
		}

		public void onAnimationUpdate(ValueAnimatorCompat animator) {
			if (!mValidValues) {
				mShadowSizeStart = this$0.mShadowDrawable.getShadowSize();
				mShadowSizeEnd = getTargetShadowSize();
				mValidValues = true;
			}
			this$0.mShadowDrawable.setShadowSize(mShadowSizeStart + ((mShadowSizeEnd - mShadowSizeStart) * animator.getAnimatedFraction()));
		}
	}

	private class DisabledElevationAnimation extends FloatingActionButtonGingerbread.ShadowAnimatorImpl {
		final /* synthetic */ FloatingActionButtonGingerbread this$0;

		DisabledElevationAnimation(FloatingActionButtonGingerbread r2_FloatingActionButtonGingerbread) {
			super(r2_FloatingActionButtonGingerbread, null);
			this$0 = r2_FloatingActionButtonGingerbread;
		}

		protected float getTargetShadowSize() {
			return BitmapDescriptorFactory.HUE_RED;
		}
	}

	private class ElevateToTranslationZAnimation extends FloatingActionButtonGingerbread.ShadowAnimatorImpl {
		final /* synthetic */ FloatingActionButtonGingerbread this$0;

		ElevateToTranslationZAnimation(FloatingActionButtonGingerbread r2_FloatingActionButtonGingerbread) {
			super(r2_FloatingActionButtonGingerbread, null);
			this$0 = r2_FloatingActionButtonGingerbread;
		}

		protected float getTargetShadowSize() {
			return this$0.mElevation + this$0.mPressedTranslationZ;
		}
	}

	private class ResetElevationAnimation extends FloatingActionButtonGingerbread.ShadowAnimatorImpl {
		final /* synthetic */ FloatingActionButtonGingerbread this$0;

		ResetElevationAnimation(FloatingActionButtonGingerbread r2_FloatingActionButtonGingerbread) {
			super(r2_FloatingActionButtonGingerbread, null);
			this$0 = r2_FloatingActionButtonGingerbread;
		}

		protected float getTargetShadowSize() {
			return this$0.mElevation;
		}
	}


	FloatingActionButtonGingerbread(VisibilityAwareImageButton view, ShadowViewDelegate shadowViewDelegate, Creator animatorCreator) {
		super(view, shadowViewDelegate, animatorCreator);
		mStateListAnimator = new StateListAnimator();
		mStateListAnimator.addState(PRESSED_ENABLED_STATE_SET, createAnimator(new ElevateToTranslationZAnimation(this)));
		mStateListAnimator.addState(FOCUSED_ENABLED_STATE_SET, createAnimator(new ElevateToTranslationZAnimation(this)));
		mStateListAnimator.addState(ENABLED_STATE_SET, createAnimator(new ResetElevationAnimation(this)));
		mStateListAnimator.addState(EMPTY_STATE_SET, createAnimator(new DisabledElevationAnimation(this)));
	}

	private ValueAnimatorCompat createAnimator(@NonNull ShadowAnimatorImpl impl) {
		ValueAnimatorCompat animator = mAnimatorCreator.createAnimator();
		animator.setInterpolator(ANIM_INTERPOLATOR);
		animator.setDuration(100);
		animator.addListener(impl);
		animator.addUpdateListener(impl);
		animator.setFloatValues(BitmapDescriptorFactory.HUE_RED, 1.0f);
		return animator;
	}

	private static ColorStateList createColorStateList(int selectedColor) {
		int[][] states = new int[3][];
		int[] colors = new int[3];
		states[0] = FOCUSED_ENABLED_STATE_SET;
		colors[0] = selectedColor;
		int i = 0 + 1;
		states[i] = PRESSED_ENABLED_STATE_SET;
		colors[i] = selectedColor;
		i++;
		states[i] = new int[0];
		colors[i] = 0;
		return new ColorStateList(states, colors);
	}

	float getElevation() {
		return mElevation;
	}

	void getPadding(Rect rect) {
		mShadowDrawable.getPadding(rect);
	}

	void hide(@Nullable InternalVisibilityChangedListener listener, boolean fromUser) {
		if (isOrWillBeHidden()) {
		} else {
			mAnimState = 1;
			Animation anim = AnimationUtils.loadAnimation(mView.getContext(), R.anim.design_fab_out);
			anim.setInterpolator(AnimationUtils.FAST_OUT_LINEAR_IN_INTERPOLATOR);
			anim.setDuration(200);
			anim.setAnimationListener(new AnonymousClass_1(this, fromUser, listener));
			mView.startAnimation(anim);
		}
	}

	void jumpDrawableToCurrentState() {
		mStateListAnimator.jumpToCurrentState();
	}

	void onCompatShadowChanged() {
	}

	void onDrawableStateChanged(int[] state) {
		mStateListAnimator.setState(state);
	}

	void onElevationsChanged(float elevation, float pressedTranslationZ) {
		if (mShadowDrawable != null) {
			mShadowDrawable.setShadowSize(elevation, mPressedTranslationZ + elevation);
			updatePadding();
		}
	}

	void setBackgroundDrawable(ColorStateList backgroundTint, Mode backgroundTintMode, int rippleColor, int borderWidth) {
		Drawable[] layers;
		mShapeDrawable = DrawableCompat.wrap(createShapeDrawable());
		DrawableCompat.setTintList(mShapeDrawable, backgroundTint);
		if (backgroundTintMode != null) {
			DrawableCompat.setTintMode(mShapeDrawable, backgroundTintMode);
		}
		mRippleDrawable = DrawableCompat.wrap(createShapeDrawable());
		DrawableCompat.setTintList(mRippleDrawable, createColorStateList(rippleColor));
		if (borderWidth > 0) {
			mBorderDrawable = createBorderDrawable(borderWidth, backgroundTint);
			layers = new Drawable[3];
			layers[0] = mBorderDrawable;
			layers[1] = mShapeDrawable;
			layers[2] = mRippleDrawable;
		} else {
			mBorderDrawable = null;
			layers = new Drawable[2];
			layers[0] = mShapeDrawable;
			layers[1] = mRippleDrawable;
		}
		mContentBackground = new LayerDrawable(layers);
		mShadowDrawable = new ShadowDrawableWrapper(mView.getResources(), mContentBackground, mShadowViewDelegate.getRadius(), mElevation, mElevation + mPressedTranslationZ);
		mShadowDrawable.setAddPaddingForCorners(false);
		mShadowViewDelegate.setBackgroundDrawable(mShadowDrawable);
	}

	void setBackgroundTintList(ColorStateList tint) {
		if (mShapeDrawable != null) {
			DrawableCompat.setTintList(mShapeDrawable, tint);
		}
		if (mBorderDrawable != null) {
			mBorderDrawable.setBorderTint(tint);
		}
	}

	void setBackgroundTintMode(Mode tintMode) {
		if (mShapeDrawable != null) {
			DrawableCompat.setTintMode(mShapeDrawable, tintMode);
		}
	}

	void setRippleColor(int rippleColor) {
		if (mRippleDrawable != null) {
			DrawableCompat.setTintList(mRippleDrawable, createColorStateList(rippleColor));
		}
	}

	void show(@Nullable InternalVisibilityChangedListener listener, boolean fromUser) {
		if (isOrWillBeShown()) {
		} else {
			mAnimState = 2;
			mView.internalSetVisibility(0, fromUser);
			Animation anim = AnimationUtils.loadAnimation(mView.getContext(), R.anim.design_fab_in);
			anim.setDuration(200);
			anim.setInterpolator(AnimationUtils.LINEAR_OUT_SLOW_IN_INTERPOLATOR);
			anim.setAnimationListener(new AnonymousClass_2(this, listener));
			mView.startAnimation(anim);
		}
	}
}
