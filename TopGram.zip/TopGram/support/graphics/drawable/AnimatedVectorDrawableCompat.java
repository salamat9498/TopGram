package android.support.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.util.ArrayMap;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@TargetApi(21)
public class AnimatedVectorDrawableCompat extends VectorDrawableCommon implements Animatable {
	private static final String ANIMATED_VECTOR = "animated-vector";
	private static final boolean DBG_ANIMATION_VECTOR_DRAWABLE = false;
	private static final String LOGTAG = "AnimatedVDCompat";
	private static final String TARGET = "target";
	private AnimatedVectorDrawableCompatState mAnimatedVectorState;
	private ArgbEvaluator mArgbEvaluator;
	AnimatedVectorDrawableDelegateState mCachedConstantStateDelegate;
	final Callback mCallback;
	private Context mContext;

	class AnonymousClass_1 implements Callback {
		final /* synthetic */ AnimatedVectorDrawableCompat this$0;

		AnonymousClass_1(AnimatedVectorDrawableCompat this$0) {
			super();
			this.this$0 = this$0;
		}

		public void invalidateDrawable(Drawable who) {
			this$0.invalidateSelf();
		}

		public void scheduleDrawable(Drawable who, Runnable what, long when) {
			this$0.scheduleSelf(what, when);
		}

		public void unscheduleDrawable(Drawable who, Runnable what) {
			this$0.unscheduleSelf(what);
		}
	}

	private static class AnimatedVectorDrawableCompatState extends ConstantState {
		ArrayList<Animator> mAnimators;
		int mChangingConfigurations;
		ArrayMap<Animator, String> mTargetNameMap;
		VectorDrawableCompat mVectorDrawable;

		public AnimatedVectorDrawableCompatState(Context context, AnimatedVectorDrawableCompat.AnimatedVectorDrawableCompatState copy, Callback owner, Resources res) {
			super();
			if (copy != null) {
				mChangingConfigurations = copy.mChangingConfigurations;
				if (copy.mVectorDrawable != null) {
					ConstantState cs = copy.mVectorDrawable.getConstantState();
					if (res != null) {
						mVectorDrawable = (VectorDrawableCompat) cs.newDrawable(res);
					} else {
						mVectorDrawable = (VectorDrawableCompat) cs.newDrawable();
					}
					mVectorDrawable = (VectorDrawableCompat) mVectorDrawable.mutate();
					mVectorDrawable.setCallback(owner);
					mVectorDrawable.setBounds(copy.mVectorDrawable.getBounds());
					mVectorDrawable.setAllowCaching(DBG_ANIMATION_VECTOR_DRAWABLE);
				}
				if (copy.mAnimators != null) {
					int numAnimators = copy.mAnimators.size();
					mAnimators = new ArrayList(numAnimators);
					mTargetNameMap = new ArrayMap(numAnimators);
					int i = 0;
					while (i < numAnimators) {
						Animator anim = (Animator) copy.mAnimators.get(i);
						Animator animClone = anim.clone();
						String targetName = (String) copy.mTargetNameMap.get(anim);
						animClone.setTarget(mVectorDrawable.getTargetByName(targetName));
						mAnimators.add(animClone);
						mTargetNameMap.put(animClone, targetName);
						i++;
					}
				}
			}
		}

		public int getChangingConfigurations() {
			return mChangingConfigurations;
		}

		public Drawable newDrawable() {
			throw new IllegalStateException("No constant state support for SDK < 23.");
		}

		public Drawable newDrawable(Resources res) {
			throw new IllegalStateException("No constant state support for SDK < 23.");
		}
	}

	private static class AnimatedVectorDrawableDelegateState extends ConstantState {
		private final ConstantState mDelegateState;

		public AnimatedVectorDrawableDelegateState(ConstantState state) {
			super();
			mDelegateState = state;
		}

		public boolean canApplyTheme() {
			return mDelegateState.canApplyTheme();
		}

		public int getChangingConfigurations() {
			return mDelegateState.getChangingConfigurations();
		}

		public Drawable newDrawable() {
			Drawable drawableCompat = new AnimatedVectorDrawableCompat();
			drawableCompat.mDelegateDrawable = mDelegateState.newDrawable();
			drawableCompat.mDelegateDrawable.setCallback(drawableCompat.mCallback);
			return drawableCompat;
		}

		public Drawable newDrawable(Resources res) {
			Drawable drawableCompat = new AnimatedVectorDrawableCompat();
			drawableCompat.mDelegateDrawable = mDelegateState.newDrawable(res);
			drawableCompat.mDelegateDrawable.setCallback(drawableCompat.mCallback);
			return drawableCompat;
		}

		public Drawable newDrawable(Resources res, Theme theme) {
			Drawable drawableCompat = new AnimatedVectorDrawableCompat();
			drawableCompat.mDelegateDrawable = mDelegateState.newDrawable(res, theme);
			drawableCompat.mDelegateDrawable.setCallback(drawableCompat.mCallback);
			return drawableCompat;
		}
	}


	AnimatedVectorDrawableCompat() {
		this(null, null, null);
	}

	private AnimatedVectorDrawableCompat(@Nullable Context context) {
		this(context, null, null);
	}

	private AnimatedVectorDrawableCompat(@Nullable Context context, @Nullable AnimatedVectorDrawableCompatState state, @Nullable Resources res) {
		super();
		mArgbEvaluator = null;
		mCallback = new AnonymousClass_1(this);
		mContext = context;
		if (state != null) {
			mAnimatedVectorState = state;
		} else {
			mAnimatedVectorState = new AnimatedVectorDrawableCompatState(context, state, mCallback, res);
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	@android.support.annotation.Nullable
	public static android.support.graphics.drawable.AnimatedVectorDrawableCompat create(@android.support.annotation.NonNull android.content.Context r9_context, @android.support.annotation.DrawableRes int r10_resId) {
		r8 = 2;
		r6 = android.os.Build.VERSION.SDK_INT;
		r7 = 23;
		if (r6 < r7) goto L_0x002f;
	L_0x0007:
		r1 = new android.support.graphics.drawable.AnimatedVectorDrawableCompat;
		r1.<init>(r9_context);
		r6 = r9_context.getResources();
		r7 = r9_context.getTheme();
		r6 = android.support.v4.content.res.ResourcesCompat.getDrawable(r6, r10_resId, r7);
		r1_drawable.mDelegateDrawable = r6;
		r6 = r1_drawable.mDelegateDrawable;
		r7 = r1_drawable.mCallback;
		r6.setCallback(r7);
		r6 = new android.support.graphics.drawable.AnimatedVectorDrawableCompat$AnimatedVectorDrawableDelegateState;
		r7 = r1_drawable.mDelegateDrawable;
		r7 = r7.getConstantState();
		r6.<init>(r7);
		r1_drawable.mCachedConstantStateDelegate = r6;
	L_0x002e:
		return r1_drawable;
	L_0x002f:
		r4 = r9_context.getResources();
		r3 = r4_resources.getXml(r10_resId);	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
		r0_attrs = android.util.Xml.asAttributeSet(r3_parser);	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
	L_0x003b:
		r5 = r3_parser.next();	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
		if (r5_type == r8) goto L_0x0044;
	L_0x0041:
		r6 = 1;
		if (r5_type != r6) goto L_0x003b;
	L_0x0044:
		if (r5_type == r8) goto L_0x0058;
	L_0x0046:
		r6 = new org.xmlpull.v1.XmlPullParserException;	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
		r7 = "No start tag found";
		r6.<init>(r7);	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
		throw r6;	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
	L_0x004e:
		r2 = move-exception;
		r6 = "AnimatedVDCompat";
		r7 = "parser error";
		android.util.Log.e(r6, r7, r2_e);
	L_0x0056:
		r1 = 0;
		goto L_0x002e;
	L_0x0058:
		r6 = r9_context.getResources();	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
		r7 = r9_context.getTheme();	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
		r1 = createFromXmlInner(r9_context, r6, r3_parser, r0_attrs, r7);	 //Catch:{ XmlPullParserException -> 0x004e, IOException -> 0x0065 }
		goto L_0x002e;
	L_0x0065:
		r2_e = move-exception;
		r6 = "AnimatedVDCompat";
		r7 = "parser error";
		android.util.Log.e(r6, r7, r2);
		goto L_0x0056;
	}
	*/
	@Nullable
	public static AnimatedVectorDrawableCompat create(@NonNull Context context, @DrawableRes int resId) {
		if (VERSION.SDK_INT >= 23) {
			AnimatedVectorDrawableCompat drawable = new AnimatedVectorDrawableCompat(context);
			drawable.mDelegateDrawable = ResourcesCompat.getDrawable(context.getResources(), resId, context.getTheme());
			drawable.mDelegateDrawable.setCallback(drawable.mCallback);
			drawable.mCachedConstantStateDelegate = new AnimatedVectorDrawableDelegateState(drawable.mDelegateDrawable.getConstantState());
			return drawable;
		} else {
			XmlPullParser parser;
			AttributeSet attrs;
			int type;
			Resources resources = context.getResources();
			try {
				parser = resources.getXml(resId);
				attrs = Xml.asAttributeSet(parser);
				do {
					type = parser.next();
					if (type != 2) {
					}
				} while (type != 1);
				if (type != 2) {
					throw new XmlPullParserException("No start tag found");
				} else {
					return createFromXmlInner(context, context.getResources(), parser, attrs, context.getTheme());
				}
			} catch (XmlPullParserException e) {
				Log.e(LOGTAG, "parser error", e);
			} catch (IOException e_2) {
				Log.e(LOGTAG, "parser error", e_2);
			}
		}
	}

	public static AnimatedVectorDrawableCompat createFromXmlInner(Context context, Resources r, XmlPullParser parser, AttributeSet attrs, Theme theme) throws XmlPullParserException, IOException {
		AnimatedVectorDrawableCompat drawable = new AnimatedVectorDrawableCompat(context);
		drawable.inflate(r, parser, attrs, theme);
		return drawable;
	}

	private boolean isStarted() {
		ArrayList<Animator> animators = mAnimatedVectorState.mAnimators;
		if (animators == null) {
			return DBG_ANIMATION_VECTOR_DRAWABLE;
		} else {
			int i = 0;
			while (i < animators.size()) {
				if (((Animator) animators.get(i)).isRunning()) {
					return true;
				} else {
					i++;
				}
			}
			return DBG_ANIMATION_VECTOR_DRAWABLE;
		}
	}

	static TypedArray obtainAttributes(Resources res, Theme theme, AttributeSet set, int[] attrs) {
		int r0i = 0;
		if (theme == null) {
			return res.obtainAttributes(set, attrs);
		} else {
			return theme.obtainStyledAttributes(set, attrs, r0i, r0i);
		}
	}

	private void setupAnimatorsForTarget(String name, Animator animator) {
		animator.setTarget(mAnimatedVectorState.mVectorDrawable.getTargetByName(name));
		if (VERSION.SDK_INT < 21) {
			setupColorAnimator(animator);
		}
		if (mAnimatedVectorState.mAnimators == null) {
			mAnimatedVectorState.mAnimators = new ArrayList();
			mAnimatedVectorState.mTargetNameMap = new ArrayMap();
		}
		mAnimatedVectorState.mAnimators.add(animator);
		mAnimatedVectorState.mTargetNameMap.put(animator, name);
	}

	private void setupColorAnimator(Animator animator) {
		if (animator instanceof AnimatorSet) {
			List<Animator> childAnimators = ((AnimatorSet) animator).getChildAnimations();
			if (childAnimators != null) {
				int i = 0;
				while (i < childAnimators.size()) {
					setupColorAnimator((Animator) childAnimators.get(i));
					i++;
				}
			}
		}
		if (animator instanceof ObjectAnimator) {
			ObjectAnimator objectAnim = (ObjectAnimator) animator;
			String propertyName = objectAnim.getPropertyName();
			if ("fillColor".equals(propertyName) || "strokeColor".equals(propertyName)) {
				if (mArgbEvaluator == null) {
					mArgbEvaluator = new ArgbEvaluator();
				}
				objectAnim.setEvaluator(mArgbEvaluator);
			}
		}
	}

	public void applyTheme(Theme t) {
		if (mDelegateDrawable != null) {
			DrawableCompat.applyTheme(mDelegateDrawable, t);
		}
	}

	public boolean canApplyTheme() {
		if (mDelegateDrawable != null) {
			return DrawableCompat.canApplyTheme(mDelegateDrawable);
		} else {
			return DBG_ANIMATION_VECTOR_DRAWABLE;
		}
	}

	public /* bridge */ /* synthetic */ void clearColorFilter() {
		super.clearColorFilter();
	}

	public void draw(Canvas canvas) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.draw(canvas);
		} else {
			mAnimatedVectorState.mVectorDrawable.draw(canvas);
			if (isStarted()) {
				invalidateSelf();
			}
		}
	}

	public int getAlpha() {
		if (mDelegateDrawable != null) {
			return DrawableCompat.getAlpha(mDelegateDrawable);
		} else {
			return mAnimatedVectorState.mVectorDrawable.getAlpha();
		}
	}

	public int getChangingConfigurations() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getChangingConfigurations();
		} else {
			return super.getChangingConfigurations() | mAnimatedVectorState.mChangingConfigurations;
		}
	}

	public /* bridge */ /* synthetic */ ColorFilter getColorFilter() {
		return super.getColorFilter();
	}

	public ConstantState getConstantState() {
		if (mDelegateDrawable != null) {
			return new AnimatedVectorDrawableDelegateState(mDelegateDrawable.getConstantState());
		} else {
			return null;
		}
	}

	public /* bridge */ /* synthetic */ Drawable getCurrent() {
		return super.getCurrent();
	}

	public int getIntrinsicHeight() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getIntrinsicHeight();
		} else {
			return mAnimatedVectorState.mVectorDrawable.getIntrinsicHeight();
		}
	}

	public int getIntrinsicWidth() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getIntrinsicWidth();
		} else {
			return mAnimatedVectorState.mVectorDrawable.getIntrinsicWidth();
		}
	}

	public /* bridge */ /* synthetic */ int getLayoutDirection() {
		return super.getLayoutDirection();
	}

	public /* bridge */ /* synthetic */ int getMinimumHeight() {
		return super.getMinimumHeight();
	}

	public /* bridge */ /* synthetic */ int getMinimumWidth() {
		return super.getMinimumWidth();
	}

	public int getOpacity() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getOpacity();
		} else {
			return mAnimatedVectorState.mVectorDrawable.getOpacity();
		}
	}

	public /* bridge */ /* synthetic */ boolean getPadding(Rect x0) {
		return super.getPadding(x0);
	}

	public /* bridge */ /* synthetic */ int[] getState() {
		return super.getState();
	}

	public /* bridge */ /* synthetic */ Region getTransparentRegion() {
		return super.getTransparentRegion();
	}

	public void inflate(Resources res, XmlPullParser parser, AttributeSet attrs) throws XmlPullParserException, IOException {
		inflate(res, parser, attrs, null);
	}

	public void inflate(Resources res, XmlPullParser parser, AttributeSet attrs, Theme theme) throws XmlPullParserException, IOException {
		if (mDelegateDrawable != null) {
			DrawableCompat.inflate(mDelegateDrawable, res, parser, attrs, theme);
		} else {
			int eventType = parser.getEventType();
			while (eventType != 1) {
				if (eventType == 2) {
					String tagName = parser.getName();
					TypedArray a;
					if (ANIMATED_VECTOR.equals(tagName)) {
						a = obtainAttributes(res, theme, attrs, AndroidResources.styleable_AnimatedVectorDrawable);
						int drawableRes = a.getResourceId(0, 0);
						if (drawableRes != 0) {
							VectorDrawableCompat vectorDrawable = VectorDrawableCompat.create(res, drawableRes, theme);
							vectorDrawable.setAllowCaching(DBG_ANIMATION_VECTOR_DRAWABLE);
							vectorDrawable.setCallback(mCallback);
							if (mAnimatedVectorState.mVectorDrawable != null) {
								mAnimatedVectorState.mVectorDrawable.setCallback(null);
							}
							mAnimatedVectorState.mVectorDrawable = vectorDrawable;
						}
						a.recycle();
					} else if (TARGET.equals(tagName)) {
						a = res.obtainAttributes(attrs, AndroidResources.styleable_AnimatedVectorDrawableTarget);
						String target = a.getString(0);
						int id = a.getResourceId(1, 0);
						if (id != 0) {
							if (mContext != null) {
								setupAnimatorsForTarget(target, AnimatorInflater.loadAnimator(mContext, id));
							} else {
								throw new IllegalStateException("Context can't be null when inflating animators");
							}
						}
						a.recycle();
					}
				}
				eventType = parser.next();
			}
		}
	}

	public /* bridge */ /* synthetic */ boolean isAutoMirrored() {
		return super.isAutoMirrored();
	}

	public boolean isRunning() {
		if (mDelegateDrawable != null) {
			return ((AnimatedVectorDrawable) mDelegateDrawable).isRunning();
		} else {
			ArrayList<Animator> animators = mAnimatedVectorState.mAnimators;
			int i = 0;
			while (i < animators.size()) {
				if (((Animator) animators.get(i)).isRunning()) {
					return true;
				} else {
					i++;
				}
			}
			return DBG_ANIMATION_VECTOR_DRAWABLE;
		}
	}

	public boolean isStateful() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.isStateful();
		} else {
			return mAnimatedVectorState.mVectorDrawable.isStateful();
		}
	}

	public /* bridge */ /* synthetic */ void jumpToCurrentState() {
		super.jumpToCurrentState();
	}

	public Drawable mutate() {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.mutate();
			return this;
		} else {
			throw new IllegalStateException("Mutate() is not supported for older platform");
		}
	}

	protected void onBoundsChange(Rect bounds) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setBounds(bounds);
		} else {
			mAnimatedVectorState.mVectorDrawable.setBounds(bounds);
		}
	}

	protected boolean onLevelChange(int level) {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.setLevel(level);
		} else {
			return mAnimatedVectorState.mVectorDrawable.setLevel(level);
		}
	}

	protected boolean onStateChange(int[] state) {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.setState(state);
		} else {
			return mAnimatedVectorState.mVectorDrawable.setState(state);
		}
	}

	public void setAlpha(int alpha) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setAlpha(alpha);
		} else {
			mAnimatedVectorState.mVectorDrawable.setAlpha(alpha);
		}
	}

	public /* bridge */ /* synthetic */ void setAutoMirrored(boolean x0) {
		super.setAutoMirrored(x0);
	}

	public /* bridge */ /* synthetic */ void setChangingConfigurations(int x0) {
		super.setChangingConfigurations(x0);
	}

	public /* bridge */ /* synthetic */ void setColorFilter(int x0, Mode x1) {
		super.setColorFilter(x0, x1);
	}

	public void setColorFilter(ColorFilter colorFilter) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setColorFilter(colorFilter);
		} else {
			mAnimatedVectorState.mVectorDrawable.setColorFilter(colorFilter);
		}
	}

	public /* bridge */ /* synthetic */ void setFilterBitmap(boolean x0) {
		super.setFilterBitmap(x0);
	}

	public /* bridge */ /* synthetic */ void setHotspot(float x0, float x1) {
		super.setHotspot(x0, x1);
	}

	public /* bridge */ /* synthetic */ void setHotspotBounds(int x0, int x1, int x2, int x3) {
		super.setHotspotBounds(x0, x1, x2, x3);
	}

	public /* bridge */ /* synthetic */ boolean setState(int[] x0) {
		return super.setState(x0);
	}

	public void setTint(int tint) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setTint(mDelegateDrawable, tint);
		} else {
			mAnimatedVectorState.mVectorDrawable.setTint(tint);
		}
	}

	public void setTintList(ColorStateList tint) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setTintList(mDelegateDrawable, tint);
		} else {
			mAnimatedVectorState.mVectorDrawable.setTintList(tint);
		}
	}

	public void setTintMode(Mode tintMode) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setTintMode(mDelegateDrawable, tintMode);
		} else {
			mAnimatedVectorState.mVectorDrawable.setTintMode(tintMode);
		}
	}

	public boolean setVisible(boolean visible, boolean restart) {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.setVisible(visible, restart);
		} else {
			mAnimatedVectorState.mVectorDrawable.setVisible(visible, restart);
			return super.setVisible(visible, restart);
		}
	}

	public void start() {
		if (mDelegateDrawable != null) {
			((AnimatedVectorDrawable) mDelegateDrawable).start();
		} else if (!isStarted()) {
			ArrayList<Animator> animators = mAnimatedVectorState.mAnimators;
			int i = 0;
			while (i < animators.size()) {
				((Animator) animators.get(i)).start();
				i++;
			}
			invalidateSelf();
		}
	}

	public void stop() {
		if (mDelegateDrawable != null) {
			((AnimatedVectorDrawable) mDelegateDrawable).stop();
		} else {
			ArrayList<Animator> animators = mAnimatedVectorState.mAnimators;
			int i = 0;
			while (i < animators.size()) {
				((Animator) animators.get(i)).end();
				i++;
			}
		}
	}
}
