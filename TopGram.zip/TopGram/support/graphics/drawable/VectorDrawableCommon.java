package android.support.graphics.drawable;

import android.annotation.TargetApi;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.graphics.drawable.TintAwareDrawable;
import android.util.AttributeSet;

@TargetApi(21)
abstract class VectorDrawableCommon extends Drawable implements TintAwareDrawable {
	Drawable mDelegateDrawable;

	VectorDrawableCommon() {
		super();
	}

	static TypedArray obtainAttributes(Resources res, Theme theme, AttributeSet set, int[] attrs) {
		int r0i = 0;
		if (theme == null) {
			return res.obtainAttributes(set, attrs);
		} else {
			return theme.obtainStyledAttributes(set, attrs, r0i, r0i);
		}
	}

	public void applyTheme(Theme t) {
		if (mDelegateDrawable != null) {
			DrawableCompat.applyTheme(mDelegateDrawable, t);
		}
	}

	public void clearColorFilter() {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.clearColorFilter();
		} else {
			super.clearColorFilter();
		}
	}

	public ColorFilter getColorFilter() {
		if (mDelegateDrawable != null) {
			return DrawableCompat.getColorFilter(mDelegateDrawable);
		} else {
			return null;
		}
	}

	public Drawable getCurrent() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getCurrent();
		} else {
			return super.getCurrent();
		}
	}

	public int getLayoutDirection() {
		if (mDelegateDrawable != null) {
			DrawableCompat.getLayoutDirection(mDelegateDrawable);
		}
		return 0;
	}

	public int getMinimumHeight() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getMinimumHeight();
		} else {
			return super.getMinimumHeight();
		}
	}

	public int getMinimumWidth() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getMinimumWidth();
		} else {
			return super.getMinimumWidth();
		}
	}

	public boolean getPadding(Rect padding) {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getPadding(padding);
		} else {
			return super.getPadding(padding);
		}
	}

	public int[] getState() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getState();
		} else {
			return super.getState();
		}
	}

	public Region getTransparentRegion() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getTransparentRegion();
		} else {
			return super.getTransparentRegion();
		}
	}

	public boolean isAutoMirrored() {
		if (mDelegateDrawable != null) {
			DrawableCompat.isAutoMirrored(mDelegateDrawable);
		}
		return false;
	}

	public void jumpToCurrentState() {
		if (mDelegateDrawable != null) {
			DrawableCompat.jumpToCurrentState(mDelegateDrawable);
		}
	}

	protected void onBoundsChange(Rect bounds) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setBounds(bounds);
		} else {
			super.onBoundsChange(bounds);
		}
	}

	protected boolean onLevelChange(int level) {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.setLevel(level);
		} else {
			return super.onLevelChange(level);
		}
	}

	public void setAutoMirrored(boolean mirrored) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setAutoMirrored(mDelegateDrawable, mirrored);
		}
	}

	public void setChangingConfigurations(int configs) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setChangingConfigurations(configs);
		} else {
			super.setChangingConfigurations(configs);
		}
	}

	public void setColorFilter(int color, Mode mode) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setColorFilter(color, mode);
		} else {
			super.setColorFilter(color, mode);
		}
	}

	public void setFilterBitmap(boolean filter) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setFilterBitmap(filter);
		}
	}

	public void setHotspot(float x, float y) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setHotspot(mDelegateDrawable, x, y);
		}
	}

	public void setHotspotBounds(int left, int top, int right, int bottom) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setHotspotBounds(mDelegateDrawable, left, top, right, bottom);
		}
	}

	public boolean setState(int[] stateSet) {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.setState(stateSet);
		} else {
			return super.setState(stateSet);
		}
	}
}
