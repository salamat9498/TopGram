package android.support.graphics.drawable;

import android.graphics.Path;
import android.support.v7.appcompat.R;
import android.util.Log;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.googlecode.mp4parser.boxes.microsoft.XtraBox;
import com.koushikdutta.ion.loader.MediaFile;
import com.rey.material.R;
import java.util.ArrayList;
import org.telegram.messenger.AndroidUtilities;
import org.telegram.tgnet.TLRPC;

class PathParser {
	private static final String LOGTAG = "PathParser";

	private static class ExtractFloatResult {
		int mEndPosition;
		boolean mEndWithNegOrDot;

		ExtractFloatResult() {
			super();
		}
	}

	public static class PathDataNode {
		float[] params;
		char type;

		PathDataNode(char type, float[] params) {
			super();
			this.type = type;
			this.params = params;
		}

		PathDataNode(PathParser.PathDataNode n) {
			super();
			type = n.type;
			params = PathParser.copyOfRange(n.params, 0, n.params.length);
		}

		private static void addCommand(Path path, float[] current, char previousCmd, char cmd, float[] val) {
			int incr = TLRPC.USER_FLAG_FIRST_NAME;
			float currentX = current[0];
			float currentY = current[1];
			float ctrlPointX = current[2];
			float ctrlPointY = current[3];
			float currentSegmentStartX = current[4];
			float currentSegmentStartY = current[5];
			switch(cmd) {
			case R.styleable.AppCompatTheme_imageButtonStyle:
			case R.styleable.AppCompatTheme_textColorAlertDialogListItem:
				incr = AndroidUtilities.FLAG_TAG_ALL;
				break;
			case R.styleable.AppCompatTheme_textAppearanceSearchResultSubtitle:
			case R.styleable.AppCompatTheme_buttonBarNegativeButtonStyle:
				incr = R.styleable.YearPicker_dp_textHighlightColor;
				break;
			case XtraBox.MP4_XTRA_BT_GUID:
			case R.styleable.AppCompatTheme_colorControlNormal:
			case MediaFile.FILE_TYPE_MS_WORD:
			case 'v':
				incr = 1;
				break;
			case R.styleable.AppCompatTheme_listPopupWindowStyle:
			case R.styleable.AppCompatTheme_textAppearanceListItem:
			case R.styleable.AppCompatTheme_colorPrimaryDark:
			case R.styleable.AppCompatTheme_ratingBarStyle:
			case R.styleable.AppCompatTheme_ratingBarStyleIndicator:
			case 't':
				incr = TLRPC.USER_FLAG_FIRST_NAME;
				break;
			case R.styleable.AppCompatTheme_panelMenuListTheme:
			case R.styleable.AppCompatTheme_colorPrimary:
			case R.styleable.AppCompatTheme_switchStyle:
			case 's':
				incr = TLRPC.USER_FLAG_LAST_NAME;
				break;
			case R.styleable.AppCompatTheme_colorSwitchThumbNormal:
			case 'z':
				path.close();
				currentX = currentSegmentStartX;
				currentY = currentSegmentStartY;
				ctrlPointX = currentSegmentStartX;
				ctrlPointY = currentSegmentStartY;
				path.moveTo(currentX, currentY);
				break;
			}
			int k = 0;
			while (k < val.length) {
				float r9f;
				float r10f;
				float r11f;
				float r12f;
				float r13f;
				boolean r14z;
				boolean r15z;
				float reflectiveCtrlPointX;
				float reflectiveCtrlPointY;
				switch(cmd) {
				case R.styleable.AppCompatTheme_imageButtonStyle:
					r9f = val[k + 5];
					r10f = val[k + 6];
					r11f = val[k + 0];
					r12f = val[k + 1];
					r13f = val[k + 2];
					if (val[k + 3] != 0.0f) {
						r14z = true;
					} else {
						r14z = false;
					}
					if (val[k + 4] != 0.0f) {
						r15z = true;
					} else {
						r15z = false;
					}
					drawArc(path, currentX, currentY, r9f, r10f, r11f, r12f, r13f, r14z, r15z);
					currentX = val[k + 5];
					currentY = val[k + 6];
					ctrlPointX = currentX;
					ctrlPointY = currentY;
					break;
				case R.styleable.AppCompatTheme_textAppearanceSearchResultSubtitle:
					path.cubicTo(val[k + 0], val[k + 1], val[k + 2], val[k + 3], val[k + 4], val[k + 5]);
					currentX = val[k + 4];
					currentY = val[k + 5];
					ctrlPointX = val[k + 2];
					ctrlPointY = val[k + 3];
					break;
				case XtraBox.MP4_XTRA_BT_GUID:
					path.lineTo(val[k + 0], currentY);
					currentX = val[k + 0];
					break;
				case R.styleable.AppCompatTheme_listPopupWindowStyle:
					path.lineTo(val[k + 0], val[k + 1]);
					currentX = val[k + 0];
					currentY = val[k + 1];
					break;
				case R.styleable.AppCompatTheme_textAppearanceListItem:
					currentX = val[k + 0];
					currentY = val[k + 1];
					if (k > 0) {
						path.lineTo(val[k + 0], val[k + 1]);
					} else {
						path.moveTo(val[k + 0], val[k + 1]);
						currentSegmentStartX = currentX;
						currentSegmentStartY = currentY;
					}
					break;
				case R.styleable.AppCompatTheme_panelMenuListTheme:
					path.quadTo(val[k + 0], val[k + 1], val[k + 2], val[k + 3]);
					ctrlPointX = val[k + 0];
					ctrlPointY = val[k + 1];
					currentX = val[k + 2];
					currentY = val[k + 3];
					break;
				case R.styleable.AppCompatTheme_colorPrimary:
					reflectiveCtrlPointX = currentX;
					reflectiveCtrlPointY = currentY;
					if (previousCmd == 'c' || previousCmd == 's' || previousCmd == 'C' || previousCmd == 'S') {
						reflectiveCtrlPointX = (2.0f * currentX) - ctrlPointX;
						reflectiveCtrlPointY = (2.0f * currentY) - ctrlPointY;
					} else {
						path.cubicTo(reflectiveCtrlPointX, reflectiveCtrlPointY, val[k + 0], val[k + 1], val[k + 2], val[k + 3]);
						ctrlPointX = val[k + 0];
						ctrlPointY = val[k + 1];
						currentX = val[k + 2];
						currentY = val[k + 3];
					}
					path.cubicTo(reflectiveCtrlPointX, reflectiveCtrlPointY, val[k + 0], val[k + 1], val[k + 2], val[k + 3]);
					ctrlPointX = val[k + 0];
					ctrlPointY = val[k + 1];
					currentX = val[k + 2];
					currentY = val[k + 3];
					break;
				case R.styleable.AppCompatTheme_colorPrimaryDark:
					reflectiveCtrlPointX = currentX;
					reflectiveCtrlPointY = currentY;
					if (previousCmd == 'q' || previousCmd == 't' || previousCmd == 'Q' || previousCmd == 'T') {
						reflectiveCtrlPointX = (2.0f * currentX) - ctrlPointX;
						reflectiveCtrlPointY = (2.0f * currentY) - ctrlPointY;
					} else {
						path.quadTo(reflectiveCtrlPointX, reflectiveCtrlPointY, val[k + 0], val[k + 1]);
						ctrlPointX = reflectiveCtrlPointX;
						ctrlPointY = reflectiveCtrlPointY;
						currentX = val[k + 0];
						currentY = val[k + 1];
					}
					path.quadTo(reflectiveCtrlPointX, reflectiveCtrlPointY, val[k + 0], val[k + 1]);
					ctrlPointX = reflectiveCtrlPointX;
					ctrlPointY = reflectiveCtrlPointY;
					currentX = val[k + 0];
					currentY = val[k + 1];
					break;
				case R.styleable.AppCompatTheme_colorControlNormal:
					path.lineTo(currentX, val[k + 0]);
					currentY = val[k + 0];
					break;
				case R.styleable.AppCompatTheme_textColorAlertDialogListItem:
					r9f = val[k + 5] + currentX;
					r10f = val[k + 6] + currentY;
					r11f = val[k + 0];
					r12f = val[k + 1];
					r13f = val[k + 2];
					if (val[k + 3] != 0.0f) {
						r14z = true;
					} else {
						r14z = false;
					}
					if (val[k + 4] != 0.0f) {
						r15z = true;
					} else {
						r15z = false;
					}
					drawArc(path, currentX, currentY, r9f, r10f, r11f, r12f, r13f, r14z, r15z);
					currentX += val[k + 5];
					currentY += val[k + 6];
					ctrlPointX = currentX;
					ctrlPointY = currentY;
					break;
				case R.styleable.AppCompatTheme_buttonBarNegativeButtonStyle:
					path.rCubicTo(val[k + 0], val[k + 1], val[k + 2], val[k + 3], val[k + 4], val[k + 5]);
					ctrlPointX = currentX + val[k + 2];
					ctrlPointY = currentY + val[k + 3];
					currentX += val[k + 4];
					currentY += val[k + 5];
					break;
				case MediaFile.FILE_TYPE_MS_WORD:
					path.rLineTo(val[k + 0], BitmapDescriptorFactory.HUE_RED);
					currentX += val[k + 0];
					break;
				case R.styleable.AppCompatTheme_ratingBarStyle:
					path.rLineTo(val[k + 0], val[k + 1]);
					currentX += val[k + 0];
					currentY += val[k + 1];
					break;
				case R.styleable.AppCompatTheme_ratingBarStyleIndicator:
					currentX += val[k + 0];
					currentY += val[k + 1];
					if (k > 0) {
						path.rLineTo(val[k + 0], val[k + 1]);
					} else {
						path.rMoveTo(val[k + 0], val[k + 1]);
						currentSegmentStartX = currentX;
						currentSegmentStartY = currentY;
					}
					break;
				case R.styleable.AppCompatTheme_switchStyle:
					path.rQuadTo(val[k + 0], val[k + 1], val[k + 2], val[k + 3]);
					ctrlPointX = currentX + val[k + 0];
					ctrlPointY = currentY + val[k + 1];
					currentX += val[k + 2];
					currentY += val[k + 3];
					break;
				case 's':
					reflectiveCtrlPointX = BitmapDescriptorFactory.HUE_RED;
					reflectiveCtrlPointY = BitmapDescriptorFactory.HUE_RED;
					if (previousCmd == 'c' || previousCmd == 's' || previousCmd == 'C' || previousCmd == 'S') {
						reflectiveCtrlPointX = currentX - ctrlPointX;
						reflectiveCtrlPointY = currentY - ctrlPointY;
					} else {
						path.rCubicTo(reflectiveCtrlPointX, reflectiveCtrlPointY, val[k + 0], val[k + 1], val[k + 2], val[k + 3]);
						ctrlPointX = currentX + val[k + 0];
						ctrlPointY = currentY + val[k + 1];
						currentX += val[k + 2];
						currentY += val[k + 3];
					}
					path.rCubicTo(reflectiveCtrlPointX, reflectiveCtrlPointY, val[k + 0], val[k + 1], val[k + 2], val[k + 3]);
					ctrlPointX = currentX + val[k + 0];
					ctrlPointY = currentY + val[k + 1];
					currentX += val[k + 2];
					currentY += val[k + 3];
					break;
				case 't':
					reflectiveCtrlPointX = BitmapDescriptorFactory.HUE_RED;
					reflectiveCtrlPointY = BitmapDescriptorFactory.HUE_RED;
					if (previousCmd == 'q' || previousCmd == 't' || previousCmd == 'Q' || previousCmd == 'T') {
						reflectiveCtrlPointX = currentX - ctrlPointX;
						reflectiveCtrlPointY = currentY - ctrlPointY;
					} else {
						path.rQuadTo(reflectiveCtrlPointX, reflectiveCtrlPointY, val[k + 0], val[k + 1]);
						ctrlPointX = currentX + reflectiveCtrlPointX;
						ctrlPointY = currentY + reflectiveCtrlPointY;
						currentX += val[k + 0];
						currentY += val[k + 1];
					}
					path.rQuadTo(reflectiveCtrlPointX, reflectiveCtrlPointY, val[k + 0], val[k + 1]);
					ctrlPointX = currentX + reflectiveCtrlPointX;
					ctrlPointY = currentY + reflectiveCtrlPointY;
					currentX += val[k + 0];
					currentY += val[k + 1];
					break;
				case 'v':
					path.rLineTo(BitmapDescriptorFactory.HUE_RED, val[k + 0]);
					currentY += val[k + 0];
					break;
				}
				previousCmd = cmd;
				k += incr;
			}
			current[0] = currentX;
			current[1] = currentY;
			current[2] = ctrlPointX;
			current[3] = ctrlPointY;
			current[4] = currentSegmentStartX;
			current[5] = currentSegmentStartY;
		}

		private static void arcToBezier(Path p, double cx, double cy, double a, double b, double e1x, double e1y, double theta, double start, double sweep) {
			int numSegments = (int) Math.ceil(Math.abs((4.0d * sweep) / 3.141592653589793d));
			double eta1 = start;
			double cosTheta = Math.cos(theta);
			double sinTheta = Math.sin(theta);
			double cosEta1 = Math.cos(eta1);
			double sinEta1 = Math.sin(eta1);
			double ep1x = (((-a) * cosTheta) * sinEta1) - ((b * sinTheta) * cosEta1);
			double ep1y = (((-a) * sinTheta) * sinEta1) + ((b * cosTheta) * cosEta1);
			double anglePerSegment = sweep / ((double) numSegments);
			int i = 0;
			while (i < numSegments) {
				double eta2 = eta1 + anglePerSegment;
				double sinEta2 = Math.sin(eta2);
				double cosEta2 = Math.cos(eta2);
				double e2x = (((a * cosTheta) * cosEta2) + cx) - ((b * sinTheta) * sinEta2);
				double e2y = (((a * sinTheta) * cosEta2) + cy) + ((b * cosTheta) * sinEta2);
				double ep2x = (((-a) * cosTheta) * sinEta2) - ((b * sinTheta) * cosEta2);
				double ep2y = (((-a) * sinTheta) * sinEta2) + ((b * cosTheta) * cosEta2);
				double tanDiff2 = Math.tan((eta2 - eta1) / 2.0d);
				double alpha = (Math.sin(eta2 - eta1) * (Math.sqrt(4.0d + ((3.0d * tanDiff2) * tanDiff2)) - 1.0d)) / 3.0d;
				p.cubicTo((float) (e1x + (alpha * ep1x)), (float) (e1y + (alpha * ep1y)), (float) (e2x - (alpha * ep2x)), (float) (e2y - (alpha * ep2y)), (float) e2x, (float) e2y);
				eta1 = eta2;
				e1x = e2x;
				e1y = e2y;
				ep1x = ep2x;
				ep1y = ep2y;
				i++;
			}
		}

		private static void drawArc(Path p, float x0, float y0, float x1, float y1, float a, float b, float theta, boolean isMoreThanHalf, boolean isPositiveArc) {
			double thetaD = Math.toRadians((double) theta);
			double cosTheta = Math.cos(thetaD);
			double sinTheta = Math.sin(thetaD);
			double x0p = ((((double) x0) * cosTheta) + (((double) y0) * sinTheta)) / ((double) a);
			double y0p = ((((double) (-x0)) * sinTheta) + (((double) y0) * cosTheta)) / ((double) b);
			double x1p = ((((double) x1) * cosTheta) + (((double) y1) * sinTheta)) / ((double) a);
			double y1p = ((((double) (-x1)) * sinTheta) + (((double) y1) * cosTheta)) / ((double) b);
			double dx = x0p - x1p;
			double dy = y0p - y1p;
			double xm = (x0p + x1p) / 2.0d;
			double ym = (y0p + y1p) / 2.0d;
			double dsq = (dx * dx) + (dy * dy);
			if (dsq == 0.0d) {
				Log.w(LOGTAG, " Points are coincident");
			} else {
				double disc = (1.0d / dsq) - 0.25d;
				if (disc < 0.0d) {
					Log.w(LOGTAG, "Points are too far apart " + dsq);
					float adjust = (float) (Math.sqrt(dsq) / 1.99999d);
					drawArc(p, x0, y0, x1, y1, a * adjust, b * adjust, theta, isMoreThanHalf, isPositiveArc);
				} else {
					double cx;
					double cy;
					boolean r2z;
					double s = Math.sqrt(disc);
					double sdx = s * dx;
					double sdy = s * dy;
					if (isMoreThanHalf == isPositiveArc) {
						cx = xm - sdy;
						cy = ym + sdx;
					} else {
						cx = xm + sdy;
						cy = ym - sdx;
					}
					double eta0 = Math.atan2(y0p - cy, x0p - cx);
					double sweep = Math.atan2(y1p - cy, x1p - cx) - eta0;
					if (sweep >= 0.0d) {
						r2z = true;
					} else {
						r2z = false;
					}
					if (isPositiveArc != r2z) {
						if (sweep > 0.0d) {
							sweep -= 6.283185307179586d;
						} else {
							sweep += 6.283185307179586d;
						}
					}
					cx *= (double) a;
					cy *= (double) b;
					arcToBezier(p, (cx * cosTheta) - (cy * sinTheta), (cx * sinTheta) + (cy * cosTheta), (double) a, (double) b, (double) x0, (double) y0, thetaD, eta0, sweep);
				}
			}
		}

		public static void nodesToPath(PathParser.PathDataNode[] node, Path path) {
			float[] current = new float[6];
			char previousCommand = 'm';
			int i = 0;
			while (i < node.length) {
				addCommand(path, current, previousCommand, node[i].type, node[i].params);
				previousCommand = node[i].type;
				i++;
			}
		}

		public void interpolatePathDataNode(PathParser.PathDataNode nodeFrom, PathParser.PathDataNode nodeTo, float fraction) {
			int i = 0;
			while (i < nodeFrom.params.length) {
				params[i] = (nodeFrom.params[i] * (1.0f - fraction)) + (nodeTo.params[i] * fraction);
				i++;
			}
		}
	}


	PathParser() {
		super();
	}

	private static void addNode(ArrayList<PathDataNode> list, char cmd, float[] val) {
		list.add(new PathDataNode(cmd, val));
	}

	/* JADX WARNING: inconsistent code */
	/*
	public static boolean canMorph(android.support.graphics.drawable.PathParser.PathDataNode[] r4_nodesFrom, android.support.graphics.drawable.PathParser.PathDataNode[] r5_nodesTo) {
		r1 = 0;
		if (r4_nodesFrom == 0) goto L_0x0005;
	L_0x0003:
		if (r5_nodesTo != 0) goto L_0x0006;
	L_0x0005:
		return r1;
	L_0x0006:
		r2 = r4_nodesFrom.length;
		r3 = r5_nodesTo.length;
		if (r2 != r3) goto L_0x0005;
	L_0x000a:
		r0 = 0;
	L_0x000b:
		r2 = r4_nodesFrom.length;
		if (r0_i >= r2) goto L_0x0027;
	L_0x000e:
		r2 = r4_nodesFrom[r0_i];
		r2 = r2.type;
		r3 = r5_nodesTo[r0_i];
		r3 = r3.type;
		if (r2 != r3) goto L_0x0005;
	L_0x0018:
		r2 = r4_nodesFrom[r0_i];
		r2 = r2.params;
		r2 = r2.length;
		r3 = r5_nodesTo[r0_i];
		r3 = r3.params;
		r3 = r3.length;
		if (r2 != r3) goto L_0x0005;
	L_0x0024:
		r0_i++;
		goto L_0x000b;
	L_0x0027:
		r1 = 1;
		goto L_0x0005;
	}
	*/
	public static boolean canMorph(PathDataNode[] nodesFrom, PathDataNode[] nodesTo) {
		if (nodesFrom != null) {
			if (nodesTo == null) {
				return false;
			} else if (nodesFrom.length == nodesTo.length) {
				int i = 0;
				while (i < nodesFrom.length) {
					if (nodesFrom[i].type == nodesTo[i].type) {
						if (nodesFrom[i].params.length == nodesTo[i].params.length) {
							i++;
						}
					}
				}
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	static float[] copyOfRange(float[] original, int start, int end) {
		if (start > end) {
			throw new IllegalArgumentException();
		} else {
			int originalLength = original.length;
			if (start < 0 || start > originalLength) {
				throw new ArrayIndexOutOfBoundsException();
			} else {
				int resultLength = end - start;
				Object result = new Object[resultLength];
				System.arraycopy(original, start, result, 0, Math.min(resultLength, originalLength - start));
				return result;
			}
		}
	}

	public static PathDataNode[] createNodesFromPathData(String pathData) {
		if (pathData == null) {
			return null;
		} else {
			int start = 0;
			int end = 1;
			ArrayList<PathDataNode> list = new ArrayList();
			while (end < pathData.length()) {
				end = nextStart(pathData, end);
				String s = pathData.substring(start, end).trim();
				if (s.length() > 0) {
					addNode(list, s.charAt(0), getFloats(s));
				}
				start = end;
				end++;
			}
			if (end - start != 1 || start >= pathData.length()) {
				return (PathDataNode[]) list.toArray(new PathDataNode[list.size()]);
			} else {
				addNode(list, pathData.charAt(start), new float[0]);
				return (PathDataNode[]) list.toArray(new PathDataNode[list.size()]);
			}
		}
	}

	public static Path createPathFromPathData(String pathData) {
		Path path = new Path();
		PathDataNode[] nodes = createNodesFromPathData(pathData);
		if (nodes != null) {
			try {
				PathDataNode.nodesToPath(nodes, path);
				return path;
			} catch (RuntimeException e) {
				throw new RuntimeException("Error in parsing " + pathData, e);
			}
		} else {
			return null;
		}
	}

	public static PathDataNode[] deepCopyNodes(PathDataNode[] source) {
		if (source == null) {
			return null;
		} else {
			PathDataNode[] copy = new PathDataNode[source.length];
			int i = 0;
			while (i < source.length) {
				copy[i] = new PathDataNode(source[i]);
				i++;
			}
			return copy;
		}
	}

	private static void extract(String s, int start, ExtractFloatResult result) {
		int currentIndex = start;
		boolean foundSeparator = false;
		result.mEndWithNegOrDot = false;
		boolean secondDot = false;
		boolean isExponential = false;
		while (currentIndex < s.length()) {
			boolean isPrevExponential = isExponential;
			isExponential = false;
			switch(s.charAt(currentIndex)) {
			case TLRPC.USER_FLAG_PHOTO:
			case R.styleable.TextView_tv_fontFamily:
				foundSeparator = true;
				break;
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_listDividerAlertDialog:
				if (currentIndex != start) {
					if (!isPrevExponential) {
						foundSeparator = true;
						result.mEndWithNegOrDot = true;
					}
				}
				break;
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_actionDropDownStyle:
				if (!secondDot) {
					secondDot = true;
				} else {
					foundSeparator = true;
					result.mEndWithNegOrDot = true;
				}
				break;
			case android.support.v7.appcompat.R.styleable.AppCompatTheme_searchViewStyle:
			case MediaFile.FILE_TYPE_HTML:
				isExponential = true;
				break;
			}
			if (foundSeparator) {
				result.mEndPosition = currentIndex;
			} else {
				currentIndex++;
			}
		}
		result.mEndPosition = currentIndex;
	}

	private static float[] getFloats(String s) {
		int r8i;
		int r9i = 1;
		if (s.charAt(0) == 'z') {
			r8i = 1;
		} else {
			r8i = 0;
		}
		float[] results;
		int startPosition;
		ExtractFloatResult result;
		int count;
		int endPosition;
		int count_2;
		if (s.charAt(0) == 'Z') {
			if ((r8i | r9i) == 0) {
				return new float[0];
			} else {
				try {
					results = new float[s.length()];
					startPosition = 1;
					result = new ExtractFloatResult();
					count = 0;
					while (startPosition < s.length()) {
						extract(s, startPosition, result);
						endPosition = result.mEndPosition;
						if (startPosition >= endPosition) {
							count_2 = count + 1;
							results[count] = Float.parseFloat(s.substring(startPosition, endPosition));
						} else {
							count_2 = count;
						}
						if (!result.mEndWithNegOrDot) {
							startPosition = endPosition;
							count = count_2;
						} else {
							startPosition = endPosition + 1;
							count = count_2;
						}
					}
					return copyOfRange(results, 0, count);
				} catch (NumberFormatException e) {
					throw new RuntimeException("error in parsing \"" + s + "\"", e);
				}
			}
		} else {
			r9i = 0;
			if ((r8i | r9i) == 0) {
				results = new float[s.length()];
				startPosition = 1;
				result = new ExtractFloatResult();
				count = 0;
				while (startPosition < s.length()) {
					extract(s, startPosition, result);
					endPosition = result.mEndPosition;
					if (startPosition >= endPosition) {
						count_2 = count;
					} else {
						count_2 = count + 1;
						results[count] = Float.parseFloat(s.substring(startPosition, endPosition));
					}
					if (!result.mEndWithNegOrDot) {
						startPosition = endPosition + 1;
						count = count_2;
					} else {
						startPosition = endPosition;
						count = count_2;
					}
				}
				return copyOfRange(results, 0, count);
			} else {
				return new float[0];
			}
		}
	}

	private static int nextStart(String s, int end) {
		while (end < s.length()) {
			char c = s.charAt(end);
			if (((c - 65) * (c - 90) <= 0 || (c - 97) * (c - 122) <= 0) && c != 'e' && c != 'E') {
				return end;
			} else {
				end++;
			}
			end++;
		}
		return end;
	}

	public static void updateNodes(PathDataNode[] target, PathDataNode[] source) {
		int i = 0;
		while (i < source.length) {
			target[i].type = source[i].type;
			int j = 0;
			while (j < source[i].params.length) {
				target[i].params[j] = source[i].params[j];
				j++;
			}
			i++;
		}
	}
}
