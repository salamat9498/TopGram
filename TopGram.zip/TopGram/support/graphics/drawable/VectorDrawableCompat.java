package android.support.graphics.drawable;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.VectorDrawable;
import android.os.Build.VERSION;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.graphics.drawable.PathParser.PathDataNode;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.util.ArrayMap;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import com.androidquery.util.Constants;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.vision.face.Face;
import com.rey.material.R;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Stack;
import net.hockeyapp.android.BuildConfig;
import org.telegram.SQLite.SQLiteCursor;
import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.BuildConfig;
import org.telegram.tgnet.ConnectionsManager;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.Components.Glow;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@TargetApi(21)
public class VectorDrawableCompat extends VectorDrawableCommon {
	private static final boolean DBG_VECTOR_DRAWABLE = false;
	static final Mode DEFAULT_TINT_MODE;
	private static final int LINECAP_BUTT = 0;
	private static final int LINECAP_ROUND = 1;
	private static final int LINECAP_SQUARE = 2;
	private static final int LINEJOIN_BEVEL = 2;
	private static final int LINEJOIN_MITER = 0;
	private static final int LINEJOIN_ROUND = 1;
	static final String LOGTAG = "VectorDrawableCompat";
	private static final int MAX_CACHED_BITMAP_SIZE = 2048;
	private static final String SHAPE_CLIP_PATH = "clip-path";
	private static final String SHAPE_GROUP = "group";
	private static final String SHAPE_PATH = "path";
	private static final String SHAPE_VECTOR = "vector";
	private boolean mAllowCaching;
	private ConstantState mCachedConstantStateDelegate;
	private ColorFilter mColorFilter;
	private boolean mMutated;
	private PorterDuffColorFilter mTintFilter;
	private final Rect mTmpBounds;
	private final float[] mTmpFloats;
	private final Matrix mTmpMatrix;
	private VectorDrawableCompatState mVectorState;

	private static class VPath {
		int mChangingConfigurations;
		protected PathDataNode[] mNodes;
		String mPathName;

		public VPath() {
			super();
			mNodes = null;
		}

		public VPath(VectorDrawableCompat.VPath copy) {
			super();
			mNodes = null;
			mPathName = copy.mPathName;
			mChangingConfigurations = copy.mChangingConfigurations;
			mNodes = PathParser.deepCopyNodes(copy.mNodes);
		}

		public String NodesToString(PathDataNode[] nodes) {
			String result = " ";
			int i = LINEJOIN_MITER;
			while (i < nodes.length) {
				result = result + nodes[i].type + ":";
				float[] params = nodes[i].params;
				int j = LINEJOIN_MITER;
				while (j < params.length) {
					result = result + params[j] + ",";
					j++;
				}
				i++;
			}
			return result;
		}

		public void applyTheme(Theme t) {
		}

		public boolean canApplyTheme() {
			return DBG_VECTOR_DRAWABLE;
		}

		public PathDataNode[] getPathData() {
			return mNodes;
		}

		public String getPathName() {
			return mPathName;
		}

		public boolean isClipPath() {
			return DBG_VECTOR_DRAWABLE;
		}

		public void printVPath(int level) {
			String indent = BuildConfig.Base64EncodedPublicKey;
			int i = LINEJOIN_MITER;
			while (i < level) {
				indent = indent + "    ";
				i++;
			}
			Log.v(LOGTAG, indent + "current path is :" + mPathName + " pathData is " + NodesToString(mNodes));
		}

		public void setPathData(PathDataNode[] nodes) {
			if (!PathParser.canMorph(mNodes, nodes)) {
				mNodes = PathParser.deepCopyNodes(nodes);
			} else {
				PathParser.updateNodes(mNodes, nodes);
			}
		}

		public void toPath(Path path) {
			path.reset();
			if (mNodes != null) {
				PathDataNode.nodesToPath(mNodes, path);
			}
		}
	}

	private static class VClipPath extends VectorDrawableCompat.VPath {
		public VClipPath() {
			super();
		}

		public VClipPath(VectorDrawableCompat.VClipPath copy) {
			super(copy);
		}

		private void updateStateFromTypedArray(TypedArray a) {
			String pathName = a.getString(LINEJOIN_MITER);
			if (pathName != null) {
				mPathName = pathName;
			}
			String pathData = a.getString(LINEJOIN_ROUND);
			if (pathData != null) {
				mNodes = PathParser.createNodesFromPathData(pathData);
			}
		}

		public void inflate(Resources r, AttributeSet attrs, Theme theme, XmlPullParser parser) {
			if (!TypedArrayUtils.hasAttribute(parser, "pathData")) {
			} else {
				TypedArray a = VectorDrawableCommon.obtainAttributes(r, theme, attrs, AndroidResources.styleable_VectorDrawableClipPath);
				updateStateFromTypedArray(a);
				a.recycle();
			}
		}

		public boolean isClipPath() {
			return true;
		}
	}

	private static class VFullPath extends VectorDrawableCompat.VPath {
		float mFillAlpha;
		int mFillColor;
		int mFillRule;
		float mStrokeAlpha;
		int mStrokeColor;
		Cap mStrokeLineCap;
		Join mStrokeLineJoin;
		float mStrokeMiterlimit;
		float mStrokeWidth;
		private int[] mThemeAttrs;
		float mTrimPathEnd;
		float mTrimPathOffset;
		float mTrimPathStart;

		public VFullPath() {
			super();
			mStrokeColor = 0;
			mStrokeWidth = 0.0f;
			mFillColor = 0;
			mStrokeAlpha = 1.0f;
			mFillAlpha = 1.0f;
			mTrimPathStart = 0.0f;
			mTrimPathEnd = 1.0f;
			mTrimPathOffset = 0.0f;
			mStrokeLineCap = Cap.BUTT;
			mStrokeLineJoin = Join.MITER;
			mStrokeMiterlimit = 4.0f;
		}

		public VFullPath(VectorDrawableCompat.VFullPath copy) {
			super(copy);
			mStrokeColor = 0;
			mStrokeWidth = 0.0f;
			mFillColor = 0;
			mStrokeAlpha = 1.0f;
			mFillAlpha = 1.0f;
			mTrimPathStart = 0.0f;
			mTrimPathEnd = 1.0f;
			mTrimPathOffset = 0.0f;
			mStrokeLineCap = Cap.BUTT;
			mStrokeLineJoin = Join.MITER;
			mStrokeMiterlimit = 4.0f;
			mThemeAttrs = copy.mThemeAttrs;
			mStrokeColor = copy.mStrokeColor;
			mStrokeWidth = copy.mStrokeWidth;
			mStrokeAlpha = copy.mStrokeAlpha;
			mFillColor = copy.mFillColor;
			mFillRule = copy.mFillRule;
			mFillAlpha = copy.mFillAlpha;
			mTrimPathStart = copy.mTrimPathStart;
			mTrimPathEnd = copy.mTrimPathEnd;
			mTrimPathOffset = copy.mTrimPathOffset;
			mStrokeLineCap = copy.mStrokeLineCap;
			mStrokeLineJoin = copy.mStrokeLineJoin;
			mStrokeMiterlimit = copy.mStrokeMiterlimit;
		}

		private Cap getStrokeLineCap(int id, Cap defValue) {
			switch(id) {
			case LINEJOIN_MITER:
				return Cap.BUTT;
			case LINEJOIN_ROUND:
				return Cap.ROUND;
			case LINEJOIN_BEVEL:
				return Cap.SQUARE;
			}
			return defValue;
		}

		private Join getStrokeLineJoin(int id, Join defValue) {
			switch(id) {
			case LINEJOIN_MITER:
				return Join.MITER;
			case LINEJOIN_ROUND:
				return Join.ROUND;
			case LINEJOIN_BEVEL:
				return Join.BEVEL;
			}
			return defValue;
		}

		private void updateStateFromTypedArray(TypedArray a, XmlPullParser parser) {
			mThemeAttrs = null;
			if (!TypedArrayUtils.hasAttribute(parser, "pathData")) {
			} else {
				String pathName = a.getString(LINEJOIN_MITER);
				if (pathName != null) {
					mPathName = pathName;
				}
				String pathData = a.getString(LINEJOIN_BEVEL);
				if (pathData != null) {
					mNodes = PathParser.createNodesFromPathData(pathData);
				}
				mFillColor = TypedArrayUtils.getNamedColor(a, parser, "fillColor", LINEJOIN_ROUND, mFillColor);
				mFillAlpha = TypedArrayUtils.getNamedFloat(a, parser, "fillAlpha", R.styleable.YearPicker_dp_yearItemHeight, mFillAlpha);
				mStrokeLineCap = getStrokeLineCap(TypedArrayUtils.getNamedInt(a, parser, "strokeLineCap", TLRPC.USER_FLAG_USERNAME, -1), mStrokeLineCap);
				mStrokeLineJoin = getStrokeLineJoin(TypedArrayUtils.getNamedInt(a, parser, "strokeLineJoin", BuildConfig.VERSION_CODE, -1), mStrokeLineJoin);
				mStrokeMiterlimit = TypedArrayUtils.getNamedFloat(a, parser, "strokeMiterLimit", R.styleable.YearPicker_dp_yearMin, mStrokeMiterlimit);
				mStrokeColor = TypedArrayUtils.getNamedColor(a, parser, "strokeColor", ConnectionsManager.ConnectionStateConnected, mStrokeColor);
				mStrokeAlpha = TypedArrayUtils.getNamedFloat(a, parser, "strokeAlpha", Glow.PRE_HONEYCOMB, mStrokeAlpha);
				mStrokeWidth = TypedArrayUtils.getNamedFloat(a, parser, "strokeWidth", TLRPC.USER_FLAG_LAST_NAME, mStrokeWidth);
				mTrimPathEnd = TypedArrayUtils.getNamedFloat(a, parser, "trimPathEnd", R.styleable.YearPicker_dp_textHighlightColor, mTrimPathEnd);
				mTrimPathOffset = TypedArrayUtils.getNamedFloat(a, parser, "trimPathOffset", AndroidUtilities.FLAG_TAG_ALL, mTrimPathOffset);
				mTrimPathStart = TypedArrayUtils.getNamedFloat(a, parser, "trimPathStart", SQLiteCursor.FIELD_TYPE_NULL, mTrimPathStart);
			}
		}

		public void applyTheme(Theme t) {
			if (mThemeAttrs == null) {
			}
		}

		public boolean canApplyTheme() {
			if (mThemeAttrs != null) {
				return true;
			} else {
				return DBG_VECTOR_DRAWABLE;
			}
		}

		float getFillAlpha() {
			return mFillAlpha;
		}

		int getFillColor() {
			return mFillColor;
		}

		float getStrokeAlpha() {
			return mStrokeAlpha;
		}

		int getStrokeColor() {
			return mStrokeColor;
		}

		float getStrokeWidth() {
			return mStrokeWidth;
		}

		float getTrimPathEnd() {
			return mTrimPathEnd;
		}

		float getTrimPathOffset() {
			return mTrimPathOffset;
		}

		float getTrimPathStart() {
			return mTrimPathStart;
		}

		public void inflate(Resources r, AttributeSet attrs, Theme theme, XmlPullParser parser) {
			TypedArray a = VectorDrawableCommon.obtainAttributes(r, theme, attrs, AndroidResources.styleable_VectorDrawablePath);
			updateStateFromTypedArray(a, parser);
			a.recycle();
		}

		void setFillAlpha(float fillAlpha) {
			mFillAlpha = fillAlpha;
		}

		void setFillColor(int fillColor) {
			mFillColor = fillColor;
		}

		void setStrokeAlpha(float strokeAlpha) {
			mStrokeAlpha = strokeAlpha;
		}

		void setStrokeColor(int strokeColor) {
			mStrokeColor = strokeColor;
		}

		void setStrokeWidth(float strokeWidth) {
			mStrokeWidth = strokeWidth;
		}

		void setTrimPathEnd(float trimPathEnd) {
			mTrimPathEnd = trimPathEnd;
		}

		void setTrimPathOffset(float trimPathOffset) {
			mTrimPathOffset = trimPathOffset;
		}

		void setTrimPathStart(float trimPathStart) {
			mTrimPathStart = trimPathStart;
		}
	}

	private static class VGroup {
		int mChangingConfigurations;
		final ArrayList<Object> mChildren;
		private String mGroupName;
		private final Matrix mLocalMatrix;
		private float mPivotX;
		private float mPivotY;
		float mRotate;
		private float mScaleX;
		private float mScaleY;
		private final Matrix mStackedMatrix;
		private int[] mThemeAttrs;
		private float mTranslateX;
		private float mTranslateY;

		public VGroup() {
			super();
			mStackedMatrix = new Matrix();
			mChildren = new ArrayList();
			mRotate = 0.0f;
			mPivotX = 0.0f;
			mPivotY = 0.0f;
			mScaleX = 1.0f;
			mScaleY = 1.0f;
			mTranslateX = 0.0f;
			mTranslateY = 0.0f;
			mLocalMatrix = new Matrix();
			mGroupName = null;
		}

		public VGroup(VectorDrawableCompat.VGroup copy, ArrayMap<String, Object> targetsMap) {
			super();
			mStackedMatrix = new Matrix();
			mChildren = new ArrayList();
			mRotate = 0.0f;
			mPivotX = 0.0f;
			mPivotY = 0.0f;
			mScaleX = 1.0f;
			mScaleY = 1.0f;
			mTranslateX = 0.0f;
			mTranslateY = 0.0f;
			mLocalMatrix = new Matrix();
			mGroupName = null;
			mRotate = copy.mRotate;
			mPivotX = copy.mPivotX;
			mPivotY = copy.mPivotY;
			mScaleX = copy.mScaleX;
			mScaleY = copy.mScaleY;
			mTranslateX = copy.mTranslateX;
			mTranslateY = copy.mTranslateY;
			mThemeAttrs = copy.mThemeAttrs;
			mGroupName = copy.mGroupName;
			mChangingConfigurations = copy.mChangingConfigurations;
			if (mGroupName != null) {
				targetsMap.put(mGroupName, this);
			}
			mLocalMatrix.set(copy.mLocalMatrix);
			ArrayList<Object> children = copy.mChildren;
			int i = LINEJOIN_MITER;
			while (i < children.size()) {
				Object copyChild = children.get(i);
				if (copyChild instanceof VectorDrawableCompat.VGroup) {
					mChildren.add(new VectorDrawableCompat.VGroup((VectorDrawableCompat.VGroup) copyChild, targetsMap));
				} else {
					VectorDrawableCompat.VPath newPath;
					if (copyChild instanceof VectorDrawableCompat.VFullPath) {
						newPath = new VectorDrawableCompat.VFullPath((VectorDrawableCompat.VFullPath) copyChild);
					} else if (copyChild instanceof VectorDrawableCompat.VClipPath) {
						newPath = new VectorDrawableCompat.VClipPath((VectorDrawableCompat.VClipPath) copyChild);
					} else {
						throw new IllegalStateException("Unknown object in the tree!");
					}
					mChildren.add(newPath);
					if (newPath.mPathName != null) {
						targetsMap.put(newPath.mPathName, newPath);
					}
				}
				i++;
			}
		}

		private void updateLocalMatrix() {
			mLocalMatrix.reset();
			mLocalMatrix.postTranslate(-mPivotX, -mPivotY);
			mLocalMatrix.postScale(mScaleX, mScaleY);
			mLocalMatrix.postRotate(mRotate, BitmapDescriptorFactory.HUE_RED, BitmapDescriptorFactory.HUE_RED);
			mLocalMatrix.postTranslate(mTranslateX + mPivotX, mTranslateY + mPivotY);
		}

		private void updateStateFromTypedArray(TypedArray a, XmlPullParser parser) {
			mThemeAttrs = null;
			mRotate = TypedArrayUtils.getNamedFloat(a, parser, "rotation", SQLiteCursor.FIELD_TYPE_NULL, mRotate);
			mPivotX = a.getFloat(LINEJOIN_ROUND, mPivotX);
			mPivotY = a.getFloat(LINEJOIN_BEVEL, mPivotY);
			mScaleX = TypedArrayUtils.getNamedFloat(a, parser, "scaleX", ConnectionsManager.ConnectionStateConnected, mScaleX);
			mScaleY = TypedArrayUtils.getNamedFloat(a, parser, "scaleY", TLRPC.USER_FLAG_LAST_NAME, mScaleY);
			mTranslateX = TypedArrayUtils.getNamedFloat(a, parser, "translateX", R.styleable.YearPicker_dp_textHighlightColor, mTranslateX);
			mTranslateY = TypedArrayUtils.getNamedFloat(a, parser, "translateY", AndroidUtilities.FLAG_TAG_ALL, mTranslateY);
			String groupName = a.getString(LINEJOIN_MITER);
			if (groupName != null) {
				mGroupName = groupName;
			}
			updateLocalMatrix();
		}

		public String getGroupName() {
			return mGroupName;
		}

		public Matrix getLocalMatrix() {
			return mLocalMatrix;
		}

		public float getPivotX() {
			return mPivotX;
		}

		public float getPivotY() {
			return mPivotY;
		}

		public float getRotation() {
			return mRotate;
		}

		public float getScaleX() {
			return mScaleX;
		}

		public float getScaleY() {
			return mScaleY;
		}

		public float getTranslateX() {
			return mTranslateX;
		}

		public float getTranslateY() {
			return mTranslateY;
		}

		public void inflate(Resources res, AttributeSet attrs, Theme theme, XmlPullParser parser) {
			TypedArray a = VectorDrawableCommon.obtainAttributes(res, theme, attrs, AndroidResources.styleable_VectorDrawableGroup);
			updateStateFromTypedArray(a, parser);
			a.recycle();
		}

		public void setPivotX(float pivotX) {
			if (pivotX != mPivotX) {
				mPivotX = pivotX;
				updateLocalMatrix();
			}
		}

		public void setPivotY(float pivotY) {
			if (pivotY != mPivotY) {
				mPivotY = pivotY;
				updateLocalMatrix();
			}
		}

		public void setRotation(float rotation) {
			if (rotation != mRotate) {
				mRotate = rotation;
				updateLocalMatrix();
			}
		}

		public void setScaleX(float scaleX) {
			if (scaleX != mScaleX) {
				mScaleX = scaleX;
				updateLocalMatrix();
			}
		}

		public void setScaleY(float scaleY) {
			if (scaleY != mScaleY) {
				mScaleY = scaleY;
				updateLocalMatrix();
			}
		}

		public void setTranslateX(float translateX) {
			if (translateX != mTranslateX) {
				mTranslateX = translateX;
				updateLocalMatrix();
			}
		}

		public void setTranslateY(float translateY) {
			if (translateY != mTranslateY) {
				mTranslateY = translateY;
				updateLocalMatrix();
			}
		}
	}

	private static class VPathRenderer {
		private static final Matrix IDENTITY_MATRIX;
		float mBaseHeight;
		float mBaseWidth;
		private int mChangingConfigurations;
		private Paint mFillPaint;
		private final Matrix mFinalPathMatrix;
		private final Path mPath;
		private PathMeasure mPathMeasure;
		private final Path mRenderPath;
		int mRootAlpha;
		final VectorDrawableCompat.VGroup mRootGroup;
		String mRootName;
		private Paint mStrokePaint;
		final ArrayMap<String, Object> mVGTargetsMap;
		float mViewportHeight;
		float mViewportWidth;

		static {
			IDENTITY_MATRIX = new Matrix();
		}

		public VPathRenderer() {
			super();
			mFinalPathMatrix = new Matrix();
			mBaseWidth = 0.0f;
			mBaseHeight = 0.0f;
			mViewportWidth = 0.0f;
			mViewportHeight = 0.0f;
			mRootAlpha = 255;
			mRootName = null;
			mVGTargetsMap = new ArrayMap();
			mRootGroup = new VectorDrawableCompat.VGroup();
			mPath = new Path();
			mRenderPath = new Path();
		}

		public VPathRenderer(VectorDrawableCompat.VPathRenderer copy) {
			super();
			mFinalPathMatrix = new Matrix();
			mBaseWidth = 0.0f;
			mBaseHeight = 0.0f;
			mViewportWidth = 0.0f;
			mViewportHeight = 0.0f;
			mRootAlpha = 255;
			mRootName = null;
			mVGTargetsMap = new ArrayMap();
			mRootGroup = new VectorDrawableCompat.VGroup(copy.mRootGroup, mVGTargetsMap);
			mPath = new Path(copy.mPath);
			mRenderPath = new Path(copy.mRenderPath);
			mBaseWidth = copy.mBaseWidth;
			mBaseHeight = copy.mBaseHeight;
			mViewportWidth = copy.mViewportWidth;
			mViewportHeight = copy.mViewportHeight;
			mChangingConfigurations = copy.mChangingConfigurations;
			mRootAlpha = copy.mRootAlpha;
			mRootName = copy.mRootName;
			if (copy.mRootName != null) {
				mVGTargetsMap.put(copy.mRootName, this);
			}
		}

		private static float cross(float v1x, float v1y, float v2x, float v2y) {
			return (v1x * v2y) - (v1y * v2x);
		}

		private void drawGroupTree(VectorDrawableCompat.VGroup currentGroup, Matrix currentMatrix, Canvas canvas, int w, int h, ColorFilter filter) {
			currentGroup.mStackedMatrix.set(currentMatrix);
			currentGroup.mStackedMatrix.preConcat(currentGroup.mLocalMatrix);
			canvas.save();
			int i = LINEJOIN_MITER;
			while (i < currentGroup.mChildren.size()) {
				Object child = currentGroup.mChildren.get(i);
				if (child instanceof VectorDrawableCompat.VGroup) {
					drawGroupTree((VectorDrawableCompat.VGroup) child, currentGroup.mStackedMatrix, canvas, w, h, filter);
				} else if (child instanceof VectorDrawableCompat.VPath) {
					drawPath(currentGroup, (VectorDrawableCompat.VPath) child, canvas, w, h, filter);
				}
				i++;
			}
			canvas.restore();
		}

		private void drawPath(VectorDrawableCompat.VGroup vGroup, VectorDrawableCompat.VPath vPath, Canvas canvas, int w, int h, ColorFilter filter) {
			float scaleX = ((float) w) / mViewportWidth;
			float scaleY = ((float) h) / mViewportHeight;
			float minScale = Math.min(scaleX, scaleY);
			Matrix groupStackedMatrix = vGroup.mStackedMatrix;
			mFinalPathMatrix.set(groupStackedMatrix);
			mFinalPathMatrix.postScale(scaleX, scaleY);
			float matrixScale = getMatrixScale(groupStackedMatrix);
			if (matrixScale == 0.0f) {
			} else {
				vPath.toPath(mPath);
				Path path = mPath;
				mRenderPath.reset();
				if (vPath.isClipPath()) {
					mRenderPath.addPath(path, mFinalPathMatrix);
					canvas.clipPath(mRenderPath);
				} else {
					VectorDrawableCompat.VFullPath fullPath = (VectorDrawableCompat.VFullPath) vPath;
					if (fullPath.mTrimPathStart != 0.0f || fullPath.mTrimPathEnd != 1.0f) {
						float start = (fullPath.mTrimPathStart + fullPath.mTrimPathOffset) % 1.0f;
						float end = (fullPath.mTrimPathEnd + fullPath.mTrimPathOffset) % 1.0f;
						if (mPathMeasure == null) {
							mPathMeasure = new PathMeasure();
						}
						mPathMeasure.setPath(mPath, DBG_VECTOR_DRAWABLE);
						float len = mPathMeasure.getLength();
						start *= len;
						end *= len;
						path.reset();
						if (start > end) {
							mPathMeasure.getSegment(start, len, path, true);
							mPathMeasure.getSegment(BitmapDescriptorFactory.HUE_RED, end, path, true);
						} else {
							mPathMeasure.getSegment(start, end, path, true);
						}
						path.rLineTo(BitmapDescriptorFactory.HUE_RED, BitmapDescriptorFactory.HUE_RED);
					} else {
						mRenderPath.addPath(path, mFinalPathMatrix);
					}
					mRenderPath.addPath(path, mFinalPathMatrix);
					if (fullPath.mFillColor != 0) {
						if (mFillPaint == null) {
							mFillPaint = new Paint();
							mFillPaint.setStyle(Style.FILL);
							mFillPaint.setAntiAlias(true);
						}
						Paint fillPaint = mFillPaint;
						fillPaint.setColor(VectorDrawableCompat.applyAlpha(fullPath.mFillColor, fullPath.mFillAlpha));
						fillPaint.setColorFilter(filter);
						canvas.drawPath(mRenderPath, fillPaint);
					}
					if (fullPath.mStrokeColor != 0) {
						if (mStrokePaint == null) {
							mStrokePaint = new Paint();
							mStrokePaint.setStyle(Style.STROKE);
							mStrokePaint.setAntiAlias(true);
						}
						Paint strokePaint = mStrokePaint;
						if (fullPath.mStrokeLineJoin != null) {
							strokePaint.setStrokeJoin(fullPath.mStrokeLineJoin);
						}
						if (fullPath.mStrokeLineCap != null) {
							strokePaint.setStrokeCap(fullPath.mStrokeLineCap);
						}
						strokePaint.setStrokeMiter(fullPath.mStrokeMiterlimit);
						strokePaint.setColor(VectorDrawableCompat.applyAlpha(fullPath.mStrokeColor, fullPath.mStrokeAlpha));
						strokePaint.setColorFilter(filter);
						strokePaint.setStrokeWidth(fullPath.mStrokeWidth * (minScale * matrixScale));
						canvas.drawPath(mRenderPath, strokePaint);
					}
				}
			}
		}

		private float getMatrixScale(Matrix groupStackedMatrix) {
			float[] unitVectors = new float[]{0.0f, 1.0f, 1.0f, 0.0f};
			groupStackedMatrix.mapVectors(unitVectors);
			float crossProduct = cross(unitVectors[0], unitVectors[1], unitVectors[2], unitVectors[3]);
			float maxScale = Math.max((float) Math.hypot((double) unitVectors[0], (double) unitVectors[1]), (float) Math.hypot((double) unitVectors[2], (double) unitVectors[3]));
			float matrixScale = BitmapDescriptorFactory.HUE_RED;
			if (maxScale > 0.0f) {
				matrixScale = Math.abs(crossProduct) / maxScale;
			}
			return matrixScale;
		}

		public void draw(Canvas canvas, int w, int h, ColorFilter filter) {
			drawGroupTree(mRootGroup, IDENTITY_MATRIX, canvas, w, h, filter);
		}

		public float getAlpha() {
			return ((float) getRootAlpha()) / 255.0f;
		}

		public int getRootAlpha() {
			return mRootAlpha;
		}

		public void setAlpha(float alpha) {
			setRootAlpha((int) (255.0f * alpha));
		}

		public void setRootAlpha(int alpha) {
			mRootAlpha = alpha;
		}
	}

	private static class VectorDrawableCompatState extends ConstantState {
		boolean mAutoMirrored;
		boolean mCacheDirty;
		boolean mCachedAutoMirrored;
		Bitmap mCachedBitmap;
		int mCachedRootAlpha;
		int[] mCachedThemeAttrs;
		ColorStateList mCachedTint;
		Mode mCachedTintMode;
		int mChangingConfigurations;
		Paint mTempPaint;
		ColorStateList mTint;
		Mode mTintMode;
		VectorDrawableCompat.VPathRenderer mVPathRenderer;

		public VectorDrawableCompatState() {
			super();
			mTint = null;
			mTintMode = DEFAULT_TINT_MODE;
			mVPathRenderer = new VectorDrawableCompat.VPathRenderer();
		}

		public VectorDrawableCompatState(VectorDrawableCompat.VectorDrawableCompatState copy) {
			super();
			mTint = null;
			mTintMode = DEFAULT_TINT_MODE;
			if (copy != null) {
				mChangingConfigurations = copy.mChangingConfigurations;
				mVPathRenderer = new VectorDrawableCompat.VPathRenderer(copy.mVPathRenderer);
				if (copy.mVPathRenderer.mFillPaint != null) {
					mVPathRenderer.mFillPaint = new Paint(copy.mVPathRenderer.mFillPaint);
				}
				if (copy.mVPathRenderer.mStrokePaint != null) {
					mVPathRenderer.mStrokePaint = new Paint(copy.mVPathRenderer.mStrokePaint);
				}
				mTint = copy.mTint;
				mTintMode = copy.mTintMode;
				mAutoMirrored = copy.mAutoMirrored;
			}
		}

		public boolean canReuseBitmap(int width, int height) {
			if (width != mCachedBitmap.getWidth() || height != mCachedBitmap.getHeight()) {
				return DBG_VECTOR_DRAWABLE;
			} else {
				return true;
			}
		}

		public boolean canReuseCache() {
			if (mCacheDirty || mCachedTint != mTint || mCachedTintMode != mTintMode || mCachedAutoMirrored != mAutoMirrored || mCachedRootAlpha != mVPathRenderer.getRootAlpha()) {
				return DBG_VECTOR_DRAWABLE;
			} else {
				return true;
			}
		}

		public void createCachedBitmapIfNeeded(int width, int height) {
			if (mCachedBitmap == null || !canReuseBitmap(width, height)) {
				mCachedBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
				mCacheDirty = true;
			}
		}

		public void drawCachedBitmapWithRootAlpha(Canvas canvas, ColorFilter filter, Rect originalBounds) {
			canvas.drawBitmap(mCachedBitmap, null, originalBounds, getPaint(filter));
		}

		public int getChangingConfigurations() {
			return mChangingConfigurations;
		}

		public Paint getPaint(ColorFilter filter) {
			if (hasTranslucentRoot() || filter != null) {
				if (mTempPaint == null) {
					mTempPaint = new Paint();
					mTempPaint.setFilterBitmap(true);
				}
				mTempPaint.setAlpha(mVPathRenderer.getRootAlpha());
				mTempPaint.setColorFilter(filter);
				return mTempPaint;
			} else {
				return null;
			}
		}

		public boolean hasTranslucentRoot() {
			if (mVPathRenderer.getRootAlpha() < 255) {
				return true;
			} else {
				return DBG_VECTOR_DRAWABLE;
			}
		}

		public Drawable newDrawable() {
			return new VectorDrawableCompat(this);
		}

		public Drawable newDrawable(Resources res) {
			return new VectorDrawableCompat(this);
		}

		public void updateCacheStates() {
			mCachedTint = mTint;
			mCachedTintMode = mTintMode;
			mCachedRootAlpha = mVPathRenderer.getRootAlpha();
			mCachedAutoMirrored = mAutoMirrored;
			mCacheDirty = false;
		}

		public void updateCachedBitmap(int width, int height) {
			mCachedBitmap.eraseColor(LINEJOIN_MITER);
			mVPathRenderer.draw(new Canvas(mCachedBitmap), width, height, null);
		}
	}

	private static class VectorDrawableDelegateState extends ConstantState {
		private final ConstantState mDelegateState;

		public VectorDrawableDelegateState(ConstantState state) {
			super();
			mDelegateState = state;
		}

		public boolean canApplyTheme() {
			return mDelegateState.canApplyTheme();
		}

		public int getChangingConfigurations() {
			return mDelegateState.getChangingConfigurations();
		}

		public Drawable newDrawable() {
			Drawable drawableCompat = new VectorDrawableCompat();
			drawableCompat.mDelegateDrawable = (VectorDrawable) mDelegateState.newDrawable();
			return drawableCompat;
		}

		public Drawable newDrawable(Resources res) {
			Drawable drawableCompat = new VectorDrawableCompat();
			drawableCompat.mDelegateDrawable = (VectorDrawable) mDelegateState.newDrawable(res);
			return drawableCompat;
		}

		public Drawable newDrawable(Resources res, Theme theme) {
			Drawable drawableCompat = new VectorDrawableCompat();
			drawableCompat.mDelegateDrawable = (VectorDrawable) mDelegateState.newDrawable(res, theme);
			return drawableCompat;
		}
	}


	static {
		DEFAULT_TINT_MODE = Mode.SRC_IN;
	}

	VectorDrawableCompat() {
		super();
		mAllowCaching = true;
		mTmpFloats = new float[9];
		mTmpMatrix = new Matrix();
		mTmpBounds = new Rect();
		mVectorState = new VectorDrawableCompatState();
	}

	VectorDrawableCompat(@NonNull VectorDrawableCompatState state) {
		super();
		mAllowCaching = true;
		mTmpFloats = new float[9];
		mTmpMatrix = new Matrix();
		mTmpBounds = new Rect();
		mVectorState = state;
		mTintFilter = updateTintFilter(mTintFilter, state.mTint, state.mTintMode);
	}

	static int applyAlpha(int color, float alpha) {
		return (color & 16777215) | (((int) (((float) Color.alpha(color)) * alpha)) << 24);
	}

	/* JADX WARNING: inconsistent code */
	/*
	@android.support.annotation.Nullable
	public static android.support.graphics.drawable.VectorDrawableCompat create(@android.support.annotation.NonNull android.content.res.Resources r8_res, @android.support.annotation.DrawableRes int r9_resId, @android.support.annotation.Nullable android.content.res.Resources.Theme r10_theme) {
		r7 = 2;
		r5 = android.os.Build.VERSION.SDK_INT;
		r6 = 23;
		if (r5 < r6) goto L_0x0020;
	L_0x0007:
		r1 = new android.support.graphics.drawable.VectorDrawableCompat;
		r1.<init>();
		r5 = android.support.v4.content.res.ResourcesCompat.getDrawable(r8_res, r9_resId, r10_theme);
		r1_drawable.mDelegateDrawable = r5;
		r5 = new android.support.graphics.drawable.VectorDrawableCompat$VectorDrawableDelegateState;
		r6 = r1_drawable.mDelegateDrawable;
		r6 = r6.getConstantState();
		r5.<init>(r6);
		r1_drawable.mCachedConstantStateDelegate = r5;
	L_0x001f:
		return r1_drawable;
	L_0x0020:
		r3 = r8_res.getXml(r9_resId);	 //Catch:{ XmlPullParserException -> 0x003b, IOException -> 0x004a }
		r0_attrs = android.util.Xml.asAttributeSet(r3_parser);	 //Catch:{ XmlPullParserException -> 0x003b, IOException -> 0x004a }
	L_0x0028:
		r4 = r3_parser.next();	 //Catch:{ XmlPullParserException -> 0x003b, IOException -> 0x004a }
		if (r4_type == r7) goto L_0x0031;
	L_0x002e:
		r5 = 1;
		if (r4_type != r5) goto L_0x0028;
	L_0x0031:
		if (r4_type == r7) goto L_0x0045;
	L_0x0033:
		r5 = new org.xmlpull.v1.XmlPullParserException;	 //Catch:{ XmlPullParserException -> 0x003b, IOException -> 0x004a }
		r6 = "No start tag found";
		r5.<init>(r6);	 //Catch:{ XmlPullParserException -> 0x003b, IOException -> 0x004a }
		throw r5;	 //Catch:{ XmlPullParserException -> 0x003b, IOException -> 0x004a }
	L_0x003b:
		r2 = move-exception;
		r5 = "VectorDrawableCompat";
		r6 = "parser error";
		android.util.Log.e(r5, r6, r2_e);
	L_0x0043:
		r1 = 0;
		goto L_0x001f;
	L_0x0045:
		r1 = createFromXmlInner(r8_res, r3_parser, r0_attrs, r10_theme);	 //Catch:{ XmlPullParserException -> 0x003b, IOException -> 0x004a }
		goto L_0x001f;
	L_0x004a:
		r2_e = move-exception;
		r5 = "VectorDrawableCompat";
		r6 = "parser error";
		android.util.Log.e(r5, r6, r2);
		goto L_0x0043;
	}
	*/
	@Nullable
	public static VectorDrawableCompat create(@NonNull Resources res, @DrawableRes int resId, @Nullable Theme theme) {
		if (VERSION.SDK_INT >= 23) {
			VectorDrawableCompat drawable = new VectorDrawableCompat();
			drawable.mDelegateDrawable = ResourcesCompat.getDrawable(res, resId, theme);
			drawable.mCachedConstantStateDelegate = new VectorDrawableDelegateState(drawable.mDelegateDrawable.getConstantState());
			return drawable;
		} else {
			XmlPullParser parser;
			AttributeSet attrs;
			int type;
			try {
				parser = res.getXml(resId);
				attrs = Xml.asAttributeSet(parser);
				do {
					type = parser.next();
					if (type != 2) {
					}
				} while (type != 1);
				if (type != 2) {
					throw new XmlPullParserException("No start tag found");
				} else {
					return createFromXmlInner(res, parser, attrs, theme);
				}
			} catch (XmlPullParserException e) {
				Log.e(LOGTAG, "parser error", e);
			} catch (IOException e_2) {
				Log.e(LOGTAG, "parser error", e_2);
			}
		}
	}

	public static VectorDrawableCompat createFromXmlInner(Resources r, XmlPullParser parser, AttributeSet attrs, Theme theme) throws XmlPullParserException, IOException {
		VectorDrawableCompat drawable = new VectorDrawableCompat();
		drawable.inflate(r, parser, attrs, theme);
		return drawable;
	}

	private void inflateInternal(Resources res, XmlPullParser parser, AttributeSet attrs, Theme theme) throws XmlPullParserException, IOException {
		VectorDrawableCompatState state = mVectorState;
		VPathRenderer pathRenderer = state.mVPathRenderer;
		boolean noPathTag = true;
		Stack<VGroup> groupStack = new Stack();
		groupStack.push(pathRenderer.mRootGroup);
		int eventType = parser.getEventType();
		while (eventType != 1) {
			if (eventType == 2) {
				String tagName = parser.getName();
				VGroup currentGroup = (VGroup) groupStack.peek();
				if (SHAPE_PATH.equals(tagName)) {
					VFullPath path = new VFullPath();
					path.inflate(res, attrs, theme, parser);
					currentGroup.mChildren.add(path);
					if (path.getPathName() != null) {
						pathRenderer.mVGTargetsMap.put(path.getPathName(), path);
					}
					noPathTag = DBG_VECTOR_DRAWABLE;
					state.mChangingConfigurations |= path.mChangingConfigurations;
				} else if (SHAPE_CLIP_PATH.equals(tagName)) {
					VClipPath path_2 = new VClipPath();
					path_2.inflate(res, attrs, theme, parser);
					currentGroup.mChildren.add(path_2);
					if (path_2.getPathName() != null) {
						pathRenderer.mVGTargetsMap.put(path_2.getPathName(), path_2);
					}
					state.mChangingConfigurations |= path_2.mChangingConfigurations;
				} else if (SHAPE_GROUP.equals(tagName)) {
					VGroup newChildGroup = new VGroup();
					newChildGroup.inflate(res, attrs, theme, parser);
					currentGroup.mChildren.add(newChildGroup);
					groupStack.push(newChildGroup);
					if (newChildGroup.getGroupName() != null) {
						pathRenderer.mVGTargetsMap.put(newChildGroup.getGroupName(), newChildGroup);
					}
					state.mChangingConfigurations |= newChildGroup.mChangingConfigurations;
				}
			} else if (eventType != 3 || !SHAPE_GROUP.equals(parser.getName())) {
				eventType = parser.next();
			} else {
				groupStack.pop();
			}
			eventType = parser.next();
		}
		if (noPathTag) {
			StringBuffer tag = new StringBuffer();
			if (tag.length() > 0) {
				tag.append(" or ");
			}
			tag.append(SHAPE_PATH);
			throw new XmlPullParserException("no " + tag + " defined");
		}
	}

	private boolean needMirroring() {
		return DBG_VECTOR_DRAWABLE;
	}

	private static Mode parseTintModeCompat(int value, Mode defaultMode) {
		switch(value) {
		case ConnectionsManager.ConnectionStateConnected:
			return Mode.SRC_OVER;
		case SQLiteCursor.FIELD_TYPE_NULL:
			return Mode.SRC_IN;
		case BuildConfig.VERSION_CODE:
			return Mode.SRC_ATOP;
		case R.styleable.View_android_minHeight:
			return Mode.MULTIPLY;
		case R.styleable.View_android_soundEffectsEnabled:
			return Mode.SCREEN;
		case TLRPC.USER_FLAG_PHONE:
			return Mode.ADD;
		}
		return defaultMode;
	}

	private void printGroupTree(VGroup currentGroup, int level) {
		String indent = org.telegram.messenger.BuildConfig.Base64EncodedPublicKey;
		int i = LINEJOIN_MITER;
		while (i < level) {
			indent = indent + "    ";
			i++;
		}
		Log.v(LOGTAG, indent + "current group is :" + currentGroup.getGroupName() + " rotation is " + currentGroup.mRotate);
		Log.v(LOGTAG, indent + "matrix is :" + currentGroup.getLocalMatrix().toString());
		i = LINEJOIN_MITER;
		while (i < currentGroup.mChildren.size()) {
			Object child = currentGroup.mChildren.get(i);
			if (child instanceof VGroup) {
				printGroupTree((VGroup) child, level + 1);
			} else {
				((VPath) child).printVPath(level + 1);
			}
			i++;
		}
	}

	private void updateStateFromTypedArray(TypedArray a, XmlPullParser parser) throws XmlPullParserException {
		VectorDrawableCompatState state = mVectorState;
		VPathRenderer pathRenderer = state.mVPathRenderer;
		state.mTintMode = parseTintModeCompat(TypedArrayUtils.getNamedInt(a, parser, "tintMode", R.styleable.YearPicker_dp_textHighlightColor, -1), Mode.SRC_IN);
		ColorStateList tint = a.getColorStateList(LINEJOIN_ROUND);
		if (tint != null) {
			state.mTint = tint;
		}
		state.mAutoMirrored = TypedArrayUtils.getNamedBoolean(a, parser, "autoMirrored", SQLiteCursor.FIELD_TYPE_NULL, state.mAutoMirrored);
		pathRenderer.mViewportWidth = TypedArrayUtils.getNamedFloat(a, parser, "viewportWidth", AndroidUtilities.FLAG_TAG_ALL, pathRenderer.mViewportWidth);
		pathRenderer.mViewportHeight = TypedArrayUtils.getNamedFloat(a, parser, "viewportHeight", TLRPC.USER_FLAG_USERNAME, pathRenderer.mViewportHeight);
		if (pathRenderer.mViewportWidth <= 0.0f) {
			throw new XmlPullParserException(a.getPositionDescription() + "<vector> tag requires viewportWidth > 0");
		} else if (pathRenderer.mViewportHeight <= 0.0f) {
			throw new XmlPullParserException(a.getPositionDescription() + "<vector> tag requires viewportHeight > 0");
		} else {
			pathRenderer.mBaseWidth = a.getDimension(ConnectionsManager.ConnectionStateConnected, pathRenderer.mBaseWidth);
			pathRenderer.mBaseHeight = a.getDimension(LINEJOIN_BEVEL, pathRenderer.mBaseHeight);
			if (pathRenderer.mBaseWidth <= 0.0f) {
				throw new XmlPullParserException(a.getPositionDescription() + "<vector> tag requires width > 0");
			} else if (pathRenderer.mBaseHeight <= 0.0f) {
				throw new XmlPullParserException(a.getPositionDescription() + "<vector> tag requires height > 0");
			} else {
				pathRenderer.setAlpha(TypedArrayUtils.getNamedFloat(a, parser, "alpha", TLRPC.USER_FLAG_LAST_NAME, pathRenderer.getAlpha()));
				String name = a.getString(LINEJOIN_MITER);
				if (name != null) {
					pathRenderer.mRootName = name;
					pathRenderer.mVGTargetsMap.put(name, pathRenderer);
				}
			}
		}
	}

	public /* bridge */ /* synthetic */ void applyTheme(Theme r1_Theme) {
		super.applyTheme(r1_Theme);
	}

	public boolean canApplyTheme() {
		if (mDelegateDrawable != null) {
			DrawableCompat.canApplyTheme(mDelegateDrawable);
		}
		return DBG_VECTOR_DRAWABLE;
	}

	public /* bridge */ /* synthetic */ void clearColorFilter() {
		super.clearColorFilter();
	}

	public void draw(Canvas canvas) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.draw(canvas);
		} else {
			copyBounds(mTmpBounds);
			if (mTmpBounds.width() <= 0 || mTmpBounds.height() <= 0) {
			} else {
				ColorFilter colorFilter;
				int scaledWidth;
				int scaledHeight;
				if (mColorFilter == null) {
					colorFilter = mTintFilter;
				} else {
					colorFilter = mColorFilter;
				}
				canvas.getMatrix(mTmpMatrix);
				mTmpMatrix.getValues(mTmpFloats);
				float canvasScaleX = Math.abs(mTmpFloats[0]);
				float canvasScaleY = Math.abs(mTmpFloats[4]);
				float canvasSkewY = Math.abs(mTmpFloats[3]);
				if (Math.abs(mTmpFloats[1]) != 0.0f || canvasSkewY != 0.0f) {
					canvasScaleX = 1.0f;
					canvasScaleY = 1.0f;
				} else {
					scaledWidth = Math.min(MAX_CACHED_BITMAP_SIZE, (int) (((float) mTmpBounds.width()) * canvasScaleX));
					scaledHeight = Math.min(MAX_CACHED_BITMAP_SIZE, (int) (((float) mTmpBounds.height()) * canvasScaleY));
				}
				scaledWidth = Math.min(MAX_CACHED_BITMAP_SIZE, (int) (((float) mTmpBounds.width()) * canvasScaleX));
				scaledHeight = Math.min(MAX_CACHED_BITMAP_SIZE, (int) (((float) mTmpBounds.height()) * canvasScaleY));
				if (scaledWidth <= 0 || scaledHeight <= 0) {
				} else {
					int saveCount = canvas.save();
					canvas.translate((float) mTmpBounds.left, (float) mTmpBounds.top);
					if (needMirroring()) {
						canvas.translate((float) mTmpBounds.width(), BitmapDescriptorFactory.HUE_RED);
						canvas.scale(Face.UNCOMPUTED_PROBABILITY, 1.0f);
					}
					mTmpBounds.offsetTo(LINEJOIN_MITER, LINEJOIN_MITER);
					mVectorState.createCachedBitmapIfNeeded(scaledWidth, scaledHeight);
					if (!mAllowCaching) {
						mVectorState.updateCachedBitmap(scaledWidth, scaledHeight);
					} else if (!mVectorState.canReuseCache()) {
						mVectorState.updateCachedBitmap(scaledWidth, scaledHeight);
						mVectorState.updateCacheStates();
					}
					mVectorState.drawCachedBitmapWithRootAlpha(canvas, colorFilter, mTmpBounds);
					canvas.restoreToCount(saveCount);
				}
			}
		}
	}

	public int getAlpha() {
		if (mDelegateDrawable != null) {
			return DrawableCompat.getAlpha(mDelegateDrawable);
		} else {
			return mVectorState.mVPathRenderer.getRootAlpha();
		}
	}

	public int getChangingConfigurations() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getChangingConfigurations();
		} else {
			return super.getChangingConfigurations() | mVectorState.getChangingConfigurations();
		}
	}

	public /* bridge */ /* synthetic */ ColorFilter getColorFilter() {
		return super.getColorFilter();
	}

	public ConstantState getConstantState() {
		if (mDelegateDrawable != null) {
			return new VectorDrawableDelegateState(mDelegateDrawable.getConstantState());
		} else {
			mVectorState.mChangingConfigurations = getChangingConfigurations();
			return mVectorState;
		}
	}

	public /* bridge */ /* synthetic */ Drawable getCurrent() {
		return super.getCurrent();
	}

	public int getIntrinsicHeight() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getIntrinsicHeight();
		} else {
			return (int) mVectorState.mVPathRenderer.mBaseHeight;
		}
	}

	public int getIntrinsicWidth() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getIntrinsicWidth();
		} else {
			return (int) mVectorState.mVPathRenderer.mBaseWidth;
		}
	}

	public /* bridge */ /* synthetic */ int getLayoutDirection() {
		return super.getLayoutDirection();
	}

	public /* bridge */ /* synthetic */ int getMinimumHeight() {
		return super.getMinimumHeight();
	}

	public /* bridge */ /* synthetic */ int getMinimumWidth() {
		return super.getMinimumWidth();
	}

	public int getOpacity() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.getOpacity();
		} else {
			return Constants.PRESET;
		}
	}

	public /* bridge */ /* synthetic */ boolean getPadding(Rect r2_Rect) {
		return super.getPadding(r2_Rect);
	}

	public float getPixelSize() {
		if ((mVectorState != null || mVectorState.mVPathRenderer != null) && mVectorState.mVPathRenderer.mBaseWidth != 0.0f && mVectorState.mVPathRenderer.mBaseHeight != 0.0f && mVectorState.mVPathRenderer.mViewportHeight != 0.0f && mVectorState.mVPathRenderer.mViewportWidth != 0.0f) {
			return Math.min(mVectorState.mVPathRenderer.mViewportWidth / mVectorState.mVPathRenderer.mBaseWidth, mVectorState.mVPathRenderer.mViewportHeight / mVectorState.mVPathRenderer.mBaseHeight);
		} else {
			return 1.0f;
		}
		return 1.0f;
	}

	public /* bridge */ /* synthetic */ int[] getState() {
		return super.getState();
	}

	Object getTargetByName(String name) {
		return mVectorState.mVPathRenderer.mVGTargetsMap.get(name);
	}

	public /* bridge */ /* synthetic */ Region getTransparentRegion() {
		return super.getTransparentRegion();
	}

	public void inflate(Resources res, XmlPullParser parser, AttributeSet attrs) throws XmlPullParserException, IOException {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.inflate(res, parser, attrs);
		} else {
			inflate(res, parser, attrs, null);
		}
	}

	public void inflate(Resources res, XmlPullParser parser, AttributeSet attrs, Theme theme) throws XmlPullParserException, IOException {
		if (mDelegateDrawable != null) {
			DrawableCompat.inflate(mDelegateDrawable, res, parser, attrs, theme);
		} else {
			VectorDrawableCompatState state = mVectorState;
			state.mVPathRenderer = new VPathRenderer();
			TypedArray a = obtainAttributes(res, theme, attrs, AndroidResources.styleable_VectorDrawableTypeArray);
			updateStateFromTypedArray(a, parser);
			a.recycle();
			state.mChangingConfigurations = getChangingConfigurations();
			state.mCacheDirty = true;
			inflateInternal(res, parser, attrs, theme);
			mTintFilter = updateTintFilter(mTintFilter, state.mTint, state.mTintMode);
		}
	}

	public void invalidateSelf() {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.invalidateSelf();
		} else {
			super.invalidateSelf();
		}
	}

	public /* bridge */ /* synthetic */ boolean isAutoMirrored() {
		return super.isAutoMirrored();
	}

	public boolean isStateful() {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.isStateful();
		} else {
			if (!super.isStateful()) {
				if (mVectorState == null || mVectorState.mTint == null || !mVectorState.mTint.isStateful()) {
					return DBG_VECTOR_DRAWABLE;
				}
			}
			return true;
		}
	}

	public /* bridge */ /* synthetic */ void jumpToCurrentState() {
		super.jumpToCurrentState();
	}

	public Drawable mutate() {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.mutate();
			return this;
		} else if (!mMutated) {
			if (super.mutate() == this) {
				mVectorState = new VectorDrawableCompatState(mVectorState);
				mMutated = true;
				return this;
			} else {
				return this;
			}
		} else {
			return this;
		}
	}

	protected void onBoundsChange(Rect bounds) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setBounds(bounds);
		}
	}

	protected boolean onStateChange(int[] stateSet) {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.setState(stateSet);
		} else {
			VectorDrawableCompatState state = mVectorState;
			if (state.mTint == null || state.mTintMode == null) {
				return DBG_VECTOR_DRAWABLE;
			} else {
				mTintFilter = updateTintFilter(mTintFilter, state.mTint, state.mTintMode);
				invalidateSelf();
				return true;
			}
		}
	}

	public void scheduleSelf(Runnable what, long when) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.scheduleSelf(what, when);
		} else {
			super.scheduleSelf(what, when);
		}
	}

	void setAllowCaching(boolean allowCaching) {
		mAllowCaching = allowCaching;
	}

	public void setAlpha(int alpha) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setAlpha(alpha);
		} else if (mVectorState.mVPathRenderer.getRootAlpha() != alpha) {
			mVectorState.mVPathRenderer.setRootAlpha(alpha);
			invalidateSelf();
		}
	}

	public /* bridge */ /* synthetic */ void setAutoMirrored(boolean r1z) {
		super.setAutoMirrored(r1z);
	}

	public /* bridge */ /* synthetic */ void setChangingConfigurations(int r1i) {
		super.setChangingConfigurations(r1i);
	}

	public /* bridge */ /* synthetic */ void setColorFilter(int r1i, Mode r2_Mode) {
		super.setColorFilter(r1i, r2_Mode);
	}

	public void setColorFilter(ColorFilter colorFilter) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.setColorFilter(colorFilter);
		} else {
			mColorFilter = colorFilter;
			invalidateSelf();
		}
	}

	public /* bridge */ /* synthetic */ void setFilterBitmap(boolean r1z) {
		super.setFilterBitmap(r1z);
	}

	public /* bridge */ /* synthetic */ void setHotspot(float r1f, float r2f) {
		super.setHotspot(r1f, r2f);
	}

	public /* bridge */ /* synthetic */ void setHotspotBounds(int r1i, int r2i, int r3i, int r4i) {
		super.setHotspotBounds(r1i, r2i, r3i, r4i);
	}

	public /* bridge */ /* synthetic */ boolean setState(int[] r2_int_A) {
		return super.setState(r2_int_A);
	}

	public void setTint(int tint) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setTint(mDelegateDrawable, tint);
		} else {
			setTintList(ColorStateList.valueOf(tint));
		}
	}

	public void setTintList(ColorStateList tint) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setTintList(mDelegateDrawable, tint);
		} else {
			VectorDrawableCompatState state = mVectorState;
			if (state.mTint != tint) {
				state.mTint = tint;
				mTintFilter = updateTintFilter(mTintFilter, tint, state.mTintMode);
				invalidateSelf();
			}
		}
	}

	public void setTintMode(Mode tintMode) {
		if (mDelegateDrawable != null) {
			DrawableCompat.setTintMode(mDelegateDrawable, tintMode);
		} else {
			VectorDrawableCompatState state = mVectorState;
			if (state.mTintMode != tintMode) {
				state.mTintMode = tintMode;
				mTintFilter = updateTintFilter(mTintFilter, state.mTint, tintMode);
				invalidateSelf();
			}
		}
	}

	public boolean setVisible(boolean visible, boolean restart) {
		if (mDelegateDrawable != null) {
			return mDelegateDrawable.setVisible(visible, restart);
		} else {
			return super.setVisible(visible, restart);
		}
	}

	public void unscheduleSelf(Runnable what) {
		if (mDelegateDrawable != null) {
			mDelegateDrawable.unscheduleSelf(what);
		} else {
			super.unscheduleSelf(what);
		}
	}

	PorterDuffColorFilter updateTintFilter(PorterDuffColorFilter tintFilter, ColorStateList tint, Mode tintMode) {
		if (tint == null || tintMode == null) {
			return null;
		} else {
			return new PorterDuffColorFilter(tint.getColorForState(getState(), LINEJOIN_MITER), tintMode);
		}
	}
}
