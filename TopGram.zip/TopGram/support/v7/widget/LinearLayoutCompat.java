package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.vision.face.Face;
import com.googlecode.mp4parser.authoring.tracks.h265.NalUnitTypes;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import org.telegram.SQLite.SQLiteCursor;
import org.telegram.tgnet.TLRPC;

public class LinearLayoutCompat extends ViewGroup {
	public static final int HORIZONTAL = 0;
	private static final int INDEX_BOTTOM = 2;
	private static final int INDEX_CENTER_VERTICAL = 0;
	private static final int INDEX_FILL = 3;
	private static final int INDEX_TOP = 1;
	public static final int SHOW_DIVIDER_BEGINNING = 1;
	public static final int SHOW_DIVIDER_END = 4;
	public static final int SHOW_DIVIDER_MIDDLE = 2;
	public static final int SHOW_DIVIDER_NONE = 0;
	public static final int VERTICAL = 1;
	private static final int VERTICAL_GRAVITY_COUNT = 4;
	private boolean mBaselineAligned;
	private int mBaselineAlignedChildIndex;
	private int mBaselineChildTop;
	private Drawable mDivider;
	private int mDividerHeight;
	private int mDividerPadding;
	private int mDividerWidth;
	private int mGravity;
	private int[] mMaxAscent;
	private int[] mMaxDescent;
	private int mOrientation;
	private int mShowDividers;
	private int mTotalLength;
	private boolean mUseLargestChild;
	private float mWeightSum;

	public static class LayoutParams extends MarginLayoutParams {
		public int gravity;
		public float weight;

		public LayoutParams(int width, int height) {
			super(width, height);
			gravity = -1;
			weight = 0.0f;
		}

		public LayoutParams(int width, int height, float weight) {
			super(width, height);
			gravity = -1;
			this.weight = weight;
		}

		public LayoutParams(Context c, AttributeSet attrs) {
			super(c, attrs);
			gravity = -1;
			TypedArray a = c.obtainStyledAttributes(attrs, R.styleable.LinearLayoutCompat_Layout);
			weight = a.getFloat(R.styleable.LinearLayoutCompat_Layout_android_layout_weight, BitmapDescriptorFactory.HUE_RED);
			gravity = a.getInt(R.styleable.LinearLayoutCompat_Layout_android_layout_gravity, -1);
			a.recycle();
		}

		public LayoutParams(LinearLayoutCompat.LayoutParams source) {
			super(source);
			gravity = -1;
			weight = source.weight;
			gravity = source.gravity;
		}

		public LayoutParams(android.view.ViewGroup.LayoutParams p) {
			super(p);
			gravity = -1;
		}

		public LayoutParams(MarginLayoutParams source) {
			super(source);
			gravity = -1;
		}
	}

	@Retention(RetentionPolicy.SOURCE)
	public static @interface DividerMode {
	}

	@Retention(RetentionPolicy.SOURCE)
	public static @interface OrientationMode {
	}


	public LinearLayoutCompat(Context context) {
		this(context, null);
	}

	public LinearLayoutCompat(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public LinearLayoutCompat(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		mBaselineAligned = true;
		mBaselineAlignedChildIndex = -1;
		mBaselineChildTop = 0;
		mGravity = 8388659;
		TintTypedArray a = TintTypedArray.obtainStyledAttributes(context, attrs, R.styleable.LinearLayoutCompat, defStyleAttr, SHOW_DIVIDER_NONE);
		int index = a.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
		if (index >= 0) {
			setOrientation(index);
		}
		index = a.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
		if (index >= 0) {
			setGravity(index);
		}
		boolean baselineAligned = a.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
		if (!baselineAligned) {
			setBaselineAligned(baselineAligned);
		}
		mWeightSum = a.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, Face.UNCOMPUTED_PROBABILITY);
		mBaselineAlignedChildIndex = a.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
		mUseLargestChild = a.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
		setDividerDrawable(a.getDrawable(R.styleable.LinearLayoutCompat_divider));
		mShowDividers = a.getInt(R.styleable.LinearLayoutCompat_showDividers, SHOW_DIVIDER_NONE);
		mDividerPadding = a.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, SHOW_DIVIDER_NONE);
		a.recycle();
	}

	private void forceUniformHeight(int count, int widthMeasureSpec) {
		int uniformMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
		int i = SHOW_DIVIDER_NONE;
		while (i < count) {
			View child = getVirtualChildAt(i);
			if (child.getVisibility() != 8) {
				LayoutParams lp = (LayoutParams) child.getLayoutParams();
				if (lp.height == -1) {
					lp.width = child.getMeasuredWidth();
					measureChildWithMargins(child, widthMeasureSpec, SHOW_DIVIDER_NONE, uniformMeasureSpec, 0);
					lp.width = lp.width;
				}
			}
			i++;
		}
	}

	private void forceUniformWidth(int count, int heightMeasureSpec) {
		int uniformMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
		int i = SHOW_DIVIDER_NONE;
		while (i < count) {
			View child = getVirtualChildAt(i);
			if (child.getVisibility() != 8) {
				LayoutParams lp = (LayoutParams) child.getLayoutParams();
				if (lp.width == -1) {
					lp.height = child.getMeasuredHeight();
					measureChildWithMargins(child, uniformMeasureSpec, SHOW_DIVIDER_NONE, heightMeasureSpec, 0);
					lp.height = lp.height;
				}
			}
			i++;
		}
	}

	private void setChildFrame(View child, int left, int top, int width, int height) {
		child.layout(left, top, left + width, top + height);
	}

	protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams p) {
		return p instanceof LayoutParams;
	}

	void drawDividersHorizontal(Canvas canvas) {
		View child;
		LayoutParams lp;
		int position;
		int count = getVirtualChildCount();
		boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
		int i = SHOW_DIVIDER_NONE;
		while (i < count) {
			child = getVirtualChildAt(i);
			if (child == null || child.getVisibility() == 8 || !hasDividerBeforeChildAt(i)) {
				i++;
			} else {
				lp = (LayoutParams) child.getLayoutParams();
				if (isLayoutRtl) {
					position = child.getRight() + lp.rightMargin;
				} else {
					position = (child.getLeft() - lp.leftMargin) - mDividerWidth;
				}
				drawVerticalDivider(canvas, position);
				i++;
			}
		}
		if (hasDividerBeforeChildAt(count)) {
			child = getVirtualChildAt(count - 1);
			if (child == null) {
				if (isLayoutRtl) {
					position = getPaddingLeft();
				} else {
					position = (getWidth() - getPaddingRight()) - mDividerWidth;
				}
			} else {
				lp = (LayoutParams) child.getLayoutParams();
				if (isLayoutRtl) {
					position = (child.getLeft() - lp.leftMargin) - mDividerWidth;
				} else {
					position = child.getRight() + lp.rightMargin;
				}
			}
			drawVerticalDivider(canvas, position);
		}
	}

	void drawDividersVertical(Canvas canvas) {
		View child;
		int count = getVirtualChildCount();
		int i = SHOW_DIVIDER_NONE;
		while (i < count) {
			child = getVirtualChildAt(i);
			if (child == null || child.getVisibility() == 8 || !hasDividerBeforeChildAt(i)) {
				i++;
			} else {
				drawHorizontalDivider(canvas, (child.getTop() - ((LayoutParams) child.getLayoutParams()).topMargin) - mDividerHeight);
				i++;
			}
		}
		if (hasDividerBeforeChildAt(count)) {
			int bottom;
			child = getVirtualChildAt(count - 1);
			if (child == null) {
				bottom = (getHeight() - getPaddingBottom()) - mDividerHeight;
			} else {
				bottom = child.getBottom() + ((LayoutParams) child.getLayoutParams()).bottomMargin;
			}
			drawHorizontalDivider(canvas, bottom);
		}
	}

	void drawHorizontalDivider(Canvas canvas, int top) {
		mDivider.setBounds(getPaddingLeft() + mDividerPadding, top, (getWidth() - getPaddingRight()) - mDividerPadding, mDividerHeight + top);
		mDivider.draw(canvas);
	}

	void drawVerticalDivider(Canvas canvas, int left) {
		mDivider.setBounds(left, getPaddingTop() + mDividerPadding, mDividerWidth + left, (getHeight() - getPaddingBottom()) - mDividerPadding);
		mDivider.draw(canvas);
	}

	protected LayoutParams generateDefaultLayoutParams() {
		if (mOrientation == 0) {
			return new LayoutParams(-2, -2);
		} else if (mOrientation == 1) {
			return new LayoutParams(-1, -2);
		} else {
			return null;
		}
	}

	public LayoutParams generateLayoutParams(AttributeSet attrs) {
		return new LayoutParams(getContext(), attrs);
	}

	protected LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams p) {
		return new LayoutParams(p);
	}

	public int getBaseline() {
		if (mBaselineAlignedChildIndex < 0) {
			return super.getBaseline();
		} else if (getChildCount() <= mBaselineAlignedChildIndex) {
			throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
		} else {
			View child = getChildAt(mBaselineAlignedChildIndex);
			int childBaseline = child.getBaseline();
			if (childBaseline == -1) {
				if (mBaselineAlignedChildIndex != 0) {
					throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
				} else {
					return -1;
				}
			} else {
				int childTop = mBaselineChildTop;
				if (mOrientation == 1) {
					int majorGravity = mGravity & 112;
					if (majorGravity != NalUnitTypes.NAL_TYPE_UNSPEC48) {
						switch(majorGravity) {
						case TLRPC.USER_FLAG_PHONE:
							childTop += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - mTotalLength) / 2;
							break;
						case R.styleable.AppCompatTheme_panelMenuListWidth:
							childTop = ((getBottom() - getTop()) - getPaddingBottom()) - mTotalLength;
							break;
						}
					}
				}
				return (((LayoutParams) child.getLayoutParams()).topMargin + childTop) + childBaseline;
			}
		}
	}

	public int getBaselineAlignedChildIndex() {
		return mBaselineAlignedChildIndex;
	}

	int getChildrenSkipCount(View child, int index) {
		return SHOW_DIVIDER_NONE;
	}

	public Drawable getDividerDrawable() {
		return mDivider;
	}

	public int getDividerPadding() {
		return mDividerPadding;
	}

	public int getDividerWidth() {
		return mDividerWidth;
	}

	int getLocationOffset(View child) {
		return SHOW_DIVIDER_NONE;
	}

	int getNextLocationOffset(View child) {
		return SHOW_DIVIDER_NONE;
	}

	public int getOrientation() {
		return mOrientation;
	}

	public int getShowDividers() {
		return mShowDividers;
	}

	View getVirtualChildAt(int index) {
		return getChildAt(index);
	}

	int getVirtualChildCount() {
		return getChildCount();
	}

	public float getWeightSum() {
		return mWeightSum;
	}

	protected boolean hasDividerBeforeChildAt(int childIndex) {
		if (childIndex == 0) {
			if ((mShowDividers & 1) != 0) {
				return true;
			} else {
				return false;
			}
		} else if (childIndex == getChildCount()) {
			if ((mShowDividers & 4) == 0) {
				return false;
			} else {
				return true;
			}
		} else if ((mShowDividers & 2) != 0) {
			boolean hasVisibleViewBefore = false;
			int i = childIndex - 1;
			while (i >= 0) {
				if (getChildAt(i).getVisibility() != 8) {
					hasVisibleViewBefore = true;
				} else {
					i--;
				}
			}
			return hasVisibleViewBefore;
		} else {
			return false;
		}
	}

	public boolean isBaselineAligned() {
		return mBaselineAligned;
	}

	public boolean isMeasureWithLargestChildEnabled() {
		return mUseLargestChild;
	}

	void layoutHorizontal(int left, int top, int right, int bottom) {
		int childLeft;
		int start;
		int dir;
		int i;
		int childIndex;
		View child;
		int childWidth;
		int childHeight;
		int childBaseline;
		LayoutParams lp;
		int gravity;
		int childTop;
		boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
		int paddingTop = getPaddingTop();
		int height = bottom - top;
		int childBottom = height - getPaddingBottom();
		int childSpace = (height - paddingTop) - getPaddingBottom();
		int count = getVirtualChildCount();
		int minorGravity = mGravity & 112;
		boolean baselineAligned = mBaselineAligned;
		int[] maxAscent = mMaxAscent;
		int[] maxDescent = mMaxDescent;
		switch(GravityCompat.getAbsoluteGravity(mGravity & 8388615, ViewCompat.getLayoutDirection(this))) {
		case VERTICAL:
			childLeft = getPaddingLeft() + (((right - left) - mTotalLength) / 2);
			start = SHOW_DIVIDER_NONE;
			dir = VERTICAL;
			if (isLayoutRtl) {
				start = count - 1;
				dir = -1;
			}
			i = SHOW_DIVIDER_NONE;
			while (i < count) {
				childIndex = start + (dir * i);
				child = getVirtualChildAt(childIndex);
				if (child != null) {
					childLeft += measureNullChild(childIndex);
				} else if (child.getVisibility() == 8) {
					childWidth = child.getMeasuredWidth();
					childHeight = child.getMeasuredHeight();
					childBaseline = -1;
					lp = (LayoutParams) child.getLayoutParams();
					if (!baselineAligned || lp.height == -1) {
						gravity = lp.gravity;
						if (gravity >= 0) {
							gravity = minorGravity;
						}
						switch((gravity & 112)) {
						case TLRPC.USER_FLAG_PHONE:
							childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += mDividerWidth;
							}
							childLeft += lp.leftMargin;
							setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
							i += getChildrenSkipCount(child, childIndex);
							break;
						case NalUnitTypes.NAL_TYPE_UNSPEC48:
							childTop = paddingTop + lp.topMargin;
							if (childBaseline == -1) {
								childTop += maxAscent[1] - childBaseline;
							}
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							} else {
								childLeft += mDividerWidth;
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							}
							break;
						case R.styleable.AppCompatTheme_panelMenuListWidth:
							childTop = (childBottom - childHeight) - lp.bottomMargin;
							if (childBaseline == -1) {
								childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
							}
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += mDividerWidth;
							}
							childLeft += lp.leftMargin;
							setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
							i += getChildrenSkipCount(child, childIndex);
							break;
						}
						childTop = paddingTop;
						if (!hasDividerBeforeChildAt(childIndex)) {
							childLeft += lp.leftMargin;
							setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
							i += getChildrenSkipCount(child, childIndex);
						} else {
							childLeft += mDividerWidth;
							childLeft += lp.leftMargin;
							setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
							i += getChildrenSkipCount(child, childIndex);
						}
					} else {
						childBaseline = child.getBaseline();
						gravity = lp.gravity;
						if (gravity >= 0) {
							switch((gravity & 112)) {
							case TLRPC.USER_FLAG_PHONE:
								childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
								break;
							case NalUnitTypes.NAL_TYPE_UNSPEC48:
								childTop = paddingTop + lp.topMargin;
								if (childBaseline == -1) {
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									} else {
										childLeft += mDividerWidth;
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
								} else {
									childTop += maxAscent[1] - childBaseline;
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += mDividerWidth;
									}
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
								break;
							case R.styleable.AppCompatTheme_panelMenuListWidth:
								childTop = (childBottom - childHeight) - lp.bottomMargin;
								if (childBaseline == -1) {
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									} else {
										childLeft += mDividerWidth;
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
								} else {
									childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += mDividerWidth;
									}
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
								break;
							}
							childTop = paddingTop;
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							} else {
								childLeft += mDividerWidth;
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							}
						} else {
							gravity = minorGravity;
							switch((gravity & 112)) {
							case TLRPC.USER_FLAG_PHONE:
								childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
								break;
							case NalUnitTypes.NAL_TYPE_UNSPEC48:
								childTop = paddingTop + lp.topMargin;
								if (childBaseline == -1) {
									childTop += maxAscent[1] - childBaseline;
								}
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								} else {
									childLeft += mDividerWidth;
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
								break;
							case R.styleable.AppCompatTheme_panelMenuListWidth:
								childTop = (childBottom - childHeight) - lp.bottomMargin;
								if (childBaseline == -1) {
									childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
								}
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
								break;
							}
							childTop = paddingTop;
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							} else {
								childLeft += mDividerWidth;
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							}
						}
					}
				}
				i++;
			}
			break;
		case SQLiteCursor.FIELD_TYPE_NULL:
			childLeft = ((getPaddingLeft() + right) - left) - mTotalLength;
			start = SHOW_DIVIDER_NONE;
			dir = VERTICAL;
			if (isLayoutRtl) {
				i = SHOW_DIVIDER_NONE;
				while (i < count) {
					childIndex = start + (dir * i);
					child = getVirtualChildAt(childIndex);
					if (child != null) {
						if (child.getVisibility() == 8) {
							i++;
						} else {
							childWidth = child.getMeasuredWidth();
							childHeight = child.getMeasuredHeight();
							childBaseline = -1;
							lp = (LayoutParams) child.getLayoutParams();
							if (!baselineAligned || lp.height == -1) {
								gravity = lp.gravity;
								if (gravity >= 0) {
									gravity = minorGravity;
								}
								switch((gravity & 112)) {
								case TLRPC.USER_FLAG_PHONE:
									childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += mDividerWidth;
									}
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
									break;
								case NalUnitTypes.NAL_TYPE_UNSPEC48:
									childTop = paddingTop + lp.topMargin;
									if (childBaseline == -1) {
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										} else {
											childLeft += mDividerWidth;
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										}
									} else {
										childTop += maxAscent[1] - childBaseline;
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += mDividerWidth;
										}
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
									break;
								case R.styleable.AppCompatTheme_panelMenuListWidth:
									childTop = (childBottom - childHeight) - lp.bottomMargin;
									if (childBaseline == -1) {
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										} else {
											childLeft += mDividerWidth;
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										}
									} else {
										childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += mDividerWidth;
										}
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
									break;
								}
								childTop = paddingTop;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								} else {
									childLeft += mDividerWidth;
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
							} else {
								childBaseline = child.getBaseline();
								gravity = lp.gravity;
								if (gravity >= 0) {
									switch((gravity & 112)) {
									case TLRPC.USER_FLAG_PHONE:
										childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += mDividerWidth;
										}
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
										break;
									case NalUnitTypes.NAL_TYPE_UNSPEC48:
										childTop = paddingTop + lp.topMargin;
										if (childBaseline == -1) {
											childTop += maxAscent[1] - childBaseline;
										}
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										} else {
											childLeft += mDividerWidth;
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										}
										break;
									case R.styleable.AppCompatTheme_panelMenuListWidth:
										childTop = (childBottom - childHeight) - lp.bottomMargin;
										if (childBaseline == -1) {
											childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
										}
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += mDividerWidth;
										}
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
										break;
									}
									childTop = paddingTop;
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									} else {
										childLeft += mDividerWidth;
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
								} else {
									gravity = minorGravity;
									switch((gravity & 112)) {
									case TLRPC.USER_FLAG_PHONE:
										childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += mDividerWidth;
										}
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
										break;
									case NalUnitTypes.NAL_TYPE_UNSPEC48:
										childTop = paddingTop + lp.topMargin;
										if (childBaseline == -1) {
											if (!hasDividerBeforeChildAt(childIndex)) {
												childLeft += lp.leftMargin;
												setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
												i += getChildrenSkipCount(child, childIndex);
											} else {
												childLeft += mDividerWidth;
												childLeft += lp.leftMargin;
												setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
												i += getChildrenSkipCount(child, childIndex);
											}
										} else {
											childTop += maxAscent[1] - childBaseline;
											if (!hasDividerBeforeChildAt(childIndex)) {
												childLeft += mDividerWidth;
											}
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										}
										break;
									case R.styleable.AppCompatTheme_panelMenuListWidth:
										childTop = (childBottom - childHeight) - lp.bottomMargin;
										if (childBaseline == -1) {
											if (!hasDividerBeforeChildAt(childIndex)) {
												childLeft += lp.leftMargin;
												setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
												i += getChildrenSkipCount(child, childIndex);
											} else {
												childLeft += mDividerWidth;
												childLeft += lp.leftMargin;
												setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
												i += getChildrenSkipCount(child, childIndex);
											}
										} else {
											childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
											if (!hasDividerBeforeChildAt(childIndex)) {
												childLeft += mDividerWidth;
											}
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										}
										break;
									}
									childTop = paddingTop;
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									} else {
										childLeft += mDividerWidth;
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
								}
							}
						}
					} else {
						childLeft += measureNullChild(childIndex);
					}
					i++;
				}
			} else {
				start = count - 1;
				dir = -1;
				i = SHOW_DIVIDER_NONE;
				while (i < count) {
					childIndex = start + (dir * i);
					child = getVirtualChildAt(childIndex);
					if (child != null) {
						childLeft += measureNullChild(childIndex);
					} else if (child.getVisibility() == 8) {
						childWidth = child.getMeasuredWidth();
						childHeight = child.getMeasuredHeight();
						childBaseline = -1;
						lp = (LayoutParams) child.getLayoutParams();
						if (!baselineAligned || lp.height == -1) {
							gravity = lp.gravity;
							if (gravity >= 0) {
								gravity = minorGravity;
							}
							switch((gravity & 112)) {
							case TLRPC.USER_FLAG_PHONE:
								childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
								break;
							case NalUnitTypes.NAL_TYPE_UNSPEC48:
								childTop = paddingTop + lp.topMargin;
								if (childBaseline == -1) {
									childTop += maxAscent[1] - childBaseline;
								}
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								} else {
									childLeft += mDividerWidth;
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
								break;
							case R.styleable.AppCompatTheme_panelMenuListWidth:
								childTop = (childBottom - childHeight) - lp.bottomMargin;
								if (childBaseline == -1) {
									childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
								}
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
								break;
							}
							childTop = paddingTop;
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							} else {
								childLeft += mDividerWidth;
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							}
						} else {
							childBaseline = child.getBaseline();
							gravity = lp.gravity;
							if (gravity >= 0) {
								switch((gravity & 112)) {
								case TLRPC.USER_FLAG_PHONE:
									childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += mDividerWidth;
									}
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
									break;
								case NalUnitTypes.NAL_TYPE_UNSPEC48:
									childTop = paddingTop + lp.topMargin;
									if (childBaseline == -1) {
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										} else {
											childLeft += mDividerWidth;
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										}
									} else {
										childTop += maxAscent[1] - childBaseline;
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += mDividerWidth;
										}
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
									break;
								case R.styleable.AppCompatTheme_panelMenuListWidth:
									childTop = (childBottom - childHeight) - lp.bottomMargin;
									if (childBaseline == -1) {
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										} else {
											childLeft += mDividerWidth;
											childLeft += lp.leftMargin;
											setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
											i += getChildrenSkipCount(child, childIndex);
										}
									} else {
										childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
										if (!hasDividerBeforeChildAt(childIndex)) {
											childLeft += mDividerWidth;
										}
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
									break;
								}
								childTop = paddingTop;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								} else {
									childLeft += mDividerWidth;
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
							} else {
								gravity = minorGravity;
								switch((gravity & 112)) {
								case TLRPC.USER_FLAG_PHONE:
									childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += mDividerWidth;
									}
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
									break;
								case NalUnitTypes.NAL_TYPE_UNSPEC48:
									childTop = paddingTop + lp.topMargin;
									if (childBaseline == -1) {
										childTop += maxAscent[1] - childBaseline;
									}
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									} else {
										childLeft += mDividerWidth;
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
									break;
								case R.styleable.AppCompatTheme_panelMenuListWidth:
									childTop = (childBottom - childHeight) - lp.bottomMargin;
									if (childBaseline == -1) {
										childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
									}
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += mDividerWidth;
									}
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
									break;
								}
								childTop = paddingTop;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								} else {
									childLeft += mDividerWidth;
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
							}
						}
					}
					i++;
				}
			}
			break;
		}
		childLeft = getPaddingLeft();
		start = SHOW_DIVIDER_NONE;
		dir = VERTICAL;
		if (isLayoutRtl) {
			start = count - 1;
			dir = -1;
		}
		i = SHOW_DIVIDER_NONE;
		while (i < count) {
			childIndex = start + (dir * i);
			child = getVirtualChildAt(childIndex);
			if (child != null) {
				if (child.getVisibility() == 8) {
					i++;
				} else {
					childWidth = child.getMeasuredWidth();
					childHeight = child.getMeasuredHeight();
					childBaseline = -1;
					lp = (LayoutParams) child.getLayoutParams();
					if (!baselineAligned || lp.height == -1) {
						gravity = lp.gravity;
						if (gravity >= 0) {
							gravity = minorGravity;
						}
						switch((gravity & 112)) {
						case TLRPC.USER_FLAG_PHONE:
							childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += mDividerWidth;
							}
							childLeft += lp.leftMargin;
							setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
							i += getChildrenSkipCount(child, childIndex);
							break;
						case NalUnitTypes.NAL_TYPE_UNSPEC48:
							childTop = paddingTop + lp.topMargin;
							if (childBaseline == -1) {
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								} else {
									childLeft += mDividerWidth;
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
							} else {
								childTop += maxAscent[1] - childBaseline;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							}
							break;
						case R.styleable.AppCompatTheme_panelMenuListWidth:
							childTop = (childBottom - childHeight) - lp.bottomMargin;
							if (childBaseline == -1) {
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								} else {
									childLeft += mDividerWidth;
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
							} else {
								childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							}
							break;
						}
						childTop = paddingTop;
						if (!hasDividerBeforeChildAt(childIndex)) {
							childLeft += lp.leftMargin;
							setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
							i += getChildrenSkipCount(child, childIndex);
						} else {
							childLeft += mDividerWidth;
							childLeft += lp.leftMargin;
							setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
							i += getChildrenSkipCount(child, childIndex);
						}
					} else {
						childBaseline = child.getBaseline();
						gravity = lp.gravity;
						if (gravity >= 0) {
							switch((gravity & 112)) {
							case TLRPC.USER_FLAG_PHONE:
								childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
								break;
							case NalUnitTypes.NAL_TYPE_UNSPEC48:
								childTop = paddingTop + lp.topMargin;
								if (childBaseline == -1) {
									childTop += maxAscent[1] - childBaseline;
								}
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								} else {
									childLeft += mDividerWidth;
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
								break;
							case R.styleable.AppCompatTheme_panelMenuListWidth:
								childTop = (childBottom - childHeight) - lp.bottomMargin;
								if (childBaseline == -1) {
									childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
								}
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
								break;
							}
							childTop = paddingTop;
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							} else {
								childLeft += mDividerWidth;
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							}
						} else {
							gravity = minorGravity;
							switch((gravity & 112)) {
							case TLRPC.USER_FLAG_PHONE:
								childTop = ((((childSpace - childHeight) / 2) + paddingTop) + lp.topMargin) - lp.bottomMargin;
								if (!hasDividerBeforeChildAt(childIndex)) {
									childLeft += mDividerWidth;
								}
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
								break;
							case NalUnitTypes.NAL_TYPE_UNSPEC48:
								childTop = paddingTop + lp.topMargin;
								if (childBaseline == -1) {
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									} else {
										childLeft += mDividerWidth;
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
								} else {
									childTop += maxAscent[1] - childBaseline;
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += mDividerWidth;
									}
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
								break;
							case R.styleable.AppCompatTheme_panelMenuListWidth:
								childTop = (childBottom - childHeight) - lp.bottomMargin;
								if (childBaseline == -1) {
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									} else {
										childLeft += mDividerWidth;
										childLeft += lp.leftMargin;
										setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
										i += getChildrenSkipCount(child, childIndex);
									}
								} else {
									childTop -= maxDescent[2] - (child.getMeasuredHeight() - childBaseline);
									if (!hasDividerBeforeChildAt(childIndex)) {
										childLeft += mDividerWidth;
									}
									childLeft += lp.leftMargin;
									setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
									i += getChildrenSkipCount(child, childIndex);
								}
								break;
							}
							childTop = paddingTop;
							if (!hasDividerBeforeChildAt(childIndex)) {
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							} else {
								childLeft += mDividerWidth;
								childLeft += lp.leftMargin;
								setChildFrame(child, childLeft + getLocationOffset(child), childTop, childWidth, childHeight);
								i += getChildrenSkipCount(child, childIndex);
							}
						}
					}
				}
			} else {
				childLeft += measureNullChild(childIndex);
			}
			i++;
		}
	}

	void layoutVertical(int left, int top, int right, int bottom) {
		int childTop;
		int i;
		View child;
		int childWidth;
		int childHeight;
		LayoutParams lp;
		int gravity;
		int childLeft;
		int paddingLeft = getPaddingLeft();
		int width = right - left;
		int childRight = width - getPaddingRight();
		int childSpace = (width - paddingLeft) - getPaddingRight();
		int count = getVirtualChildCount();
		int minorGravity = mGravity & 8388615;
		switch((mGravity & 112)) {
		case TLRPC.USER_FLAG_PHONE:
			childTop = getPaddingTop() + (((bottom - top) - mTotalLength) / 2);
			i = SHOW_DIVIDER_NONE;
			while (i < count) {
				child = getVirtualChildAt(i);
				if (child == null) {
					childTop += measureNullChild(i);
				} else if (child.getVisibility() != 8) {
					childWidth = child.getMeasuredWidth();
					childHeight = child.getMeasuredHeight();
					lp = (LayoutParams) child.getLayoutParams();
					gravity = lp.gravity;
					if (gravity < 0) {
						gravity = minorGravity;
					}
					switch((GravityCompat.getAbsoluteGravity(gravity, ViewCompat.getLayoutDirection(this)) & 7)) {
					case VERTICAL:
						childLeft = ((((childSpace - childWidth) / 2) + paddingLeft) + lp.leftMargin) - lp.rightMargin;
						if (!hasDividerBeforeChildAt(i)) {
							childTop += mDividerHeight;
						}
						childTop += lp.topMargin;
						setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
						i += getChildrenSkipCount(child, i);
						break;
					case SQLiteCursor.FIELD_TYPE_NULL:
						childLeft = (childRight - childWidth) - lp.rightMargin;
						if (!hasDividerBeforeChildAt(i)) {
							childTop += lp.topMargin;
							setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
							i += getChildrenSkipCount(child, i);
						} else {
							childTop += mDividerHeight;
							childTop += lp.topMargin;
							setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
							i += getChildrenSkipCount(child, i);
						}
						break;
					}
					childLeft = paddingLeft + lp.leftMargin;
					if (!hasDividerBeforeChildAt(i)) {
						childTop += mDividerHeight;
					}
					childTop += lp.topMargin;
					setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
					i += getChildrenSkipCount(child, i);
				}
				i++;
			}
			break;
		case R.styleable.AppCompatTheme_panelMenuListWidth:
			childTop = ((getPaddingTop() + bottom) - top) - mTotalLength;
			i = SHOW_DIVIDER_NONE;
			while (i < count) {
				child = getVirtualChildAt(i);
				if (child == null) {
					if (child.getVisibility() != 8) {
						i++;
					} else {
						childWidth = child.getMeasuredWidth();
						childHeight = child.getMeasuredHeight();
						lp = (LayoutParams) child.getLayoutParams();
						gravity = lp.gravity;
						if (gravity < 0) {
							switch((GravityCompat.getAbsoluteGravity(gravity, ViewCompat.getLayoutDirection(this)) & 7)) {
							case VERTICAL:
								childLeft = ((((childSpace - childWidth) / 2) + paddingLeft) + lp.leftMargin) - lp.rightMargin;
								if (!hasDividerBeforeChildAt(i)) {
									childTop += lp.topMargin;
									setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
									i += getChildrenSkipCount(child, i);
								} else {
									childTop += mDividerHeight;
									childTop += lp.topMargin;
									setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
									i += getChildrenSkipCount(child, i);
								}
								break;
							case SQLiteCursor.FIELD_TYPE_NULL:
								childLeft = (childRight - childWidth) - lp.rightMargin;
								if (!hasDividerBeforeChildAt(i)) {
									childTop += mDividerHeight;
								}
								childTop += lp.topMargin;
								setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
								i += getChildrenSkipCount(child, i);
								break;
							}
							childLeft = paddingLeft + lp.leftMargin;
							if (!hasDividerBeforeChildAt(i)) {
								childTop += lp.topMargin;
								setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
								i += getChildrenSkipCount(child, i);
							} else {
								childTop += mDividerHeight;
								childTop += lp.topMargin;
								setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
								i += getChildrenSkipCount(child, i);
							}
						} else {
							gravity = minorGravity;
							switch((GravityCompat.getAbsoluteGravity(gravity, ViewCompat.getLayoutDirection(this)) & 7)) {
							case VERTICAL:
								childLeft = ((((childSpace - childWidth) / 2) + paddingLeft) + lp.leftMargin) - lp.rightMargin;
								if (!hasDividerBeforeChildAt(i)) {
									childTop += mDividerHeight;
								}
								childTop += lp.topMargin;
								setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
								i += getChildrenSkipCount(child, i);
								break;
							case SQLiteCursor.FIELD_TYPE_NULL:
								childLeft = (childRight - childWidth) - lp.rightMargin;
								if (!hasDividerBeforeChildAt(i)) {
									childTop += lp.topMargin;
									setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
									i += getChildrenSkipCount(child, i);
								} else {
									childTop += mDividerHeight;
									childTop += lp.topMargin;
									setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
									i += getChildrenSkipCount(child, i);
								}
								break;
							}
							childLeft = paddingLeft + lp.leftMargin;
							if (!hasDividerBeforeChildAt(i)) {
								childTop += mDividerHeight;
							}
							childTop += lp.topMargin;
							setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
							i += getChildrenSkipCount(child, i);
						}
					}
				} else {
					childTop += measureNullChild(i);
				}
				i++;
			}
			break;
		}
		childTop = getPaddingTop();
		i = SHOW_DIVIDER_NONE;
		while (i < count) {
			child = getVirtualChildAt(i);
			if (child == null) {
				childTop += measureNullChild(i);
			} else if (child.getVisibility() != 8) {
				childWidth = child.getMeasuredWidth();
				childHeight = child.getMeasuredHeight();
				lp = (LayoutParams) child.getLayoutParams();
				gravity = lp.gravity;
				if (gravity < 0) {
					gravity = minorGravity;
				}
				switch((GravityCompat.getAbsoluteGravity(gravity, ViewCompat.getLayoutDirection(this)) & 7)) {
				case VERTICAL:
					childLeft = ((((childSpace - childWidth) / 2) + paddingLeft) + lp.leftMargin) - lp.rightMargin;
					if (!hasDividerBeforeChildAt(i)) {
						childTop += lp.topMargin;
						setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
						i += getChildrenSkipCount(child, i);
					} else {
						childTop += mDividerHeight;
						childTop += lp.topMargin;
						setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
						i += getChildrenSkipCount(child, i);
					}
					break;
				case SQLiteCursor.FIELD_TYPE_NULL:
					childLeft = (childRight - childWidth) - lp.rightMargin;
					if (!hasDividerBeforeChildAt(i)) {
						childTop += mDividerHeight;
					}
					childTop += lp.topMargin;
					setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
					i += getChildrenSkipCount(child, i);
					break;
				}
				childLeft = paddingLeft + lp.leftMargin;
				if (!hasDividerBeforeChildAt(i)) {
					childTop += lp.topMargin;
					setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
					i += getChildrenSkipCount(child, i);
				} else {
					childTop += mDividerHeight;
					childTop += lp.topMargin;
					setChildFrame(child, childLeft, childTop + getLocationOffset(child), childWidth, childHeight);
					i += getChildrenSkipCount(child, i);
				}
			}
			i++;
		}
	}

	void measureChildBeforeLayout(View child, int childIndex, int widthMeasureSpec, int totalWidth, int heightMeasureSpec, int totalHeight) {
		measureChildWithMargins(child, widthMeasureSpec, totalWidth, heightMeasureSpec, totalHeight);
	}

	void measureHorizontal(int widthMeasureSpec, int heightMeasureSpec) {
		int[] maxAscent;
		int[] maxDescent;
		boolean baselineAligned;
		boolean useLargestChild;
		boolean isExactly;
		View child;
		LayoutParams lp;
		int childWidth;
		int totalLength;
		boolean matchHeightLocally;
		int margin;
		int childHeight;
		int childBaseline;
		int r3i;
		int index;
		mTotalLength = 0;
		int maxHeight = SHOW_DIVIDER_NONE;
		int childState = SHOW_DIVIDER_NONE;
		int alternativeMaxHeight = SHOW_DIVIDER_NONE;
		int weightedMaxHeight = SHOW_DIVIDER_NONE;
		boolean allFillParent = true;
		float totalWeight = BitmapDescriptorFactory.HUE_RED;
		int count = getVirtualChildCount();
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		boolean matchHeight = false;
		boolean skippedMeasure = false;
		if (mMaxAscent == null || mMaxDescent == null) {
			mMaxAscent = new int[4];
			mMaxDescent = new int[4];
		} else {
			maxAscent = mMaxAscent;
			maxDescent = mMaxDescent;
			maxAscent[3] = -1;
			maxAscent[2] = -1;
			maxAscent[1] = -1;
			maxAscent[0] = -1;
			maxDescent[3] = -1;
			maxDescent[2] = -1;
			maxDescent[1] = -1;
			maxDescent[0] = -1;
			baselineAligned = mBaselineAligned;
			useLargestChild = mUseLargestChild;
		}
		maxAscent = mMaxAscent;
		maxDescent = mMaxDescent;
		maxAscent[3] = -1;
		maxAscent[2] = -1;
		maxAscent[1] = -1;
		maxAscent[0] = -1;
		maxDescent[3] = -1;
		maxDescent[2] = -1;
		maxDescent[1] = -1;
		maxDescent[0] = -1;
		baselineAligned = mBaselineAligned;
		useLargestChild = mUseLargestChild;
		if (widthMode == 1073741824) {
			isExactly = true;
		} else {
			isExactly = false;
		}
		int largestChildWidth = TLRPC.MESSAGE_FLAG_MEGAGROUP;
		int i = SHOW_DIVIDER_NONE;
		while (i < count) {
			child = getVirtualChildAt(i);
			if (child == null) {
				mTotalLength += measureNullChild(i);
			} else if (child.getVisibility() == 8) {
				i += getChildrenSkipCount(child, i);
			} else {
				if (hasDividerBeforeChildAt(i)) {
					mTotalLength += mDividerWidth;
				}
				lp = (LayoutParams) child.getLayoutParams();
				totalWeight += lp.weight;
				if (widthMode != 1073741824 || lp.width != 0 || lp.weight <= 0.0f) {
					int oldWidth = TLRPC.MESSAGE_FLAG_MEGAGROUP;
					int r7i;
					if (lp.width != 0 || lp.weight <= 0.0f) {
						if (totalWeight != 0.0f) {
							r7i = mTotalLength;
						} else {
							r7i = SHOW_DIVIDER_NONE;
						}
						measureChildBeforeLayout(child, i, widthMeasureSpec, r7i, heightMeasureSpec, SHOW_DIVIDER_NONE);
						if (oldWidth == TLRPC.MESSAGE_FLAG_MEGAGROUP) {
							lp.width = oldWidth;
						}
						childWidth = child.getMeasuredWidth();
						if (isExactly) {
							mTotalLength += ((lp.leftMargin + childWidth) + lp.rightMargin) + getNextLocationOffset(child);
						} else {
							totalLength = mTotalLength;
							mTotalLength = Math.max(totalLength, (((totalLength + childWidth) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
						}
						if (useLargestChild) {
							largestChildWidth = Math.max(childWidth, largestChildWidth);
						}
					} else {
						oldWidth = SHOW_DIVIDER_NONE;
						lp.width = -2;
						if (totalWeight != 0.0f) {
							r7i = SHOW_DIVIDER_NONE;
						} else {
							r7i = mTotalLength;
						}
						measureChildBeforeLayout(child, i, widthMeasureSpec, r7i, heightMeasureSpec, SHOW_DIVIDER_NONE);
						if (oldWidth == TLRPC.MESSAGE_FLAG_MEGAGROUP) {
							childWidth = child.getMeasuredWidth();
							if (isExactly) {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((totalLength + childWidth) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							} else {
								mTotalLength += ((lp.leftMargin + childWidth) + lp.rightMargin) + getNextLocationOffset(child);
							}
							if (useLargestChild) {
								matchHeightLocally = false;
							} else {
								largestChildWidth = Math.max(childWidth, largestChildWidth);
							}
						} else {
							lp.width = oldWidth;
							childWidth = child.getMeasuredWidth();
							if (isExactly) {
								mTotalLength += ((lp.leftMargin + childWidth) + lp.rightMargin) + getNextLocationOffset(child);
							} else {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((totalLength + childWidth) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							}
							if (useLargestChild) {
								largestChildWidth = Math.max(childWidth, largestChildWidth);
							}
						}
					}
				} else {
					if (isExactly) {
						mTotalLength += lp.leftMargin + lp.rightMargin;
					} else {
						totalLength = mTotalLength;
						mTotalLength = Math.max(totalLength, (lp.leftMargin + totalLength) + lp.rightMargin);
					}
					if (baselineAligned) {
						int freeSpec = MeasureSpec.makeMeasureSpec(SHOW_DIVIDER_NONE, SHOW_DIVIDER_NONE);
						child.measure(freeSpec, freeSpec);
					} else {
						skippedMeasure = true;
					}
				}
				matchHeightLocally = false;
				if (heightMode == 1073741824 || lp.height != -1) {
					margin = lp.topMargin + lp.bottomMargin;
					childHeight = child.getMeasuredHeight() + margin;
					childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
					if (!baselineAligned) {
						childBaseline = child.getBaseline();
						if (childBaseline == -1) {
							if (lp.gravity >= 0) {
								r3i = mGravity;
							} else {
								r3i = lp.gravity;
							}
							index = (((r3i & 112) >> 4) & -2) >> 1;
							maxAscent[index] = Math.max(maxAscent[index], childBaseline);
							maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
						}
					}
					maxHeight = Math.max(maxHeight, childHeight);
					if (!allFillParent || lp.height != -1) {
						allFillParent = false;
					} else {
						allFillParent = true;
					}
					if (lp.weight <= 0.0f) {
						if (!matchHeightLocally) {
							weightedMaxHeight = Math.max(weightedMaxHeight, margin);
						} else {
							margin = childHeight;
							weightedMaxHeight = Math.max(weightedMaxHeight, margin);
						}
					} else if (!matchHeightLocally) {
						alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
					} else {
						alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
					}
					i += getChildrenSkipCount(child, i);
				} else {
					matchHeight = true;
					matchHeightLocally = true;
					margin = lp.topMargin + lp.bottomMargin;
					childHeight = child.getMeasuredHeight() + margin;
					childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
					if (!baselineAligned) {
						maxHeight = Math.max(maxHeight, childHeight);
						if (!allFillParent || lp.height != -1) {
							allFillParent = false;
						} else {
							allFillParent = true;
						}
						if (lp.weight <= 0.0f) {
							if (!matchHeightLocally) {
							}
							alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
						} else {
							if (!matchHeightLocally) {
								margin = childHeight;
							}
							weightedMaxHeight = Math.max(weightedMaxHeight, margin);
						}
						i += getChildrenSkipCount(child, i);
					} else {
						childBaseline = child.getBaseline();
						if (childBaseline == -1) {
							maxHeight = Math.max(maxHeight, childHeight);
							if (!allFillParent || lp.height != -1) {
								allFillParent = false;
							} else {
								allFillParent = true;
							}
							if (lp.weight <= 0.0f) {
								if (!matchHeightLocally) {
									weightedMaxHeight = Math.max(weightedMaxHeight, margin);
								} else {
									margin = childHeight;
									weightedMaxHeight = Math.max(weightedMaxHeight, margin);
								}
							} else if (!matchHeightLocally) {
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
							} else {
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
							}
							i += getChildrenSkipCount(child, i);
						} else {
							if (lp.gravity >= 0) {
								r3i = lp.gravity;
							} else {
								r3i = mGravity;
							}
							index = (((r3i & 112) >> 4) & -2) >> 1;
							maxAscent[index] = Math.max(maxAscent[index], childBaseline);
							maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
							maxHeight = Math.max(maxHeight, childHeight);
							if (!allFillParent || lp.height != -1) {
								allFillParent = false;
							} else {
								allFillParent = true;
							}
							if (lp.weight <= 0.0f) {
								if (!matchHeightLocally) {
								}
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
							} else {
								if (!matchHeightLocally) {
									margin = childHeight;
								}
								weightedMaxHeight = Math.max(weightedMaxHeight, margin);
							}
							i += getChildrenSkipCount(child, i);
						}
					}
				}
			}
			i++;
		}
		int widthSizeAndState;
		int delta;
		float weightSum;
		float childExtra;
		int share;
		int childHeightMeasureSpec;
		if (mTotalLength <= 0 || !hasDividerBeforeChildAt(count)) {
			if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
				maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
			} else if (!useLargestChild) {
				if (widthMode == -2147483648 || widthMode == 0) {
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child != null) {
							mTotalLength += measureNullChild(i);
						} else if (child.getVisibility() != 8) {
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							if (!isExactly) {
								mTotalLength += ((lp.leftMargin + largestChildWidth) + lp.rightMargin) + getNextLocationOffset(child);
							} else {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((totalLength + largestChildWidth) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							}
						}
						i++;
					}
				}
			}
			if (!useLargestChild) {
				mTotalLength += getPaddingLeft() + getPaddingRight();
				widthSizeAndState = ViewCompat.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumWidth()), widthMeasureSpec, SHOW_DIVIDER_NONE);
				delta = (widthSizeAndState & 16777215) - mTotalLength;
				if (skippedMeasure) {
					if (delta == 0 || totalWeight <= 0.0f) {
						if (!useLargestChild) {
							if (widthMode == 1073741824) {
								i = SHOW_DIVIDER_NONE;
								while (i < count) {
									child = getVirtualChildAt(i);
									if (child == null || child.getVisibility() == 8 || ((LayoutParams) child.getLayoutParams()).weight <= 0.0f) {
										i++;
									} else {
										child.measure(MeasureSpec.makeMeasureSpec(largestChildWidth, 1073741824), MeasureSpec.makeMeasureSpec(child.getMeasuredHeight(), 1073741824));
										i++;
									}
								}
							}
						}
					} else {
						if (mWeightSum <= 0.0f) {
							weightSum = mWeightSum;
						} else {
							weightSum = totalWeight;
						}
						maxAscent[3] = -1;
						maxAscent[2] = -1;
						maxAscent[1] = -1;
						maxAscent[0] = -1;
						maxDescent[3] = -1;
						maxDescent[2] = -1;
						maxDescent[1] = -1;
						maxDescent[0] = -1;
						maxHeight = -1;
						mTotalLength = 0;
						i = SHOW_DIVIDER_NONE;
						while (i < count) {
							child = getVirtualChildAt(i);
							if (child == null || child.getVisibility() == 8) {
								i++;
							} else {
								lp = (LayoutParams) child.getLayoutParams();
								childExtra = lp.weight;
								if (childExtra <= 0.0f) {
									share = (int) ((((float) delta) * childExtra) / weightSum);
									delta -= share;
									childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
									if (lp.width != 0 || widthMode != 1073741824) {
										childWidth = child.getMeasuredWidth() + share;
										if (childWidth >= 0) {
											childWidth = SHOW_DIVIDER_NONE;
										}
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else if (share <= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
									} else {
										share = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
									}
									childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								}
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								}
							}
						}
						mTotalLength += getPaddingLeft() + getPaddingRight();
						if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
							maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
						}
					}
				} else {
					if (mWeightSum <= 0.0f) {
						weightSum = totalWeight;
					} else {
						weightSum = mWeightSum;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								if (!isExactly) {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								} else {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									margin = childHeight;
								}
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
								if (!allFillParent || lp.height != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								if (baselineAligned) {
									childBaseline = child.getBaseline();
									if (childBaseline != -1) {
										if (lp.gravity < 0) {
											r3i = mGravity;
										} else {
											r3i = lp.gravity;
										}
										index = (((r3i & 112) >> 4) & -2) >> 1;
										maxAscent[index] = Math.max(maxAscent[index], childBaseline);
										maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
									}
								}
								i++;
							} else {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else {
										childWidth = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									}
								} else {
									if (share <= 0) {
										share = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								}
							}
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				}
				if (allFillParent || heightMode == 1073741824) {
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
						forceUniformHeight(count, widthMeasureSpec);
					}
				} else {
					maxHeight = alternativeMaxHeight;
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
					} else {
						forceUniformHeight(count, widthMeasureSpec);
					}
				}
			} else if (widthMode == -2147483648 || widthMode == 0) {
				mTotalLength = 0;
				i = SHOW_DIVIDER_NONE;
				while (i < count) {
					child = getVirtualChildAt(i);
					if (child != null) {
						if (child.getVisibility() != 8) {
							lp = (LayoutParams) child.getLayoutParams();
							if (!isExactly) {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((totalLength + largestChildWidth) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							} else {
								mTotalLength += ((lp.leftMargin + largestChildWidth) + lp.rightMargin) + getNextLocationOffset(child);
							}
						}
					} else {
						mTotalLength += measureNullChild(i);
					}
					i++;
				}
				mTotalLength += getPaddingLeft() + getPaddingRight();
				widthSizeAndState = ViewCompat.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumWidth()), widthMeasureSpec, SHOW_DIVIDER_NONE);
				delta = (widthSizeAndState & 16777215) - mTotalLength;
				if (skippedMeasure) {
					if (mWeightSum <= 0.0f) {
						weightSum = mWeightSum;
					} else {
						weightSum = totalWeight;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										childWidth = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
								} else if (share <= 0) {
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								} else {
									share = SHOW_DIVIDER_NONE;
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
							}
							if (!isExactly) {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							} else {
								mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
							}
							if (heightMode == 1073741824 || lp.height != -1) {
								matchHeightLocally = false;
							} else {
								matchHeightLocally = true;
							}
							margin = lp.topMargin + lp.bottomMargin;
							childHeight = child.getMeasuredHeight() + margin;
							maxHeight = Math.max(maxHeight, childHeight);
							if (!matchHeightLocally) {
								margin = childHeight;
							}
							alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
							if (!allFillParent || lp.height != -1) {
								allFillParent = false;
							} else {
								allFillParent = true;
							}
							if (baselineAligned) {
								i++;
							} else {
								childBaseline = child.getBaseline();
								if (childBaseline != -1) {
									i++;
								} else {
									if (lp.gravity < 0) {
										r3i = lp.gravity;
									} else {
										r3i = mGravity;
									}
									index = (((r3i & 112) >> 4) & -2) >> 1;
									maxAscent[index] = Math.max(maxAscent[index], childBaseline);
									maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
									i++;
								}
							}
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				} else if (delta == 0 || totalWeight <= 0.0f) {
					if (!useLargestChild) {
						if (allFillParent || heightMode == 1073741824) {
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
								forceUniformHeight(count, widthMeasureSpec);
							}
						} else {
							maxHeight = alternativeMaxHeight;
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
							} else {
								forceUniformHeight(count, widthMeasureSpec);
							}
						}
					} else if (widthMode == 1073741824) {
						if (allFillParent || heightMode == 1073741824) {
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
								forceUniformHeight(count, widthMeasureSpec);
							}
						} else {
							maxHeight = alternativeMaxHeight;
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
							} else {
								forceUniformHeight(count, widthMeasureSpec);
							}
						}
					} else {
						i = SHOW_DIVIDER_NONE;
						while (i < count) {
							child = getVirtualChildAt(i);
							if (child == null || child.getVisibility() == 8 || ((LayoutParams) child.getLayoutParams()).weight <= 0.0f) {
								i++;
							} else {
								child.measure(MeasureSpec.makeMeasureSpec(largestChildWidth, 1073741824), MeasureSpec.makeMeasureSpec(child.getMeasuredHeight(), 1073741824));
								i++;
							}
						}
					}
				} else {
					if (mWeightSum <= 0.0f) {
						weightSum = totalWeight;
					} else {
						weightSum = mWeightSum;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								}
							} else {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else {
										childWidth = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									}
								} else {
									if (share <= 0) {
										share = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								if (!isExactly) {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								} else {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									margin = childHeight;
								}
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
								if (!allFillParent || lp.height != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								if (baselineAligned) {
									childBaseline = child.getBaseline();
									if (childBaseline != -1) {
										if (lp.gravity < 0) {
											r3i = mGravity;
										} else {
											r3i = lp.gravity;
										}
										index = (((r3i & 112) >> 4) & -2) >> 1;
										maxAscent[index] = Math.max(maxAscent[index], childBaseline);
										maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
									}
								}
								i++;
							}
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				}
				if (allFillParent || heightMode == 1073741824) {
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
						forceUniformHeight(count, widthMeasureSpec);
					}
				} else {
					maxHeight = alternativeMaxHeight;
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
					} else {
						forceUniformHeight(count, widthMeasureSpec);
					}
				}
			} else {
				mTotalLength += getPaddingLeft() + getPaddingRight();
				widthSizeAndState = ViewCompat.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumWidth()), widthMeasureSpec, SHOW_DIVIDER_NONE);
				delta = (widthSizeAndState & 16777215) - mTotalLength;
				if (skippedMeasure) {
					if (delta == 0 || totalWeight <= 0.0f) {
						if (!useLargestChild) {
							if (widthMode == 1073741824) {
								i = SHOW_DIVIDER_NONE;
								while (i < count) {
									child = getVirtualChildAt(i);
									if (child == null || child.getVisibility() == 8 || ((LayoutParams) child.getLayoutParams()).weight <= 0.0f) {
										i++;
									} else {
										child.measure(MeasureSpec.makeMeasureSpec(largestChildWidth, 1073741824), MeasureSpec.makeMeasureSpec(child.getMeasuredHeight(), 1073741824));
										i++;
									}
								}
							}
						}
					} else {
						if (mWeightSum <= 0.0f) {
							weightSum = mWeightSum;
						} else {
							weightSum = totalWeight;
						}
						maxAscent[3] = -1;
						maxAscent[2] = -1;
						maxAscent[1] = -1;
						maxAscent[0] = -1;
						maxDescent[3] = -1;
						maxDescent[2] = -1;
						maxDescent[1] = -1;
						maxDescent[0] = -1;
						maxHeight = -1;
						mTotalLength = 0;
						i = SHOW_DIVIDER_NONE;
						while (i < count) {
							child = getVirtualChildAt(i);
							if (child == null || child.getVisibility() == 8) {
								i++;
							} else {
								lp = (LayoutParams) child.getLayoutParams();
								childExtra = lp.weight;
								if (childExtra <= 0.0f) {
									share = (int) ((((float) delta) * childExtra) / weightSum);
									delta -= share;
									childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
									if (lp.width != 0 || widthMode != 1073741824) {
										childWidth = child.getMeasuredWidth() + share;
										if (childWidth >= 0) {
											childWidth = SHOW_DIVIDER_NONE;
										}
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else if (share <= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
									} else {
										share = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
									}
									childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								}
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								}
							}
						}
						mTotalLength += getPaddingLeft() + getPaddingRight();
						if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
							maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
						}
					}
				} else {
					if (mWeightSum <= 0.0f) {
						weightSum = totalWeight;
					} else {
						weightSum = mWeightSum;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								if (!isExactly) {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								} else {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									margin = childHeight;
								}
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
								if (!allFillParent || lp.height != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								if (baselineAligned) {
									i++;
								} else {
									childBaseline = child.getBaseline();
									if (childBaseline != -1) {
										i++;
									} else {
										if (lp.gravity < 0) {
											r3i = lp.gravity;
										} else {
											r3i = mGravity;
										}
										index = (((r3i & 112) >> 4) & -2) >> 1;
										maxAscent[index] = Math.max(maxAscent[index], childBaseline);
										maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										i++;
									}
								}
							} else {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else {
										childWidth = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									}
								} else {
									if (share <= 0) {
										share = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								}
							}
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				}
				if (allFillParent || heightMode == 1073741824) {
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
						forceUniformHeight(count, widthMeasureSpec);
					}
				} else {
					maxHeight = alternativeMaxHeight;
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
					} else {
						forceUniformHeight(count, widthMeasureSpec);
					}
				}
			}
		} else {
			mTotalLength += mDividerWidth;
			if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
				maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
			} else if (!useLargestChild) {
				if (widthMode == -2147483648 || widthMode == 0) {
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child != null) {
							mTotalLength += measureNullChild(i);
						} else if (child.getVisibility() != 8) {
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							if (!isExactly) {
								mTotalLength += ((lp.leftMargin + largestChildWidth) + lp.rightMargin) + getNextLocationOffset(child);
							} else {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((totalLength + largestChildWidth) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							}
						}
						i++;
					}
				}
			}
			if (!useLargestChild) {
				mTotalLength += getPaddingLeft() + getPaddingRight();
				widthSizeAndState = ViewCompat.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumWidth()), widthMeasureSpec, SHOW_DIVIDER_NONE);
				delta = (widthSizeAndState & 16777215) - mTotalLength;
				if (skippedMeasure) {
					if (mWeightSum <= 0.0f) {
						weightSum = mWeightSum;
					} else {
						weightSum = totalWeight;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										childWidth = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
								} else if (share <= 0) {
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								} else {
									share = SHOW_DIVIDER_NONE;
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
							}
							if (!isExactly) {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							} else {
								mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
							}
							if (heightMode == 1073741824 || lp.height != -1) {
								matchHeightLocally = false;
							} else {
								matchHeightLocally = true;
							}
							margin = lp.topMargin + lp.bottomMargin;
							childHeight = child.getMeasuredHeight() + margin;
							maxHeight = Math.max(maxHeight, childHeight);
							if (!matchHeightLocally) {
								margin = childHeight;
							}
							alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
							if (!allFillParent || lp.height != -1) {
								allFillParent = false;
							} else {
								allFillParent = true;
							}
							if (baselineAligned) {
								childBaseline = child.getBaseline();
								if (childBaseline != -1) {
									if (lp.gravity < 0) {
										r3i = mGravity;
									} else {
										r3i = lp.gravity;
									}
									index = (((r3i & 112) >> 4) & -2) >> 1;
									maxAscent[index] = Math.max(maxAscent[index], childBaseline);
									maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
								}
							}
							i++;
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				} else if (delta == 0 || totalWeight <= 0.0f) {
					if (!useLargestChild) {
						if (allFillParent || heightMode == 1073741824) {
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
								forceUniformHeight(count, widthMeasureSpec);
							}
						} else {
							maxHeight = alternativeMaxHeight;
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
							} else {
								forceUniformHeight(count, widthMeasureSpec);
							}
						}
					} else if (widthMode == 1073741824) {
						if (allFillParent || heightMode == 1073741824) {
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
								forceUniformHeight(count, widthMeasureSpec);
							}
						} else {
							maxHeight = alternativeMaxHeight;
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
							} else {
								forceUniformHeight(count, widthMeasureSpec);
							}
						}
					} else {
						i = SHOW_DIVIDER_NONE;
						while (i < count) {
							child = getVirtualChildAt(i);
							if (child == null || child.getVisibility() == 8 || ((LayoutParams) child.getLayoutParams()).weight <= 0.0f) {
								i++;
							} else {
								child.measure(MeasureSpec.makeMeasureSpec(largestChildWidth, 1073741824), MeasureSpec.makeMeasureSpec(child.getMeasuredHeight(), 1073741824));
								i++;
							}
						}
					}
				} else {
					if (mWeightSum <= 0.0f) {
						weightSum = totalWeight;
					} else {
						weightSum = mWeightSum;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								}
							} else {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else {
										childWidth = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									}
								} else {
									if (share <= 0) {
										share = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								if (!isExactly) {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								} else {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									margin = childHeight;
								}
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
								if (!allFillParent || lp.height != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								if (baselineAligned) {
									i++;
								} else {
									childBaseline = child.getBaseline();
									if (childBaseline != -1) {
										i++;
									} else {
										if (lp.gravity < 0) {
											r3i = lp.gravity;
										} else {
											r3i = mGravity;
										}
										index = (((r3i & 112) >> 4) & -2) >> 1;
										maxAscent[index] = Math.max(maxAscent[index], childBaseline);
										maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										i++;
									}
								}
							}
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				}
				if (allFillParent || heightMode == 1073741824) {
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
						forceUniformHeight(count, widthMeasureSpec);
					}
				} else {
					maxHeight = alternativeMaxHeight;
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
					} else {
						forceUniformHeight(count, widthMeasureSpec);
					}
				}
			} else if (widthMode == -2147483648 || widthMode == 0) {
				mTotalLength = 0;
				i = SHOW_DIVIDER_NONE;
				while (i < count) {
					child = getVirtualChildAt(i);
					if (child != null) {
						if (child.getVisibility() != 8) {
							lp = (LayoutParams) child.getLayoutParams();
							if (!isExactly) {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((totalLength + largestChildWidth) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							} else {
								mTotalLength += ((lp.leftMargin + largestChildWidth) + lp.rightMargin) + getNextLocationOffset(child);
							}
						}
					} else {
						mTotalLength += measureNullChild(i);
					}
					i++;
				}
				mTotalLength += getPaddingLeft() + getPaddingRight();
				widthSizeAndState = ViewCompat.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumWidth()), widthMeasureSpec, SHOW_DIVIDER_NONE);
				delta = (widthSizeAndState & 16777215) - mTotalLength;
				if (skippedMeasure) {
					if (delta == 0 || totalWeight <= 0.0f) {
						if (!useLargestChild) {
							if (widthMode == 1073741824) {
								i = SHOW_DIVIDER_NONE;
								while (i < count) {
									child = getVirtualChildAt(i);
									if (child == null || child.getVisibility() == 8 || ((LayoutParams) child.getLayoutParams()).weight <= 0.0f) {
										i++;
									} else {
										child.measure(MeasureSpec.makeMeasureSpec(largestChildWidth, 1073741824), MeasureSpec.makeMeasureSpec(child.getMeasuredHeight(), 1073741824));
										i++;
									}
								}
							}
						}
					} else {
						if (mWeightSum <= 0.0f) {
							weightSum = mWeightSum;
						} else {
							weightSum = totalWeight;
						}
						maxAscent[3] = -1;
						maxAscent[2] = -1;
						maxAscent[1] = -1;
						maxAscent[0] = -1;
						maxDescent[3] = -1;
						maxDescent[2] = -1;
						maxDescent[1] = -1;
						maxDescent[0] = -1;
						maxHeight = -1;
						mTotalLength = 0;
						i = SHOW_DIVIDER_NONE;
						while (i < count) {
							child = getVirtualChildAt(i);
							if (child == null || child.getVisibility() == 8) {
								i++;
							} else {
								lp = (LayoutParams) child.getLayoutParams();
								childExtra = lp.weight;
								if (childExtra <= 0.0f) {
									share = (int) ((((float) delta) * childExtra) / weightSum);
									delta -= share;
									childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
									if (lp.width != 0 || widthMode != 1073741824) {
										childWidth = child.getMeasuredWidth() + share;
										if (childWidth >= 0) {
											childWidth = SHOW_DIVIDER_NONE;
										}
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else if (share <= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
									} else {
										share = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
									}
									childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								}
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								}
							}
						}
						mTotalLength += getPaddingLeft() + getPaddingRight();
						if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
							maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
						}
					}
				} else {
					if (mWeightSum <= 0.0f) {
						weightSum = totalWeight;
					} else {
						weightSum = mWeightSum;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								if (!isExactly) {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								} else {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									margin = childHeight;
								}
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
								if (!allFillParent || lp.height != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								if (baselineAligned) {
									childBaseline = child.getBaseline();
									if (childBaseline != -1) {
										if (lp.gravity < 0) {
											r3i = mGravity;
										} else {
											r3i = lp.gravity;
										}
										index = (((r3i & 112) >> 4) & -2) >> 1;
										maxAscent[index] = Math.max(maxAscent[index], childBaseline);
										maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
									}
								}
								i++;
							} else {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else {
										childWidth = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									}
								} else {
									if (share <= 0) {
										share = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								}
							}
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				}
				if (allFillParent || heightMode == 1073741824) {
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
						forceUniformHeight(count, widthMeasureSpec);
					}
				} else {
					maxHeight = alternativeMaxHeight;
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
					} else {
						forceUniformHeight(count, widthMeasureSpec);
					}
				}
			} else {
				mTotalLength += getPaddingLeft() + getPaddingRight();
				widthSizeAndState = ViewCompat.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumWidth()), widthMeasureSpec, SHOW_DIVIDER_NONE);
				delta = (widthSizeAndState & 16777215) - mTotalLength;
				if (skippedMeasure) {
					if (mWeightSum <= 0.0f) {
						weightSum = mWeightSum;
					} else {
						weightSum = totalWeight;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										childWidth = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
								} else if (share <= 0) {
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								} else {
									share = SHOW_DIVIDER_NONE;
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
							}
							if (!isExactly) {
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
							} else {
								mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
							}
							if (heightMode == 1073741824 || lp.height != -1) {
								matchHeightLocally = false;
							} else {
								matchHeightLocally = true;
							}
							margin = lp.topMargin + lp.bottomMargin;
							childHeight = child.getMeasuredHeight() + margin;
							maxHeight = Math.max(maxHeight, childHeight);
							if (!matchHeightLocally) {
								margin = childHeight;
							}
							alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
							if (!allFillParent || lp.height != -1) {
								allFillParent = false;
							} else {
								allFillParent = true;
							}
							if (baselineAligned) {
								i++;
							} else {
								childBaseline = child.getBaseline();
								if (childBaseline != -1) {
									i++;
								} else {
									if (lp.gravity < 0) {
										r3i = lp.gravity;
									} else {
										r3i = mGravity;
									}
									index = (((r3i & 112) >> 4) & -2) >> 1;
									maxAscent[index] = Math.max(maxAscent[index], childBaseline);
									maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
									i++;
								}
							}
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				} else if (delta == 0 || totalWeight <= 0.0f) {
					if (!useLargestChild) {
						if (allFillParent || heightMode == 1073741824) {
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
								forceUniformHeight(count, widthMeasureSpec);
							}
						} else {
							maxHeight = alternativeMaxHeight;
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
							} else {
								forceUniformHeight(count, widthMeasureSpec);
							}
						}
					} else if (widthMode == 1073741824) {
						if (allFillParent || heightMode == 1073741824) {
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
								forceUniformHeight(count, widthMeasureSpec);
							}
						} else {
							maxHeight = alternativeMaxHeight;
							setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
							if (!matchHeight) {
							} else {
								forceUniformHeight(count, widthMeasureSpec);
							}
						}
					} else {
						i = SHOW_DIVIDER_NONE;
						while (i < count) {
							child = getVirtualChildAt(i);
							if (child == null || child.getVisibility() == 8 || ((LayoutParams) child.getLayoutParams()).weight <= 0.0f) {
								i++;
							} else {
								child.measure(MeasureSpec.makeMeasureSpec(largestChildWidth, 1073741824), MeasureSpec.makeMeasureSpec(child.getMeasuredHeight(), 1073741824));
								i++;
							}
						}
					}
				} else {
					if (mWeightSum <= 0.0f) {
						weightSum = totalWeight;
					} else {
						weightSum = mWeightSum;
					}
					maxAscent[3] = -1;
					maxAscent[2] = -1;
					maxAscent[1] = -1;
					maxAscent[0] = -1;
					maxDescent[3] = -1;
					maxDescent[2] = -1;
					maxDescent[1] = -1;
					maxDescent[0] = -1;
					maxHeight = -1;
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								if (!isExactly) {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								} else {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											if (lp.gravity < 0) {
												r3i = mGravity;
											} else {
												r3i = lp.gravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
										}
									}
									i++;
								} else {
									margin = childHeight;
									alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
									if (!allFillParent || lp.height != -1) {
										allFillParent = false;
									} else {
										allFillParent = true;
									}
									if (baselineAligned) {
										i++;
									} else {
										childBaseline = child.getBaseline();
										if (childBaseline != -1) {
											i++;
										} else {
											if (lp.gravity < 0) {
												r3i = lp.gravity;
											} else {
												r3i = mGravity;
											}
											index = (((r3i & 112) >> 4) & -2) >> 1;
											maxAscent[index] = Math.max(maxAscent[index], childBaseline);
											maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
											i++;
										}
									}
								}
							} else {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, ((getPaddingTop() + getPaddingBottom()) + lp.topMargin) + lp.bottomMargin, lp.height);
								if (lp.width != 0 || widthMode != 1073741824) {
									childWidth = child.getMeasuredWidth() + share;
									if (childWidth >= 0) {
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									} else {
										childWidth = SHOW_DIVIDER_NONE;
										child.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), childHeightMeasureSpec);
									}
								} else {
									if (share <= 0) {
										share = SHOW_DIVIDER_NONE;
									}
									child.measure(MeasureSpec.makeMeasureSpec(share, 1073741824), childHeightMeasureSpec);
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -16777216);
								if (!isExactly) {
									totalLength = mTotalLength;
									mTotalLength = Math.max(totalLength, (((child.getMeasuredWidth() + totalLength) + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child));
								} else {
									mTotalLength += ((child.getMeasuredWidth() + lp.leftMargin) + lp.rightMargin) + getNextLocationOffset(child);
								}
								if (heightMode == 1073741824 || lp.height != -1) {
									matchHeightLocally = false;
								} else {
									matchHeightLocally = true;
								}
								margin = lp.topMargin + lp.bottomMargin;
								childHeight = child.getMeasuredHeight() + margin;
								maxHeight = Math.max(maxHeight, childHeight);
								if (!matchHeightLocally) {
									margin = childHeight;
								}
								alternativeMaxHeight = Math.max(alternativeMaxHeight, margin);
								if (!allFillParent || lp.height != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								if (baselineAligned) {
									childBaseline = child.getBaseline();
									if (childBaseline != -1) {
										if (lp.gravity < 0) {
											r3i = mGravity;
										} else {
											r3i = lp.gravity;
										}
										index = (((r3i & 112) >> 4) & -2) >> 1;
										maxAscent[index] = Math.max(maxAscent[index], childBaseline);
										maxDescent[index] = Math.max(maxDescent[index], childHeight - childBaseline);
									}
								}
								i++;
							}
						}
					}
					mTotalLength += getPaddingLeft() + getPaddingRight();
					if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
						maxHeight = Math.max(maxHeight, Math.max(maxAscent[3], Math.max(maxAscent[0], Math.max(maxAscent[1], maxAscent[2]))) + Math.max(maxDescent[3], Math.max(maxDescent[0], Math.max(maxDescent[1], maxDescent[2]))));
					}
				}
				if (allFillParent || heightMode == 1073741824) {
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
						forceUniformHeight(count, widthMeasureSpec);
					}
				} else {
					maxHeight = alternativeMaxHeight;
					setMeasuredDimension((-16777216 & childState) | widthSizeAndState, ViewCompat.resolveSizeAndState(Math.max(maxHeight + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), heightMeasureSpec, childState << 16));
					if (!matchHeight) {
					} else {
						forceUniformHeight(count, widthMeasureSpec);
					}
				}
			}
		}
	}

	int measureNullChild(int childIndex) {
		return SHOW_DIVIDER_NONE;
	}

	/* JADX WARNING: inconsistent code */
	/*
	void measureVertical(int r39_widthMeasureSpec, int r40_heightMeasureSpec) {
		r38_this = this;
		r3 = 0;
		r0 = r38;
		r0.mTotalLength = r3;
		r27 = 0;
		r15 = 0;
		r11 = 0;
		r36 = 0;
		r10 = 1;
		r33 = 0;
		r17 = r38.getVirtualChildCount();
		r37 = android.view.View.MeasureSpec.getMode(r39_widthMeasureSpec);
		r19 = android.view.View.MeasureSpec.getMode(r40_heightMeasureSpec);
		r25 = 0;
		r31 = 0;
		r0 = r38;
		r12 = r0.mBaselineAlignedChildIndex;
		r0 = r38;
		r0 = r0.mUseLargestChild;
		r34 = r0;
		r22 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
		r5 = 0;
	L_0x002b:
		r0 = r17_count;
		if (r5_i >= r0) goto L_0x019d;
	L_0x002f:
		r0 = r38;
		r4 = r0.getVirtualChildAt(r5_i);
		if (r4_child != 0) goto L_0x0049;
	L_0x0037:
		r0 = r38;
		r3 = r0.mTotalLength;
		r0 = r38;
		r6 = r0.measureNullChild(r5_i);
		r3 += r6;
		r0 = r38;
		r0.mTotalLength = r3;
	L_0x0046:
		r5_i++;
		goto L_0x002b;
	L_0x0049:
		r3 = r4_child.getVisibility();
		r6 = 8;
		if (r3 != r6) goto L_0x0059;
	L_0x0051:
		r0 = r38;
		r3 = r0.getChildrenSkipCount(r4_child, r5_i);
		r5_i += r3;
		goto L_0x0046;
	L_0x0059:
		r0 = r38;
		r3 = r0.hasDividerBeforeChildAt(r5_i);
		if (r3 == 0) goto L_0x006e;
	L_0x0061:
		r0 = r38;
		r3 = r0.mTotalLength;
		r0 = r38;
		r6 = r0.mDividerHeight;
		r3 += r6;
		r0 = r38;
		r0.mTotalLength = r3;
	L_0x006e:
		r23 = r4_child.getLayoutParams();
		r23 = (android.support.v7.widget.LinearLayoutCompat.LayoutParams) r23;
		r0 = r23_lp;
		r3 = r0.weight;
		r33_totalWeight += r3;
		r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r0 = r19_heightMode;
		if (r0 != r3) goto L_0x00cd;
	L_0x0080:
		r0 = r23_lp;
		r3 = r0.height;
		if (r3 != 0) goto L_0x00cd;
	L_0x0086:
		r0 = r23_lp;
		r3 = r0.weight;
		r6 = 0;
		r3 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
		if (r3 <= 0) goto L_0x00cd;
	L_0x008f:
		r0 = r38;
		r0 = r0.mTotalLength;
		r32 = r0;
		r0 = r23_lp;
		r3 = r0.topMargin;
		r3 += r32_totalLength;
		r0 = r23_lp;
		r6 = r0.bottomMargin;
		r3 += r6;
		r0 = r32_totalLength;
		r3 = java.lang.Math.max(r0, r3);
		r0 = r38;
		r0.mTotalLength = r3;
		r31_skippedMeasure = 1;
	L_0x00ac:
		if (r12_baselineChildIndex < 0) goto L_0x00ba;
	L_0x00ae:
		r3 = r5_i + 1;
		if (r12_baselineChildIndex != r3) goto L_0x00ba;
	L_0x00b2:
		r0 = r38;
		r3 = r0.mTotalLength;
		r0 = r38;
		r0.mBaselineChildTop = r3;
	L_0x00ba:
		if (r5_i >= r12_baselineChildIndex) goto L_0x0137;
	L_0x00bc:
		r0 = r23_lp;
		r3 = r0.weight;
		r6 = 0;
		r3 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
		if (r3 <= 0) goto L_0x0137;
	L_0x00c5:
		r3 = new java.lang.RuntimeException;
		r6 = "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.";
		r3.<init>(r6);
		throw r3;
	L_0x00cd:
		r29 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
		r0 = r23_lp;
		r3 = r0.height;
		if (r3 != 0) goto L_0x00e5;
	L_0x00d5:
		r0 = r23_lp;
		r3 = r0.weight;
		r6 = 0;
		r3 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
		if (r3 <= 0) goto L_0x00e5;
	L_0x00de:
		r29_oldHeight = 0;
		r3 = -2;
		r0 = r23_lp;
		r0.height = r3;
	L_0x00e5:
		r7 = 0;
		r3 = 0;
		r3 = (r33_totalWeight > r3 ? 1 : (r33_totalWeight == r3 ? 0 : -1));
		if (r3 != 0) goto L_0x0135;
	L_0x00eb:
		r0 = r38;
		r9 = r0.mTotalLength;
	L_0x00ef:
		r3 = r38;
		r6 = r39_widthMeasureSpec;
		r8 = r40_heightMeasureSpec;
		r3.measureChildBeforeLayout(r4_child, r5_i, r6, r7, r8, r9);
		r3 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
		r0 = r29_oldHeight;
		if (r0 == r3) goto L_0x0104;
	L_0x00fe:
		r0 = r29_oldHeight;
		r1 = r23_lp;
		r1.height = r0;
	L_0x0104:
		r14 = r4_child.getMeasuredHeight();
		r0 = r38;
		r0 = r0.mTotalLength;
		r32_totalLength = r0;
		r3 = r32_totalLength + r14_childHeight;
		r0 = r23_lp;
		r6 = r0.topMargin;
		r3 += r6;
		r0 = r23_lp;
		r6 = r0.bottomMargin;
		r3 += r6;
		r0 = r38;
		r6 = r0.getNextLocationOffset(r4_child);
		r3 += r6;
		r0 = r32_totalLength;
		r3 = java.lang.Math.max(r0, r3);
		r0 = r38;
		r0.mTotalLength = r3;
		if (r34_useLargestChild == 0) goto L_0x00ac;
	L_0x012d:
		r0 = r22_largestChildHeight;
		r22_largestChildHeight = java.lang.Math.max(r14_childHeight, r0);
		goto L_0x00ac;
	L_0x0135:
		r9 = 0;
		goto L_0x00ef;
	L_0x0137:
		r26 = 0;
		r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r0 = r37_widthMode;
		if (r0 == r3) goto L_0x014a;
	L_0x013f:
		r0 = r23_lp;
		r3 = r0.width;
		r6 = -1;
		if (r3 != r6) goto L_0x014a;
	L_0x0146:
		r25_matchWidth = 1;
		r26_matchWidthLocally = 1;
	L_0x014a:
		r0 = r23_lp;
		r3 = r0.leftMargin;
		r0 = r23_lp;
		r6 = r0.rightMargin;
		r24 = r3 + r6;
		r3 = r4_child.getMeasuredWidth();
		r28 = r3 + r24_margin;
		r27_maxWidth = java.lang.Math.max(r27_maxWidth, r28_measuredWidth);
		r3 = android.support.v4.view.ViewCompat.getMeasuredState(r4_child);
		r15_childState = android.support.v7.widget.ViewUtils.combineMeasuredStates(r15_childState, r3);
		if (r10_allFillParent == 0) goto L_0x018c;
	L_0x0168:
		r0 = r23_lp;
		r3 = r0.width;
		r6 = -1;
		if (r3 != r6) goto L_0x018c;
	L_0x016f:
		r10_allFillParent = 1;
	L_0x0170:
		r0 = r23_lp;
		r3 = r0.weight;
		r6 = 0;
		r3 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
		if (r3 <= 0) goto L_0x0191;
	L_0x0179:
		if (r26_matchWidthLocally == 0) goto L_0x018e;
	L_0x017b:
		r0 = r36_weightedMaxWidth;
		r1 = r24_margin;
		r36_weightedMaxWidth = java.lang.Math.max(r0, r1);
	L_0x0183:
		r0 = r38;
		r3 = r0.getChildrenSkipCount(r4_child, r5_i);
		r5_i += r3;
		goto L_0x0046;
	L_0x018c:
		r10_allFillParent = 0;
		goto L_0x0170;
	L_0x018e:
		r24_margin = r28_measuredWidth;
		goto L_0x017b;
	L_0x0191:
		if (r26_matchWidthLocally == 0) goto L_0x019a;
	L_0x0193:
		r0 = r24_margin;
		r11_alternativeMaxWidth = java.lang.Math.max(r11_alternativeMaxWidth, r0);
		goto L_0x0183;
	L_0x019a:
		r24_margin = r28_measuredWidth;
		goto L_0x0193;
	L_0x019d:
		r0 = r38;
		r3 = r0.mTotalLength;
		if (r3 <= 0) goto L_0x01ba;
	L_0x01a3:
		r0 = r38;
		r1 = r17_count;
		r3 = r0.hasDividerBeforeChildAt(r1);
		if (r3 == 0) goto L_0x01ba;
	L_0x01ad:
		r0 = r38;
		r3 = r0.mTotalLength;
		r0 = r38;
		r6 = r0.mDividerHeight;
		r3 += r6;
		r0 = r38;
		r0.mTotalLength = r3;
	L_0x01ba:
		if (r34_useLargestChild == 0) goto L_0x0222;
	L_0x01bc:
		r3 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
		r0 = r19_heightMode;
		if (r0 == r3) goto L_0x01c4;
	L_0x01c2:
		if (r19_heightMode != 0) goto L_0x0222;
	L_0x01c4:
		r3 = 0;
		r0 = r38;
		r0.mTotalLength = r3;
		r5_i = 0;
	L_0x01ca:
		r0 = r17_count;
		if (r5_i >= r0) goto L_0x0222;
	L_0x01ce:
		r0 = r38;
		r4_child = r0.getVirtualChildAt(r5_i);
		if (r4_child != 0) goto L_0x01e8;
	L_0x01d6:
		r0 = r38;
		r3 = r0.mTotalLength;
		r0 = r38;
		r6 = r0.measureNullChild(r5_i);
		r3 += r6;
		r0 = r38;
		r0.mTotalLength = r3;
	L_0x01e5:
		r5_i++;
		goto L_0x01ca;
	L_0x01e8:
		r3 = r4_child.getVisibility();
		r6 = 8;
		if (r3 != r6) goto L_0x01f8;
	L_0x01f0:
		r0 = r38;
		r3 = r0.getChildrenSkipCount(r4_child, r5_i);
		r5_i += r3;
		goto L_0x01e5;
	L_0x01f8:
		r23_lp = r4_child.getLayoutParams();
		r23_lp = (android.support.v7.widget.LinearLayoutCompat.LayoutParams) r23_lp;
		r0 = r38;
		r0 = r0.mTotalLength;
		r32_totalLength = r0;
		r3 = r32_totalLength + r22_largestChildHeight;
		r0 = r23_lp;
		r6 = r0.topMargin;
		r3 += r6;
		r0 = r23_lp;
		r6 = r0.bottomMargin;
		r3 += r6;
		r0 = r38;
		r6 = r0.getNextLocationOffset(r4_child);
		r3 += r6;
		r0 = r32_totalLength;
		r3 = java.lang.Math.max(r0, r3);
		r0 = r38;
		r0.mTotalLength = r3;
		goto L_0x01e5;
	L_0x0222:
		r0 = r38;
		r3 = r0.mTotalLength;
		r6 = r38.getPaddingTop();
		r7 = r38.getPaddingBottom();
		r6 += r7;
		r3 += r6;
		r0 = r38;
		r0.mTotalLength = r3;
		r0 = r38;
		r0 = r0.mTotalLength;
		r20 = r0;
		r3 = r38.getSuggestedMinimumHeight();
		r0 = r20_heightSize;
		r20_heightSize = java.lang.Math.max(r0, r3);
		r3 = 0;
		r0 = r20_heightSize;
		r1 = r40_heightMeasureSpec;
		r21 = android.support.v4.view.ViewCompat.resolveSizeAndState(r0, r1, r3);
		r3 = 16777215; // 0xffffff float:2.3509886E-38 double:8.2890456E-317;
		r20_heightSize = r21_heightSizeAndState & r3;
		r0 = r38;
		r3 = r0.mTotalLength;
		r18 = r20_heightSize - r3;
		if (r31_skippedMeasure != 0) goto L_0x0261;
	L_0x025a:
		if (r18_delta == 0) goto L_0x03b6;
	L_0x025c:
		r3 = 0;
		r3 = (r33_totalWeight > r3 ? 1 : (r33_totalWeight == r3 ? 0 : -1));
		if (r3 <= 0) goto L_0x03b6;
	L_0x0261:
		r0 = r38;
		r3 = r0.mWeightSum;
		r6 = 0;
		r3 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
		if (r3 <= 0) goto L_0x028b;
	L_0x026a:
		r0 = r38;
		r0 = r0.mWeightSum;
		r35 = r0;
	L_0x0270:
		r3 = 0;
		r0 = r38;
		r0.mTotalLength = r3;
		r5_i = 0;
	L_0x0276:
		r0 = r17_count;
		if (r5_i >= r0) goto L_0x036a;
	L_0x027a:
		r0 = r38;
		r4_child = r0.getVirtualChildAt(r5_i);
		r3 = r4_child.getVisibility();
		r6 = 8;
		if (r3 != r6) goto L_0x028e;
	L_0x0288:
		r5_i++;
		goto L_0x0276;
	L_0x028b:
		r35_weightSum = r33_totalWeight;
		goto L_0x0270;
	L_0x028e:
		r23_lp = r4_child.getLayoutParams();
		r23_lp = (android.support.v7.widget.LinearLayoutCompat.LayoutParams) r23_lp;
		r0 = r23_lp;
		r13 = r0.weight;
		r3 = 0;
		r3 = (r13_childExtra > r3 ? 1 : (r13_childExtra == r3 ? 0 : -1));
		if (r3 <= 0) goto L_0x02f1;
	L_0x029d:
		r0 = r18_delta;
		r3 = (float) r0;
		r3 *= r13_childExtra;
		r3 /= r35_weightSum;
		r0 = (int) r3;
		r30 = r0;
		r35_weightSum -= r13_childExtra;
		r18_delta -= r30_share;
		r3 = r38.getPaddingLeft();
		r6 = r38.getPaddingRight();
		r3 += r6;
		r0 = r23_lp;
		r6 = r0.leftMargin;
		r3 += r6;
		r0 = r23_lp;
		r6 = r0.rightMargin;
		r3 += r6;
		r0 = r23_lp;
		r6 = r0.width;
		r0 = r39_widthMeasureSpec;
		r16 = getChildMeasureSpec(r0, r3, r6);
		r0 = r23_lp;
		r3 = r0.height;
		if (r3 != 0) goto L_0x02d3;
	L_0x02cd:
		r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r0 = r19_heightMode;
		if (r0 == r3) goto L_0x034f;
	L_0x02d3:
		r3 = r4_child.getMeasuredHeight();
		r14_childHeight = r3 + r30_share;
		if (r14_childHeight >= 0) goto L_0x02dc;
	L_0x02db:
		r14_childHeight = 0;
	L_0x02dc:
		r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r3 = android.view.View.MeasureSpec.makeMeasureSpec(r14_childHeight, r3);
		r0 = r16_childWidthMeasureSpec;
		r4_child.measure(r0, r3);
	L_0x02e7:
		r3 = android.support.v4.view.ViewCompat.getMeasuredState(r4_child);
		r3 &= -256;
		r15_childState = android.support.v7.widget.ViewUtils.combineMeasuredStates(r15_childState, r3);
	L_0x02f1:
		r0 = r23_lp;
		r3 = r0.leftMargin;
		r0 = r23_lp;
		r6 = r0.rightMargin;
		r24_margin = r3 + r6;
		r3 = r4_child.getMeasuredWidth();
		r28_measuredWidth = r3 + r24_margin;
		r27_maxWidth = java.lang.Math.max(r27_maxWidth, r28_measuredWidth);
		r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r0 = r37_widthMode;
		if (r0 == r3) goto L_0x0362;
	L_0x030b:
		r0 = r23_lp;
		r3 = r0.width;
		r6 = -1;
		if (r3 != r6) goto L_0x0362;
	L_0x0312:
		r26_matchWidthLocally = 1;
	L_0x0314:
		if (r26_matchWidthLocally == 0) goto L_0x0365;
	L_0x0316:
		r0 = r24_margin;
		r11_alternativeMaxWidth = java.lang.Math.max(r11_alternativeMaxWidth, r0);
		if (r10_allFillParent == 0) goto L_0x0368;
	L_0x031e:
		r0 = r23_lp;
		r3 = r0.width;
		r6 = -1;
		if (r3 != r6) goto L_0x0368;
	L_0x0325:
		r10_allFillParent = 1;
	L_0x0326:
		r0 = r38;
		r0 = r0.mTotalLength;
		r32_totalLength = r0;
		r3 = r4_child.getMeasuredHeight();
		r3 += r32_totalLength;
		r0 = r23_lp;
		r6 = r0.topMargin;
		r3 += r6;
		r0 = r23_lp;
		r6 = r0.bottomMargin;
		r3 += r6;
		r0 = r38;
		r6 = r0.getNextLocationOffset(r4_child);
		r3 += r6;
		r0 = r32_totalLength;
		r3 = java.lang.Math.max(r0, r3);
		r0 = r38;
		r0.mTotalLength = r3;
		goto L_0x0288;
	L_0x034f:
		if (r30_share <= 0) goto L_0x035f;
	L_0x0351:
		r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r0 = r30_share;
		r3 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r3);
		r0 = r16_childWidthMeasureSpec;
		r4_child.measure(r0, r3);
		goto L_0x02e7;
	L_0x035f:
		r30_share = 0;
		goto L_0x0351;
	L_0x0362:
		r26_matchWidthLocally = 0;
		goto L_0x0314;
	L_0x0365:
		r24_margin = r28_measuredWidth;
		goto L_0x0316;
	L_0x0368:
		r10_allFillParent = 0;
		goto L_0x0326;
	L_0x036a:
		r0 = r38;
		r3 = r0.mTotalLength;
		r6 = r38.getPaddingTop();
		r7 = r38.getPaddingBottom();
		r6 += r7;
		r3 += r6;
		r0 = r38;
		r0.mTotalLength = r3;
	L_0x037c:
		if (r10_allFillParent != 0) goto L_0x0386;
	L_0x037e:
		r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r0 = r37_widthMode;
		if (r0 == r3) goto L_0x0386;
	L_0x0384:
		r27_maxWidth = r11_alternativeMaxWidth;
	L_0x0386:
		r3 = r38.getPaddingLeft();
		r6 = r38.getPaddingRight();
		r3 += r6;
		r27_maxWidth += r3;
		r3 = r38.getSuggestedMinimumWidth();
		r0 = r27_maxWidth;
		r27_maxWidth = java.lang.Math.max(r0, r3);
		r0 = r27_maxWidth;
		r1 = r39_widthMeasureSpec;
		r3 = android.support.v4.view.ViewCompat.resolveSizeAndState(r0, r1, r15_childState);
		r0 = r38;
		r1 = r21_heightSizeAndState;
		r0.setMeasuredDimension(r3, r1);
		if (r25_matchWidth == 0) goto L_0x03b5;
	L_0x03ac:
		r0 = r38;
		r1 = r17_count;
		r2 = r40_heightMeasureSpec;
		r0.forceUniformWidth(r1, r2);
	L_0x03b5:
		return;
	L_0x03b6:
		r0 = r36_weightedMaxWidth;
		r11_alternativeMaxWidth = java.lang.Math.max(r11_alternativeMaxWidth, r0);
		if (r34_useLargestChild == 0) goto L_0x037c;
	L_0x03be:
		r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r0 = r19_heightMode;
		if (r0 == r3) goto L_0x037c;
	L_0x03c4:
		r5_i = 0;
	L_0x03c5:
		r0 = r17_count;
		if (r5_i >= r0) goto L_0x037c;
	L_0x03c9:
		r0 = r38;
		r4_child = r0.getVirtualChildAt(r5_i);
		if (r4_child == 0) goto L_0x03d9;
	L_0x03d1:
		r3 = r4_child.getVisibility();
		r6 = 8;
		if (r3 != r6) goto L_0x03dc;
	L_0x03d9:
		r5_i++;
		goto L_0x03c5;
	L_0x03dc:
		r23_lp = r4_child.getLayoutParams();
		r23_lp = (android.support.v7.widget.LinearLayoutCompat.LayoutParams) r23_lp;
		r0 = r23_lp;
		r13_childExtra = r0.weight;
		r3 = 0;
		r3 = (r13_childExtra > r3 ? 1 : (r13_childExtra == r3 ? 0 : -1));
		if (r3 <= 0) goto L_0x03d9;
	L_0x03eb:
		r3 = r4_child.getMeasuredWidth();
		r6 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r3 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r6);
		r6 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
		r0 = r22_largestChildHeight;
		r6 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r6);
		r4_child.measure(r3, r6);
		goto L_0x03d9;
	}
	*/
	void measureVertical(int widthMeasureSpec, int heightMeasureSpec) {
		View child;
		LayoutParams lp;
		int childHeight;
		int totalLength;
		boolean matchWidthLocally;
		int margin;
		int measuredWidth;
		mTotalLength = 0;
		int maxWidth = SHOW_DIVIDER_NONE;
		int childState = SHOW_DIVIDER_NONE;
		int alternativeMaxWidth = SHOW_DIVIDER_NONE;
		int weightedMaxWidth = SHOW_DIVIDER_NONE;
		boolean allFillParent = true;
		float totalWeight = BitmapDescriptorFactory.HUE_RED;
		int count = getVirtualChildCount();
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		boolean matchWidth = false;
		boolean skippedMeasure = false;
		int baselineChildIndex = mBaselineAlignedChildIndex;
		boolean useLargestChild = mUseLargestChild;
		int largestChildHeight = TLRPC.MESSAGE_FLAG_MEGAGROUP;
		int i = SHOW_DIVIDER_NONE;
		while (i < count) {
			child = getVirtualChildAt(i);
			if (child == null) {
				mTotalLength += measureNullChild(i);
			} else if (child.getVisibility() == 8) {
				i += getChildrenSkipCount(child, i);
			} else {
				if (hasDividerBeforeChildAt(i)) {
					mTotalLength += mDividerHeight;
				}
				lp = (LayoutParams) child.getLayoutParams();
				totalWeight += lp.weight;
				if (heightMode != 1073741824 || lp.height != 0 || lp.weight <= 0.0f) {
					int oldHeight = TLRPC.MESSAGE_FLAG_MEGAGROUP;
					int r9i;
					if (lp.height != 0 || lp.weight <= 0.0f) {
						if (totalWeight != 0.0f) {
							r9i = mTotalLength;
						} else {
							r9i = SHOW_DIVIDER_NONE;
						}
						measureChildBeforeLayout(child, i, widthMeasureSpec, SHOW_DIVIDER_NONE, heightMeasureSpec, r9i);
						if (oldHeight == TLRPC.MESSAGE_FLAG_MEGAGROUP) {
							lp.height = oldHeight;
						}
						childHeight = child.getMeasuredHeight();
						totalLength = mTotalLength;
						mTotalLength = Math.max(totalLength, (((totalLength + childHeight) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
						if (useLargestChild) {
							largestChildHeight = Math.max(childHeight, largestChildHeight);
						}
					} else {
						oldHeight = SHOW_DIVIDER_NONE;
						lp.height = -2;
						if (totalWeight != 0.0f) {
							r9i = SHOW_DIVIDER_NONE;
						} else {
							r9i = mTotalLength;
						}
						measureChildBeforeLayout(child, i, widthMeasureSpec, SHOW_DIVIDER_NONE, heightMeasureSpec, r9i);
						if (oldHeight == TLRPC.MESSAGE_FLAG_MEGAGROUP) {
							childHeight = child.getMeasuredHeight();
							totalLength = mTotalLength;
							mTotalLength = Math.max(totalLength, (((totalLength + childHeight) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
							if (useLargestChild) {
								if (baselineChildIndex < 0 || baselineChildIndex != i + 1) {
									matchWidthLocally = false;
									if (widthMode == 1073741824 || lp.width != -1) {
										margin = lp.leftMargin + lp.rightMargin;
										measuredWidth = child.getMeasuredWidth() + margin;
										maxWidth = Math.max(maxWidth, measuredWidth);
										childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
										if (!allFillParent || lp.width != -1) {
											allFillParent = false;
										} else {
											allFillParent = true;
										}
										if (lp.weight <= 0.0f) {
											if (!matchWidthLocally) {
												weightedMaxWidth = Math.max(weightedMaxWidth, margin);
											} else {
												margin = measuredWidth;
												weightedMaxWidth = Math.max(weightedMaxWidth, margin);
											}
										} else if (!matchWidthLocally) {
											alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
										} else {
											alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
										}
										i += getChildrenSkipCount(child, i);
									} else {
										matchWidth = true;
										matchWidthLocally = true;
										margin = lp.leftMargin + lp.rightMargin;
										measuredWidth = child.getMeasuredWidth() + margin;
										maxWidth = Math.max(maxWidth, measuredWidth);
										childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
										if (!allFillParent || lp.width != -1) {
											allFillParent = false;
										} else {
											allFillParent = true;
										}
										if (lp.weight <= 0.0f) {
											if (!matchWidthLocally) {
											}
											alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
										} else {
											if (!matchWidthLocally) {
												margin = measuredWidth;
											}
											weightedMaxWidth = Math.max(weightedMaxWidth, margin);
										}
										i += getChildrenSkipCount(child, i);
									}
								} else {
									mBaselineChildTop = mTotalLength;
									matchWidthLocally = false;
									if (widthMode == 1073741824 || lp.width != -1) {
										margin = lp.leftMargin + lp.rightMargin;
										measuredWidth = child.getMeasuredWidth() + margin;
										maxWidth = Math.max(maxWidth, measuredWidth);
										childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
										if (!allFillParent || lp.width != -1) {
											allFillParent = false;
										} else {
											allFillParent = true;
										}
										if (lp.weight <= 0.0f) {
											if (!matchWidthLocally) {
												weightedMaxWidth = Math.max(weightedMaxWidth, margin);
											} else {
												margin = measuredWidth;
												weightedMaxWidth = Math.max(weightedMaxWidth, margin);
											}
										} else if (!matchWidthLocally) {
											alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
										} else {
											alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
										}
										i += getChildrenSkipCount(child, i);
									} else {
										matchWidth = true;
										matchWidthLocally = true;
										margin = lp.leftMargin + lp.rightMargin;
										measuredWidth = child.getMeasuredWidth() + margin;
										maxWidth = Math.max(maxWidth, measuredWidth);
										childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
										if (!allFillParent || lp.width != -1) {
											allFillParent = false;
										} else {
											allFillParent = true;
										}
										if (lp.weight <= 0.0f) {
											if (!matchWidthLocally) {
											}
											alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
										} else {
											if (!matchWidthLocally) {
												margin = measuredWidth;
											}
											weightedMaxWidth = Math.max(weightedMaxWidth, margin);
										}
										i += getChildrenSkipCount(child, i);
									}
								}
							} else {
								largestChildHeight = Math.max(childHeight, largestChildHeight);
							}
						} else {
							lp.height = oldHeight;
							childHeight = child.getMeasuredHeight();
							totalLength = mTotalLength;
							mTotalLength = Math.max(totalLength, (((totalLength + childHeight) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
							if (useLargestChild) {
								largestChildHeight = Math.max(childHeight, largestChildHeight);
							}
						}
					}
				} else {
					totalLength = mTotalLength;
					mTotalLength = Math.max(totalLength, (lp.topMargin + totalLength) + lp.bottomMargin);
					skippedMeasure = true;
				}
				if (baselineChildIndex < 0 || baselineChildIndex != i + 1) {
					matchWidthLocally = false;
					if (widthMode == 1073741824 || lp.width != -1) {
						margin = lp.leftMargin + lp.rightMargin;
						measuredWidth = child.getMeasuredWidth() + margin;
						maxWidth = Math.max(maxWidth, measuredWidth);
						childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
						if (!allFillParent || lp.width != -1) {
							allFillParent = false;
						} else {
							allFillParent = true;
						}
						if (lp.weight <= 0.0f) {
							if (!matchWidthLocally) {
								weightedMaxWidth = Math.max(weightedMaxWidth, margin);
							} else {
								margin = measuredWidth;
								weightedMaxWidth = Math.max(weightedMaxWidth, margin);
							}
						} else if (!matchWidthLocally) {
							alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
						} else {
							alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
						}
						i += getChildrenSkipCount(child, i);
					} else {
						matchWidth = true;
						matchWidthLocally = true;
						margin = lp.leftMargin + lp.rightMargin;
						measuredWidth = child.getMeasuredWidth() + margin;
						maxWidth = Math.max(maxWidth, measuredWidth);
						childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
						if (!allFillParent || lp.width != -1) {
							allFillParent = false;
						} else {
							allFillParent = true;
						}
						if (lp.weight <= 0.0f) {
							if (!matchWidthLocally) {
							}
							alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
						} else {
							if (!matchWidthLocally) {
								margin = measuredWidth;
							}
							weightedMaxWidth = Math.max(weightedMaxWidth, margin);
						}
						i += getChildrenSkipCount(child, i);
					}
				} else {
					mBaselineChildTop = mTotalLength;
					matchWidthLocally = false;
					if (widthMode == 1073741824 || lp.width != -1) {
						margin = lp.leftMargin + lp.rightMargin;
						measuredWidth = child.getMeasuredWidth() + margin;
						maxWidth = Math.max(maxWidth, measuredWidth);
						childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
						if (!allFillParent || lp.width != -1) {
							allFillParent = false;
						} else {
							allFillParent = true;
						}
						if (lp.weight <= 0.0f) {
							if (!matchWidthLocally) {
								weightedMaxWidth = Math.max(weightedMaxWidth, margin);
							} else {
								margin = measuredWidth;
								weightedMaxWidth = Math.max(weightedMaxWidth, margin);
							}
						} else if (!matchWidthLocally) {
							alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
						} else {
							alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
						}
						i += getChildrenSkipCount(child, i);
					} else {
						matchWidth = true;
						matchWidthLocally = true;
						margin = lp.leftMargin + lp.rightMargin;
						measuredWidth = child.getMeasuredWidth() + margin;
						maxWidth = Math.max(maxWidth, measuredWidth);
						childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child));
						if (!allFillParent || lp.width != -1) {
							allFillParent = false;
						} else {
							allFillParent = true;
						}
						if (lp.weight <= 0.0f) {
							if (!matchWidthLocally) {
							}
							alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
						} else {
							if (!matchWidthLocally) {
								margin = measuredWidth;
							}
							weightedMaxWidth = Math.max(weightedMaxWidth, margin);
						}
						i += getChildrenSkipCount(child, i);
					}
				}
			}
			i++;
		}
		int heightSizeAndState;
		int delta;
		float weightSum;
		float childExtra;
		int share;
		int childWidthMeasureSpec;
		if (mTotalLength <= 0 || !hasDividerBeforeChildAt(count)) {
			mTotalLength += getPaddingTop() + getPaddingBottom();
			heightSizeAndState = ViewCompat.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumHeight()), heightMeasureSpec, SHOW_DIVIDER_NONE);
			delta = (heightSizeAndState & 16777215) - mTotalLength;
			if (skippedMeasure) {
				if (delta == 0 || totalWeight <= 0.0f) {
					if (!useLargestChild) {
						if (heightMode == 1073741824) {
							i = SHOW_DIVIDER_NONE;
							while (i < count) {
								child = getVirtualChildAt(i);
								if (child == null || child.getVisibility() == 8 || ((LayoutParams) child.getLayoutParams()).weight <= 0.0f) {
									i++;
								} else {
									child.measure(MeasureSpec.makeMeasureSpec(child.getMeasuredWidth(), 1073741824), MeasureSpec.makeMeasureSpec(largestChildHeight, 1073741824));
									i++;
								}
							}
						}
					}
				} else {
					if (mWeightSum <= 0.0f) {
						weightSum = mWeightSum;
					} else {
						weightSum = totalWeight;
					}
					mTotalLength = 0;
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child.getVisibility() != 8) {
							i++;
						} else {
							lp = (LayoutParams) child.getLayoutParams();
							childExtra = lp.weight;
							if (childExtra <= 0.0f) {
								share = (int) ((((float) delta) * childExtra) / weightSum);
								delta -= share;
								childWidthMeasureSpec = getChildMeasureSpec(widthMeasureSpec, ((getPaddingLeft() + getPaddingRight()) + lp.leftMargin) + lp.rightMargin, lp.width);
								if (lp.height != 0 || heightMode != 1073741824) {
									childHeight = child.getMeasuredHeight() + share;
									if (childHeight >= 0) {
										childHeight = SHOW_DIVIDER_NONE;
									}
									child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(childHeight, 1073741824));
								} else if (share <= 0) {
									child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(share, 1073741824));
								} else {
									share = SHOW_DIVIDER_NONE;
									child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(share, 1073741824));
								}
								childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -256);
							}
							margin = lp.leftMargin + lp.rightMargin;
							measuredWidth = child.getMeasuredWidth() + margin;
							maxWidth = Math.max(maxWidth, measuredWidth);
							if (widthMode == 1073741824 || lp.width != -1) {
								matchWidthLocally = false;
							} else {
								matchWidthLocally = true;
							}
							if (!matchWidthLocally) {
								alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
								if (!allFillParent || lp.width != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
								i++;
							} else {
								margin = measuredWidth;
								alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
								if (!allFillParent || lp.width != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
								i++;
							}
						}
					}
					mTotalLength += getPaddingTop() + getPaddingBottom();
				}
			} else {
				if (mWeightSum <= 0.0f) {
					weightSum = totalWeight;
				} else {
					weightSum = mWeightSum;
				}
				mTotalLength = 0;
				i = SHOW_DIVIDER_NONE;
				while (i < count) {
					child = getVirtualChildAt(i);
					if (child.getVisibility() != 8) {
						lp = (LayoutParams) child.getLayoutParams();
						childExtra = lp.weight;
						if (childExtra <= 0.0f) {
							margin = lp.leftMargin + lp.rightMargin;
							measuredWidth = child.getMeasuredWidth() + margin;
							maxWidth = Math.max(maxWidth, measuredWidth);
							if (widthMode == 1073741824 || lp.width != -1) {
								matchWidthLocally = false;
							} else {
								matchWidthLocally = true;
							}
							if (!matchWidthLocally) {
								margin = measuredWidth;
							}
							alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
							if (!allFillParent || lp.width != -1) {
								allFillParent = false;
							} else {
								allFillParent = true;
							}
							totalLength = mTotalLength;
							mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
						} else {
							share = (int) ((((float) delta) * childExtra) / weightSum);
							delta -= share;
							childWidthMeasureSpec = getChildMeasureSpec(widthMeasureSpec, ((getPaddingLeft() + getPaddingRight()) + lp.leftMargin) + lp.rightMargin, lp.width);
							if (lp.height != 0 || heightMode != 1073741824) {
								childHeight = child.getMeasuredHeight() + share;
								if (childHeight >= 0) {
									child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(childHeight, 1073741824));
								} else {
									childHeight = SHOW_DIVIDER_NONE;
									child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(childHeight, 1073741824));
								}
							} else {
								if (share <= 0) {
									share = SHOW_DIVIDER_NONE;
								}
								child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(share, 1073741824));
							}
							childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -256);
							margin = lp.leftMargin + lp.rightMargin;
							measuredWidth = child.getMeasuredWidth() + margin;
							maxWidth = Math.max(maxWidth, measuredWidth);
							if (widthMode == 1073741824 || lp.width != -1) {
								matchWidthLocally = false;
							} else {
								matchWidthLocally = true;
							}
							if (!matchWidthLocally) {
								alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
								if (!allFillParent || lp.width != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
							} else {
								margin = measuredWidth;
								alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
								if (!allFillParent || lp.width != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
							}
						}
					}
					i++;
				}
				mTotalLength += getPaddingTop() + getPaddingBottom();
			}
			if (allFillParent || widthMode == 1073741824) {
				setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(maxWidth + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), widthMeasureSpec, childState), heightSizeAndState);
				if (!matchWidth) {
					forceUniformWidth(count, heightMeasureSpec);
				}
			} else {
				setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(maxWidth + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), widthMeasureSpec, childState), heightSizeAndState);
				if (!matchWidth) {
				} else {
					forceUniformWidth(count, heightMeasureSpec);
				}
			}
		} else {
			mTotalLength += mDividerHeight;
			mTotalLength += getPaddingTop() + getPaddingBottom();
			heightSizeAndState = ViewCompat.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumHeight()), heightMeasureSpec, SHOW_DIVIDER_NONE);
			delta = (heightSizeAndState & 16777215) - mTotalLength;
			if (skippedMeasure) {
				if (mWeightSum <= 0.0f) {
					weightSum = mWeightSum;
				} else {
					weightSum = totalWeight;
				}
				mTotalLength = 0;
				i = SHOW_DIVIDER_NONE;
				while (i < count) {
					child = getVirtualChildAt(i);
					if (child.getVisibility() != 8) {
						i++;
					} else {
						lp = (LayoutParams) child.getLayoutParams();
						childExtra = lp.weight;
						if (childExtra <= 0.0f) {
							share = (int) ((((float) delta) * childExtra) / weightSum);
							delta -= share;
							childWidthMeasureSpec = getChildMeasureSpec(widthMeasureSpec, ((getPaddingLeft() + getPaddingRight()) + lp.leftMargin) + lp.rightMargin, lp.width);
							if (lp.height != 0 || heightMode != 1073741824) {
								childHeight = child.getMeasuredHeight() + share;
								if (childHeight >= 0) {
									childHeight = SHOW_DIVIDER_NONE;
								}
								child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(childHeight, 1073741824));
							} else if (share <= 0) {
								child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(share, 1073741824));
							} else {
								share = SHOW_DIVIDER_NONE;
								child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(share, 1073741824));
							}
							childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -256);
						}
						margin = lp.leftMargin + lp.rightMargin;
						measuredWidth = child.getMeasuredWidth() + margin;
						maxWidth = Math.max(maxWidth, measuredWidth);
						if (widthMode == 1073741824 || lp.width != -1) {
							matchWidthLocally = false;
						} else {
							matchWidthLocally = true;
						}
						if (!matchWidthLocally) {
							margin = measuredWidth;
						}
						alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
						if (!allFillParent || lp.width != -1) {
							allFillParent = false;
						} else {
							allFillParent = true;
						}
						totalLength = mTotalLength;
						mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
						i++;
					}
				}
				mTotalLength += getPaddingTop() + getPaddingBottom();
			} else if (delta == 0 || totalWeight <= 0.0f) {
				if (!useLargestChild) {
					if (allFillParent || widthMode == 1073741824) {
						setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(maxWidth + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), widthMeasureSpec, childState), heightSizeAndState);
						if (!matchWidth) {
							forceUniformWidth(count, heightMeasureSpec);
						}
					} else {
						setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(maxWidth + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), widthMeasureSpec, childState), heightSizeAndState);
						if (!matchWidth) {
						} else {
							forceUniformWidth(count, heightMeasureSpec);
						}
					}
				} else if (heightMode == 1073741824) {
					if (allFillParent || widthMode == 1073741824) {
						setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(maxWidth + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), widthMeasureSpec, childState), heightSizeAndState);
						if (!matchWidth) {
							forceUniformWidth(count, heightMeasureSpec);
						}
					} else {
						setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(maxWidth + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), widthMeasureSpec, childState), heightSizeAndState);
						if (!matchWidth) {
						} else {
							forceUniformWidth(count, heightMeasureSpec);
						}
					}
				} else {
					i = SHOW_DIVIDER_NONE;
					while (i < count) {
						child = getVirtualChildAt(i);
						if (child == null || child.getVisibility() == 8 || ((LayoutParams) child.getLayoutParams()).weight <= 0.0f) {
							i++;
						} else {
							child.measure(MeasureSpec.makeMeasureSpec(child.getMeasuredWidth(), 1073741824), MeasureSpec.makeMeasureSpec(largestChildHeight, 1073741824));
							i++;
						}
					}
				}
			} else {
				if (mWeightSum <= 0.0f) {
					weightSum = totalWeight;
				} else {
					weightSum = mWeightSum;
				}
				mTotalLength = 0;
				i = SHOW_DIVIDER_NONE;
				while (i < count) {
					child = getVirtualChildAt(i);
					if (child.getVisibility() != 8) {
						lp = (LayoutParams) child.getLayoutParams();
						childExtra = lp.weight;
						if (childExtra <= 0.0f) {
							margin = lp.leftMargin + lp.rightMargin;
							measuredWidth = child.getMeasuredWidth() + margin;
							maxWidth = Math.max(maxWidth, measuredWidth);
							if (widthMode == 1073741824 || lp.width != -1) {
								matchWidthLocally = false;
							} else {
								matchWidthLocally = true;
							}
							if (!matchWidthLocally) {
								alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
								if (!allFillParent || lp.width != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
							} else {
								margin = measuredWidth;
								alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
								if (!allFillParent || lp.width != -1) {
									allFillParent = false;
								} else {
									allFillParent = true;
								}
								totalLength = mTotalLength;
								mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
							}
						} else {
							share = (int) ((((float) delta) * childExtra) / weightSum);
							delta -= share;
							childWidthMeasureSpec = getChildMeasureSpec(widthMeasureSpec, ((getPaddingLeft() + getPaddingRight()) + lp.leftMargin) + lp.rightMargin, lp.width);
							if (lp.height != 0 || heightMode != 1073741824) {
								childHeight = child.getMeasuredHeight() + share;
								if (childHeight >= 0) {
									child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(childHeight, 1073741824));
								} else {
									childHeight = SHOW_DIVIDER_NONE;
									child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(childHeight, 1073741824));
								}
							} else {
								if (share <= 0) {
									share = SHOW_DIVIDER_NONE;
								}
								child.measure(childWidthMeasureSpec, MeasureSpec.makeMeasureSpec(share, 1073741824));
							}
							childState = ViewUtils.combineMeasuredStates(childState, ViewCompat.getMeasuredState(child) & -256);
							margin = lp.leftMargin + lp.rightMargin;
							measuredWidth = child.getMeasuredWidth() + margin;
							maxWidth = Math.max(maxWidth, measuredWidth);
							if (widthMode == 1073741824 || lp.width != -1) {
								matchWidthLocally = false;
							} else {
								matchWidthLocally = true;
							}
							if (!matchWidthLocally) {
								margin = measuredWidth;
							}
							alternativeMaxWidth = Math.max(alternativeMaxWidth, margin);
							if (!allFillParent || lp.width != -1) {
								allFillParent = false;
							} else {
								allFillParent = true;
							}
							totalLength = mTotalLength;
							mTotalLength = Math.max(totalLength, (((child.getMeasuredHeight() + totalLength) + lp.topMargin) + lp.bottomMargin) + getNextLocationOffset(child));
						}
					}
					i++;
				}
				mTotalLength += getPaddingTop() + getPaddingBottom();
			}
			if (allFillParent || widthMode == 1073741824) {
				setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(maxWidth + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), widthMeasureSpec, childState), heightSizeAndState);
				if (!matchWidth) {
					forceUniformWidth(count, heightMeasureSpec);
				}
			} else {
				setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(maxWidth + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), widthMeasureSpec, childState), heightSizeAndState);
				if (!matchWidth) {
				} else {
					forceUniformWidth(count, heightMeasureSpec);
				}
			}
		}
	}

	protected void onDraw(Canvas canvas) {
		if (mDivider == null) {
		} else if (mOrientation == 1) {
			drawDividersVertical(canvas);
		} else {
			drawDividersHorizontal(canvas);
		}
	}

	public void onInitializeAccessibilityEvent(AccessibilityEvent event) {
		if (VERSION.SDK_INT >= 14) {
			super.onInitializeAccessibilityEvent(event);
			event.setClassName(LinearLayoutCompat.class.getName());
		}
	}

	public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
		if (VERSION.SDK_INT >= 14) {
			super.onInitializeAccessibilityNodeInfo(info);
			info.setClassName(LinearLayoutCompat.class.getName());
		}
	}

	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		if (mOrientation == 1) {
			layoutVertical(l, t, r, b);
		} else {
			layoutHorizontal(l, t, r, b);
		}
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		if (mOrientation == 1) {
			measureVertical(widthMeasureSpec, heightMeasureSpec);
		} else {
			measureHorizontal(widthMeasureSpec, heightMeasureSpec);
		}
	}

	public void setBaselineAligned(boolean baselineAligned) {
		mBaselineAligned = baselineAligned;
	}

	public void setBaselineAlignedChildIndex(int i) {
		if (i < 0 || i >= getChildCount()) {
			throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
		} else {
			mBaselineAlignedChildIndex = i;
		}
	}

	public void setDividerDrawable(Drawable divider) {
		boolean r0z = false;
		if (divider == mDivider) {
		} else {
			mDivider = divider;
			if (divider != null) {
				mDividerWidth = divider.getIntrinsicWidth();
				mDividerHeight = divider.getIntrinsicHeight();
			} else {
				mDividerWidth = 0;
				mDividerHeight = 0;
			}
			if (divider == null) {
				r0z = true;
			}
			setWillNotDraw(r0z);
			requestLayout();
		}
	}

	public void setDividerPadding(int padding) {
		mDividerPadding = padding;
	}

	public void setGravity(int gravity) {
		if (mGravity != gravity) {
			if ((8388615 & gravity) == 0) {
				gravity |= 8388611;
			}
			if ((gravity & 112) == 0) {
				gravity |= 48;
			}
			mGravity = gravity;
			requestLayout();
		}
	}

	public void setHorizontalGravity(int horizontalGravity) {
		int gravity = horizontalGravity & 8388615;
		if ((mGravity & 8388615) != gravity) {
			mGravity = (mGravity & -8388616) | gravity;
			requestLayout();
		}
	}

	public void setMeasureWithLargestChildEnabled(boolean enabled) {
		mUseLargestChild = enabled;
	}

	public void setOrientation(int orientation) {
		if (mOrientation != orientation) {
			mOrientation = orientation;
			requestLayout();
		}
	}

	public void setShowDividers(int showDividers) {
		if (showDividers != mShowDividers) {
			requestLayout();
		}
		mShowDividers = showDividers;
	}

	public void setVerticalGravity(int verticalGravity) {
		int gravity = verticalGravity & 112;
		if ((mGravity & 112) != gravity) {
			mGravity = (mGravity & -113) | gravity;
			requestLayout();
		}
	}

	public void setWeightSum(float weightSum) {
		mWeightSum = Math.max(BitmapDescriptorFactory.HUE_RED, weightSum);
	}

	public boolean shouldDelayChildPressedState() {
		return false;
	}
}
