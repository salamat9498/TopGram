package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.v4.view.TintableBackgroundView;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.widget.ImageButton;

public class AppCompatImageButton extends ImageButton implements TintableBackgroundView {
	private AppCompatBackgroundHelper mBackgroundTintHelper;
	private AppCompatImageHelper mImageHelper;

	public AppCompatImageButton(Context context) {
		this(context, null);
	}

	public AppCompatImageButton(Context context, AttributeSet attrs) {
		this(context, attrs, R.attr.imageButtonStyle);
	}

	public AppCompatImageButton(Context context, AttributeSet attrs, int defStyleAttr) {
		super(TintContextWrapper.wrap(context), attrs, defStyleAttr);
		mBackgroundTintHelper = new AppCompatBackgroundHelper(this);
		mBackgroundTintHelper.loadFromAttributes(attrs, defStyleAttr);
		mImageHelper = new AppCompatImageHelper(this);
		mImageHelper.loadFromAttributes(attrs, defStyleAttr);
	}

	protected void drawableStateChanged() {
		super.drawableStateChanged();
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.applySupportBackgroundTint();
		}
	}

	@Nullable
	public ColorStateList getSupportBackgroundTintList() {
		if (mBackgroundTintHelper != null) {
			return mBackgroundTintHelper.getSupportBackgroundTintList();
		} else {
			return null;
		}
	}

	@Nullable
	public Mode getSupportBackgroundTintMode() {
		if (mBackgroundTintHelper != null) {
			return mBackgroundTintHelper.getSupportBackgroundTintMode();
		} else {
			return null;
		}
	}

	public boolean hasOverlappingRendering() {
		if (!mImageHelper.hasOverlappingRendering() || !super.hasOverlappingRendering()) {
			return false;
		} else {
			return true;
		}
	}

	public void setBackgroundDrawable(Drawable background) {
		super.setBackgroundDrawable(background);
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.onSetBackgroundDrawable(background);
		}
	}

	public void setBackgroundResource(@DrawableRes int resId) {
		super.setBackgroundResource(resId);
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.onSetBackgroundResource(resId);
		}
	}

	public void setImageResource(@DrawableRes int resId) {
		mImageHelper.setImageResource(resId);
	}

	public void setSupportBackgroundTintList(@Nullable ColorStateList tint) {
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.setSupportBackgroundTintList(tint);
		}
	}

	public void setSupportBackgroundTintMode(@Nullable Mode tintMode) {
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.setSupportBackgroundTintMode(tintMode);
		}
	}
}
