package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.v4.view.TintableBackgroundView;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.widget.EditText;

public class AppCompatEditText extends EditText implements TintableBackgroundView {
	private AppCompatBackgroundHelper mBackgroundTintHelper;
	private AppCompatTextHelper mTextHelper;

	public AppCompatEditText(Context context) {
		this(context, null);
	}

	public AppCompatEditText(Context context, AttributeSet attrs) {
		this(context, attrs, R.attr.editTextStyle);
	}

	public AppCompatEditText(Context context, AttributeSet attrs, int defStyleAttr) {
		super(TintContextWrapper.wrap(context), attrs, defStyleAttr);
		mBackgroundTintHelper = new AppCompatBackgroundHelper(this);
		mBackgroundTintHelper.loadFromAttributes(attrs, defStyleAttr);
		mTextHelper = AppCompatTextHelper.create(this);
		mTextHelper.loadFromAttributes(attrs, defStyleAttr);
		mTextHelper.applyCompoundDrawablesTints();
	}

	protected void drawableStateChanged() {
		super.drawableStateChanged();
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.applySupportBackgroundTint();
		}
		if (mTextHelper != null) {
			mTextHelper.applyCompoundDrawablesTints();
		}
	}

	@Nullable
	public ColorStateList getSupportBackgroundTintList() {
		if (mBackgroundTintHelper != null) {
			return mBackgroundTintHelper.getSupportBackgroundTintList();
		} else {
			return null;
		}
	}

	@Nullable
	public Mode getSupportBackgroundTintMode() {
		if (mBackgroundTintHelper != null) {
			return mBackgroundTintHelper.getSupportBackgroundTintMode();
		} else {
			return null;
		}
	}

	public void setBackgroundDrawable(Drawable background) {
		super.setBackgroundDrawable(background);
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.onSetBackgroundDrawable(background);
		}
	}

	public void setBackgroundResource(@DrawableRes int resId) {
		super.setBackgroundResource(resId);
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.onSetBackgroundResource(resId);
		}
	}

	public void setSupportBackgroundTintList(@Nullable ColorStateList tint) {
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.setSupportBackgroundTintList(tint);
		}
	}

	public void setSupportBackgroundTintMode(@Nullable Mode tintMode) {
		if (mBackgroundTintHelper != null) {
			mBackgroundTintHelper.setSupportBackgroundTintMode(tintMode);
		}
	}

	public void setTextAppearance(Context context, int resId) {
		super.setTextAppearance(context, resId);
		if (mTextHelper != null) {
			mTextHelper.onSetTextAppearance(context, resId);
		}
	}
}
