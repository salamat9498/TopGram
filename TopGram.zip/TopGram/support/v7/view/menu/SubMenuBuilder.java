package android.support.v7.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.view.menu.MenuBuilder.Callback;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public class SubMenuBuilder extends MenuBuilder implements SubMenu {
	private MenuItemImpl mItem;
	private MenuBuilder mParentMenu;

	public SubMenuBuilder(Context context, MenuBuilder parentMenu, MenuItemImpl item) {
		super(context);
		mParentMenu = parentMenu;
		mItem = item;
	}

	public boolean collapseItemActionView(MenuItemImpl item) {
		return mParentMenu.collapseItemActionView(item);
	}

	boolean dispatchMenuItemSelected(MenuBuilder menu, MenuItem item) {
		if (super.dispatchMenuItemSelected(menu, item) || mParentMenu.dispatchMenuItemSelected(menu, item)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean expandItemActionView(MenuItemImpl item) {
		return mParentMenu.expandItemActionView(item);
	}

	public String getActionViewStatesKey() {
		int itemId;
		if (mItem != null) {
			itemId = mItem.getItemId();
		} else {
			itemId = 0;
		}
		if (itemId == 0) {
			return null;
		} else {
			return super.getActionViewStatesKey() + ":" + itemId;
		}
	}

	public MenuItem getItem() {
		return mItem;
	}

	public Menu getParentMenu() {
		return mParentMenu;
	}

	public MenuBuilder getRootMenu() {
		return mParentMenu.getRootMenu();
	}

	public boolean isQwertyMode() {
		return mParentMenu.isQwertyMode();
	}

	public boolean isShortcutsVisible() {
		return mParentMenu.isShortcutsVisible();
	}

	public void setCallback(Callback callback) {
		mParentMenu.setCallback(callback);
	}

	public SubMenu setHeaderIcon(int iconRes) {
		return (SubMenu) super.setHeaderIconInt(iconRes);
	}

	public SubMenu setHeaderIcon(Drawable icon) {
		return (SubMenu) super.setHeaderIconInt(icon);
	}

	public SubMenu setHeaderTitle(int titleRes) {
		return (SubMenu) super.setHeaderTitleInt(titleRes);
	}

	public SubMenu setHeaderTitle(CharSequence title) {
		return (SubMenu) super.setHeaderTitleInt(title);
	}

	public SubMenu setHeaderView(View view) {
		return (SubMenu) super.setHeaderViewInt(view);
	}

	public SubMenu setIcon(int iconRes) {
		mItem.setIcon(iconRes);
		return this;
	}

	public SubMenu setIcon(Drawable icon) {
		mItem.setIcon(icon);
		return this;
	}

	public void setQwertyMode(boolean isQwerty) {
		mParentMenu.setQwertyMode(isQwerty);
	}

	public void setShortcutsVisible(boolean shortcutsVisible) {
		mParentMenu.setShortcutsVisible(shortcutsVisible);
	}
}
