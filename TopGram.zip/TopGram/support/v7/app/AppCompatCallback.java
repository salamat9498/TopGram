package android.support.v7.app;

import android.support.annotation.Nullable;
import android.support.v7.view.ActionMode;
import android.support.v7.view.ActionMode.Callback;

public interface AppCompatCallback {
	public void onSupportActionModeFinished(ActionMode r1_ActionMode);

	public void onSupportActionModeStarted(ActionMode r1_ActionMode);

	@Nullable
	public ActionMode onWindowStartingSupportActionMode(Callback r1_Callback);
}
