package android.support.v7.app;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import com.rey.material.R;
import org.telegram.tgnet.ConnectionsManager;
import org.telegram.tgnet.TLRPC;

public class AppCompatDialogFragment extends DialogFragment {
	public AppCompatDialogFragment() {
		super();
	}

	public Dialog onCreateDialog(Bundle savedInstanceState) {
		return new AppCompatDialog(getContext(), getTheme());
	}

	public void setupDialog(Dialog dialog, int style) {
		if (dialog instanceof AppCompatDialog) {
			AppCompatDialog acd = (AppCompatDialog) dialog;
			switch(style) {
			case TLRPC.USER_FLAG_ACCESS_HASH:
			case TLRPC.USER_FLAG_FIRST_NAME:
				break;
			case ConnectionsManager.ConnectionStateConnected:
				dialog.getWindow().addFlags(R.styleable.View_android_paddingEnd);
				break;
			default:
				break;
			}
			acd.supportRequestWindowFeature(1);
		} else {
			super.setupDialog(dialog, style);
		}
	}
}
