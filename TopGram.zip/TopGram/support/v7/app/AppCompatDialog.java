package android.support.v7.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v7.appcompat.R;
import android.support.v7.view.ActionMode;
import android.support.v7.view.ActionMode.Callback;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

public class AppCompatDialog extends Dialog implements AppCompatCallback {
	private AppCompatDelegate mDelegate;

	public AppCompatDialog(Context context) {
		this(context, 0);
	}

	public AppCompatDialog(Context context, int theme) {
		super(context, getThemeResId(context, theme));
		getDelegate().onCreate(null);
		getDelegate().applyDayNight();
	}

	protected AppCompatDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
	}

	private static int getThemeResId(Context context, int themeId) {
		if (themeId == 0) {
			TypedValue outValue = new TypedValue();
			context.getTheme().resolveAttribute(R.attr.dialogTheme, outValue, true);
			themeId = outValue.resourceId;
		}
		return themeId;
	}

	public void addContentView(View view, LayoutParams params) {
		getDelegate().addContentView(view, params);
	}

	@Nullable
	public View findViewById(@IdRes int id) {
		return getDelegate().findViewById(id);
	}

	public AppCompatDelegate getDelegate() {
		if (mDelegate == null) {
			mDelegate = AppCompatDelegate.create((Dialog)this, (AppCompatCallback)this);
		}
		return mDelegate;
	}

	public ActionBar getSupportActionBar() {
		return getDelegate().getSupportActionBar();
	}

	public void invalidateOptionsMenu() {
		getDelegate().invalidateOptionsMenu();
	}

	protected void onCreate(Bundle savedInstanceState) {
		getDelegate().installViewFactory();
		super.onCreate(savedInstanceState);
		getDelegate().onCreate(savedInstanceState);
	}

	protected void onStop() {
		super.onStop();
		getDelegate().onStop();
	}

	public void onSupportActionModeFinished(ActionMode mode) {
	}

	public void onSupportActionModeStarted(ActionMode mode) {
	}

	@Nullable
	public ActionMode onWindowStartingSupportActionMode(Callback callback) {
		return null;
	}

	public void setContentView(@LayoutRes int layoutResID) {
		getDelegate().setContentView(layoutResID);
	}

	public void setContentView(View view) {
		getDelegate().setContentView(view);
	}

	public void setContentView(View view, LayoutParams params) {
		getDelegate().setContentView(view, params);
	}

	public void setTitle(int titleId) {
		super.setTitle(titleId);
		getDelegate().setTitle(getContext().getString(titleId));
	}

	public void setTitle(CharSequence title) {
		super.setTitle(title);
		getDelegate().setTitle(title);
	}

	public boolean supportRequestWindowFeature(int featureId) {
		return getDelegate().requestWindowFeature(featureId);
	}
}
