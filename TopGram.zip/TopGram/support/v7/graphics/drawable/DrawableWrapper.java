package android.support.v7.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.support.v4.graphics.drawable.DrawableCompat;

public class DrawableWrapper extends Drawable implements Callback {
	private Drawable mDrawable;

	public DrawableWrapper(Drawable drawable) {
		super();
		setWrappedDrawable(drawable);
	}

	public void draw(Canvas canvas) {
		mDrawable.draw(canvas);
	}

	public int getChangingConfigurations() {
		return mDrawable.getChangingConfigurations();
	}

	public Drawable getCurrent() {
		return mDrawable.getCurrent();
	}

	public int getIntrinsicHeight() {
		return mDrawable.getIntrinsicHeight();
	}

	public int getIntrinsicWidth() {
		return mDrawable.getIntrinsicWidth();
	}

	public int getMinimumHeight() {
		return mDrawable.getMinimumHeight();
	}

	public int getMinimumWidth() {
		return mDrawable.getMinimumWidth();
	}

	public int getOpacity() {
		return mDrawable.getOpacity();
	}

	public boolean getPadding(Rect padding) {
		return mDrawable.getPadding(padding);
	}

	public int[] getState() {
		return mDrawable.getState();
	}

	public Region getTransparentRegion() {
		return mDrawable.getTransparentRegion();
	}

	public Drawable getWrappedDrawable() {
		return mDrawable;
	}

	public void invalidateDrawable(Drawable who) {
		invalidateSelf();
	}

	public boolean isAutoMirrored() {
		return DrawableCompat.isAutoMirrored(mDrawable);
	}

	public boolean isStateful() {
		return mDrawable.isStateful();
	}

	public void jumpToCurrentState() {
		DrawableCompat.jumpToCurrentState(mDrawable);
	}

	protected void onBoundsChange(Rect bounds) {
		mDrawable.setBounds(bounds);
	}

	protected boolean onLevelChange(int level) {
		return mDrawable.setLevel(level);
	}

	public void scheduleDrawable(Drawable who, Runnable what, long when) {
		scheduleSelf(what, when);
	}

	public void setAlpha(int alpha) {
		mDrawable.setAlpha(alpha);
	}

	public void setAutoMirrored(boolean mirrored) {
		DrawableCompat.setAutoMirrored(mDrawable, mirrored);
	}

	public void setChangingConfigurations(int configs) {
		mDrawable.setChangingConfigurations(configs);
	}

	public void setColorFilter(ColorFilter cf) {
		mDrawable.setColorFilter(cf);
	}

	public void setDither(boolean dither) {
		mDrawable.setDither(dither);
	}

	public void setFilterBitmap(boolean filter) {
		mDrawable.setFilterBitmap(filter);
	}

	public void setHotspot(float x, float y) {
		DrawableCompat.setHotspot(mDrawable, x, y);
	}

	public void setHotspotBounds(int left, int top, int right, int bottom) {
		DrawableCompat.setHotspotBounds(mDrawable, left, top, right, bottom);
	}

	public boolean setState(int[] stateSet) {
		return mDrawable.setState(stateSet);
	}

	public void setTint(int tint) {
		DrawableCompat.setTint(mDrawable, tint);
	}

	public void setTintList(ColorStateList tint) {
		DrawableCompat.setTintList(mDrawable, tint);
	}

	public void setTintMode(Mode tintMode) {
		DrawableCompat.setTintMode(mDrawable, tintMode);
	}

	public boolean setVisible(boolean visible, boolean restart) {
		if (super.setVisible(visible, restart) || mDrawable.setVisible(visible, restart)) {
			return true;
		} else {
			return false;
		}
	}

	public void setWrappedDrawable(Drawable drawable) {
		if (mDrawable != null) {
			mDrawable.setCallback(null);
		}
		mDrawable = drawable;
		if (drawable != null) {
			drawable.setCallback(this);
		}
	}

	public void unscheduleDrawable(Drawable who, Runnable what) {
		unscheduleSelf(what);
	}
}
