package android.support.v4.animation;

import android.view.View;
import com.rey.material.util.ViewUtil;
import java.util.ArrayList;
import java.util.List;

class GingerbreadAnimatorCompatProvider implements AnimatorProvider {
	private static class GingerbreadFloatValueAnimator implements ValueAnimatorCompat {
		private long mDuration;
		private boolean mEnded;
		private float mFraction;
		List<AnimatorListenerCompat> mListeners;
		private Runnable mLoopRunnable;
		private long mStartTime;
		private boolean mStarted;
		View mTarget;
		List<AnimatorUpdateListenerCompat> mUpdateListeners;

		class AnonymousClass_1 implements Runnable {
			final /* synthetic */ GingerbreadAnimatorCompatProvider.GingerbreadFloatValueAnimator this$0;

			AnonymousClass_1(GingerbreadAnimatorCompatProvider.GingerbreadFloatValueAnimator this$0) {
				super();
				this.this$0 = this$0;
			}

			public void run() {
				float fraction = (((float) (this$0.getTime() - this$0.mStartTime)) * 1.0f) / ((float) this$0.mDuration);
				if (fraction > 1.0f || this$0.mTarget.getParent() == null) {
					fraction = 1.0f;
				} else {
					this$0.mFraction = fraction;
					this$0.notifyUpdateListeners();
				}
				this$0.mFraction = fraction;
				this$0.notifyUpdateListeners();
				if (this$0.mFraction >= 1.0f) {
					this$0.dispatchEnd();
				} else {
					this$0.mTarget.postDelayed(this$0.mLoopRunnable, ViewUtil.FRAME_DURATION);
				}
			}
		}


		public GingerbreadFloatValueAnimator() {
			super();
			mListeners = new ArrayList();
			mUpdateListeners = new ArrayList();
			mDuration = 200;
			mFraction = 0.0f;
			mStarted = false;
			mEnded = false;
			mLoopRunnable = new AnonymousClass_1(this);
		}

		private void dispatchCancel() {
			int i = mListeners.size() - 1;
			while (i >= 0) {
				((AnimatorListenerCompat) mListeners.get(i)).onAnimationCancel(this);
				i--;
			}
		}

		private void dispatchEnd() {
			int i = mListeners.size() - 1;
			while (i >= 0) {
				((AnimatorListenerCompat) mListeners.get(i)).onAnimationEnd(this);
				i--;
			}
		}

		private void dispatchStart() {
			int i = mListeners.size() - 1;
			while (i >= 0) {
				((AnimatorListenerCompat) mListeners.get(i)).onAnimationStart(this);
				i--;
			}
		}

		private long getTime() {
			return mTarget.getDrawingTime();
		}

		private void notifyUpdateListeners() {
			int i = mUpdateListeners.size() - 1;
			while (i >= 0) {
				((AnimatorUpdateListenerCompat) mUpdateListeners.get(i)).onAnimationUpdate(this);
				i--;
			}
		}

		public void addListener(AnimatorListenerCompat listener) {
			mListeners.add(listener);
		}

		public void addUpdateListener(AnimatorUpdateListenerCompat animatorUpdateListener) {
			mUpdateListeners.add(animatorUpdateListener);
		}

		public void cancel() {
			if (mEnded) {
			} else {
				mEnded = true;
				if (mStarted) {
					dispatchCancel();
				}
				dispatchEnd();
			}
		}

		public float getAnimatedFraction() {
			return mFraction;
		}

		public void setDuration(long duration) {
			if (!mStarted) {
				mDuration = duration;
			}
		}

		public void setTarget(View view) {
			mTarget = view;
		}

		public void start() {
			if (mStarted) {
			} else {
				mStarted = true;
				dispatchStart();
				mFraction = 0.0f;
				mStartTime = getTime();
				mTarget.postDelayed(mLoopRunnable, ViewUtil.FRAME_DURATION);
			}
		}
	}


	GingerbreadAnimatorCompatProvider() {
		super();
	}

	public void clearInterpolator(View view) {
	}

	public ValueAnimatorCompat emptyValueAnimator() {
		return new GingerbreadFloatValueAnimator();
	}
}
