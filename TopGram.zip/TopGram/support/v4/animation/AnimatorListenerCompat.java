package android.support.v4.animation;

public interface AnimatorListenerCompat {
	public void onAnimationCancel(ValueAnimatorCompat r1_ValueAnimatorCompat);

	public void onAnimationEnd(ValueAnimatorCompat r1_ValueAnimatorCompat);

	public void onAnimationRepeat(ValueAnimatorCompat r1_ValueAnimatorCompat);

	public void onAnimationStart(ValueAnimatorCompat r1_ValueAnimatorCompat);
}
