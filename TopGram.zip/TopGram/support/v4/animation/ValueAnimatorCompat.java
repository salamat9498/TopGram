package android.support.v4.animation;

import android.view.View;

public interface ValueAnimatorCompat {
	public void addListener(AnimatorListenerCompat r1_AnimatorListenerCompat);

	public void addUpdateListener(AnimatorUpdateListenerCompat r1_AnimatorUpdateListenerCompat);

	public void cancel();

	public float getAnimatedFraction();

	public void setDuration(long r1j);

	public void setTarget(View r1_View);

	public void start();
}
