package android.support.v4.animation;

public interface AnimatorUpdateListenerCompat {
	public void onAnimationUpdate(ValueAnimatorCompat r1_ValueAnimatorCompat);
}
