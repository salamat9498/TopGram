package android.support.v4.animation;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.view.View;

class HoneycombMr1AnimatorCompatProvider implements AnimatorProvider {
	private TimeInterpolator mDefaultInterpolator;

	static class AnimatorListenerCompatWrapper implements AnimatorListener {
		final ValueAnimatorCompat mValueAnimatorCompat;
		final AnimatorListenerCompat mWrapped;

		public AnimatorListenerCompatWrapper(AnimatorListenerCompat wrapped, ValueAnimatorCompat valueAnimatorCompat) {
			super();
			mWrapped = wrapped;
			mValueAnimatorCompat = valueAnimatorCompat;
		}

		public void onAnimationCancel(Animator animation) {
			mWrapped.onAnimationCancel(mValueAnimatorCompat);
		}

		public void onAnimationEnd(Animator animation) {
			mWrapped.onAnimationEnd(mValueAnimatorCompat);
		}

		public void onAnimationRepeat(Animator animation) {
			mWrapped.onAnimationRepeat(mValueAnimatorCompat);
		}

		public void onAnimationStart(Animator animation) {
			mWrapped.onAnimationStart(mValueAnimatorCompat);
		}
	}

	static class HoneycombValueAnimatorCompat implements ValueAnimatorCompat {
		final Animator mWrapped;

		class AnonymousClass_1 implements AnimatorUpdateListener {
			final /* synthetic */ HoneycombMr1AnimatorCompatProvider.HoneycombValueAnimatorCompat this$0;
			final /* synthetic */ AnimatorUpdateListenerCompat val$animatorUpdateListener;

			AnonymousClass_1(HoneycombMr1AnimatorCompatProvider.HoneycombValueAnimatorCompat this$0, AnimatorUpdateListenerCompat r2_AnimatorUpdateListenerCompat) {
				super();
				this.this$0 = this$0;
				val$animatorUpdateListener = r2_AnimatorUpdateListenerCompat;
			}

			public void onAnimationUpdate(ValueAnimator animation) {
				val$animatorUpdateListener.onAnimationUpdate(this$0);
			}
		}


		public HoneycombValueAnimatorCompat(Animator wrapped) {
			super();
			mWrapped = wrapped;
		}

		public void addListener(AnimatorListenerCompat listener) {
			mWrapped.addListener(new HoneycombMr1AnimatorCompatProvider.AnimatorListenerCompatWrapper(listener, this));
		}

		public void addUpdateListener(AnimatorUpdateListenerCompat animatorUpdateListener) {
			if (mWrapped instanceof ValueAnimator) {
				((ValueAnimator) mWrapped).addUpdateListener(new AnonymousClass_1(this, animatorUpdateListener));
			}
		}

		public void cancel() {
			mWrapped.cancel();
		}

		public float getAnimatedFraction() {
			return ((ValueAnimator) mWrapped).getAnimatedFraction();
		}

		public void setDuration(long duration) {
			mWrapped.setDuration(duration);
		}

		public void setTarget(View view) {
			mWrapped.setTarget(view);
		}

		public void start() {
			mWrapped.start();
		}
	}


	HoneycombMr1AnimatorCompatProvider() {
		super();
	}

	public void clearInterpolator(View view) {
		if (mDefaultInterpolator == null) {
			mDefaultInterpolator = new ValueAnimator().getInterpolator();
		}
		view.animate().setInterpolator(mDefaultInterpolator);
	}

	public ValueAnimatorCompat emptyValueAnimator() {
		return new HoneycombValueAnimatorCompat(ValueAnimator.ofFloat(new float[]{0.0f, 1.0f}));
	}
}
