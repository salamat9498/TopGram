package android.support.v4.animation;

import android.view.View;

interface AnimatorProvider {
	public void clearInterpolator(View r1_View);

	public ValueAnimatorCompat emptyValueAnimator();
}
