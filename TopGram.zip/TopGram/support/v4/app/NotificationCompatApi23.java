package android.support.v4.app;

class NotificationCompatApi23 {
	public static final String CATEGORY_REMINDER = "reminder";

	NotificationCompatApi23() {
		super();
	}
}
