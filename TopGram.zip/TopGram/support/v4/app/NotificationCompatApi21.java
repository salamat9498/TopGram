package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.NotificationCompatBase.Action;
import android.support.v4.app.NotificationCompatBase.UnreadConversation;
import android.support.v4.app.NotificationCompatBase.UnreadConversation.Factory;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;

class NotificationCompatApi21 {
	public static final String CATEGORY_ALARM = "alarm";
	public static final String CATEGORY_CALL = "call";
	public static final String CATEGORY_EMAIL = "email";
	public static final String CATEGORY_ERROR = "err";
	public static final String CATEGORY_EVENT = "event";
	public static final String CATEGORY_MESSAGE = "msg";
	public static final String CATEGORY_PROGRESS = "progress";
	public static final String CATEGORY_PROMO = "promo";
	public static final String CATEGORY_RECOMMENDATION = "recommendation";
	public static final String CATEGORY_SERVICE = "service";
	public static final String CATEGORY_SOCIAL = "social";
	public static final String CATEGORY_STATUS = "status";
	public static final String CATEGORY_SYSTEM = "sys";
	public static final String CATEGORY_TRANSPORT = "transport";
	private static final String KEY_AUTHOR = "author";
	private static final String KEY_MESSAGES = "messages";
	private static final String KEY_ON_READ = "on_read";
	private static final String KEY_ON_REPLY = "on_reply";
	private static final String KEY_PARTICIPANTS = "participants";
	private static final String KEY_REMOTE_INPUT = "remote_input";
	private static final String KEY_TEXT = "text";
	private static final String KEY_TIMESTAMP = "timestamp";

	public static class Builder implements NotificationBuilderWithBuilderAccessor, NotificationBuilderWithActions {
		private android.app.Notification.Builder b;
		private RemoteViews mBigContentView;
		private RemoteViews mContentView;
		private Bundle mExtras;
		private RemoteViews mHeadsUpContentView;

		public Builder(Context context, Notification n, CharSequence contentTitle, CharSequence contentText, CharSequence contentInfo, RemoteViews tickerView, int number, PendingIntent contentIntent, PendingIntent fullScreenIntent, Bitmap largeIcon, int progressMax, int progress, boolean progressIndeterminate, boolean showWhen, boolean useChronometer, int priority, CharSequence subText, boolean localOnly, String category, ArrayList<String> people, Bundle extras, int color, int visibility, Notification publicVersion, String groupKey, boolean groupSummary, String sortKey, RemoteViews contentView, RemoteViews bigContentView, RemoteViews headsUpContentView) {
			boolean r5z;
			super();
			android.app.Notification.Builder r6_android_app_Notification_Builder = new android.app.Notification.Builder(context).setWhen(n.when).setShowWhen(showWhen).setSmallIcon(n.icon, n.iconLevel).setContent(n.contentView).setTicker(n.tickerText, tickerView).setSound(n.sound, n.audioStreamType).setVibrate(n.vibrate).setLights(n.ledARGB, n.ledOnMS, n.ledOffMS);
			if ((n.flags & 2) != 0) {
				r5z = true;
			} else {
				r5z = false;
			}
			r6_android_app_Notification_Builder = r6_android_app_Notification_Builder.setOngoing(r5z);
			if ((n.flags & 8) != 0) {
				r5z = true;
			} else {
				r5z = false;
			}
			r6_android_app_Notification_Builder = r6_android_app_Notification_Builder.setOnlyAlertOnce(r5z);
			if ((n.flags & 16) != 0) {
				r5z = true;
			} else {
				r5z = false;
			}
			r6_android_app_Notification_Builder = r6_android_app_Notification_Builder.setAutoCancel(r5z).setDefaults(n.defaults).setContentTitle(contentTitle).setContentText(contentText).setSubText(subText).setContentInfo(contentInfo).setContentIntent(contentIntent).setDeleteIntent(n.deleteIntent);
			if ((n.flags & 128) != 0) {
				r5z = true;
			} else {
				r5z = false;
			}
			b = r6_android_app_Notification_Builder.setFullScreenIntent(fullScreenIntent, r5z).setLargeIcon(largeIcon).setNumber(number).setUsesChronometer(useChronometer).setPriority(priority).setProgress(progressMax, progress, progressIndeterminate).setLocalOnly(localOnly).setGroup(groupKey).setGroupSummary(groupSummary).setSortKey(sortKey).setCategory(category).setColor(color).setVisibility(visibility).setPublicVersion(publicVersion);
			mExtras = new Bundle();
			if (extras != null) {
				mExtras.putAll(extras);
			}
			Iterator r5_Iterator = people.iterator();
			while (r5_Iterator.hasNext()) {
				b.addPerson((String) r5_Iterator.next());
			}
			mContentView = contentView;
			mBigContentView = bigContentView;
			mHeadsUpContentView = headsUpContentView;
		}

		public void addAction(Action action) {
			NotificationCompatApi20.addAction(b, action);
		}

		public Notification build() {
			b.setExtras(mExtras);
			Notification notification = b.build();
			if (mContentView != null) {
				notification.contentView = mContentView;
			}
			if (mBigContentView != null) {
				notification.bigContentView = mBigContentView;
			}
			if (mHeadsUpContentView != null) {
				notification.headsUpContentView = mHeadsUpContentView;
			}
			return notification;
		}

		public android.app.Notification.Builder getBuilder() {
			return b;
		}
	}


	NotificationCompatApi21() {
		super();
	}

	private static RemoteInput fromCompatRemoteInput(RemoteInputCompatBase.RemoteInput src) {
		return new android.app.RemoteInput.Builder(src.getResultKey()).setLabel(src.getLabel()).setChoices(src.getChoices()).setAllowFreeFormInput(src.getAllowFreeFormInput()).addExtras(src.getExtras()).build();
	}

	static Bundle getBundleForUnreadConversation(UnreadConversation uc) {
		if (uc == null) {
			return null;
		} else {
			Bundle b = new Bundle();
			String author = null;
			Parcelable[] messages;
			int i;
			Bundle m;
			RemoteInputCompatBase.RemoteInput remoteInput;
			if (uc.getParticipants() == null || uc.getParticipants().length <= 1) {
				messages = new Parcelable[uc.getMessages().length];
				i = 0;
				while (i < messages.length) {
					m = new Bundle();
					m.putString(KEY_TEXT, uc.getMessages()[i]);
					m.putString(KEY_AUTHOR, author);
					messages[i] = m;
					i++;
				}
				b.putParcelableArray(KEY_MESSAGES, messages);
				remoteInput = uc.getRemoteInput();
				if (remoteInput == null) {
					b.putParcelable(KEY_REMOTE_INPUT, fromCompatRemoteInput(remoteInput));
				}
				b.putParcelable(KEY_ON_REPLY, uc.getReplyPendingIntent());
				b.putParcelable(KEY_ON_READ, uc.getReadPendingIntent());
				b.putStringArray(KEY_PARTICIPANTS, uc.getParticipants());
				b.putLong(KEY_TIMESTAMP, uc.getLatestTimestamp());
				return b;
			} else {
				author = uc.getParticipants()[0];
				messages = new Parcelable[uc.getMessages().length];
				i = 0;
				while (i < messages.length) {
					m = new Bundle();
					m.putString(KEY_TEXT, uc.getMessages()[i]);
					m.putString(KEY_AUTHOR, author);
					messages[i] = m;
					i++;
				}
				b.putParcelableArray(KEY_MESSAGES, messages);
				remoteInput = uc.getRemoteInput();
				if (remoteInput == null) {
					b.putParcelable(KEY_ON_REPLY, uc.getReplyPendingIntent());
					b.putParcelable(KEY_ON_READ, uc.getReadPendingIntent());
					b.putStringArray(KEY_PARTICIPANTS, uc.getParticipants());
					b.putLong(KEY_TIMESTAMP, uc.getLatestTimestamp());
					return b;
				} else {
					b.putParcelable(KEY_REMOTE_INPUT, fromCompatRemoteInput(remoteInput));
					b.putParcelable(KEY_ON_REPLY, uc.getReplyPendingIntent());
					b.putParcelable(KEY_ON_READ, uc.getReadPendingIntent());
					b.putStringArray(KEY_PARTICIPANTS, uc.getParticipants());
					b.putLong(KEY_TIMESTAMP, uc.getLatestTimestamp());
					return b;
				}
			}
		}
	}

	public static String getCategory(Notification notif) {
		return notif.category;
	}

	static UnreadConversation getUnreadConversationFromBundle(Bundle b, Factory factory, RemoteInputCompatBase.RemoteInput.Factory remoteInputFactory) {
		RemoteInputCompatBase.RemoteInput r2_RemoteInputCompatBase_RemoteInput = null;
		if (b == null) {
			return null;
		} else {
			Parcelable[] parcelableMessages = b.getParcelableArray(KEY_MESSAGES);
			String[] messages = null;
			if (parcelableMessages != null) {
				String[] tmp = new String[parcelableMessages.length];
				boolean success = true;
				int i = 0;
				while (i < tmp.length) {
					if (!(parcelableMessages[i] instanceof Bundle)) {
						success = false;
					} else {
						tmp[i] = ((Bundle) parcelableMessages[i]).getString(KEY_TEXT);
						if (tmp[i] == null) {
							success = false;
						} else {
							i++;
						}
					}
				}
				if (success) {
					messages = tmp;
				} else {
					return null;
				}
			}
			PendingIntent onRead = (PendingIntent) b.getParcelable(KEY_ON_READ);
			PendingIntent onReply = (PendingIntent) b.getParcelable(KEY_ON_REPLY);
			RemoteInput remoteInput = (RemoteInput) b.getParcelable(KEY_REMOTE_INPUT);
			String[] participants = b.getStringArray(KEY_PARTICIPANTS);
			if (participants != null) {
				if (participants.length == 1) {
					if (remoteInput != null) {
						r2_RemoteInputCompatBase_RemoteInput = toCompatRemoteInput(remoteInput, remoteInputFactory);
					}
					return factory.build(messages, r2_RemoteInputCompatBase_RemoteInput, onReply, onRead, participants, b.getLong(KEY_TIMESTAMP));
				} else {
					return null;
				}
			} else {
				return null;
			}
		}
	}

	private static RemoteInputCompatBase.RemoteInput toCompatRemoteInput(RemoteInput remoteInput, RemoteInputCompatBase.RemoteInput.Factory factory) {
		return factory.build(remoteInput.getResultKey(), remoteInput.getLabel(), remoteInput.getChoices(), remoteInput.getAllowFreeFormInput(), remoteInput.getExtras());
	}
}
