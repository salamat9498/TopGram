package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat.OnRequestPermissionsResultCallback;
import android.support.v4.app.ActivityCompatApi23.RequestPermissionsRequestCodeValidator;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.util.SimpleArrayMap;
import android.support.v4.util.SparseArrayCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import com.androidquery.util.Constants;
import com.rey.material.R;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.Components.Glow;

public class FragmentActivity extends BaseFragmentActivityJB implements OnRequestPermissionsResultCallback, RequestPermissionsRequestCodeValidator {
	static final String ALLOCATED_REQUEST_INDICIES_TAG = "android:support:request_indicies";
	static final String FRAGMENTS_TAG = "android:support:fragments";
	private static final int HONEYCOMB = 11;
	static final int MAX_NUM_PENDING_FRAGMENT_ACTIVITY_RESULTS = 65534;
	static final int MSG_REALLY_STOPPED = 1;
	static final int MSG_RESUME_PENDING = 2;
	static final String NEXT_CANDIDATE_REQUEST_INDEX_TAG = "android:support:next_request_index";
	static final String REQUEST_FRAGMENT_WHO_TAG = "android:support:request_fragment_who";
	private static final String TAG = "FragmentActivity";
	boolean mCreated;
	final FragmentController mFragments;
	final Handler mHandler;
	MediaControllerCompat mMediaController;
	int mNextCandidateRequestIndex;
	boolean mOptionsMenuInvalidated;
	SparseArrayCompat<String> mPendingFragmentActivityResults;
	boolean mReallyStopped;
	boolean mRequestedPermissionsFromFragment;
	boolean mResumed;
	boolean mRetaining;
	boolean mStopped;

	class AnonymousClass_1 extends Handler {
		final /* synthetic */ FragmentActivity this$0;

		AnonymousClass_1(FragmentActivity this$0) {
			super();
			this.this$0 = this$0;
		}

		public void handleMessage(Message msg) {
			switch(msg.what) {
			case MSG_REALLY_STOPPED:
				if (this$0.mStopped) {
					this$0.doReallyStop(false);
				}
			case MSG_RESUME_PENDING:
				this$0.onResumeFragments();
				this$0.mFragments.execPendingActions();
			}
			super.handleMessage(msg);
		}
	}

	class HostCallbacks extends FragmentHostCallback<FragmentActivity> {
		final /* synthetic */ FragmentActivity this$0;

		public HostCallbacks(FragmentActivity this$0) {
			super(this$0);
			this.this$0 = this$0;
		}

		public void onAttachFragment(Fragment fragment) {
			this$0.onAttachFragment(fragment);
		}

		public void onDump(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
			this$0.dump(prefix, fd, writer, args);
		}

		@Nullable
		public View onFindViewById(int id) {
			return this$0.findViewById(id);
		}

		public FragmentActivity onGetHost() {
			return this$0;
		}

		public LayoutInflater onGetLayoutInflater() {
			return this$0.getLayoutInflater().cloneInContext(this$0);
		}

		public int onGetWindowAnimations() {
			Window w = this$0.getWindow();
			if (w == null) {
				return 0;
			} else {
				return w.getAttributes().windowAnimations;
			}
		}

		public boolean onHasView() {
			Window w = this$0.getWindow();
			if (w == null || w.peekDecorView() == null) {
				return false;
			} else {
				return true;
			}
		}

		public boolean onHasWindowAnimations() {
			if (this$0.getWindow() != null) {
				return true;
			} else {
				return false;
			}
		}

		public void onRequestPermissionsFromFragment(@NonNull Fragment fragment, @NonNull String[] permissions, int requestCode) {
			this$0.requestPermissionsFromFragment(fragment, permissions, requestCode);
		}

		public boolean onShouldSaveFragmentState(Fragment fragment) {
			if (!this$0.isFinishing()) {
				return true;
			} else {
				return false;
			}
		}

		public boolean onShouldShowRequestPermissionRationale(@NonNull String permission) {
			return ActivityCompat.shouldShowRequestPermissionRationale(this$0, permission);
		}

		public void onStartActivityFromFragment(Fragment fragment, Intent intent, int requestCode) {
			this$0.startActivityFromFragment(fragment, intent, requestCode);
		}

		public void onStartActivityFromFragment(Fragment fragment, Intent intent, int requestCode, @Nullable Bundle options) {
			this$0.startActivityFromFragment(fragment, intent, requestCode, options);
		}

		public void onStartIntentSenderFromFragment(Fragment fragment, IntentSender intent, int requestCode, @Nullable Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags, Bundle options) throws SendIntentException {
			this$0.startIntentSenderFromFragment(fragment, intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags, options);
		}

		public void onSupportInvalidateOptionsMenu() {
			this$0.supportInvalidateOptionsMenu();
		}
	}

	static final class NonConfigurationInstances {
		Object custom;
		FragmentManagerNonConfig fragments;
		SimpleArrayMap<String, LoaderManager> loaders;

		NonConfigurationInstances() {
			super();
		}
	}


	public FragmentActivity() {
		super();
		mHandler = new AnonymousClass_1(this);
		mFragments = FragmentController.createController(new HostCallbacks(this));
	}

	private int allocateRequestIndex(Fragment fragment) {
		if (mPendingFragmentActivityResults.size() >= 65534) {
			throw new IllegalStateException("Too many pending Fragment activity results.");
		}
		while (true) {
			if (mPendingFragmentActivityResults.indexOfKey(mNextCandidateRequestIndex) >= 0) {
				mNextCandidateRequestIndex = (mNextCandidateRequestIndex + 1) % 65534;
			} else {
				int requestIndex = mNextCandidateRequestIndex;
				mPendingFragmentActivityResults.put(requestIndex, fragment.mWho);
				mNextCandidateRequestIndex = (mNextCandidateRequestIndex + 1) % 65534;
				return requestIndex;
			}
		}
	}

	private void dumpViewHierarchy(String prefix, PrintWriter writer, View view) {
		writer.print(prefix);
		if (view == null) {
			writer.println("null");
		} else {
			writer.println(viewToString(view));
			if (view instanceof ViewGroup) {
				ViewGroup grp = (ViewGroup) view;
				int N = grp.getChildCount();
				if (N > 0) {
					prefix = prefix + "  ";
					int i = 0;
					while (i < N) {
						dumpViewHierarchy(prefix, writer, grp.getChildAt(i));
						i++;
					}
				}
			}
		}
	}

	private static String viewToString(View view) {
		char r6c;
		int id;
		Resources r;
		String pkgname;
		char r7c = 'F';
		char r8c = '.';
		StringBuilder out = new StringBuilder(128);
		out.append(view.getClass().getName());
		out.append('{');
		out.append(Integer.toHexString(System.identityHashCode(view)));
		out.append(' ');
		switch(view.getVisibility()) {
		case Glow.ALWAYS:
			out.append('V');
			if (!view.isFocusable()) {
				r6c = 'F';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isEnabled()) {
				r6c = 'E';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.willNotDraw()) {
				r6c = '.';
			} else {
				r6c = 'D';
			}
			out.append(r6c);
			if (!view.isHorizontalScrollBarEnabled()) {
				r6c = 'H';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isVerticalScrollBarEnabled()) {
				r6c = 'V';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isClickable()) {
				r6c = 'C';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isLongClickable()) {
				r6c = 'L';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			out.append(' ');
			if (!view.isFocused()) {
				out.append(r7c);
				if (!view.isSelected()) {
					r6c = 'S';
				} else {
					r6c = '.';
				}
				out.append(r6c);
				if (!view.isPressed()) {
					r8c = 'P';
				}
				out.append(r8c);
				out.append(' ');
				out.append(view.getLeft());
				out.append(',');
				out.append(view.getTop());
				out.append('-');
				out.append(view.getRight());
				out.append(',');
				out.append(view.getBottom());
				id = view.getId();
				if (id != -1) {
					out.append(" #");
					out.append(Integer.toHexString(id));
					r = view.getResources();
					if (id == 0 || r == null) {
						out.append("}");
						return out.toString();
					} else {
						switch((-16777216 & id)) {
						case Constants.FLAG_HARDWARE_ACCELERATED:
							pkgname = "android";
							out.append(" ");
							out.append(pkgname);
							out.append(":");
							out.append(r.getResourceTypeName(id));
							out.append("/");
							out.append(r.getResourceEntryName(id));
							break;
						case 2130706432:
							pkgname = "app";
							out.append(" ");
							out.append(pkgname);
							out.append(":");
							out.append(r.getResourceTypeName(id));
							out.append("/");
							out.append(r.getResourceEntryName(id));
							break;
						}
						pkgname = r.getResourcePackageName(id);
						out.append(" ");
						out.append(pkgname);
						out.append(":");
						out.append(r.getResourceTypeName(id));
						out.append("/");
						out.append(r.getResourceEntryName(id));
					}
				}
				out.append("}");
				return out.toString();
			} else {
				r7c = '.';
				out.append(r7c);
				if (!view.isSelected()) {
					r6c = '.';
				} else {
					r6c = 'S';
				}
				out.append(r6c);
				if (!view.isPressed()) {
					out.append(r8c);
					out.append(' ');
					out.append(view.getLeft());
					out.append(',');
					out.append(view.getTop());
					out.append('-');
					out.append(view.getRight());
					out.append(',');
					out.append(view.getBottom());
					id = view.getId();
					if (id != -1) {
						out.append("}");
						return out.toString();
					} else {
						out.append(" #");
						out.append(Integer.toHexString(id));
						r = view.getResources();
						if (id == 0 || r == null) {
							out.append("}");
							return out.toString();
						} else {
							switch((-16777216 & id)) {
							case Constants.FLAG_HARDWARE_ACCELERATED:
								pkgname = "android";
								out.append(" ");
								out.append(pkgname);
								out.append(":");
								out.append(r.getResourceTypeName(id));
								out.append("/");
								out.append(r.getResourceEntryName(id));
								out.append("}");
								return out.toString();
							case 2130706432:
								pkgname = "app";
								out.append(" ");
								out.append(pkgname);
								out.append(":");
								out.append(r.getResourceTypeName(id));
								out.append("/");
								out.append(r.getResourceEntryName(id));
								out.append("}");
								return out.toString();
							}
							pkgname = r.getResourcePackageName(id);
							out.append(" ");
							out.append(pkgname);
							out.append(":");
							out.append(r.getResourceTypeName(id));
							out.append("/");
							out.append(r.getResourceEntryName(id));
							out.append("}");
							return out.toString();
						}
					}
				} else {
					r8c = 'P';
					out.append(r8c);
					out.append(' ');
					out.append(view.getLeft());
					out.append(',');
					out.append(view.getTop());
					out.append('-');
					out.append(view.getRight());
					out.append(',');
					out.append(view.getBottom());
					id = view.getId();
					if (id != -1) {
						out.append(" #");
						out.append(Integer.toHexString(id));
						r = view.getResources();
						if (id == 0 || r == null) {
							out.append("}");
							return out.toString();
						} else {
							switch((-16777216 & id)) {
							case Constants.FLAG_HARDWARE_ACCELERATED:
								pkgname = "android";
								out.append(" ");
								out.append(pkgname);
								out.append(":");
								out.append(r.getResourceTypeName(id));
								out.append("/");
								out.append(r.getResourceEntryName(id));
								break;
							case 2130706432:
								pkgname = "app";
								out.append(" ");
								out.append(pkgname);
								out.append(":");
								out.append(r.getResourceTypeName(id));
								out.append("/");
								out.append(r.getResourceEntryName(id));
								break;
							}
							pkgname = r.getResourcePackageName(id);
							out.append(" ");
							out.append(pkgname);
							out.append(":");
							out.append(r.getResourceTypeName(id));
							out.append("/");
							out.append(r.getResourceEntryName(id));
						}
					}
					out.append("}");
					return out.toString();
				}
			}
		case TLRPC.USER_FLAG_LAST_NAME:
			out.append('I');
			if (!view.isFocusable()) {
				r6c = '.';
			} else {
				r6c = 'F';
			}
			out.append(r6c);
			if (!view.isEnabled()) {
				r6c = '.';
			} else {
				r6c = 'E';
			}
			out.append(r6c);
			if (!view.willNotDraw()) {
				r6c = 'D';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isHorizontalScrollBarEnabled()) {
				r6c = '.';
			} else {
				r6c = 'H';
			}
			out.append(r6c);
			if (!view.isVerticalScrollBarEnabled()) {
				r6c = '.';
			} else {
				r6c = 'V';
			}
			out.append(r6c);
			if (!view.isClickable()) {
				r6c = '.';
			} else {
				r6c = 'C';
			}
			out.append(r6c);
			if (!view.isLongClickable()) {
				r6c = '.';
			} else {
				r6c = 'L';
			}
			out.append(r6c);
			out.append(' ');
			if (!view.isFocused()) {
				r7c = '.';
			}
			out.append(r7c);
			if (!view.isSelected()) {
				r6c = 'S';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isPressed()) {
				r8c = 'P';
			}
			out.append(r8c);
			out.append(' ');
			out.append(view.getLeft());
			out.append(',');
			out.append(view.getTop());
			out.append('-');
			out.append(view.getRight());
			out.append(',');
			out.append(view.getBottom());
			id = view.getId();
			if (id != -1) {
				out.append("}");
				return out.toString();
			} else {
				out.append(" #");
				out.append(Integer.toHexString(id));
				r = view.getResources();
				if (id == 0 || r == null) {
					out.append("}");
					return out.toString();
				} else {
					switch((-16777216 & id)) {
					case Constants.FLAG_HARDWARE_ACCELERATED:
						pkgname = "android";
						out.append(" ");
						out.append(pkgname);
						out.append(":");
						out.append(r.getResourceTypeName(id));
						out.append("/");
						out.append(r.getResourceEntryName(id));
						out.append("}");
						return out.toString();
					case 2130706432:
						pkgname = "app";
						out.append(" ");
						out.append(pkgname);
						out.append(":");
						out.append(r.getResourceTypeName(id));
						out.append("/");
						out.append(r.getResourceEntryName(id));
						out.append("}");
						return out.toString();
					}
					pkgname = r.getResourcePackageName(id);
					out.append(" ");
					out.append(pkgname);
					out.append(":");
					out.append(r.getResourceTypeName(id));
					out.append("/");
					out.append(r.getResourceEntryName(id));
					out.append("}");
					return out.toString();
				}
			}
		case TLRPC.USER_FLAG_USERNAME:
			out.append('G');
			if (!view.isFocusable()) {
				r6c = 'F';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isEnabled()) {
				r6c = 'E';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.willNotDraw()) {
				r6c = '.';
			} else {
				r6c = 'D';
			}
			out.append(r6c);
			if (!view.isHorizontalScrollBarEnabled()) {
				r6c = 'H';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isVerticalScrollBarEnabled()) {
				r6c = 'V';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isClickable()) {
				r6c = 'C';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			if (!view.isLongClickable()) {
				r6c = 'L';
			} else {
				r6c = '.';
			}
			out.append(r6c);
			out.append(' ');
			if (!view.isFocused()) {
				out.append(r7c);
				if (!view.isSelected()) {
					r6c = '.';
				} else {
					r6c = 'S';
				}
				out.append(r6c);
				if (!view.isPressed()) {
					out.append(r8c);
					out.append(' ');
					out.append(view.getLeft());
					out.append(',');
					out.append(view.getTop());
					out.append('-');
					out.append(view.getRight());
					out.append(',');
					out.append(view.getBottom());
					id = view.getId();
					if (id != -1) {
						out.append(" #");
						out.append(Integer.toHexString(id));
						r = view.getResources();
						if (id == 0 || r == null) {
							out.append("}");
							return out.toString();
						} else {
							switch((-16777216 & id)) {
							case Constants.FLAG_HARDWARE_ACCELERATED:
								pkgname = "android";
								out.append(" ");
								out.append(pkgname);
								out.append(":");
								out.append(r.getResourceTypeName(id));
								out.append("/");
								out.append(r.getResourceEntryName(id));
								break;
							case 2130706432:
								pkgname = "app";
								out.append(" ");
								out.append(pkgname);
								out.append(":");
								out.append(r.getResourceTypeName(id));
								out.append("/");
								out.append(r.getResourceEntryName(id));
								break;
							}
							pkgname = r.getResourcePackageName(id);
							out.append(" ");
							out.append(pkgname);
							out.append(":");
							out.append(r.getResourceTypeName(id));
							out.append("/");
							out.append(r.getResourceEntryName(id));
						}
					}
					out.append("}");
					return out.toString();
				} else {
					r8c = 'P';
					out.append(r8c);
					out.append(' ');
					out.append(view.getLeft());
					out.append(',');
					out.append(view.getTop());
					out.append('-');
					out.append(view.getRight());
					out.append(',');
					out.append(view.getBottom());
					id = view.getId();
					if (id != -1) {
						out.append("}");
						return out.toString();
					} else {
						out.append(" #");
						out.append(Integer.toHexString(id));
						r = view.getResources();
						if (id == 0 || r == null) {
							out.append("}");
							return out.toString();
						} else {
							switch((-16777216 & id)) {
							case Constants.FLAG_HARDWARE_ACCELERATED:
								pkgname = "android";
								out.append(" ");
								out.append(pkgname);
								out.append(":");
								out.append(r.getResourceTypeName(id));
								out.append("/");
								out.append(r.getResourceEntryName(id));
								out.append("}");
								return out.toString();
							case 2130706432:
								pkgname = "app";
								out.append(" ");
								out.append(pkgname);
								out.append(":");
								out.append(r.getResourceTypeName(id));
								out.append("/");
								out.append(r.getResourceEntryName(id));
								out.append("}");
								return out.toString();
							}
							pkgname = r.getResourcePackageName(id);
							out.append(" ");
							out.append(pkgname);
							out.append(":");
							out.append(r.getResourceTypeName(id));
							out.append("/");
							out.append(r.getResourceEntryName(id));
							out.append("}");
							return out.toString();
						}
					}
				}
			} else {
				r7c = '.';
				out.append(r7c);
				if (!view.isSelected()) {
					r6c = 'S';
				} else {
					r6c = '.';
				}
				out.append(r6c);
				if (!view.isPressed()) {
					r8c = 'P';
				}
				out.append(r8c);
				out.append(' ');
				out.append(view.getLeft());
				out.append(',');
				out.append(view.getTop());
				out.append('-');
				out.append(view.getRight());
				out.append(',');
				out.append(view.getBottom());
				id = view.getId();
				if (id != -1) {
					out.append(" #");
					out.append(Integer.toHexString(id));
					r = view.getResources();
					if (id == 0 || r == null) {
						out.append("}");
						return out.toString();
					} else {
						switch((-16777216 & id)) {
						case Constants.FLAG_HARDWARE_ACCELERATED:
							pkgname = "android";
							out.append(" ");
							out.append(pkgname);
							out.append(":");
							out.append(r.getResourceTypeName(id));
							out.append("/");
							out.append(r.getResourceEntryName(id));
							break;
						case 2130706432:
							pkgname = "app";
							out.append(" ");
							out.append(pkgname);
							out.append(":");
							out.append(r.getResourceTypeName(id));
							out.append("/");
							out.append(r.getResourceEntryName(id));
							break;
						}
						pkgname = r.getResourcePackageName(id);
						out.append(" ");
						out.append(pkgname);
						out.append(":");
						out.append(r.getResourceTypeName(id));
						out.append("/");
						out.append(r.getResourceEntryName(id));
					}
				}
				out.append("}");
				return out.toString();
			}
		}
		out.append('.');
		if (!view.isFocusable()) {
			r6c = '.';
		} else {
			r6c = 'F';
		}
		out.append(r6c);
		if (!view.isEnabled()) {
			r6c = '.';
		} else {
			r6c = 'E';
		}
		out.append(r6c);
		if (!view.willNotDraw()) {
			r6c = 'D';
		} else {
			r6c = '.';
		}
		out.append(r6c);
		if (!view.isHorizontalScrollBarEnabled()) {
			r6c = '.';
		} else {
			r6c = 'H';
		}
		out.append(r6c);
		if (!view.isVerticalScrollBarEnabled()) {
			r6c = '.';
		} else {
			r6c = 'V';
		}
		out.append(r6c);
		if (!view.isClickable()) {
			r6c = '.';
		} else {
			r6c = 'C';
		}
		out.append(r6c);
		if (!view.isLongClickable()) {
			r6c = '.';
		} else {
			r6c = 'L';
		}
		out.append(r6c);
		out.append(' ');
		if (!view.isFocused()) {
			r7c = '.';
		}
		out.append(r7c);
		if (!view.isSelected()) {
			r6c = '.';
		} else {
			r6c = 'S';
		}
		out.append(r6c);
		if (!view.isPressed()) {
			out.append(r8c);
			out.append(' ');
			out.append(view.getLeft());
			out.append(',');
			out.append(view.getTop());
			out.append('-');
			out.append(view.getRight());
			out.append(',');
			out.append(view.getBottom());
			id = view.getId();
			if (id != -1) {
				out.append("}");
				return out.toString();
			} else {
				out.append(" #");
				out.append(Integer.toHexString(id));
				r = view.getResources();
				if (id == 0 || r == null) {
					out.append("}");
					return out.toString();
				} else {
					switch((-16777216 & id)) {
					case Constants.FLAG_HARDWARE_ACCELERATED:
						pkgname = "android";
						out.append(" ");
						out.append(pkgname);
						out.append(":");
						out.append(r.getResourceTypeName(id));
						out.append("/");
						out.append(r.getResourceEntryName(id));
						out.append("}");
						return out.toString();
					case 2130706432:
						pkgname = "app";
						out.append(" ");
						out.append(pkgname);
						out.append(":");
						out.append(r.getResourceTypeName(id));
						out.append("/");
						out.append(r.getResourceEntryName(id));
						out.append("}");
						return out.toString();
					}
					pkgname = r.getResourcePackageName(id);
					out.append(" ");
					out.append(pkgname);
					out.append(":");
					out.append(r.getResourceTypeName(id));
					out.append("/");
					out.append(r.getResourceEntryName(id));
					out.append("}");
					return out.toString();
				}
			}
		} else {
			r8c = 'P';
			out.append(r8c);
			out.append(' ');
			out.append(view.getLeft());
			out.append(',');
			out.append(view.getTop());
			out.append('-');
			out.append(view.getRight());
			out.append(',');
			out.append(view.getBottom());
			id = view.getId();
			if (id != -1) {
				out.append(" #");
				out.append(Integer.toHexString(id));
				r = view.getResources();
				if (id == 0 || r == null) {
					out.append("}");
					return out.toString();
				} else {
					switch((-16777216 & id)) {
					case Constants.FLAG_HARDWARE_ACCELERATED:
						pkgname = "android";
						out.append(" ");
						out.append(pkgname);
						out.append(":");
						out.append(r.getResourceTypeName(id));
						out.append("/");
						out.append(r.getResourceEntryName(id));
						break;
					case 2130706432:
						pkgname = "app";
						out.append(" ");
						out.append(pkgname);
						out.append(":");
						out.append(r.getResourceTypeName(id));
						out.append("/");
						out.append(r.getResourceEntryName(id));
						break;
					}
					pkgname = r.getResourcePackageName(id);
					out.append(" ");
					out.append(pkgname);
					out.append(":");
					out.append(r.getResourceTypeName(id));
					out.append("/");
					out.append(r.getResourceEntryName(id));
				}
			}
			out.append("}");
			return out.toString();
		}
	}

	final View dispatchFragmentsOnCreateView(View parent, String name, Context context, AttributeSet attrs) {
		return mFragments.onCreateView(parent, name, context, attrs);
	}

	void doReallyStop(boolean retaining) {
		if (!mReallyStopped) {
			mReallyStopped = true;
			mRetaining = retaining;
			mHandler.removeMessages(MSG_REALLY_STOPPED);
			onReallyStop();
		} else if (retaining) {
			mFragments.doLoaderStart();
			mFragments.doLoaderStop(true);
		}
	}

	public void dump(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
		String innerPrefix;
		if (VERSION.SDK_INT >= 11) {
			writer.print(prefix);
			writer.print("Local FragmentActivity ");
			writer.print(Integer.toHexString(System.identityHashCode(this)));
			writer.println(" State:");
			innerPrefix = prefix + "  ";
			writer.print(innerPrefix);
			writer.print("mCreated=");
			writer.print(mCreated);
			writer.print("mResumed=");
			writer.print(mResumed);
			writer.print(" mStopped=");
			writer.print(mStopped);
			writer.print(" mReallyStopped=");
			writer.println(mReallyStopped);
			mFragments.dumpLoaders(innerPrefix, fd, writer, args);
			mFragments.getSupportFragmentManager().dump(prefix, fd, writer, args);
			writer.print(prefix);
			writer.println("View Hierarchy:");
			dumpViewHierarchy(prefix + "  ", writer, getWindow().getDecorView());
		} else {
			writer.print(prefix);
			writer.print("Local FragmentActivity ");
			writer.print(Integer.toHexString(System.identityHashCode(this)));
			writer.println(" State:");
			innerPrefix = prefix + "  ";
			writer.print(innerPrefix);
			writer.print("mCreated=");
			writer.print(mCreated);
			writer.print("mResumed=");
			writer.print(mResumed);
			writer.print(" mStopped=");
			writer.print(mStopped);
			writer.print(" mReallyStopped=");
			writer.println(mReallyStopped);
			mFragments.dumpLoaders(innerPrefix, fd, writer, args);
			mFragments.getSupportFragmentManager().dump(prefix, fd, writer, args);
			writer.print(prefix);
			writer.println("View Hierarchy:");
			dumpViewHierarchy(prefix + "  ", writer, getWindow().getDecorView());
		}
	}

	public Object getLastCustomNonConfigurationInstance() {
		NonConfigurationInstances nc = (NonConfigurationInstances) getLastNonConfigurationInstance();
		if (nc != null) {
			return nc.custom;
		} else {
			return null;
		}
	}

	public FragmentManager getSupportFragmentManager() {
		return mFragments.getSupportFragmentManager();
	}

	public LoaderManager getSupportLoaderManager() {
		return mFragments.getSupportLoaderManager();
	}

	public final MediaControllerCompat getSupportMediaController() {
		return mMediaController;
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		mFragments.noteStateNotSaved();
		int requestIndex = requestCode >> 16;
		if (requestIndex != 0) {
			requestIndex--;
			String who = (String) mPendingFragmentActivityResults.get(requestIndex);
			mPendingFragmentActivityResults.remove(requestIndex);
			if (who == null) {
				Log.w(TAG, "Activity result delivered for unknown Fragment.");
			} else {
				Fragment targetFragment = mFragments.findFragmentByWho(who);
				if (targetFragment == null) {
					Log.w(TAG, "Activity result no fragment exists for who: " + who);
				} else {
					targetFragment.onActivityResult(65535 & requestCode, resultCode, data);
				}
			}
		} else {
			super.onActivityResult(requestCode, resultCode, data);
		}
	}

	public void onAttachFragment(Fragment fragment) {
	}

	public void onBackPressed() {
		if (!mFragments.getSupportFragmentManager().popBackStackImmediate()) {
			super.onBackPressed();
		}
	}

	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		mFragments.dispatchConfigurationChanged(newConfig);
	}

	protected void onCreate(@Nullable Bundle savedInstanceState) {
		FragmentManagerNonConfig r5_FragmentManagerNonConfig = null;
		mFragments.attachHost(null);
		super.onCreate(savedInstanceState);
		NonConfigurationInstances nc = (NonConfigurationInstances) getLastNonConfigurationInstance();
		if (nc != null) {
			mFragments.restoreLoaderNonConfig(nc.loaders);
		}
		if (savedInstanceState != null) {
			Parcelable p = savedInstanceState.getParcelable(FRAGMENTS_TAG);
			FragmentController r6_FragmentController = mFragments;
			if (nc != null) {
				r5_FragmentManagerNonConfig = nc.fragments;
			}
			r6_FragmentController.restoreAllState(p, r5_FragmentManagerNonConfig);
			if (savedInstanceState.containsKey(NEXT_CANDIDATE_REQUEST_INDEX_TAG)) {
				mNextCandidateRequestIndex = savedInstanceState.getInt(NEXT_CANDIDATE_REQUEST_INDEX_TAG);
				int[] requestCodes = savedInstanceState.getIntArray(ALLOCATED_REQUEST_INDICIES_TAG);
				String[] fragmentWhos = savedInstanceState.getStringArray(REQUEST_FRAGMENT_WHO_TAG);
				if (requestCodes == null || fragmentWhos == null || requestCodes.length != fragmentWhos.length) {
					Log.w(TAG, "Invalid requestCode mapping in savedInstanceState.");
				} else {
					mPendingFragmentActivityResults = new SparseArrayCompat(requestCodes.length);
					int i = 0;
					while (i < requestCodes.length) {
						mPendingFragmentActivityResults.put(requestCodes[i], fragmentWhos[i]);
						i++;
					}
				}
			}
		}
		if (mPendingFragmentActivityResults == null) {
			mPendingFragmentActivityResults = new SparseArrayCompat();
			mNextCandidateRequestIndex = 0;
		}
		mFragments.dispatchCreate();
	}

	public boolean onCreatePanelMenu(int featureId, Menu menu) {
		if (featureId == 0) {
			boolean show = super.onCreatePanelMenu(featureId, menu) | mFragments.dispatchCreateOptionsMenu(menu, getMenuInflater());
			if (VERSION.SDK_INT >= HONEYCOMB) {
				return show;
			} else {
				return true;
			}
		} else {
			return super.onCreatePanelMenu(featureId, menu);
		}
	}

	public /* bridge */ /* synthetic */ View onCreateView(View x0, String x1, Context x2, AttributeSet x3) {
		return super.onCreateView(x0, x1, x2, x3);
	}

	public /* bridge */ /* synthetic */ View onCreateView(String x0, Context x1, AttributeSet x2) {
		return super.onCreateView(x0, x1, x2);
	}

	protected void onDestroy() {
		super.onDestroy();
		doReallyStop(false);
		mFragments.dispatchDestroy();
		mFragments.doLoaderDestroy();
	}

	public void onLowMemory() {
		super.onLowMemory();
		mFragments.dispatchLowMemory();
	}

	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		if (super.onMenuItemSelected(featureId, item)) {
			return true;
		} else {
			switch(featureId) {
			case Glow.ALWAYS:
				return mFragments.dispatchOptionsItemSelected(item);
			case R.styleable.YearPicker_dp_textHighlightColor:
				return mFragments.dispatchContextItemSelected(item);
			}
			return false;
		}
	}

	@CallSuper
	public void onMultiWindowModeChanged(boolean isInMultiWindowMode) {
		mFragments.dispatchMultiWindowModeChanged(isInMultiWindowMode);
	}

	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		mFragments.noteStateNotSaved();
	}

	public void onPanelClosed(int featureId, Menu menu) {
		switch(featureId) {
		case Glow.ALWAYS:
			mFragments.dispatchOptionsMenuClosed(menu);
			break;
		}
		super.onPanelClosed(featureId, menu);
	}

	protected void onPause() {
		super.onPause();
		mResumed = false;
		if (mHandler.hasMessages(MSG_RESUME_PENDING)) {
			mHandler.removeMessages(MSG_RESUME_PENDING);
			onResumeFragments();
		}
		mFragments.dispatchPause();
	}

	@CallSuper
	public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
		mFragments.dispatchPictureInPictureModeChanged(isInPictureInPictureMode);
	}

	protected void onPostResume() {
		super.onPostResume();
		mHandler.removeMessages(MSG_RESUME_PENDING);
		onResumeFragments();
		mFragments.execPendingActions();
	}

	protected boolean onPrepareOptionsPanel(View view, Menu menu) {
		return super.onPreparePanel(0, view, menu);
	}

	public boolean onPreparePanel(int featureId, View view, Menu menu) {
		if (featureId != 0 || menu == null) {
			return super.onPreparePanel(featureId, view, menu);
		} else {
			if (mOptionsMenuInvalidated) {
				mOptionsMenuInvalidated = false;
				menu.clear();
				onCreatePanelMenu(featureId, menu);
			}
			return onPrepareOptionsPanel(view, menu) | mFragments.dispatchPrepareOptionsMenu(menu);
		}
	}

	void onReallyStop() {
		mFragments.doLoaderStop(mRetaining);
		mFragments.dispatchReallyStop();
	}

	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		int index = (requestCode >> 16) & 65535;
		if (index != 0) {
			index--;
			String who = (String) mPendingFragmentActivityResults.get(index);
			mPendingFragmentActivityResults.remove(index);
			if (who == null) {
				Log.w(TAG, "Activity result delivered for unknown Fragment.");
			} else {
				Fragment frag = mFragments.findFragmentByWho(who);
				if (frag == null) {
					Log.w(TAG, "Activity result no fragment exists for who: " + who);
				} else {
					frag.onRequestPermissionsResult(requestCode & 65535, permissions, grantResults);
				}
			}
		}
	}

	protected void onResume() {
		super.onResume();
		mHandler.sendEmptyMessage(MSG_RESUME_PENDING);
		mResumed = true;
		mFragments.execPendingActions();
	}

	protected void onResumeFragments() {
		mFragments.dispatchResume();
	}

	public Object onRetainCustomNonConfigurationInstance() {
		return null;
	}

	public final Object onRetainNonConfigurationInstance() {
		if (mStopped) {
			doReallyStop(true);
		}
		Object custom = onRetainCustomNonConfigurationInstance();
		FragmentManagerNonConfig fragments = mFragments.retainNestedNonConfig();
		SimpleArrayMap<String, LoaderManager> loaders = mFragments.retainLoaderNonConfig();
		if (fragments != null || loaders != null || custom != null) {
			NonConfigurationInstances nci = new NonConfigurationInstances();
			nci.custom = custom;
			nci.fragments = fragments;
			nci.loaders = loaders;
			return nci;
		} else {
			return null;
		}
	}

	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		Parcelable p = mFragments.saveAllState();
		if (p != null) {
			outState.putParcelable(FRAGMENTS_TAG, p);
		}
		if (mPendingFragmentActivityResults.size() > 0) {
			outState.putInt(NEXT_CANDIDATE_REQUEST_INDEX_TAG, mNextCandidateRequestIndex);
			int[] requestCodes = new int[mPendingFragmentActivityResults.size()];
			String[] fragmentWhos = new String[mPendingFragmentActivityResults.size()];
			int i = 0;
			while (i < mPendingFragmentActivityResults.size()) {
				requestCodes[i] = mPendingFragmentActivityResults.keyAt(i);
				fragmentWhos[i] = (String) mPendingFragmentActivityResults.valueAt(i);
				i++;
			}
			outState.putIntArray(ALLOCATED_REQUEST_INDICIES_TAG, requestCodes);
			outState.putStringArray(REQUEST_FRAGMENT_WHO_TAG, fragmentWhos);
		}
	}

	protected void onStart() {
		super.onStart();
		mStopped = false;
		mReallyStopped = false;
		mHandler.removeMessages(MSG_REALLY_STOPPED);
		if (!mCreated) {
			mCreated = true;
			mFragments.dispatchActivityCreated();
		}
		mFragments.noteStateNotSaved();
		mFragments.execPendingActions();
		mFragments.doLoaderStart();
		mFragments.dispatchStart();
		mFragments.reportLoaderStart();
	}

	public void onStateNotSaved() {
		mFragments.noteStateNotSaved();
	}

	protected void onStop() {
		super.onStop();
		mStopped = true;
		mHandler.sendEmptyMessage(MSG_REALLY_STOPPED);
		mFragments.dispatchStop();
	}

	void requestPermissionsFromFragment(Fragment fragment, String[] permissions, int requestCode) {
		if (requestCode == -1) {
			ActivityCompat.requestPermissions(this, permissions, requestCode);
		} else {
			checkForValidRequestCode(requestCode);
			boolean r1z = true;
			mRequestedPermissionsFromFragment = r1z;
			ActivityCompat.requestPermissions(this, permissions, ((allocateRequestIndex(fragment) + 1) << 16) + (65535 & requestCode));
			mRequestedPermissionsFromFragment = false;
		}
	}

	public void setEnterSharedElementCallback(SharedElementCallback callback) {
		ActivityCompat.setEnterSharedElementCallback(this, callback);
	}

	public void setExitSharedElementCallback(SharedElementCallback listener) {
		ActivityCompat.setExitSharedElementCallback(this, listener);
	}

	public final void setSupportMediaController(MediaControllerCompat mediaController) {
		mMediaController = mediaController;
		if (VERSION.SDK_INT >= 21) {
			ActivityCompat21.setMediaController(this, mediaController.getMediaController());
		}
	}

	public void startActivityForResult(Intent intent, int requestCode) {
		if (mStartedActivityFromFragment || requestCode == -1) {
			super.startActivityForResult(intent, requestCode);
		} else {
			checkForValidRequestCode(requestCode);
			super.startActivityForResult(intent, requestCode);
		}
	}

	public /* bridge */ /* synthetic */ void startActivityForResult(Intent r1_Intent, int r2i, @Nullable Bundle r3_Bundle) {
		super.startActivityForResult(r1_Intent, r2i, r3_Bundle);
	}

	public void startActivityFromFragment(Fragment fragment, Intent intent, int requestCode) {
		startActivityFromFragment(fragment, intent, requestCode, null);
	}

	public void startActivityFromFragment(Fragment fragment, Intent intent, int requestCode, @Nullable Bundle options) {
		mStartedActivityFromFragment = true;
		if (requestCode == -1) {
			ActivityCompat.startActivityForResult(this, intent, -1, options);
			mStartedActivityFromFragment = false;
		} else {
			checkForValidRequestCode(requestCode);
			ActivityCompat.startActivityForResult(this, intent, ((allocateRequestIndex(fragment) + 1) << 16) + (65535 & requestCode), options);
			mStartedActivityFromFragment = false;
		}
	}

	public /* bridge */ /* synthetic */ void startIntentSenderForResult(IntentSender r1_IntentSender, int r2i, @Nullable Intent r3_Intent, int r4i, int r5i, int r6i) throws SendIntentException {
		super.startIntentSenderForResult(r1_IntentSender, r2i, r3_Intent, r4i, r5i, r6i);
	}

	public /* bridge */ /* synthetic */ void startIntentSenderForResult(IntentSender r1_IntentSender, int r2i, @Nullable Intent r3_Intent, int r4i, int r5i, int r6i, Bundle r7_Bundle) throws SendIntentException {
		super.startIntentSenderForResult(r1_IntentSender, r2i, r3_Intent, r4i, r5i, r6i, r7_Bundle);
	}

	public void startIntentSenderFromFragment(Fragment fragment, IntentSender intent, int requestCode, @Nullable Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags, Bundle options) throws SendIntentException {
		mStartedIntentSenderFromFragment = true;
		if (requestCode == -1) {
			Activity r0_Activity = this;
			IntentSender r1_IntentSender = intent;
			int r2i = requestCode;
			Intent r3_Intent = fillInIntent;
			int r4i = flagsMask;
			int r5i = flagsValues;
			int r6i = extraFlags;
			Bundle r7_Bundle = options;
			ActivityCompat.startIntentSenderForResult(r0_Activity, r1_IntentSender, r2i, r3_Intent, r4i, r5i, r6i, r7_Bundle);
			mStartedIntentSenderFromFragment = false;
		} else {
			checkForValidRequestCode(requestCode);
			ActivityCompat.startIntentSenderForResult(this, intent, ((allocateRequestIndex(fragment) + 1) << 16) + (65535 & requestCode), fillInIntent, flagsMask, flagsValues, extraFlags, options);
			mStartedIntentSenderFromFragment = false;
		}
	}

	public void supportFinishAfterTransition() {
		ActivityCompat.finishAfterTransition(this);
	}

	public void supportInvalidateOptionsMenu() {
		if (VERSION.SDK_INT >= 11) {
			ActivityCompatHoneycomb.invalidateOptionsMenu(this);
		} else {
			mOptionsMenuInvalidated = true;
		}
	}

	public void supportPostponeEnterTransition() {
		ActivityCompat.postponeEnterTransition(this);
	}

	public void supportStartPostponedEnterTransition() {
		ActivityCompat.startPostponedEnterTransition(this);
	}

	public final void validateRequestPermissionsRequestCode(int requestCode) {
		if (mRequestedPermissionsFromFragment || requestCode == -1) {
		} else {
			checkForValidRequestCode(requestCode);
		}
	}
}
