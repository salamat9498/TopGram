package android.support.v4.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.app.SharedElementCallback.OnSharedElementsReadyListener;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Parcelable;
import android.support.v4.app.ActivityCompat21.SharedElementCallback21;
import android.view.View;
import java.util.List;
import java.util.Map;

class ActivityCompatApi23 {
	public static abstract class SharedElementCallback23 extends SharedElementCallback21 {
		public SharedElementCallback23() {
			super();
		}

		public abstract void onSharedElementsArrived(List<String> r1_List_String, List<View> r2_List_View, ActivityCompatApi23.OnSharedElementsReadyListenerBridge r3_ActivityCompatApi23_OnSharedElementsReadyListenerBridge);
	}

	public static interface OnSharedElementsReadyListenerBridge {
		public void onSharedElementsReady();
	}

	public static interface RequestPermissionsRequestCodeValidator {
		public void validateRequestPermissionsRequestCode(int r1i);
	}

	private static class SharedElementCallbackImpl extends SharedElementCallback {
		private ActivityCompatApi23.SharedElementCallback23 mCallback;

		class AnonymousClass_1 implements ActivityCompatApi23.OnSharedElementsReadyListenerBridge {
			final /* synthetic */ ActivityCompatApi23.SharedElementCallbackImpl this$0;
			final /* synthetic */ OnSharedElementsReadyListener val$listener;

			AnonymousClass_1(ActivityCompatApi23.SharedElementCallbackImpl this$0, OnSharedElementsReadyListener r2_OnSharedElementsReadyListener) {
				super();
				this.this$0 = this$0;
				val$listener = r2_OnSharedElementsReadyListener;
			}

			public void onSharedElementsReady() {
				val$listener.onSharedElementsReady();
			}
		}


		public SharedElementCallbackImpl(ActivityCompatApi23.SharedElementCallback23 callback) {
			super();
			mCallback = callback;
		}

		public Parcelable onCaptureSharedElementSnapshot(View sharedElement, Matrix viewToGlobalMatrix, RectF screenBounds) {
			return mCallback.onCaptureSharedElementSnapshot(sharedElement, viewToGlobalMatrix, screenBounds);
		}

		public View onCreateSnapshotView(Context context, Parcelable snapshot) {
			return mCallback.onCreateSnapshotView(context, snapshot);
		}

		public void onMapSharedElements(List<String> names, Map<String, View> sharedElements) {
			mCallback.onMapSharedElements(names, sharedElements);
		}

		public void onRejectSharedElements(List<View> rejectedSharedElements) {
			mCallback.onRejectSharedElements(rejectedSharedElements);
		}

		public void onSharedElementEnd(List<String> sharedElementNames, List<View> sharedElements, List<View> sharedElementSnapshots) {
			mCallback.onSharedElementEnd(sharedElementNames, sharedElements, sharedElementSnapshots);
		}

		public void onSharedElementStart(List<String> sharedElementNames, List<View> sharedElements, List<View> sharedElementSnapshots) {
			mCallback.onSharedElementStart(sharedElementNames, sharedElements, sharedElementSnapshots);
		}

		public void onSharedElementsArrived(List<String> sharedElementNames, List<View> sharedElements, OnSharedElementsReadyListener listener) {
			mCallback.onSharedElementsArrived(sharedElementNames, sharedElements, new AnonymousClass_1(this, listener));
		}
	}


	ActivityCompatApi23() {
		super();
	}

	private static SharedElementCallback createCallback(SharedElementCallback23 callback) {
		SharedElementCallbackImpl newListener = null;
		if (callback != null) {
			newListener = new SharedElementCallbackImpl(callback);
		}
		return newListener;
	}

	public static void requestPermissions(Activity activity, String[] permissions, int requestCode) {
		if (activity instanceof RequestPermissionsRequestCodeValidator) {
			((RequestPermissionsRequestCodeValidator) activity).validateRequestPermissionsRequestCode(requestCode);
		}
		activity.requestPermissions(permissions, requestCode);
	}

	public static void setEnterSharedElementCallback(Activity activity, SharedElementCallback23 callback) {
		activity.setEnterSharedElementCallback(createCallback(callback));
	}

	public static void setExitSharedElementCallback(Activity activity, SharedElementCallback23 callback) {
		activity.setExitSharedElementCallback(createCallback(callback));
	}

	public static boolean shouldShowRequestPermissionRationale(Activity activity, String permission) {
		return activity.shouldShowRequestPermissionRationale(permission);
	}
}
