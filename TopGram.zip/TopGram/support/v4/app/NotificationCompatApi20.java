package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.NotificationCompatBase.Action;
import android.support.v4.app.NotificationCompatBase.Action.Factory;
import android.widget.RemoteViews;
import java.util.ArrayList;

class NotificationCompatApi20 {
	public static class Builder implements NotificationBuilderWithBuilderAccessor, NotificationBuilderWithActions {
		private android.app.Notification.Builder b;
		private RemoteViews mBigContentView;
		private RemoteViews mContentView;
		private Bundle mExtras;

		public Builder(Context context, Notification n, CharSequence contentTitle, CharSequence contentText, CharSequence contentInfo, RemoteViews tickerView, int number, PendingIntent contentIntent, PendingIntent fullScreenIntent, Bitmap largeIcon, int progressMax, int progress, boolean progressIndeterminate, boolean showWhen, boolean useChronometer, int priority, CharSequence subText, boolean localOnly, ArrayList<String> people, Bundle extras, String groupKey, boolean groupSummary, String sortKey, RemoteViews contentView, RemoteViews bigContentView) {
			boolean r4z;
			super();
			android.app.Notification.Builder r5_android_app_Notification_Builder = new android.app.Notification.Builder(context).setWhen(n.when).setShowWhen(showWhen).setSmallIcon(n.icon, n.iconLevel).setContent(n.contentView).setTicker(n.tickerText, tickerView).setSound(n.sound, n.audioStreamType).setVibrate(n.vibrate).setLights(n.ledARGB, n.ledOnMS, n.ledOffMS);
			if ((n.flags & 2) != 0) {
				r4z = true;
			} else {
				r4z = false;
			}
			r5_android_app_Notification_Builder = r5_android_app_Notification_Builder.setOngoing(r4z);
			if ((n.flags & 8) != 0) {
				r4z = true;
			} else {
				r4z = false;
			}
			r5_android_app_Notification_Builder = r5_android_app_Notification_Builder.setOnlyAlertOnce(r4z);
			if ((n.flags & 16) != 0) {
				r4z = true;
			} else {
				r4z = false;
			}
			r5_android_app_Notification_Builder = r5_android_app_Notification_Builder.setAutoCancel(r4z).setDefaults(n.defaults).setContentTitle(contentTitle).setContentText(contentText).setSubText(subText).setContentInfo(contentInfo).setContentIntent(contentIntent).setDeleteIntent(n.deleteIntent);
			if ((n.flags & 128) != 0) {
				r4z = true;
			} else {
				r4z = false;
			}
			b = r5_android_app_Notification_Builder.setFullScreenIntent(fullScreenIntent, r4z).setLargeIcon(largeIcon).setNumber(number).setUsesChronometer(useChronometer).setPriority(priority).setProgress(progressMax, progress, progressIndeterminate).setLocalOnly(localOnly).setGroup(groupKey).setGroupSummary(groupSummary).setSortKey(sortKey);
			mExtras = new Bundle();
			if (extras != null) {
				mExtras.putAll(extras);
			}
			if (people == null || people.isEmpty()) {
				mContentView = contentView;
				mBigContentView = bigContentView;
			} else {
				mExtras.putStringArray(EXTRA_PEOPLE, (String[]) people.toArray(new String[people.size()]));
				mContentView = contentView;
				mBigContentView = bigContentView;
			}
		}

		public void addAction(Action action) {
			NotificationCompatApi20.addAction(b, action);
		}

		public Notification build() {
			b.setExtras(mExtras);
			Notification notification = b.build();
			if (mContentView != null) {
				notification.contentView = mContentView;
			}
			if (mBigContentView != null) {
				notification.bigContentView = mBigContentView;
			}
			return notification;
		}

		public android.app.Notification.Builder getBuilder() {
			return b;
		}
	}


	NotificationCompatApi20() {
		super();
	}

	public static void addAction(android.app.Notification.Builder b, Action action) {
		Bundle actionExtras;
		android.app.Notification.Action.Builder actionBuilder = new android.app.Notification.Action.Builder(action.getIcon(), action.getTitle(), action.getActionIntent());
		if (action.getRemoteInputs() != null) {
			RemoteInput[] r4_RemoteInput_A = RemoteInputCompatApi20.fromCompat(action.getRemoteInputs());
			int r3i = 0;
			while (r3i < r4_RemoteInput_A.length) {
				actionBuilder.addRemoteInput(r4_RemoteInput_A[r3i]);
				r3i++;
			}
		}
		if (action.getExtras() != null) {
			actionExtras = new Bundle(action.getExtras());
		} else {
			actionExtras = new Bundle();
		}
		actionExtras.putBoolean("android.support.allowGeneratedReplies", action.getAllowGeneratedReplies());
		actionBuilder.addExtras(actionExtras);
		b.addAction(actionBuilder.build());
	}

	public static Action getAction(Notification notif, int actionIndex, Factory actionFactory, RemoteInputCompatBase.RemoteInput.Factory remoteInputFactory) {
		return getActionCompatFromAction(notif.actions[actionIndex], actionFactory, remoteInputFactory);
	}

	private static Action getActionCompatFromAction(android.app.Notification.Action action, Factory actionFactory, RemoteInputCompatBase.RemoteInput.Factory remoteInputFactory) {
		return actionFactory.build(action.icon, action.title, action.actionIntent, action.getExtras(), RemoteInputCompatApi20.toCompat(action.getRemoteInputs(), remoteInputFactory), action.getExtras().getBoolean("android.support.allowGeneratedReplies"));
	}

	private static android.app.Notification.Action getActionFromActionCompat(Action actionCompat) {
		android.app.Notification.Action.Builder actionBuilder = new android.app.Notification.Action.Builder(actionCompat.getIcon(), actionCompat.getTitle(), actionCompat.getActionIntent()).addExtras(actionCompat.getExtras());
		RemoteInputCompatBase.RemoteInput[] remoteInputCompats = actionCompat.getRemoteInputs();
		if (remoteInputCompats != null) {
			RemoteInput[] remoteInputs = RemoteInputCompatApi20.fromCompat(remoteInputCompats);
			int r4i = 0;
			while (r4i < remoteInputs.length) {
				actionBuilder.addRemoteInput(remoteInputs[r4i]);
				r4i++;
			}
		}
		return actionBuilder.build();
	}

	public static Action[] getActionsFromParcelableArrayList(ArrayList<Parcelable> parcelables, Factory actionFactory, RemoteInputCompatBase.RemoteInput.Factory remoteInputFactory) {
		if (parcelables == null) {
			return null;
		} else {
			Action[] actions = actionFactory.newArray(parcelables.size());
			int i = 0;
			while (i < actions.length) {
				actions[i] = getActionCompatFromAction((android.app.Notification.Action) parcelables.get(i), actionFactory, remoteInputFactory);
				i++;
			}
			return actions;
		}
	}

	public static String getGroup(Notification notif) {
		return notif.getGroup();
	}

	public static boolean getLocalOnly(Notification notif) {
		if ((notif.flags & 256) != 0) {
			return true;
		} else {
			return false;
		}
	}

	public static ArrayList<Parcelable> getParcelableArrayListForActions(Action[] actions) {
		if (actions == null) {
			return null;
		} else {
			ArrayList<Parcelable> parcelables = new ArrayList(actions.length);
			int r2i = 0;
			while (r2i < actions.length) {
				parcelables.add(getActionFromActionCompat(actions[r2i]));
				r2i++;
			}
			return parcelables;
		}
	}

	public static String getSortKey(Notification notif) {
		return notif.getSortKey();
	}

	public static boolean isGroupSummary(Notification notif) {
		if ((notif.flags & 512) != 0) {
			return true;
		} else {
			return false;
		}
	}
}
