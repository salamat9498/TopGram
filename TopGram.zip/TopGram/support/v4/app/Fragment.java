package android.support.v4.app;

import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.SimpleArrayMap;
import android.support.v4.view.LayoutInflaterCompat;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class Fragment implements ComponentCallbacks, OnCreateContextMenuListener {
	static final int ACTIVITY_CREATED = 2;
	static final int CREATED = 1;
	static final int INITIALIZING = 0;
	static final int RESUMED = 5;
	static final int STARTED = 4;
	static final int STOPPED = 3;
	static final Object USE_DEFAULT_TRANSITION;
	private static final SimpleArrayMap<String, Class<?>> sClassMap;
	boolean mAdded;
	Boolean mAllowEnterTransitionOverlap;
	Boolean mAllowReturnTransitionOverlap;
	View mAnimatingAway;
	Bundle mArguments;
	int mBackStackNesting;
	boolean mCalled;
	boolean mCheckedForLoaderManager;
	FragmentManagerImpl mChildFragmentManager;
	FragmentManagerNonConfig mChildNonConfig;
	ViewGroup mContainer;
	int mContainerId;
	boolean mDeferStart;
	boolean mDetached;
	Object mEnterTransition;
	SharedElementCallback mEnterTransitionCallback;
	Object mExitTransition;
	SharedElementCallback mExitTransitionCallback;
	int mFragmentId;
	FragmentManagerImpl mFragmentManager;
	boolean mFromLayout;
	boolean mHasMenu;
	boolean mHidden;
	FragmentHostCallback mHost;
	boolean mInLayout;
	int mIndex;
	View mInnerView;
	LoaderManagerImpl mLoaderManager;
	boolean mLoadersStarted;
	boolean mMenuVisible;
	int mNextAnim;
	Fragment mParentFragment;
	Object mReenterTransition;
	boolean mRemoving;
	boolean mRestored;
	boolean mRetainInstance;
	boolean mRetaining;
	Object mReturnTransition;
	Bundle mSavedFragmentState;
	SparseArray<Parcelable> mSavedViewState;
	Object mSharedElementEnterTransition;
	Object mSharedElementReturnTransition;
	int mState;
	int mStateAfterAnimating;
	String mTag;
	Fragment mTarget;
	int mTargetIndex;
	int mTargetRequestCode;
	boolean mUserVisibleHint;
	View mView;
	String mWho;

	class AnonymousClass_1 extends FragmentContainer {
		final /* synthetic */ Fragment this$0;

		AnonymousClass_1(Fragment this$0) {
			super();
			this.this$0 = this$0;
		}

		@Nullable
		public View onFindViewById(int id) {
			if (this$0.mView == null) {
				throw new IllegalStateException("Fragment does not have a view");
			} else {
				return this$0.mView.findViewById(id);
			}
		}

		public boolean onHasView() {
			if (this$0.mView != null) {
				return true;
			} else {
				return false;
			}
		}
	}

	public static class InstantiationException extends RuntimeException {
		public InstantiationException(String msg, Exception cause) {
			super(msg, cause);
		}
	}

	public static class SavedState implements Parcelable {
		public static final Creator<Fragment.SavedState> CREATOR;
		final Bundle mState;

		static class AnonymousClass_1 implements Creator<Fragment.SavedState> {
			AnonymousClass_1() {
				super();
			}

			public Fragment.SavedState createFromParcel(Parcel in) {
				return new Fragment.SavedState(in, null);
			}

			public Fragment.SavedState[] newArray(int size) {
				return new Fragment.SavedState[size];
			}
		}


		static {
			CREATOR = new AnonymousClass_1();
		}

		SavedState(Bundle state) {
			super();
			mState = state;
		}

		SavedState(Parcel in, ClassLoader loader) {
			super();
			mState = in.readBundle();
			if (loader == null || mState == null) {
			} else {
				mState.setClassLoader(loader);
			}
		}

		public int describeContents() {
			return INITIALIZING;
		}

		public void writeToParcel(Parcel dest, int flags) {
			dest.writeBundle(mState);
		}
	}


	static {
		sClassMap = new SimpleArrayMap();
		USE_DEFAULT_TRANSITION = new Object();
	}

	public Fragment() {
		super();
		mState = 0;
		mIndex = -1;
		mTargetIndex = -1;
		mMenuVisible = true;
		mUserVisibleHint = true;
		mEnterTransition = null;
		mReturnTransition = USE_DEFAULT_TRANSITION;
		mExitTransition = null;
		mReenterTransition = USE_DEFAULT_TRANSITION;
		mSharedElementEnterTransition = null;
		mSharedElementReturnTransition = USE_DEFAULT_TRANSITION;
		mEnterTransitionCallback = null;
		mExitTransitionCallback = null;
	}

	public static Fragment instantiate(Context context, String fname) {
		return instantiate(context, fname, null);
	}

	public static Fragment instantiate(Context context, String fname, @Nullable Bundle args) {
		Class<?> clazz;
		Fragment f;
		try {
			clazz = (Class) sClassMap.get(fname);
			if (clazz == null) {
				clazz = context.getClassLoader().loadClass(fname);
				sClassMap.put(fname, clazz);
			}
			f = (Fragment) clazz.newInstance();
			if (args != null) {
				args.setClassLoader(f.getClass().getClassLoader());
				f.mArguments = args;
				return f;
			} else {
				return f;
			}
		} catch (ClassNotFoundException e) {
			throw new InstantiationException("Unable to instantiate fragment " + fname + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e);
		} catch (InstantiationException e_2) {
			throw new InstantiationException("Unable to instantiate fragment " + fname + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e_2);
		} catch (IllegalAccessException e_3) {
			throw new InstantiationException("Unable to instantiate fragment " + fname + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e_3);
		}
	}

	static boolean isSupportFragmentClass(Context context, String fname) {
		Class<?> clazz;
		try {
			clazz = (Class) sClassMap.get(fname);
			if (clazz == null) {
				clazz = context.getClassLoader().loadClass(fname);
				sClassMap.put(fname, clazz);
			}
			return Fragment.class.isAssignableFrom(clazz);
		} catch (ClassNotFoundException e) {
			return false;
		}
	}

	public void dump(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
		writer.print(prefix);
		writer.print("mFragmentId=#");
		writer.print(Integer.toHexString(mFragmentId));
		writer.print(" mContainerId=#");
		writer.print(Integer.toHexString(mContainerId));
		writer.print(" mTag=");
		writer.println(mTag);
		writer.print(prefix);
		writer.print("mState=");
		writer.print(mState);
		writer.print(" mIndex=");
		writer.print(mIndex);
		writer.print(" mWho=");
		writer.print(mWho);
		writer.print(" mBackStackNesting=");
		writer.println(mBackStackNesting);
		writer.print(prefix);
		writer.print("mAdded=");
		writer.print(mAdded);
		writer.print(" mRemoving=");
		writer.print(mRemoving);
		writer.print(" mFromLayout=");
		writer.print(mFromLayout);
		writer.print(" mInLayout=");
		writer.println(mInLayout);
		writer.print(prefix);
		writer.print("mHidden=");
		writer.print(mHidden);
		writer.print(" mDetached=");
		writer.print(mDetached);
		writer.print(" mMenuVisible=");
		writer.print(mMenuVisible);
		writer.print(" mHasMenu=");
		writer.println(mHasMenu);
		writer.print(prefix);
		writer.print("mRetainInstance=");
		writer.print(mRetainInstance);
		writer.print(" mRetaining=");
		writer.print(mRetaining);
		writer.print(" mUserVisibleHint=");
		writer.println(mUserVisibleHint);
		if (mFragmentManager != null) {
			writer.print(prefix);
			writer.print("mFragmentManager=");
			writer.println(mFragmentManager);
		}
		if (mHost != null) {
			writer.print(prefix);
			writer.print("mHost=");
			writer.println(mHost);
		}
		if (mParentFragment != null) {
			writer.print(prefix);
			writer.print("mParentFragment=");
			writer.println(mParentFragment);
		}
		if (mArguments != null) {
			writer.print(prefix);
			writer.print("mArguments=");
			writer.println(mArguments);
		}
		if (mSavedFragmentState != null) {
			writer.print(prefix);
			writer.print("mSavedFragmentState=");
			writer.println(mSavedFragmentState);
		}
		if (mSavedViewState != null) {
			writer.print(prefix);
			writer.print("mSavedViewState=");
			writer.println(mSavedViewState);
		}
		if (mTarget != null) {
			writer.print(prefix);
			writer.print("mTarget=");
			writer.print(mTarget);
			writer.print(" mTargetRequestCode=");
			writer.println(mTargetRequestCode);
		}
		if (mNextAnim != 0) {
			writer.print(prefix);
			writer.print("mNextAnim=");
			writer.println(mNextAnim);
		}
		if (mContainer != null) {
			writer.print(prefix);
			writer.print("mContainer=");
			writer.println(mContainer);
		}
		if (mView != null) {
			writer.print(prefix);
			writer.print("mView=");
			writer.println(mView);
		}
		if (mInnerView != null) {
			writer.print(prefix);
			writer.print("mInnerView=");
			writer.println(mView);
		}
		if (mAnimatingAway != null) {
			writer.print(prefix);
			writer.print("mAnimatingAway=");
			writer.println(mAnimatingAway);
			writer.print(prefix);
			writer.print("mStateAfterAnimating=");
			writer.println(mStateAfterAnimating);
		}
		if (mLoaderManager != null) {
			writer.print(prefix);
			writer.println("Loader Manager:");
			mLoaderManager.dump(prefix + "  ", fd, writer, args);
		}
		if (mChildFragmentManager != null) {
			writer.print(prefix);
			writer.println("Child " + mChildFragmentManager + ":");
			mChildFragmentManager.dump(prefix + "  ", fd, writer, args);
		}
	}

	public final boolean equals(Object o) {
		return super.equals(o);
	}

	Fragment findFragmentByWho(String who) {
		if (who.equals(mWho)) {
			return this;
		} else if (mChildFragmentManager != null) {
			return mChildFragmentManager.findFragmentByWho(who);
		} else {
			return null;
		}
	}

	public final FragmentActivity getActivity() {
		if (mHost == null) {
			return null;
		} else {
			return (FragmentActivity) mHost.getActivity();
		}
	}

	public boolean getAllowEnterTransitionOverlap() {
		if (mAllowEnterTransitionOverlap == null) {
			return true;
		} else {
			return mAllowEnterTransitionOverlap.booleanValue();
		}
	}

	public boolean getAllowReturnTransitionOverlap() {
		if (mAllowReturnTransitionOverlap == null) {
			return true;
		} else {
			return mAllowReturnTransitionOverlap.booleanValue();
		}
	}

	public final Bundle getArguments() {
		return mArguments;
	}

	public final FragmentManager getChildFragmentManager() {
		if (mChildFragmentManager == null) {
			instantiateChildFragmentManager();
			if (mState >= 5) {
				mChildFragmentManager.dispatchResume();
			} else if (mState >= 4) {
				mChildFragmentManager.dispatchStart();
			} else if (mState >= 2) {
				mChildFragmentManager.dispatchActivityCreated();
			} else if (mState >= 1) {
				mChildFragmentManager.dispatchCreate();
			}
		}
		return mChildFragmentManager;
	}

	public Context getContext() {
		if (mHost == null) {
			return null;
		} else {
			return mHost.getContext();
		}
	}

	public Object getEnterTransition() {
		return mEnterTransition;
	}

	public Object getExitTransition() {
		return mExitTransition;
	}

	public final FragmentManager getFragmentManager() {
		return mFragmentManager;
	}

	public final Object getHost() {
		if (mHost == null) {
			return null;
		} else {
			return mHost.onGetHost();
		}
	}

	public final int getId() {
		return mFragmentId;
	}

	public LayoutInflater getLayoutInflater(Bundle savedInstanceState) {
		LayoutInflater result = mHost.onGetLayoutInflater();
		getChildFragmentManager();
		LayoutInflaterCompat.setFactory(result, mChildFragmentManager.getLayoutInflaterFactory());
		return result;
	}

	public LoaderManager getLoaderManager() {
		if (mLoaderManager != null) {
			return mLoaderManager;
		} else if (mHost == null) {
			throw new IllegalStateException("Fragment " + this + " not attached to Activity");
		} else {
			mCheckedForLoaderManager = true;
			mLoaderManager = mHost.getLoaderManager(mWho, mLoadersStarted, true);
			return mLoaderManager;
		}
	}

	public final Fragment getParentFragment() {
		return mParentFragment;
	}

	public Object getReenterTransition() {
		if (mReenterTransition == USE_DEFAULT_TRANSITION) {
			return getExitTransition();
		} else {
			return mReenterTransition;
		}
	}

	public final Resources getResources() {
		if (mHost == null) {
			throw new IllegalStateException("Fragment " + this + " not attached to Activity");
		} else {
			return mHost.getContext().getResources();
		}
	}

	public final boolean getRetainInstance() {
		return mRetainInstance;
	}

	public Object getReturnTransition() {
		if (mReturnTransition == USE_DEFAULT_TRANSITION) {
			return getEnterTransition();
		} else {
			return mReturnTransition;
		}
	}

	public Object getSharedElementEnterTransition() {
		return mSharedElementEnterTransition;
	}

	public Object getSharedElementReturnTransition() {
		if (mSharedElementReturnTransition == USE_DEFAULT_TRANSITION) {
			return getSharedElementEnterTransition();
		} else {
			return mSharedElementReturnTransition;
		}
	}

	public final String getString(@StringRes int resId) {
		return getResources().getString(resId);
	}

	public final String getString(@StringRes int resId, Object ... formatArgs) {
		return getResources().getString(resId, formatArgs);
	}

	public final String getTag() {
		return mTag;
	}

	public final Fragment getTargetFragment() {
		return mTarget;
	}

	public final int getTargetRequestCode() {
		return mTargetRequestCode;
	}

	public final CharSequence getText(@StringRes int resId) {
		return getResources().getText(resId);
	}

	public boolean getUserVisibleHint() {
		return mUserVisibleHint;
	}

	@Nullable
	public View getView() {
		return mView;
	}

	public final boolean hasOptionsMenu() {
		return mHasMenu;
	}

	public final int hashCode() {
		return super.hashCode();
	}

	void initState() {
		mIndex = -1;
		mWho = null;
		mAdded = false;
		mRemoving = false;
		mFromLayout = false;
		mInLayout = false;
		mRestored = false;
		mBackStackNesting = 0;
		mFragmentManager = null;
		mChildFragmentManager = null;
		mHost = null;
		mFragmentId = 0;
		mContainerId = 0;
		mTag = null;
		mHidden = false;
		mDetached = false;
		mRetaining = false;
		mLoaderManager = null;
		mLoadersStarted = false;
		mCheckedForLoaderManager = false;
	}

	void instantiateChildFragmentManager() {
		mChildFragmentManager = new FragmentManagerImpl();
		mChildFragmentManager.attachController(mHost, new AnonymousClass_1(this), this);
	}

	public final boolean isAdded() {
		if (mHost == null || !mAdded) {
			return false;
		} else {
			return true;
		}
	}

	public final boolean isDetached() {
		return mDetached;
	}

	public final boolean isHidden() {
		return mHidden;
	}

	final boolean isInBackStack() {
		if (mBackStackNesting > 0) {
			return true;
		} else {
			return false;
		}
	}

	public final boolean isInLayout() {
		return mInLayout;
	}

	public final boolean isMenuVisible() {
		return mMenuVisible;
	}

	public final boolean isRemoving() {
		return mRemoving;
	}

	public final boolean isResumed() {
		if (mState >= 5) {
			return true;
		} else {
			return false;
		}
	}

	public final boolean isVisible() {
		if (!isAdded() || isHidden() || mView == null || mView.getWindowToken() == null || mView.getVisibility() != 0) {
			return false;
		} else {
			return true;
		}
	}

	@CallSuper
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		mCalled = true;
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
	}

	@CallSuper
	@Deprecated
	public void onAttach(Activity activity) {
		mCalled = true;
	}

	@CallSuper
	public void onAttach(Context context) {
		Activity hostActivity;
		mCalled = true;
		if (mHost == null) {
			hostActivity = null;
		} else {
			hostActivity = mHost.getActivity();
		}
		if (hostActivity != null) {
			mCalled = false;
			onAttach(hostActivity);
		}
	}

	public void onAttachFragment(Fragment childFragment) {
	}

	@CallSuper
	public void onConfigurationChanged(Configuration newConfig) {
		mCalled = true;
	}

	public boolean onContextItemSelected(MenuItem item) {
		return false;
	}

	@CallSuper
	public void onCreate(@Nullable Bundle savedInstanceState) {
		mCalled = true;
		restoreChildFragmentState(savedInstanceState);
		if (mChildFragmentManager == null || mChildFragmentManager.isStateAtLeast(CREATED)) {
		} else {
			mChildFragmentManager.dispatchCreate();
		}
	}

	public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
		return null;
	}

	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		getActivity().onCreateContextMenu(menu, v, menuInfo);
	}

	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
	}

	@Nullable
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		return null;
	}

	@CallSuper
	public void onDestroy() {
		boolean r1z = true;
		mCalled = true;
		if (!mCheckedForLoaderManager) {
			mCheckedForLoaderManager = r1z;
			mLoaderManager = mHost.getLoaderManager(mWho, mLoadersStarted, false);
		}
		if (mLoaderManager != null) {
			mLoaderManager.doDestroy();
		}
	}

	public void onDestroyOptionsMenu() {
	}

	@CallSuper
	public void onDestroyView() {
		mCalled = true;
	}

	@CallSuper
	public void onDetach() {
		mCalled = true;
	}

	public void onHiddenChanged(boolean hidden) {
	}

	@CallSuper
	@Deprecated
	public void onInflate(Activity activity, AttributeSet attrs, Bundle savedInstanceState) {
		mCalled = true;
	}

	@CallSuper
	public void onInflate(Context context, AttributeSet attrs, Bundle savedInstanceState) {
		Activity hostActivity;
		mCalled = true;
		if (mHost == null) {
			hostActivity = null;
		} else {
			hostActivity = mHost.getActivity();
		}
		if (hostActivity != null) {
			mCalled = false;
			onInflate(hostActivity, attrs, savedInstanceState);
		}
	}

	@CallSuper
	public void onLowMemory() {
		mCalled = true;
	}

	public void onMultiWindowModeChanged(boolean isInMultiWindowMode) {
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		return false;
	}

	public void onOptionsMenuClosed(Menu menu) {
	}

	@CallSuper
	public void onPause() {
		mCalled = true;
	}

	public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
	}

	public void onPrepareOptionsMenu(Menu menu) {
	}

	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
	}

	@CallSuper
	public void onResume() {
		mCalled = true;
	}

	public void onSaveInstanceState(Bundle outState) {
	}

	@CallSuper
	public void onStart() {
		boolean r1z = true;
		mCalled = true;
		if (!mLoadersStarted) {
			mLoadersStarted = true;
			if (!mCheckedForLoaderManager) {
				mCheckedForLoaderManager = r1z;
				mLoaderManager = mHost.getLoaderManager(mWho, mLoadersStarted, false);
			}
			if (mLoaderManager != null) {
				mLoaderManager.doStart();
			}
		}
	}

	@CallSuper
	public void onStop() {
		mCalled = true;
	}

	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
	}

	@CallSuper
	public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
		mCalled = true;
	}

	void performActivityCreated(Bundle savedInstanceState) {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.noteStateNotSaved();
		}
		mState = 2;
		mCalled = false;
		onActivityCreated(savedInstanceState);
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onActivityCreated()");
		} else if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchActivityCreated();
		}
	}

	void performConfigurationChanged(Configuration newConfig) {
		onConfigurationChanged(newConfig);
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchConfigurationChanged(newConfig);
		}
	}

	boolean performContextItemSelected(MenuItem item) {
		if (!mHidden) {
			if (onContextItemSelected(item)) {
				return true;
			} else if (mChildFragmentManager == null || !mChildFragmentManager.dispatchContextItemSelected(item)) {
				return false;
			} else {
				return true;
			}
		}
		return false;
	}

	void performCreate(Bundle savedInstanceState) {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.noteStateNotSaved();
		}
		mState = 1;
		mCalled = false;
		onCreate(savedInstanceState);
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onCreate()");
		}
	}

	boolean performCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		boolean show = false;
		if (!mHidden) {
			if (!mHasMenu || !mMenuVisible) {
				if (mChildFragmentManager == null) {
					show |= mChildFragmentManager.dispatchCreateOptionsMenu(menu, inflater);
				}
			} else {
				show = true;
				onCreateOptionsMenu(menu, inflater);
				if (mChildFragmentManager == null) {
					return show;
				} else {
					show |= mChildFragmentManager.dispatchCreateOptionsMenu(menu, inflater);
				}
			}
		}
		return show;
	}

	View performCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.noteStateNotSaved();
		}
		return onCreateView(inflater, container, savedInstanceState);
	}

	void performDestroy() {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchDestroy();
		}
		mState = 0;
		mCalled = false;
		onDestroy();
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onDestroy()");
		} else {
			mChildFragmentManager = null;
		}
	}

	void performDestroyView() {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchDestroyView();
		}
		mState = 1;
		mCalled = false;
		onDestroyView();
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onDestroyView()");
		} else if (mLoaderManager != null) {
			mLoaderManager.doReportNextStart();
		}
	}

	void performDetach() {
		mCalled = false;
		onDetach();
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onDetach()");
		} else if (mChildFragmentManager != null) {
			if (!mRetaining) {
				throw new IllegalStateException("Child FragmentManager of " + this + " was not " + " destroyed and this fragment is not retaining instance");
			} else {
				mChildFragmentManager.dispatchDestroy();
				mChildFragmentManager = null;
			}
		}
	}

	void performLowMemory() {
		onLowMemory();
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchLowMemory();
		}
	}

	void performMultiWindowModeChanged(boolean isInMultiWindowMode) {
		onMultiWindowModeChanged(isInMultiWindowMode);
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchMultiWindowModeChanged(isInMultiWindowMode);
		}
	}

	boolean performOptionsItemSelected(MenuItem item) {
		if (!mHidden) {
			if (!mHasMenu || !mMenuVisible || !onOptionsItemSelected(item)) {
				if (mChildFragmentManager == null || !mChildFragmentManager.dispatchOptionsItemSelected(item)) {
					return false;
				} else {
					return true;
				}
			} else {
				return true;
			}
		}
		return false;
	}

	void performOptionsMenuClosed(Menu menu) {
		if (!mHidden) {
			if (!mHasMenu || !mMenuVisible) {
				if (mChildFragmentManager == null) {
					mChildFragmentManager.dispatchOptionsMenuClosed(menu);
				}
			} else {
				onOptionsMenuClosed(menu);
				if (mChildFragmentManager == null) {
				} else {
					mChildFragmentManager.dispatchOptionsMenuClosed(menu);
				}
			}
		}
	}

	void performPause() {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchPause();
		}
		mState = 4;
		mCalled = false;
		onPause();
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onPause()");
		}
	}

	void performPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
		onPictureInPictureModeChanged(isInPictureInPictureMode);
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchPictureInPictureModeChanged(isInPictureInPictureMode);
		}
	}

	boolean performPrepareOptionsMenu(Menu menu) {
		boolean show = false;
		if (!mHidden) {
			if (!mHasMenu || !mMenuVisible) {
				if (mChildFragmentManager == null) {
					show |= mChildFragmentManager.dispatchPrepareOptionsMenu(menu);
				}
			} else {
				show = true;
				onPrepareOptionsMenu(menu);
				if (mChildFragmentManager == null) {
					return show;
				} else {
					show |= mChildFragmentManager.dispatchPrepareOptionsMenu(menu);
				}
			}
		}
		return show;
	}

	void performReallyStop() {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchReallyStop();
		}
		mState = 2;
		if (mLoadersStarted) {
			mLoadersStarted = false;
			if (!mCheckedForLoaderManager) {
				mCheckedForLoaderManager = true;
				mLoaderManager = mHost.getLoaderManager(mWho, mLoadersStarted, false);
			}
			if (mLoaderManager != null) {
				if (mHost.getRetainLoaders()) {
					mLoaderManager.doRetain();
				} else {
					mLoaderManager.doStop();
				}
			}
		}
	}

	void performResume() {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.noteStateNotSaved();
			mChildFragmentManager.execPendingActions();
		}
		mState = 5;
		mCalled = false;
		onResume();
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onResume()");
		} else if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchResume();
			mChildFragmentManager.execPendingActions();
		}
	}

	void performSaveInstanceState(Bundle outState) {
		onSaveInstanceState(outState);
		if (mChildFragmentManager != null) {
			Parcelable p = mChildFragmentManager.saveAllState();
			if (p != null) {
				outState.putParcelable("android:support:fragments", p);
			}
		}
	}

	void performStart() {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.noteStateNotSaved();
			mChildFragmentManager.execPendingActions();
		}
		mState = 4;
		mCalled = false;
		onStart();
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onStart()");
		} else {
			if (mChildFragmentManager != null) {
				mChildFragmentManager.dispatchStart();
			}
			if (mLoaderManager != null) {
				mLoaderManager.doReportStart();
			}
		}
	}

	void performStop() {
		if (mChildFragmentManager != null) {
			mChildFragmentManager.dispatchStop();
		}
		mState = 3;
		mCalled = false;
		onStop();
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onStop()");
		}
	}

	public void registerForContextMenu(View view) {
		view.setOnCreateContextMenuListener(this);
	}

	public final void requestPermissions(@NonNull String[] permissions, int requestCode) {
		if (mHost == null) {
			throw new IllegalStateException("Fragment " + this + " not attached to Activity");
		} else {
			mHost.onRequestPermissionsFromFragment(this, permissions, requestCode);
		}
	}

	void restoreChildFragmentState(@Nullable Bundle savedInstanceState) {
		if (savedInstanceState != null) {
			Parcelable p = savedInstanceState.getParcelable("android:support:fragments");
			if (p != null) {
				if (mChildFragmentManager == null) {
					instantiateChildFragmentManager();
				}
				mChildFragmentManager.restoreAllState(p, mChildNonConfig);
				mChildNonConfig = null;
				mChildFragmentManager.dispatchCreate();
			}
		}
	}

	final void restoreViewState(Bundle savedInstanceState) {
		if (mSavedViewState != null) {
			mInnerView.restoreHierarchyState(mSavedViewState);
			mSavedViewState = null;
		}
		mCalled = false;
		onViewStateRestored(savedInstanceState);
		if (!mCalled) {
			throw new SuperNotCalledException("Fragment " + this + " did not call through to super.onViewStateRestored()");
		}
	}

	public void setAllowEnterTransitionOverlap(boolean allow) {
		mAllowEnterTransitionOverlap = Boolean.valueOf(allow);
	}

	public void setAllowReturnTransitionOverlap(boolean allow) {
		mAllowReturnTransitionOverlap = Boolean.valueOf(allow);
	}

	public void setArguments(Bundle args) {
		if (mIndex >= 0) {
			throw new IllegalStateException("Fragment already active");
		} else {
			mArguments = args;
		}
	}

	public void setEnterSharedElementCallback(SharedElementCallback callback) {
		mEnterTransitionCallback = callback;
	}

	public void setEnterTransition(Object transition) {
		mEnterTransition = transition;
	}

	public void setExitSharedElementCallback(SharedElementCallback callback) {
		mExitTransitionCallback = callback;
	}

	public void setExitTransition(Object transition) {
		mExitTransition = transition;
	}

	public void setHasOptionsMenu(boolean hasMenu) {
		if (mHasMenu != hasMenu) {
			mHasMenu = hasMenu;
			if (!isAdded() || isHidden()) {
			} else {
				mHost.onSupportInvalidateOptionsMenu();
			}
		}
	}

	final void setIndex(int index, Fragment parent) {
		mIndex = index;
		if (parent != null) {
			parent.mWho += ":" + mIndex;
		} else {
			mWho = "android:fragment:" + mIndex;
		}
	}

	public void setInitialSavedState(SavedState state) {
		if (mIndex >= 0) {
			throw new IllegalStateException("Fragment already active");
		} else {
			Bundle r0_Bundle;
			if (state == null || state.mState == null) {
				r0_Bundle = null;
			} else {
				r0_Bundle = state.mState;
			}
			mSavedFragmentState = r0_Bundle;
		}
	}

	public void setMenuVisibility(boolean menuVisible) {
		if (mMenuVisible != menuVisible) {
			mMenuVisible = menuVisible;
			if (!mHasMenu || !isAdded() || isHidden()) {
			} else {
				mHost.onSupportInvalidateOptionsMenu();
			}
		}
	}

	public void setReenterTransition(Object transition) {
		mReenterTransition = transition;
	}

	public void setRetainInstance(boolean retain) {
		mRetainInstance = retain;
	}

	public void setReturnTransition(Object transition) {
		mReturnTransition = transition;
	}

	public void setSharedElementEnterTransition(Object transition) {
		mSharedElementEnterTransition = transition;
	}

	public void setSharedElementReturnTransition(Object transition) {
		mSharedElementReturnTransition = transition;
	}

	public void setTargetFragment(Fragment fragment, int requestCode) {
		mTarget = fragment;
		mTargetRequestCode = requestCode;
	}

	public void setUserVisibleHint(boolean isVisibleToUser) {
		boolean r0z;
		if (mUserVisibleHint || !isVisibleToUser || mState >= 4 || mFragmentManager == null || !isAdded()) {
			mUserVisibleHint = isVisibleToUser;
			if (mState >= 4 || isVisibleToUser) {
				r0z = false;
			} else {
				r0z = true;
			}
			mDeferStart = r0z;
		} else {
			mFragmentManager.performPendingDeferredStart(this);
			mUserVisibleHint = isVisibleToUser;
			if (mState >= 4 || isVisibleToUser) {
				r0z = false;
			} else {
				r0z = true;
			}
			mDeferStart = r0z;
		}
	}

	public boolean shouldShowRequestPermissionRationale(@NonNull String permission) {
		if (mHost != null) {
			return mHost.onShouldShowRequestPermissionRationale(permission);
		} else {
			return false;
		}
	}

	public void startActivity(Intent intent) {
		startActivity(intent, null);
	}

	public void startActivity(Intent intent, @Nullable Bundle options) {
		if (mHost == null) {
			throw new IllegalStateException("Fragment " + this + " not attached to Activity");
		} else {
			mHost.onStartActivityFromFragment(this, intent, -1, options);
		}
	}

	public void startActivityForResult(Intent intent, int requestCode) {
		startActivityForResult(intent, requestCode, null);
	}

	public void startActivityForResult(Intent intent, int requestCode, @Nullable Bundle options) {
		if (mHost == null) {
			throw new IllegalStateException("Fragment " + this + " not attached to Activity");
		} else {
			mHost.onStartActivityFromFragment(this, intent, requestCode, options);
		}
	}

	public void startIntentSenderForResult(IntentSender intent, int requestCode, @Nullable Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags, Bundle options) throws SendIntentException {
		if (mHost == null) {
			throw new IllegalStateException("Fragment " + this + " not attached to Activity");
		} else {
			mHost.onStartIntentSenderFromFragment(this, intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags, options);
		}
	}

	public String toString() {
		StringBuilder sb = new StringBuilder(128);
		DebugUtils.buildShortClassTag(this, sb);
		if (mIndex >= 0) {
			sb.append(" #");
			sb.append(mIndex);
		}
		if (mFragmentId != 0) {
			sb.append(" id=0x");
			sb.append(Integer.toHexString(mFragmentId));
		}
		if (mTag != null) {
			sb.append(" ");
			sb.append(mTag);
		}
		sb.append('}');
		return sb.toString();
	}

	public void unregisterForContextMenu(View view) {
		view.setOnCreateContextMenuListener(null);
	}
}
