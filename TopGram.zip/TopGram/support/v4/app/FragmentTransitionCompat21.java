package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

class FragmentTransitionCompat21 {
	public static interface ViewRetriever {
		public View getView();
	}

	static class AnonymousClass_1 extends EpicenterCallback {
		final /* synthetic */ Rect val$epicenter;

		AnonymousClass_1(Rect r1_Rect) {
			super();
			val$epicenter = r1_Rect;
		}

		public Rect onGetEpicenter(Transition transition) {
			return val$epicenter;
		}
	}

	static class AnonymousClass_2 implements OnPreDrawListener {
		final /* synthetic */ View val$container;
		final /* synthetic */ Transition val$enterTransition;
		final /* synthetic */ ArrayList val$enteringViews;
		final /* synthetic */ Transition val$exitTransition;
		final /* synthetic */ FragmentTransitionCompat21.ViewRetriever val$inFragment;
		final /* synthetic */ Map val$nameOverrides;
		final /* synthetic */ View val$nonExistentView;
		final /* synthetic */ Map val$renamedViews;

		AnonymousClass_2(View r1_View, Transition r2_Transition, View r3_View, FragmentTransitionCompat21.ViewRetriever r4_FragmentTransitionCompat21_ViewRetriever, Map r5_Map, Map r6_Map, ArrayList r7_ArrayList, Transition r8_Transition) {
			super();
			val$container = r1_View;
			val$enterTransition = r2_Transition;
			val$nonExistentView = r3_View;
			val$inFragment = r4_FragmentTransitionCompat21_ViewRetriever;
			val$nameOverrides = r5_Map;
			val$renamedViews = r6_Map;
			val$enteringViews = r7_ArrayList;
			val$exitTransition = r8_Transition;
		}

		public boolean onPreDraw() {
			val$container.getViewTreeObserver().removeOnPreDrawListener(this);
			if (val$enterTransition != null) {
				val$enterTransition.removeTarget(val$nonExistentView);
			}
			if (val$inFragment != null) {
				View fragmentView = val$inFragment.getView();
				if (fragmentView != null) {
					if (!val$nameOverrides.isEmpty()) {
						FragmentTransitionCompat21.findNamedViews(val$renamedViews, fragmentView);
						val$renamedViews.keySet().retainAll(val$nameOverrides.values());
						Iterator r5_Iterator = val$nameOverrides.entrySet().iterator();
						while (r5_Iterator.hasNext()) {
							Entry<String, String> entry = (Entry) r5_Iterator.next();
							View view = (View) val$renamedViews.get((String) entry.getValue());
							if (view != null) {
								view.setTransitionName((String) entry.getKey());
							}
						}
					}
					if (val$enterTransition != null) {
						FragmentTransitionCompat21.captureTransitioningViews(val$enteringViews, fragmentView);
						val$enteringViews.removeAll(val$renamedViews.values());
						val$enteringViews.add(val$nonExistentView);
						FragmentTransitionCompat21.addTargets(val$enterTransition, val$enteringViews);
					}
				}
			}
			FragmentTransitionCompat21.excludeViews(val$exitTransition, val$enterTransition, val$enteringViews, true);
			return true;
		}
	}

	static class AnonymousClass_3 extends EpicenterCallback {
		private Rect mEpicenter;
		final /* synthetic */ FragmentTransitionCompat21.EpicenterView val$epicenterView;

		AnonymousClass_3(FragmentTransitionCompat21.EpicenterView r1_FragmentTransitionCompat21_EpicenterView) {
			super();
			val$epicenterView = r1_FragmentTransitionCompat21_EpicenterView;
		}

		public Rect onGetEpicenter(Transition transition) {
			if (mEpicenter != null || val$epicenterView.epicenter == null) {
				return mEpicenter;
			} else {
				mEpicenter = FragmentTransitionCompat21.getBoundsOnScreen(val$epicenterView.epicenter);
				return mEpicenter;
			}
		}
	}

	static class AnonymousClass_4 implements OnPreDrawListener {
		final /* synthetic */ Transition val$enterTransition;
		final /* synthetic */ ArrayList val$enteringViews;
		final /* synthetic */ Transition val$exitTransition;
		final /* synthetic */ ArrayList val$exitingViews;
		final /* synthetic */ ArrayList val$hiddenViews;
		final /* synthetic */ View val$nonExistentView;
		final /* synthetic */ Transition val$overallTransition;
		final /* synthetic */ Map val$renamedViews;
		final /* synthetic */ View val$sceneRoot;
		final /* synthetic */ ArrayList val$sharedElementTargets;
		final /* synthetic */ Transition val$sharedElementTransition;

		AnonymousClass_4(View r1_View, Transition r2_Transition, ArrayList r3_ArrayList, Transition r4_Transition, ArrayList r5_ArrayList, Transition r6_Transition, ArrayList r7_ArrayList, Map r8_Map, ArrayList r9_ArrayList, Transition r10_Transition, View r11_View) {
			super();
			val$sceneRoot = r1_View;
			val$enterTransition = r2_Transition;
			val$enteringViews = r3_ArrayList;
			val$exitTransition = r4_Transition;
			val$exitingViews = r5_ArrayList;
			val$sharedElementTransition = r6_Transition;
			val$sharedElementTargets = r7_ArrayList;
			val$renamedViews = r8_Map;
			val$hiddenViews = r9_ArrayList;
			val$overallTransition = r10_Transition;
			val$nonExistentView = r11_View;
		}

		public boolean onPreDraw() {
			val$sceneRoot.getViewTreeObserver().removeOnPreDrawListener(this);
			if (val$enterTransition != null) {
				FragmentTransitionCompat21.removeTargets(val$enterTransition, val$enteringViews);
				FragmentTransitionCompat21.excludeViews(val$enterTransition, val$exitTransition, val$exitingViews, false);
				FragmentTransitionCompat21.excludeViews(val$enterTransition, val$sharedElementTransition, val$sharedElementTargets, false);
			}
			if (val$exitTransition != null) {
				FragmentTransitionCompat21.removeTargets(val$exitTransition, val$exitingViews);
				FragmentTransitionCompat21.excludeViews(val$exitTransition, val$enterTransition, val$enteringViews, false);
				FragmentTransitionCompat21.excludeViews(val$exitTransition, val$sharedElementTransition, val$sharedElementTargets, false);
			}
			if (val$sharedElementTransition != null) {
				FragmentTransitionCompat21.removeTargets(val$sharedElementTransition, val$sharedElementTargets);
			}
			Iterator r5_Iterator = val$renamedViews.entrySet().iterator();
			while (r5_Iterator.hasNext()) {
				Entry<String, View> entry = (Entry) r5_Iterator.next();
				((View) entry.getValue()).setTransitionName((String) entry.getKey());
			}
			int i = 0;
			while (i < val$hiddenViews.size()) {
				val$overallTransition.excludeTarget((View) val$hiddenViews.get(i), false);
				i++;
			}
			val$overallTransition.excludeTarget(val$nonExistentView, false);
			return true;
		}
	}

	public static class EpicenterView {
		public View epicenter;

		public EpicenterView() {
			super();
		}
	}


	FragmentTransitionCompat21() {
		super();
	}

	public static void addTargets(Object transitionObject, ArrayList<View> views) {
		Transition transition = (Transition) transitionObject;
		int i;
		if (transition instanceof TransitionSet) {
			TransitionSet set = (TransitionSet) transition;
			i = 0;
			while (i < set.getTransitionCount()) {
				addTargets(set.getTransitionAt(i), views);
				i++;
			}
		} else if (hasSimpleTarget(transition) || !isNullOrEmpty(transition.getTargets())) {
		} else {
			i = 0;
			while (i < views.size()) {
				transition.addTarget((View) views.get(i));
				i++;
			}
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	public static void addTransitionTargets(java.lang.Object r14_enterTransitionObject, java.lang.Object r15_sharedElementTransitionObject, java.lang.Object r16_exitTransitionObject, android.view.View r17_container, android.support.v4.app.FragmentTransitionCompat21.ViewRetriever r18_inFragment, android.view.View r19_nonExistentView, android.support.v4.app.FragmentTransitionCompat21.EpicenterView r20_epicenterView, java.util.Map<java.lang.String, java.lang.String> r21_nameOverrides, java.util.ArrayList<android.view.View> r22_enteringViews, java.util.ArrayList<android.view.View> r23_exitingViews, java.util.Map<java.lang.String, android.view.View> r24_namedViews, java.util.Map<java.lang.String, android.view.View> r25_renamedViews, java.util.ArrayList<android.view.View> r26_sharedElementTargets) {
		r5 = r14_enterTransitionObject;
		r5 = (android.transition.Transition) r5;
		r11 = r16_exitTransitionObject;
		r11 = (android.transition.Transition) r11;
		r12 = r15_sharedElementTransitionObject;
		r12 = (android.transition.Transition) r12;
		r3 = 1;
		r0 = r23_exitingViews;
		excludeViews(r5_enterTransition, r11_exitTransition, r0, r3);
		if (r14_enterTransitionObject != 0) goto L_0x0014;
	L_0x0012:
		if (r15_sharedElementTransitionObject == 0) goto L_0x004f;
	L_0x0014:
		if (r5_enterTransition == 0) goto L_0x001b;
	L_0x0016:
		r0 = r19_nonExistentView;
		r5_enterTransition.addTarget(r0);
	L_0x001b:
		if (r15_sharedElementTransitionObject == 0) goto L_0x0032;
	L_0x001d:
		r0 = r19_nonExistentView;
		r1 = r24_namedViews;
		r2 = r26_sharedElementTargets;
		setSharedElementTargets(r12_sharedElementTransition, r0, r1, r2);
		r3 = 1;
		r0 = r26_sharedElementTargets;
		excludeViews(r5_enterTransition, r12_sharedElementTransition, r0, r3);
		r3 = 1;
		r0 = r26_sharedElementTargets;
		excludeViews(r11_exitTransition, r12_sharedElementTransition, r0, r3);
	L_0x0032:
		r13 = r17_container.getViewTreeObserver();
		r3 = new android.support.v4.app.FragmentTransitionCompat21$2;
		r4 = r17_container;
		r6 = r19_nonExistentView;
		r7 = r18_inFragment;
		r8 = r21_nameOverrides;
		r9 = r25_renamedViews;
		r10 = r22_enteringViews;
		r3.<init>(r4, r5_enterTransition, r6, r7, r8, r9, r10, r11_exitTransition);
		r13.addOnPreDrawListener(r3);
		r0 = r20_epicenterView;
		setSharedElementEpicenter(r5_enterTransition, r0);
	L_0x004f:
		return;
	}
	*/
	public static void addTransitionTargets(Object enterTransitionObject, Object sharedElementTransitionObject, Object exitTransitionObject, View container, ViewRetriever inFragment, View nonExistentView, EpicenterView epicenterView, Map<String, String> r21_Map_StringString, ArrayList<View> r22_ArrayList_View, ArrayList<View> r23_ArrayList_View, Map<String, View> r24_Map_StringView, Map<String, View> r25_Map_StringView, ArrayList<View> r26_ArrayList_View) {
		Transition enterTransition = (Transition) enterTransitionObject;
		Transition exitTransition = (Transition) exitTransitionObject;
		Transition sharedElementTransition = (Transition) sharedElementTransitionObject;
		excludeViews(enterTransition, exitTransition, exitingViews, true);
		if (enterTransitionObject != null || sharedElementTransitionObject != null) {
			if (sharedElementTransitionObject != null) {
				setSharedElementTargets(sharedElementTransition, nonExistentView, namedViews, sharedElementTargets);
				excludeViews(enterTransition, sharedElementTransition, sharedElementTargets, true);
				excludeViews(exitTransition, sharedElementTransition, sharedElementTargets, true);
			}
			container.getViewTreeObserver().addOnPreDrawListener(new AnonymousClass_2(container, enterTransition, nonExistentView, inFragment, nameOverrides, renamedViews, enteringViews, exitTransition));
			setSharedElementEpicenter(enterTransition, epicenterView);
		}
	}

	public static void beginDelayedTransition(ViewGroup sceneRoot, Object transitionObject) {
		TransitionManager.beginDelayedTransition(sceneRoot, (Transition) transitionObject);
	}

	private static void bfsAddViewChildren(List<View> views, View startView) {
		int startIndex = views.size();
		if (containedBeforeIndex(views, startView, startIndex)) {
		} else {
			views.add(startView);
			int index = startIndex;
			while (index < views.size()) {
				View view = (View) views.get(index);
				if (view instanceof ViewGroup) {
					ViewGroup viewGroup = (ViewGroup) view;
					int childIndex = 0;
					while (childIndex < viewGroup.getChildCount()) {
						View child = viewGroup.getChildAt(childIndex);
						if (!containedBeforeIndex(views, child, startIndex)) {
							views.add(child);
						}
						childIndex++;
					}
				}
				index++;
			}
		}
	}

	public static Object captureExitingViews(Object exitTransition, View root, ArrayList<View> viewList, Map<String, View> namedViews, View nonExistentView) {
		if (exitTransition != null) {
			captureTransitioningViews(viewList, root);
			if (namedViews != null) {
				viewList.removeAll(namedViews.values());
			}
			if (viewList.isEmpty()) {
				return null;
			} else {
				viewList.add(nonExistentView);
				addTargets((Transition) exitTransition, viewList);
				return exitTransition;
			}
		} else {
			return exitTransition;
		}
	}

	private static void captureTransitioningViews(ArrayList<View> transitioningViews, View view) {
		if (view.getVisibility() == 0) {
			if (view instanceof ViewGroup) {
				ViewGroup viewGroup = (ViewGroup) view;
				if (viewGroup.isTransitionGroup()) {
					transitioningViews.add(viewGroup);
				} else {
					int i = 0;
					while (i < viewGroup.getChildCount()) {
						captureTransitioningViews(transitioningViews, viewGroup.getChildAt(i));
						i++;
					}
				}
			} else {
				transitioningViews.add(view);
			}
		}
	}

	public static void cleanupTransitions(View sceneRoot, View nonExistentView, Object enterTransitionObject, ArrayList<View> enteringViews, Object exitTransitionObject, ArrayList<View> exitingViews, Object sharedElementTransitionObject, ArrayList<View> sharedElementTargets, Object overallTransitionObject, ArrayList<View> hiddenViews, Map<String, View> renamedViews) {
		Transition enterTransition = (Transition) enterTransitionObject;
		Transition exitTransition = (Transition) exitTransitionObject;
		Transition sharedElementTransition = (Transition) sharedElementTransitionObject;
		Transition overallTransition = (Transition) overallTransitionObject;
		if (overallTransition != null) {
			sceneRoot.getViewTreeObserver().addOnPreDrawListener(new AnonymousClass_4(sceneRoot, enterTransition, enteringViews, exitTransition, exitingViews, sharedElementTransition, sharedElementTargets, renamedViews, hiddenViews, overallTransition, nonExistentView));
		}
	}

	public static Object cloneTransition(Object transition) {
		if (transition != null) {
			transition = ((Transition) transition).clone();
		}
		return transition;
	}

	private static boolean containedBeforeIndex(List<View> views, View view, int maxIndex) {
		int i = 0;
		while (i < maxIndex) {
			if (views.get(i) == view) {
				return true;
			} else {
				i++;
			}
		}
		return false;
	}

	public static void excludeSharedElementViews(Object enterTransitionObj, Object exitTransitionObj, Object sharedElementTransitionObj, ArrayList<View> views, boolean exclude) {
		Transition sharedElementTransition = (Transition) sharedElementTransitionObj;
		excludeViews((Transition) enterTransitionObj, sharedElementTransition, views, exclude);
		excludeViews((Transition) exitTransitionObj, sharedElementTransition, views, exclude);
	}

	public static void excludeTarget(Object transitionObject, View view, boolean exclude) {
		((Transition) transitionObject).excludeTarget(view, exclude);
	}

	private static void excludeViews(Transition transition, Transition fromTransition, ArrayList<View> views, boolean exclude) {
		if (transition != null) {
			int viewCount;
			if (fromTransition == null) {
				viewCount = 0;
			} else {
				viewCount = views.size();
			}
			int i = 0;
			while (i < viewCount) {
				transition.excludeTarget((View) views.get(i), exclude);
				i++;
			}
		}
	}

	public static void findNamedViews(Map<String, View> namedViews, View view) {
		if (view.getVisibility() == 0) {
			String transitionName = view.getTransitionName();
			if (transitionName != null) {
				namedViews.put(transitionName, view);
			}
			if (view instanceof ViewGroup) {
				ViewGroup viewGroup = (ViewGroup) view;
				int i = 0;
				while (i < viewGroup.getChildCount()) {
					findNamedViews(namedViews, viewGroup.getChildAt(i));
					i++;
				}
			}
		}
	}

	private static Rect getBoundsOnScreen(View view) {
		Rect epicenter = new Rect();
		int[] loc = new int[2];
		view.getLocationOnScreen(loc);
		epicenter.set(loc[0], loc[1], loc[0] + view.getWidth(), loc[1] + view.getHeight());
		return epicenter;
	}

	public static String getTransitionName(View view) {
		return view.getTransitionName();
	}

	private static boolean hasSimpleTarget(Transition transition) {
		if (!isNullOrEmpty(transition.getTargetIds()) || !isNullOrEmpty(transition.getTargetNames()) || !isNullOrEmpty(transition.getTargetTypes())) {
			return true;
		} else {
			return false;
		}
	}

	private static boolean isNullOrEmpty(List list) {
		if (list == null || list.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	public static java.lang.Object mergeTransitions(java.lang.Object r10_enterTransitionObject, java.lang.Object r11_exitTransitionObject, java.lang.Object r12_sharedElementTransitionObject, boolean r13_allowOverlap) {
		r2 = 1;
		r0 = r10_enterTransitionObject;
		r0 = (android.transition.Transition) r0;
		r1 = r11_exitTransitionObject;
		r1 = (android.transition.Transition) r1;
		r3 = r12_sharedElementTransitionObject;
		r3 = (android.transition.Transition) r3;
		if (r0_enterTransition == 0) goto L_0x000f;
	L_0x000c:
		if (r1_exitTransition == 0) goto L_0x000f;
	L_0x000e:
		r2_overlap = r13_allowOverlap;
	L_0x000f:
		if (r2_overlap == 0) goto L_0x0027;
	L_0x0011:
		r7 = new android.transition.TransitionSet;
		r7.<init>();
		if (r0_enterTransition == 0) goto L_0x001b;
	L_0x0018:
		r7_transitionSet.addTransition(r0_enterTransition);
	L_0x001b:
		if (r1_exitTransition == 0) goto L_0x0020;
	L_0x001d:
		r7_transitionSet.addTransition(r1_exitTransition);
	L_0x0020:
		if (r3_sharedElementTransition == 0) goto L_0x0025;
	L_0x0022:
		r7_transitionSet.addTransition(r3_sharedElementTransition);
	L_0x0025:
		r6 = r7_transitionSet;
	L_0x0026:
		return r6_transition;
	L_0x0027:
		r4 = 0;
		if (r1_exitTransition == 0) goto L_0x004f;
	L_0x002a:
		if (r0_enterTransition == 0) goto L_0x004f;
	L_0x002c:
		r8 = new android.transition.TransitionSet;
		r8.<init>();
		r8 = r8.addTransition(r1_exitTransition);
		r8 = r8.addTransition(r0_enterTransition);
		r9 = 1;
		r4_staggered = r8.setOrdering(r9);
	L_0x003e:
		if (r3_sharedElementTransition == 0) goto L_0x0057;
	L_0x0040:
		r5 = new android.transition.TransitionSet;
		r5.<init>();
		if (r4_staggered == 0) goto L_0x004a;
	L_0x0047:
		r5_together.addTransition(r4_staggered);
	L_0x004a:
		r5_together.addTransition(r3_sharedElementTransition);
		r6_transition = r5_together;
		goto L_0x0026;
	L_0x004f:
		if (r1_exitTransition == 0) goto L_0x0053;
	L_0x0051:
		r4_staggered = r1_exitTransition;
		goto L_0x003e;
	L_0x0053:
		if (r0_enterTransition == 0) goto L_0x003e;
	L_0x0055:
		r4_staggered = r0_enterTransition;
		goto L_0x003e;
	L_0x0057:
		r6_transition = r4_staggered;
		goto L_0x0026;
	}
	*/
	public static Object mergeTransitions(Object enterTransitionObject, Object exitTransitionObject, Object sharedElementTransitionObject, boolean allowOverlap) {
		boolean overlap = true;
		Transition enterTransition = (Transition) enterTransitionObject;
		Transition exitTransition = (Transition) exitTransitionObject;
		Transition sharedElementTransition = (Transition) sharedElementTransitionObject;
		Transition staggered;
		TransitionSet together;
		if (enterTransition == null || exitTransition == null) {
			staggered = null;
			if (exitTransition == null || enterTransition == null) {
				if (enterTransition == null) {
					staggered = enterTransition;
				}
			} else {
				staggered = new TransitionSet().addTransition(exitTransition).addTransition(enterTransition).setOrdering(1);
			}
			if (sharedElementTransition != null) {
				together = new TransitionSet();
				if (staggered != null) {
					together.addTransition(staggered);
				}
				together.addTransition(sharedElementTransition);
				return together;
			} else {
				return staggered;
			}
		} else {
			overlap = allowOverlap;
			staggered = null;
			if (exitTransition == null || enterTransition == null) {
				if (enterTransition == null) {
					if (sharedElementTransition != null) {
						return staggered;
					} else {
						together = new TransitionSet();
						if (staggered != null) {
							together.addTransition(sharedElementTransition);
							return together;
						} else {
							together.addTransition(staggered);
							together.addTransition(sharedElementTransition);
							return together;
						}
					}
				} else {
					staggered = enterTransition;
				}
			} else {
				staggered = new TransitionSet().addTransition(exitTransition).addTransition(enterTransition).setOrdering(1);
			}
			if (sharedElementTransition != null) {
				together = new TransitionSet();
				if (staggered != null) {
					together.addTransition(staggered);
				}
				together.addTransition(sharedElementTransition);
				return together;
			} else {
				return staggered;
			}
		}
	}

	public static void removeTargets(Object transitionObject, ArrayList<View> views) {
		Transition transition = (Transition) transitionObject;
		int i;
		if (transition instanceof TransitionSet) {
			TransitionSet set = (TransitionSet) transition;
			i = 0;
			while (i < set.getTransitionCount()) {
				removeTargets(set.getTransitionAt(i), views);
				i++;
			}
		} else if (!hasSimpleTarget(transition)) {
			List<View> targets = transition.getTargets();
			if (targets == null || targets.size() != views.size() || !targets.containsAll(views)) {
			} else {
				i = views.size() - 1;
				while (i >= 0) {
					transition.removeTarget((View) views.get(i));
					i--;
				}
			}
		}
	}

	public static void setEpicenter(Object transitionObject, View view) {
		((Transition) transitionObject).setEpicenterCallback(new AnonymousClass_1(getBoundsOnScreen(view)));
	}

	private static void setSharedElementEpicenter(Transition transition, EpicenterView epicenterView) {
		if (transition != null) {
			transition.setEpicenterCallback(new AnonymousClass_3(epicenterView));
		}
	}

	public static void setSharedElementTargets(Object transitionObj, View nonExistentView, Map<String, View> namedViews, ArrayList<View> sharedElementTargets) {
		TransitionSet transition = (TransitionSet) transitionObj;
		sharedElementTargets.clear();
		sharedElementTargets.addAll(namedViews.values());
		List<View> views = transition.getTargets();
		views.clear();
		int i = 0;
		while (i < sharedElementTargets.size()) {
			bfsAddViewChildren(views, (View) sharedElementTargets.get(i));
			i++;
		}
		sharedElementTargets.add(nonExistentView);
		addTargets(transition, sharedElementTargets);
	}

	public static Object wrapSharedElementTransition(Object transitionObj) {
		if (transitionObj == null) {
			return null;
		} else {
			Transition transition = (Transition) transitionObj;
			if (transition != null) {
				TransitionSet transitionSet = new TransitionSet();
				transitionSet.addTransition(transition);
				return transitionSet;
			} else {
				return null;
			}
		}
	}
}
