package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.util.SimpleArrayMap;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class FragmentController {
	private final FragmentHostCallback<?> mHost;

	private FragmentController(FragmentHostCallback<?> callbacks) {
		super();
		mHost = callbacks;
	}

	public static final FragmentController createController(FragmentHostCallback<?> callbacks) {
		return new FragmentController(callbacks);
	}

	public void attachHost(Fragment parent) {
		mHost.mFragmentManager.attachController(mHost, mHost, parent);
	}

	public void dispatchActivityCreated() {
		mHost.mFragmentManager.dispatchActivityCreated();
	}

	public void dispatchConfigurationChanged(Configuration newConfig) {
		mHost.mFragmentManager.dispatchConfigurationChanged(newConfig);
	}

	public boolean dispatchContextItemSelected(MenuItem item) {
		return mHost.mFragmentManager.dispatchContextItemSelected(item);
	}

	public void dispatchCreate() {
		mHost.mFragmentManager.dispatchCreate();
	}

	public boolean dispatchCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		return mHost.mFragmentManager.dispatchCreateOptionsMenu(menu, inflater);
	}

	public void dispatchDestroy() {
		mHost.mFragmentManager.dispatchDestroy();
	}

	public void dispatchDestroyView() {
		mHost.mFragmentManager.dispatchDestroyView();
	}

	public void dispatchLowMemory() {
		mHost.mFragmentManager.dispatchLowMemory();
	}

	public void dispatchMultiWindowModeChanged(boolean isInMultiWindowMode) {
		mHost.mFragmentManager.dispatchMultiWindowModeChanged(isInMultiWindowMode);
	}

	public boolean dispatchOptionsItemSelected(MenuItem item) {
		return mHost.mFragmentManager.dispatchOptionsItemSelected(item);
	}

	public void dispatchOptionsMenuClosed(Menu menu) {
		mHost.mFragmentManager.dispatchOptionsMenuClosed(menu);
	}

	public void dispatchPause() {
		mHost.mFragmentManager.dispatchPause();
	}

	public void dispatchPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
		mHost.mFragmentManager.dispatchPictureInPictureModeChanged(isInPictureInPictureMode);
	}

	public boolean dispatchPrepareOptionsMenu(Menu menu) {
		return mHost.mFragmentManager.dispatchPrepareOptionsMenu(menu);
	}

	public void dispatchReallyStop() {
		mHost.mFragmentManager.dispatchReallyStop();
	}

	public void dispatchResume() {
		mHost.mFragmentManager.dispatchResume();
	}

	public void dispatchStart() {
		mHost.mFragmentManager.dispatchStart();
	}

	public void dispatchStop() {
		mHost.mFragmentManager.dispatchStop();
	}

	public void doLoaderDestroy() {
		mHost.doLoaderDestroy();
	}

	public void doLoaderRetain() {
		mHost.doLoaderRetain();
	}

	public void doLoaderStart() {
		mHost.doLoaderStart();
	}

	public void doLoaderStop(boolean retain) {
		mHost.doLoaderStop(retain);
	}

	public void dumpLoaders(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
		mHost.dumpLoaders(prefix, fd, writer, args);
	}

	public boolean execPendingActions() {
		return mHost.mFragmentManager.execPendingActions();
	}

	@Nullable
	public Fragment findFragmentByWho(String who) {
		return mHost.mFragmentManager.findFragmentByWho(who);
	}

	public List<Fragment> getActiveFragments(List<Fragment> actives) {
		if (mHost.mFragmentManager.mActive == null) {
			return null;
		} else {
			if (actives == null) {
				actives = new ArrayList(getActiveFragmentsCount());
			}
			actives.addAll(mHost.mFragmentManager.mActive);
			return actives;
		}
	}

	public int getActiveFragmentsCount() {
		List actives = mHost.mFragmentManager.mActive;
		if (actives == null) {
			return 0;
		} else {
			return actives.size();
		}
	}

	public FragmentManager getSupportFragmentManager() {
		return mHost.getFragmentManagerImpl();
	}

	public LoaderManager getSupportLoaderManager() {
		return mHost.getLoaderManagerImpl();
	}

	public void noteStateNotSaved() {
		mHost.mFragmentManager.noteStateNotSaved();
	}

	public View onCreateView(View parent, String name, Context context, AttributeSet attrs) {
		return mHost.mFragmentManager.onCreateView(parent, name, context, attrs);
	}

	public void reportLoaderStart() {
		mHost.reportLoaderStart();
	}

	public void restoreAllState(Parcelable state, FragmentManagerNonConfig nonConfig) {
		mHost.mFragmentManager.restoreAllState(state, nonConfig);
	}

	@Deprecated
	public void restoreAllState(Parcelable state, List<Fragment> nonConfigList) {
		mHost.mFragmentManager.restoreAllState(state, new FragmentManagerNonConfig(nonConfigList, null));
	}

	public void restoreLoaderNonConfig(SimpleArrayMap<String, LoaderManager> loaderManagers) {
		mHost.restoreLoaderNonConfig(loaderManagers);
	}

	public SimpleArrayMap<String, LoaderManager> retainLoaderNonConfig() {
		return mHost.retainLoaderNonConfig();
	}

	public FragmentManagerNonConfig retainNestedNonConfig() {
		return mHost.mFragmentManager.retainNonConfig();
	}

	@Deprecated
	public List<Fragment> retainNonConfig() {
		FragmentManagerNonConfig nonconf = mHost.mFragmentManager.retainNonConfig();
		if (nonconf != null) {
			return nonconf.getFragments();
		} else {
			return null;
		}
	}

	public Parcelable saveAllState() {
		return mHost.mFragmentManager.saveAllState();
	}
}
