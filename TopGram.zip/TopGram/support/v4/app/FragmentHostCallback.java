package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.SimpleArrayMap;
import android.view.LayoutInflater;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class FragmentHostCallback<E> extends FragmentContainer {
	private final Activity mActivity;
	private SimpleArrayMap<String, LoaderManager> mAllLoaderManagers;
	private boolean mCheckedForLoaderManager;
	final Context mContext;
	final FragmentManagerImpl mFragmentManager;
	private final Handler mHandler;
	private LoaderManagerImpl mLoaderManager;
	private boolean mLoadersStarted;
	private boolean mRetainLoaders;
	final int mWindowAnimations;

	FragmentHostCallback(Activity activity, Context context, Handler handler, int windowAnimations) {
		super();
		mFragmentManager = new FragmentManagerImpl();
		mActivity = activity;
		mContext = context;
		mHandler = handler;
		mWindowAnimations = windowAnimations;
	}

	public FragmentHostCallback(Context context, Handler handler, int windowAnimations) {
		this(null, context, handler, windowAnimations);
	}

	FragmentHostCallback(FragmentActivity activity) {
		this(activity, activity, activity.mHandler, 0);
	}

	void doLoaderDestroy() {
		if (mLoaderManager == null) {
		} else {
			mLoaderManager.doDestroy();
		}
	}

	void doLoaderRetain() {
		if (mLoaderManager == null) {
		} else {
			mLoaderManager.doRetain();
		}
	}

	void doLoaderStart() {
		if (mLoadersStarted) {
		} else {
			mLoadersStarted = true;
			if (mLoaderManager != null) {
				mLoaderManager.doStart();
			} else if (!mCheckedForLoaderManager) {
				mLoaderManager = getLoaderManager("(root)", mLoadersStarted, false);
				if (mLoaderManager == null || mLoaderManager.mStarted) {
					mCheckedForLoaderManager = true;
				} else {
					mLoaderManager.doStart();
				}
			}
			mCheckedForLoaderManager = true;
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	void doLoaderStop(boolean r2_retain) {
		r1_this = this;
		mRetainLoaders = r2_retain;
		r0 = mLoaderManager;
		if (r0 != 0) goto L_0x0007;
	L_0x0006:
		return;
	L_0x0007:
		r0 = mLoadersStarted;
		if (r0 == 0) goto L_0x0006;
	L_0x000b:
		r0 = 0;
		mLoadersStarted = r0;
		if (r2_retain == 0) goto L_0x0016;
	L_0x0010:
		r0 = mLoaderManager;
		r0.doRetain();
		goto L_0x0006;
	L_0x0016:
		r0 = mLoaderManager;
		r0.doStop();
		goto L_0x0006;
	}
	*/
	void doLoaderStop(boolean retain) {
		mRetainLoaders = retain;
		if (mLoaderManager != null && mLoadersStarted) {
			mLoadersStarted = false;
			if (retain) {
				mLoaderManager.doRetain();
			} else {
				mLoaderManager.doStop();
			}
		}
	}

	void dumpLoaders(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
		writer.print(prefix);
		writer.print("mLoadersStarted=");
		writer.println(mLoadersStarted);
		if (mLoaderManager != null) {
			writer.print(prefix);
			writer.print("Loader Manager ");
			writer.print(Integer.toHexString(System.identityHashCode(mLoaderManager)));
			writer.println(":");
			mLoaderManager.dump(prefix + "  ", fd, writer, args);
		}
	}

	Activity getActivity() {
		return mActivity;
	}

	Context getContext() {
		return mContext;
	}

	FragmentManagerImpl getFragmentManagerImpl() {
		return mFragmentManager;
	}

	Handler getHandler() {
		return mHandler;
	}

	LoaderManagerImpl getLoaderManager(String who, boolean started, boolean create) {
		if (mAllLoaderManagers == null) {
			mAllLoaderManagers = new SimpleArrayMap();
		}
		LoaderManagerImpl lm = (LoaderManagerImpl) mAllLoaderManagers.get(who);
		if (lm == null) {
			if (create) {
				lm = new LoaderManagerImpl(who, this, started);
				mAllLoaderManagers.put(who, lm);
				return lm;
			} else {
				return lm;
			}
		} else {
			lm.updateHostController(this);
			return lm;
		}
	}

	LoaderManagerImpl getLoaderManagerImpl() {
		if (mLoaderManager != null) {
			return mLoaderManager;
		} else {
			mCheckedForLoaderManager = true;
			mLoaderManager = getLoaderManager("(root)", mLoadersStarted, true);
			return mLoaderManager;
		}
	}

	boolean getRetainLoaders() {
		return mRetainLoaders;
	}

	void inactivateFragment(String who) {
		if (mAllLoaderManagers != null) {
			LoaderManagerImpl lm = (LoaderManagerImpl) mAllLoaderManagers.get(who);
			if (lm == null || lm.mRetaining) {
			} else {
				lm.doDestroy();
				mAllLoaderManagers.remove(who);
			}
		}
	}

	void onAttachFragment(Fragment fragment) {
	}

	public void onDump(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
	}

	@Nullable
	public View onFindViewById(int id) {
		return null;
	}

	@Nullable
	public abstract E onGetHost();

	public LayoutInflater onGetLayoutInflater() {
		return (LayoutInflater) mContext.getSystemService("layout_inflater");
	}

	public int onGetWindowAnimations() {
		return mWindowAnimations;
	}

	public boolean onHasView() {
		return true;
	}

	public boolean onHasWindowAnimations() {
		return true;
	}

	public void onRequestPermissionsFromFragment(@NonNull Fragment fragment, @NonNull String[] permissions, int requestCode) {
	}

	public boolean onShouldSaveFragmentState(Fragment fragment) {
		return true;
	}

	public boolean onShouldShowRequestPermissionRationale(@NonNull String permission) {
		return false;
	}

	public void onStartActivityFromFragment(Fragment fragment, Intent intent, int requestCode) {
		onStartActivityFromFragment(fragment, intent, requestCode, null);
	}

	public void onStartActivityFromFragment(Fragment fragment, Intent intent, int requestCode, @Nullable Bundle options) {
		if (requestCode != -1) {
			throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
		} else {
			mContext.startActivity(intent);
		}
	}

	public void onStartIntentSenderFromFragment(Fragment fragment, IntentSender intent, int requestCode, @Nullable Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags, Bundle options) throws SendIntentException {
		if (requestCode != -1) {
			throw new IllegalStateException("Starting intent sender with a requestCode requires a FragmentActivity host");
		} else {
			ActivityCompat.startIntentSenderForResult(mActivity, intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags, options);
		}
	}

	public void onSupportInvalidateOptionsMenu() {
	}

	void reportLoaderStart() {
		if (mAllLoaderManagers != null) {
			int N = mAllLoaderManagers.size();
			LoaderManagerImpl[] loaders = new LoaderManagerImpl[N];
			int i = N - 1;
			while (i >= 0) {
				loaders[i] = (LoaderManagerImpl) mAllLoaderManagers.valueAt(i);
				i--;
			}
			i = 0;
			while (i < N) {
				LoaderManagerImpl lm = loaders[i];
				lm.finishRetain();
				lm.doReportStart();
				i++;
			}
		}
	}

	void restoreLoaderNonConfig(SimpleArrayMap<String, LoaderManager> loaderManagers) {
		mAllLoaderManagers = loaderManagers;
	}

	SimpleArrayMap<String, LoaderManager> retainLoaderNonConfig() {
		boolean retainLoaders = false;
		if (mAllLoaderManagers != null) {
			int N = mAllLoaderManagers.size();
			LoaderManagerImpl[] loaders = new LoaderManagerImpl[N];
			int i = N - 1;
			while (i >= 0) {
				loaders[i] = (LoaderManagerImpl) mAllLoaderManagers.valueAt(i);
				i--;
			}
			boolean doRetainLoaders = getRetainLoaders();
			i = 0;
			while (i < N) {
				LoaderManagerImpl lm = loaders[i];
				if (lm.mRetaining || !doRetainLoaders) {
					if (!lm.mRetaining) {
						retainLoaders = true;
					} else {
						lm.doDestroy();
						mAllLoaderManagers.remove(lm.mWho);
					}
					i++;
				} else {
					if (!lm.mStarted) {
						lm.doStart();
					}
					lm.doRetain();
					if (!lm.mRetaining) {
						lm.doDestroy();
						mAllLoaderManagers.remove(lm.mWho);
					} else {
						retainLoaders = true;
					}
					i++;
				}
			}
		}
		if (retainLoaders) {
			return mAllLoaderManagers;
		} else {
			return null;
		}
	}
}
