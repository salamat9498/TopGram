package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.MessagingStyle;
import android.app.Notification.MessagingStyle.Message;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompatBase.Action;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class NotificationCompatApi24 {
	public static final String CATEGORY_ALARM = "alarm";
	public static final String CATEGORY_CALL = "call";
	public static final String CATEGORY_EMAIL = "email";
	public static final String CATEGORY_ERROR = "err";
	public static final String CATEGORY_EVENT = "event";
	public static final String CATEGORY_MESSAGE = "msg";
	public static final String CATEGORY_PROGRESS = "progress";
	public static final String CATEGORY_PROMO = "promo";
	public static final String CATEGORY_RECOMMENDATION = "recommendation";
	public static final String CATEGORY_SERVICE = "service";
	public static final String CATEGORY_SOCIAL = "social";
	public static final String CATEGORY_STATUS = "status";
	public static final String CATEGORY_SYSTEM = "sys";
	public static final String CATEGORY_TRANSPORT = "transport";

	public static class Builder implements NotificationBuilderWithBuilderAccessor, NotificationBuilderWithActions {
		private android.app.Notification.Builder b;

		public Builder(Context context, Notification n, CharSequence contentTitle, CharSequence contentText, CharSequence contentInfo, RemoteViews tickerView, int number, PendingIntent contentIntent, PendingIntent fullScreenIntent, Bitmap largeIcon, int progressMax, int progress, boolean progressIndeterminate, boolean showWhen, boolean useChronometer, int priority, CharSequence subText, boolean localOnly, String category, ArrayList<String> people, Bundle extras, int color, int visibility, Notification publicVersion, String groupKey, boolean groupSummary, String sortKey, CharSequence[] remoteInputHistory, RemoteViews contentView, RemoteViews bigContentView, RemoteViews headsUpContentView) {
			boolean r5z;
			super();
			android.app.Notification.Builder r6_android_app_Notification_Builder = new android.app.Notification.Builder(context).setWhen(n.when).setShowWhen(showWhen).setSmallIcon(n.icon, n.iconLevel).setContent(n.contentView).setTicker(n.tickerText, tickerView).setSound(n.sound, n.audioStreamType).setVibrate(n.vibrate).setLights(n.ledARGB, n.ledOnMS, n.ledOffMS);
			if ((n.flags & 2) != 0) {
				r5z = true;
			} else {
				r5z = false;
			}
			r6_android_app_Notification_Builder = r6_android_app_Notification_Builder.setOngoing(r5z);
			if ((n.flags & 8) != 0) {
				r5z = true;
			} else {
				r5z = false;
			}
			r6_android_app_Notification_Builder = r6_android_app_Notification_Builder.setOnlyAlertOnce(r5z);
			if ((n.flags & 16) != 0) {
				r5z = true;
			} else {
				r5z = false;
			}
			r6_android_app_Notification_Builder = r6_android_app_Notification_Builder.setAutoCancel(r5z).setDefaults(n.defaults).setContentTitle(contentTitle).setContentText(contentText).setSubText(subText).setContentInfo(contentInfo).setContentIntent(contentIntent).setDeleteIntent(n.deleteIntent);
			if ((n.flags & 128) != 0) {
				r5z = true;
			} else {
				r5z = false;
			}
			b = r6_android_app_Notification_Builder.setFullScreenIntent(fullScreenIntent, r5z).setLargeIcon(largeIcon).setNumber(number).setUsesChronometer(useChronometer).setPriority(priority).setProgress(progressMax, progress, progressIndeterminate).setLocalOnly(localOnly).setExtras(extras).setGroup(groupKey).setGroupSummary(groupSummary).setSortKey(sortKey).setCategory(category).setColor(color).setVisibility(visibility).setPublicVersion(publicVersion).setRemoteInputHistory(remoteInputHistory);
			if (contentView != null) {
				b.setCustomContentView(contentView);
			}
			if (bigContentView != null) {
				b.setCustomBigContentView(bigContentView);
			}
			if (headsUpContentView != null) {
				b.setCustomHeadsUpContentView(headsUpContentView);
			}
			Iterator r5_Iterator = people.iterator();
			while (r5_Iterator.hasNext()) {
				b.addPerson((String) r5_Iterator.next());
			}
		}

		public void addAction(Action action) {
			Bundle actionExtras;
			android.app.Notification.Action.Builder actionBuilder = new android.app.Notification.Action.Builder(action.getIcon(), action.getTitle(), action.getActionIntent());
			if (action.getRemoteInputs() != null) {
				RemoteInput[] r4_RemoteInput_A = RemoteInputCompatApi20.fromCompat(action.getRemoteInputs());
				int r3i = 0;
				while (r3i < r4_RemoteInput_A.length) {
					actionBuilder.addRemoteInput(r4_RemoteInput_A[r3i]);
					r3i++;
				}
			}
			if (action.getExtras() != null) {
				actionExtras = new Bundle(action.getExtras());
			} else {
				actionExtras = new Bundle();
			}
			actionExtras.putBoolean("android.support.allowGeneratedReplies", action.getAllowGeneratedReplies());
			actionBuilder.addExtras(actionExtras);
			actionBuilder.setAllowGeneratedReplies(action.getAllowGeneratedReplies());
			b.addAction(actionBuilder.build());
		}

		public Notification build() {
			return b.build();
		}

		public android.app.Notification.Builder getBuilder() {
			return b;
		}
	}


	NotificationCompatApi24() {
		super();
	}

	public static void addMessagingStyle(NotificationBuilderWithBuilderAccessor b, CharSequence userDisplayName, CharSequence conversationTitle, List<CharSequence> texts, List<Long> timestamps, List<CharSequence> senders, List<String> dataMimeTypes, List<Uri> dataUris) {
		MessagingStyle style = new MessagingStyle(userDisplayName).setConversationTitle(conversationTitle);
		int i = 0;
		while (i < texts.size()) {
			Message message = new Message((CharSequence) texts.get(i), ((Long) timestamps.get(i)).longValue(), (CharSequence) senders.get(i));
			if (dataMimeTypes.get(i) != null) {
				message.setData((String) dataMimeTypes.get(i), (Uri) dataUris.get(i));
			}
			style.addMessage(message);
			i++;
		}
		style.setBuilder(b.getBuilder());
	}
}
