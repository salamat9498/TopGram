package android.support.v4.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.media.session.MediaController;
import android.os.Parcelable;
import android.view.View;
import java.util.List;
import java.util.Map;

class ActivityCompat21 {
	public static abstract class SharedElementCallback21 {
		public SharedElementCallback21() {
			super();
		}

		public abstract Parcelable onCaptureSharedElementSnapshot(View r1_View, Matrix r2_Matrix, RectF r3_RectF);

		public abstract View onCreateSnapshotView(Context r1_Context, Parcelable r2_Parcelable);

		public abstract void onMapSharedElements(List<String> r1_List_String, Map<String, View> r2_Map_StringView);

		public abstract void onRejectSharedElements(List<View> r1_List_View);

		public abstract void onSharedElementEnd(List<String> r1_List_String, List<View> r2_List_View, List<View> r3_List_View);

		public abstract void onSharedElementStart(List<String> r1_List_String, List<View> r2_List_View, List<View> r3_List_View);
	}

	private static class SharedElementCallbackImpl extends SharedElementCallback {
		private ActivityCompat21.SharedElementCallback21 mCallback;

		public SharedElementCallbackImpl(ActivityCompat21.SharedElementCallback21 callback) {
			super();
			mCallback = callback;
		}

		public Parcelable onCaptureSharedElementSnapshot(View sharedElement, Matrix viewToGlobalMatrix, RectF screenBounds) {
			return mCallback.onCaptureSharedElementSnapshot(sharedElement, viewToGlobalMatrix, screenBounds);
		}

		public View onCreateSnapshotView(Context context, Parcelable snapshot) {
			return mCallback.onCreateSnapshotView(context, snapshot);
		}

		public void onMapSharedElements(List<String> names, Map<String, View> sharedElements) {
			mCallback.onMapSharedElements(names, sharedElements);
		}

		public void onRejectSharedElements(List<View> rejectedSharedElements) {
			mCallback.onRejectSharedElements(rejectedSharedElements);
		}

		public void onSharedElementEnd(List<String> sharedElementNames, List<View> sharedElements, List<View> sharedElementSnapshots) {
			mCallback.onSharedElementEnd(sharedElementNames, sharedElements, sharedElementSnapshots);
		}

		public void onSharedElementStart(List<String> sharedElementNames, List<View> sharedElements, List<View> sharedElementSnapshots) {
			mCallback.onSharedElementStart(sharedElementNames, sharedElements, sharedElementSnapshots);
		}
	}


	ActivityCompat21() {
		super();
	}

	private static SharedElementCallback createCallback(SharedElementCallback21 callback) {
		SharedElementCallbackImpl newListener = null;
		if (callback != null) {
			newListener = new SharedElementCallbackImpl(callback);
		}
		return newListener;
	}

	public static void finishAfterTransition(Activity activity) {
		activity.finishAfterTransition();
	}

	public static void postponeEnterTransition(Activity activity) {
		activity.postponeEnterTransition();
	}

	public static void setEnterSharedElementCallback(Activity activity, SharedElementCallback21 callback) {
		activity.setEnterSharedElementCallback(createCallback(callback));
	}

	public static void setExitSharedElementCallback(Activity activity, SharedElementCallback21 callback) {
		activity.setExitSharedElementCallback(createCallback(callback));
	}

	public static void setMediaController(Activity activity, Object mediaControllerObj) {
		activity.setMediaController((MediaController) mediaControllerObj);
	}

	public static void startPostponedEnterTransition(Activity activity) {
		activity.startPostponedEnterTransition();
	}
}
