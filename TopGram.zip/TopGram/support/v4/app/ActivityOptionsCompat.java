package android.support.v4.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.util.Pair;
import android.view.View;

public class ActivityOptionsCompat {
	public static final String EXTRA_USAGE_TIME_REPORT = "android.activity.usage_time";
	public static final String EXTRA_USAGE_TIME_REPORT_PACKAGES = "android.usage_time_packages";

	private static class ActivityOptionsImpl21 extends ActivityOptionsCompat {
		private final ActivityOptionsCompat21 mImpl;

		ActivityOptionsImpl21(ActivityOptionsCompat21 impl) {
			super();
			mImpl = impl;
		}

		public Bundle toBundle() {
			return mImpl.toBundle();
		}

		public void update(ActivityOptionsCompat otherOptions) {
			if (otherOptions instanceof ActivityOptionsCompat.ActivityOptionsImpl21) {
				mImpl.update(((ActivityOptionsCompat.ActivityOptionsImpl21) otherOptions).mImpl);
			}
		}
	}

	private static class ActivityOptionsImpl23 extends ActivityOptionsCompat {
		private final ActivityOptionsCompat23 mImpl;

		ActivityOptionsImpl23(ActivityOptionsCompat23 impl) {
			super();
			mImpl = impl;
		}

		public void requestUsageTimeReport(PendingIntent receiver) {
			mImpl.requestUsageTimeReport(receiver);
		}

		public Bundle toBundle() {
			return mImpl.toBundle();
		}

		public void update(ActivityOptionsCompat otherOptions) {
			if (otherOptions instanceof ActivityOptionsCompat.ActivityOptionsImpl23) {
				mImpl.update(((ActivityOptionsCompat.ActivityOptionsImpl23) otherOptions).mImpl);
			}
		}
	}

	private static class ActivityOptionsImpl24 extends ActivityOptionsCompat {
		private final ActivityOptionsCompat24 mImpl;

		ActivityOptionsImpl24(ActivityOptionsCompat24 impl) {
			super();
			mImpl = impl;
		}

		public Rect getLaunchBounds() {
			return mImpl.getLaunchBounds();
		}

		public void requestUsageTimeReport(PendingIntent receiver) {
			mImpl.requestUsageTimeReport(receiver);
		}

		public ActivityOptionsCompat setLaunchBounds(@Nullable Rect screenSpacePixelRect) {
			return new ActivityOptionsCompat.ActivityOptionsImpl24(mImpl.setLaunchBounds(screenSpacePixelRect));
		}

		public Bundle toBundle() {
			return mImpl.toBundle();
		}

		public void update(ActivityOptionsCompat otherOptions) {
			if (otherOptions instanceof ActivityOptionsCompat.ActivityOptionsImpl24) {
				mImpl.update(((ActivityOptionsCompat.ActivityOptionsImpl24) otherOptions).mImpl);
			}
		}
	}

	private static class ActivityOptionsImplJB extends ActivityOptionsCompat {
		private final ActivityOptionsCompatJB mImpl;

		ActivityOptionsImplJB(ActivityOptionsCompatJB impl) {
			super();
			mImpl = impl;
		}

		public Bundle toBundle() {
			return mImpl.toBundle();
		}

		public void update(ActivityOptionsCompat otherOptions) {
			if (otherOptions instanceof ActivityOptionsCompat.ActivityOptionsImplJB) {
				mImpl.update(((ActivityOptionsCompat.ActivityOptionsImplJB) otherOptions).mImpl);
			}
		}
	}


	protected ActivityOptionsCompat() {
		super();
	}

	public static ActivityOptionsCompat makeBasic() {
		if (VERSION.SDK_INT >= 24) {
			return new ActivityOptionsImpl24(ActivityOptionsCompat24.makeBasic());
		} else if (VERSION.SDK_INT >= 23) {
			return new ActivityOptionsImpl23(ActivityOptionsCompat23.makeBasic());
		} else {
			return new ActivityOptionsCompat();
		}
	}

	public static ActivityOptionsCompat makeClipRevealAnimation(View source, int startX, int startY, int width, int height) {
		if (VERSION.SDK_INT >= 24) {
			return new ActivityOptionsImpl24(ActivityOptionsCompat24.makeClipRevealAnimation(source, startX, startY, width, height));
		} else if (VERSION.SDK_INT >= 23) {
			return new ActivityOptionsImpl23(ActivityOptionsCompat23.makeClipRevealAnimation(source, startX, startY, width, height));
		} else {
			return new ActivityOptionsCompat();
		}
	}

	public static ActivityOptionsCompat makeCustomAnimation(Context context, int enterResId, int exitResId) {
		if (VERSION.SDK_INT >= 24) {
			return new ActivityOptionsImpl24(ActivityOptionsCompat24.makeCustomAnimation(context, enterResId, exitResId));
		} else if (VERSION.SDK_INT >= 23) {
			return new ActivityOptionsImpl23(ActivityOptionsCompat23.makeCustomAnimation(context, enterResId, exitResId));
		} else if (VERSION.SDK_INT >= 21) {
			return new ActivityOptionsImpl21(ActivityOptionsCompat21.makeCustomAnimation(context, enterResId, exitResId));
		} else if (VERSION.SDK_INT >= 16) {
			return new ActivityOptionsImplJB(ActivityOptionsCompatJB.makeCustomAnimation(context, enterResId, exitResId));
		} else {
			return new ActivityOptionsCompat();
		}
	}

	public static ActivityOptionsCompat makeScaleUpAnimation(View source, int startX, int startY, int startWidth, int startHeight) {
		if (VERSION.SDK_INT >= 24) {
			return new ActivityOptionsImpl24(ActivityOptionsCompat24.makeScaleUpAnimation(source, startX, startY, startWidth, startHeight));
		} else if (VERSION.SDK_INT >= 23) {
			return new ActivityOptionsImpl23(ActivityOptionsCompat23.makeScaleUpAnimation(source, startX, startY, startWidth, startHeight));
		} else if (VERSION.SDK_INT >= 21) {
			return new ActivityOptionsImpl21(ActivityOptionsCompat21.makeScaleUpAnimation(source, startX, startY, startWidth, startHeight));
		} else if (VERSION.SDK_INT >= 16) {
			return new ActivityOptionsImplJB(ActivityOptionsCompatJB.makeScaleUpAnimation(source, startX, startY, startWidth, startHeight));
		} else {
			return new ActivityOptionsCompat();
		}
	}

	public static ActivityOptionsCompat makeSceneTransitionAnimation(Activity activity, View sharedElement, String sharedElementName) {
		if (VERSION.SDK_INT >= 24) {
			return new ActivityOptionsImpl24(ActivityOptionsCompat24.makeSceneTransitionAnimation(activity, sharedElement, sharedElementName));
		} else if (VERSION.SDK_INT >= 23) {
			return new ActivityOptionsImpl23(ActivityOptionsCompat23.makeSceneTransitionAnimation(activity, sharedElement, sharedElementName));
		} else if (VERSION.SDK_INT >= 21) {
			return new ActivityOptionsImpl21(ActivityOptionsCompat21.makeSceneTransitionAnimation(activity, sharedElement, sharedElementName));
		} else {
			return new ActivityOptionsCompat();
		}
	}

	public static ActivityOptionsCompat makeSceneTransitionAnimation(Activity activity, Pair<View, String> ... sharedElements) {
		if (VERSION.SDK_INT >= 21) {
			View[] views = null;
			String[] names = null;
			if (sharedElements != null) {
				views = new View[sharedElements.length];
				names = new String[sharedElements.length];
				int i = 0;
				while (i < sharedElements.length) {
					views[i] = (View) sharedElements[i].first;
					names[i] = (String) sharedElements[i].second;
					i++;
				}
			}
			if (VERSION.SDK_INT >= 24) {
				return new ActivityOptionsImpl24(ActivityOptionsCompat24.makeSceneTransitionAnimation(activity, views, names));
			} else if (VERSION.SDK_INT >= 23) {
				return new ActivityOptionsImpl23(ActivityOptionsCompat23.makeSceneTransitionAnimation(activity, views, names));
			} else {
				return new ActivityOptionsImpl21(ActivityOptionsCompat21.makeSceneTransitionAnimation(activity, views, names));
			}
		} else {
			return new ActivityOptionsCompat();
		}
	}

	public static ActivityOptionsCompat makeTaskLaunchBehind() {
		if (VERSION.SDK_INT >= 24) {
			return new ActivityOptionsImpl24(ActivityOptionsCompat24.makeTaskLaunchBehind());
		} else if (VERSION.SDK_INT >= 23) {
			return new ActivityOptionsImpl23(ActivityOptionsCompat23.makeTaskLaunchBehind());
		} else if (VERSION.SDK_INT >= 21) {
			return new ActivityOptionsImpl21(ActivityOptionsCompat21.makeTaskLaunchBehind());
		} else {
			return new ActivityOptionsCompat();
		}
	}

	public static ActivityOptionsCompat makeThumbnailScaleUpAnimation(View source, Bitmap thumbnail, int startX, int startY) {
		if (VERSION.SDK_INT >= 24) {
			return new ActivityOptionsImpl24(ActivityOptionsCompat24.makeThumbnailScaleUpAnimation(source, thumbnail, startX, startY));
		} else if (VERSION.SDK_INT >= 23) {
			return new ActivityOptionsImpl23(ActivityOptionsCompat23.makeThumbnailScaleUpAnimation(source, thumbnail, startX, startY));
		} else if (VERSION.SDK_INT >= 21) {
			return new ActivityOptionsImpl21(ActivityOptionsCompat21.makeThumbnailScaleUpAnimation(source, thumbnail, startX, startY));
		} else if (VERSION.SDK_INT >= 16) {
			return new ActivityOptionsImplJB(ActivityOptionsCompatJB.makeThumbnailScaleUpAnimation(source, thumbnail, startX, startY));
		} else {
			return new ActivityOptionsCompat();
		}
	}

	@Nullable
	public Rect getLaunchBounds() {
		return null;
	}

	public void requestUsageTimeReport(PendingIntent receiver) {
	}

	public ActivityOptionsCompat setLaunchBounds(@Nullable Rect screenSpacePixelRect) {
		return null;
	}

	public Bundle toBundle() {
		return null;
	}

	public void update(ActivityOptionsCompat otherOptions) {
	}
}
