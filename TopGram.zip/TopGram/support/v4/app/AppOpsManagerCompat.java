package android.support.v4.app;

import android.content.Context;
import android.os.Build.VERSION;
import android.support.annotation.NonNull;

public final class AppOpsManagerCompat {
	private static final AppOpsManagerImpl IMPL;
	public static final int MODE_ALLOWED = 0;
	public static final int MODE_DEFAULT = 3;
	public static final int MODE_IGNORED = 1;

	private static class AppOpsManagerImpl {
		AppOpsManagerImpl() {
			super();
		}

		public int noteOp(Context context, String op, int uid, String packageName) {
			return MODE_IGNORED;
		}

		public int noteProxyOp(Context context, String op, String proxiedPackageName) {
			return MODE_IGNORED;
		}

		public String permissionToOp(String permission) {
			return null;
		}
	}

	private static class AppOpsManager23 extends AppOpsManagerCompat.AppOpsManagerImpl {
		AppOpsManager23() {
			super();
		}

		public int noteOp(Context context, String op, int uid, String packageName) {
			return AppOpsManagerCompat23.noteOp(context, op, uid, packageName);
		}

		public int noteProxyOp(Context context, String op, String proxiedPackageName) {
			return AppOpsManagerCompat23.noteProxyOp(context, op, proxiedPackageName);
		}

		public String permissionToOp(String permission) {
			return AppOpsManagerCompat23.permissionToOp(permission);
		}
	}


	static {
		if (VERSION.SDK_INT >= 23) {
			IMPL = new AppOpsManager23();
		} else {
			IMPL = new AppOpsManagerImpl();
		}
	}

	private AppOpsManagerCompat() {
		super();
	}

	public static int noteOp(@NonNull Context context, @NonNull String op, int uid, @NonNull String packageName) {
		return IMPL.noteOp(context, op, uid, packageName);
	}

	public static int noteProxyOp(@NonNull Context context, @NonNull String op, @NonNull String proxiedPackageName) {
		return IMPL.noteProxyOp(context, op, proxiedPackageName);
	}

	public static String permissionToOp(@NonNull String permission) {
		return IMPL.permissionToOp(permission);
	}
}
