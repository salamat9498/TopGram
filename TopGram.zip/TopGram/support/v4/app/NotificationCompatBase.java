package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.RemoteInputCompatBase.RemoteInput;

public class NotificationCompatBase {
	public static abstract class Action {
		public static interface Factory {
			public NotificationCompatBase.Action build(int r1i, CharSequence r2_CharSequence, PendingIntent r3_PendingIntent, Bundle r4_Bundle, RemoteInput[] r5_RemoteInput_A, boolean r6z);

			public NotificationCompatBase.Action[] newArray(int r1i);
		}


		public Action() {
			super();
		}

		public abstract PendingIntent getActionIntent();

		public abstract boolean getAllowGeneratedReplies();

		public abstract Bundle getExtras();

		public abstract int getIcon();

		public abstract RemoteInput[] getRemoteInputs();

		public abstract CharSequence getTitle();
	}

	public static abstract class UnreadConversation {
		public static interface Factory {
			public NotificationCompatBase.UnreadConversation build(String[] r1_String_A, RemoteInput r2_RemoteInput, PendingIntent r3_PendingIntent, PendingIntent r4_PendingIntent, String[] r5_String_A, long r6j);
		}


		public UnreadConversation() {
			super();
		}

		abstract long getLatestTimestamp();

		abstract String[] getMessages();

		abstract String getParticipant();

		abstract String[] getParticipants();

		abstract PendingIntent getReadPendingIntent();

		abstract RemoteInput getRemoteInput();

		abstract PendingIntent getReplyPendingIntent();
	}


	public NotificationCompatBase() {
		super();
	}

	public static Notification add(Notification notification, Context context, CharSequence contentTitle, CharSequence contentText, PendingIntent contentIntent, PendingIntent fullScreenIntent) {
		notification.setLatestEventInfo(context, contentTitle, contentText, contentIntent);
		notification.fullScreenIntent = fullScreenIntent;
		return notification;
	}
}
