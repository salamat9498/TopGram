package android.support.v4.app;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;

class ActivityOptionsCompat21 {
	private final ActivityOptions mActivityOptions;

	private ActivityOptionsCompat21(ActivityOptions activityOptions) {
		super();
		mActivityOptions = activityOptions;
	}

	public static ActivityOptionsCompat21 makeCustomAnimation(Context context, int enterResId, int exitResId) {
		return new ActivityOptionsCompat21(ActivityOptions.makeCustomAnimation(context, enterResId, exitResId));
	}

	public static ActivityOptionsCompat21 makeScaleUpAnimation(View source, int startX, int startY, int startWidth, int startHeight) {
		return new ActivityOptionsCompat21(ActivityOptions.makeScaleUpAnimation(source, startX, startY, startWidth, startHeight));
	}

	public static ActivityOptionsCompat21 makeSceneTransitionAnimation(Activity activity, View sharedElement, String sharedElementName) {
		return new ActivityOptionsCompat21(ActivityOptions.makeSceneTransitionAnimation(activity, sharedElement, sharedElementName));
	}

	public static ActivityOptionsCompat21 makeSceneTransitionAnimation(Activity activity, View[] sharedElements, String[] sharedElementNames) {
		Pair[] pairs = null;
		if (sharedElements != null) {
			pairs = new Pair[sharedElements.length];
			int i = 0;
			while (i < pairs.length) {
				pairs[i] = Pair.create(sharedElements[i], sharedElementNames[i]);
				i++;
			}
		}
		return new ActivityOptionsCompat21(ActivityOptions.makeSceneTransitionAnimation(activity, pairs));
	}

	public static ActivityOptionsCompat21 makeTaskLaunchBehind() {
		return new ActivityOptionsCompat21(ActivityOptions.makeTaskLaunchBehind());
	}

	public static ActivityOptionsCompat21 makeThumbnailScaleUpAnimation(View source, Bitmap thumbnail, int startX, int startY) {
		return new ActivityOptionsCompat21(ActivityOptions.makeThumbnailScaleUpAnimation(source, thumbnail, startX, startY));
	}

	public Bundle toBundle() {
		return mActivityOptions.toBundle();
	}

	public void update(ActivityOptionsCompat21 otherOptions) {
		mActivityOptions.update(otherOptions.mActivityOptions);
	}
}
