package android.support.v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.support.annotation.ColorInt;

public interface TintAwareDrawable {
	public void setTint(@ColorInt int r1i);

	public void setTintList(ColorStateList r1_ColorStateList);

	public void setTintMode(Mode r1_Mode);
}
