package android.support.v4.content;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Process;
import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.v4.os.BuildCompat;
import android.util.Log;
import android.util.TypedValue;
import java.io.File;

public class ContextCompat {
	private static final String DIR_ANDROID = "Android";
	private static final String DIR_OBB = "obb";
	private static final String TAG = "ContextCompat";
	private static final Object sLock;
	private static TypedValue sTempValue;

	static {
		sLock = new Object();
	}

	@Deprecated
	public ContextCompat() {
		super();
	}

	private static File buildPath(File base, String ... segments) {
		int r3i = 0;
		File cur = base;
		while (r3i < segments.length) {
			File cur_2;
			String segment = segments[r3i];
			if (cur == null) {
				cur_2 = new File(segment);
			} else if (segment != null) {
				cur_2 = new File(cur, segment);
			} else {
				cur_2 = cur;
			}
			r3i++;
			cur = cur_2;
		}
		return cur;
	}

	public static int checkSelfPermission(@NonNull Context context, @NonNull String permission) {
		if (permission == null) {
			throw new IllegalArgumentException("permission is null");
		} else {
			return context.checkPermission(permission, Process.myPid(), Process.myUid());
		}
	}

	@Deprecated
	public static Context createDeviceEncryptedStorageContext(Context context) {
		return createDeviceProtectedStorageContext(context);
	}

	public static Context createDeviceProtectedStorageContext(Context context) {
		if (BuildCompat.isAtLeastN()) {
			return ContextCompatApi24.createDeviceProtectedStorageContext(context);
		} else {
			return null;
		}
	}

	private static synchronized File createFilesDir(File file) {
		synchronized(ContextCompat.class) {
			if (file.exists() || file.mkdirs() || file.exists()) {
				return file;
			} else {
				Log.w(TAG, "Unable to create files subdir " + null.getPath());
				file = null;
				return file;
			}
		}
	}

	public static File getCodeCacheDir(Context context) {
		if (VERSION.SDK_INT >= 21) {
			return ContextCompatApi21.getCodeCacheDir(context);
		} else {
			return createFilesDir(new File(context.getApplicationInfo().dataDir, "code_cache"));
		}
	}

	@ColorInt
	public static final int getColor(Context context, @ColorRes int id) {
		if (VERSION.SDK_INT >= 23) {
			return ContextCompatApi23.getColor(context, id);
		} else {
			return context.getResources().getColor(id);
		}
	}

	public static final ColorStateList getColorStateList(Context context, @ColorRes int id) {
		if (VERSION.SDK_INT >= 23) {
			return ContextCompatApi23.getColorStateList(context, id);
		} else {
			return context.getResources().getColorStateList(id);
		}
	}

	public static File getDataDir(Context context) {
		if (BuildCompat.isAtLeastN()) {
			return ContextCompatApi24.getDataDir(context);
		} else {
			String dataDir = context.getApplicationInfo().dataDir;
			if (dataDir != null) {
				return new File(dataDir);
			} else {
				return null;
			}
		}
	}

	public static final Drawable getDrawable(Context context, @DrawableRes int id) {
		int version = VERSION.SDK_INT;
		if (version >= 21) {
			return ContextCompatApi21.getDrawable(context, id);
		} else if (version >= 16) {
			return context.getResources().getDrawable(id);
		} else {
			int resolvedId;
			synchronized(sLock) {
				if (sTempValue == null) {
					sTempValue = new TypedValue();
				}
				context.getResources().getValue(id, sTempValue, true);
				resolvedId = sTempValue.resourceId;
			}
			return context.getResources().getDrawable(resolvedId);
		}
	}

	public static File[] getExternalCacheDirs(Context context) {
		if (VERSION.SDK_INT >= 19) {
			return ContextCompatKitKat.getExternalCacheDirs(context);
		} else {
			File[] r1_File_A = new File[1];
			r1_File_A[0] = context.getExternalCacheDir();
			return r1_File_A;
		}
	}

	public static File[] getExternalFilesDirs(Context context, String type) {
		if (VERSION.SDK_INT >= 19) {
			return ContextCompatKitKat.getExternalFilesDirs(context, type);
		} else {
			File[] r1_File_A = new File[1];
			r1_File_A[0] = context.getExternalFilesDir(type);
			return r1_File_A;
		}
	}

	public static final File getNoBackupFilesDir(Context context) {
		if (VERSION.SDK_INT >= 21) {
			return ContextCompatApi21.getNoBackupFilesDir(context);
		} else {
			return createFilesDir(new File(context.getApplicationInfo().dataDir, "no_backup"));
		}
	}

	public static File[] getObbDirs(Context context) {
		int version = VERSION.SDK_INT;
		if (version >= 19) {
			return ContextCompatKitKat.getObbDirs(context);
		} else {
			File single;
			if (version >= 11) {
				single = ContextCompatHoneycomb.getObbDir(context);
			} else {
				String[] r3_String_A = new String[3];
				r3_String_A[0] = DIR_ANDROID;
				r3_String_A[1] = DIR_OBB;
				r3_String_A[2] = context.getPackageName();
				single = buildPath(Environment.getExternalStorageDirectory(), r3_String_A);
			}
			File[] r2_File_A = new File[1];
			r2_File_A[0] = single;
			return r2_File_A;
		}
	}

	@Deprecated
	public static boolean isDeviceEncryptedStorage(Context context) {
		return isDeviceProtectedStorage(context);
	}

	public static boolean isDeviceProtectedStorage(Context context) {
		if (BuildCompat.isAtLeastN()) {
			return ContextCompatApi24.isDeviceProtectedStorage(context);
		} else {
			return false;
		}
	}

	public static boolean startActivities(Context context, Intent[] intents) {
		return startActivities(context, intents, null);
	}

	public static boolean startActivities(Context context, Intent[] intents, Bundle options) {
		int version = VERSION.SDK_INT;
		if (version >= 16) {
			ContextCompatJellybean.startActivities(context, intents, options);
			return true;
		} else if (version >= 11) {
			ContextCompatHoneycomb.startActivities(context, intents);
			return true;
		} else {
			return false;
		}
	}
}
