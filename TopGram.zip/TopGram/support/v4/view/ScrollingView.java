package android.support.v4.view;

public interface ScrollingView {
	public int computeHorizontalScrollExtent();

	public int computeHorizontalScrollOffset();

	public int computeHorizontalScrollRange();

	public int computeVerticalScrollExtent();

	public int computeVerticalScrollOffset();

	public int computeVerticalScrollRange();
}
