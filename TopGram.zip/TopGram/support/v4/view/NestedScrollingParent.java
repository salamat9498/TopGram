package android.support.v4.view;

import android.view.View;

public interface NestedScrollingParent {
	public int getNestedScrollAxes();

	public boolean onNestedFling(View r1_View, float r2f, float r3f, boolean r4z);

	public boolean onNestedPreFling(View r1_View, float r2f, float r3f);

	public void onNestedPreScroll(View r1_View, int r2i, int r3i, int[] r4_int_A);

	public void onNestedScroll(View r1_View, int r2i, int r3i, int r4i, int r5i);

	public void onNestedScrollAccepted(View r1_View, View r2_View, int r3i);

	public boolean onStartNestedScroll(View r1_View, View r2_View, int r3i);

	public void onStopNestedScroll(View r1_View);
}
