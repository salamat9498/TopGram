package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public interface LayoutInflaterFactory {
	public View onCreateView(View r1_View, String r2_String, Context r3_Context, AttributeSet r4_AttributeSet);
}
