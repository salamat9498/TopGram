package android.support.v4.view;

public interface NestedScrollingChild {
	public boolean dispatchNestedFling(float r1f, float r2f, boolean r3z);

	public boolean dispatchNestedPreFling(float r1f, float r2f);

	public boolean dispatchNestedPreScroll(int r1i, int r2i, int[] r3_int_A, int[] r4_int_A);

	public boolean dispatchNestedScroll(int r1i, int r2i, int r3i, int r4i, int[] r5_int_A);

	public boolean hasNestedScrollingParent();

	public boolean isNestedScrollingEnabled();

	public void setNestedScrollingEnabled(boolean r1z);

	public boolean startNestedScroll(int r1i);

	public void stopNestedScroll();
}
