package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.support.annotation.Nullable;

public interface TintableBackgroundView {
	@Nullable
	public ColorStateList getSupportBackgroundTintList();

	@Nullable
	public Mode getSupportBackgroundTintMode();

	public void setSupportBackgroundTintList(@Nullable ColorStateList r1_ColorStateList);

	public void setSupportBackgroundTintMode(@Nullable Mode r1_Mode);
}
