package android.support.v4.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.PackageManager;

class AccessibilityServiceInfoCompatJellyBean {
	AccessibilityServiceInfoCompatJellyBean() {
		super();
	}

	public static String loadDescription(AccessibilityServiceInfo info, PackageManager pm) {
		return info.loadDescription(pm);
	}
}
