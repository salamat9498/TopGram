package android.support.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import net.hockeyapp.android.tasks.LoginTask;
import org.telegram.tgnet.TLRPC;

final class MultiDexExtractor {
	private static final int BUFFER_SIZE = 16384;
	private static final String DEX_PREFIX = "classes";
	private static final String DEX_SUFFIX = ".dex";
	private static final String EXTRACTED_NAME_EXT = ".classes";
	private static final String EXTRACTED_SUFFIX = ".zip";
	private static final String KEY_CRC = "crc";
	private static final String KEY_DEX_NUMBER = "dex.number";
	private static final String KEY_TIME_STAMP = "timestamp";
	private static final int MAX_EXTRACT_ATTEMPTS = 3;
	private static final long NO_VALUE = -1;
	private static final String PREFS_FILE = "multidex.version";
	private static final String TAG = "MultiDex";
	private static Method sApplyMethod;

	static class AnonymousClass_1 implements FileFilter {
		final /* synthetic */ String val$extractedFilePrefix;

		AnonymousClass_1(String r1_String) {
			super();
			val$extractedFilePrefix = r1_String;
		}

		public boolean accept(File pathname) {
			if (!pathname.getName().startsWith(val$extractedFilePrefix)) {
				return true;
			} else {
				return false;
			}
		}
	}


	static {
		try {
			sApplyMethod = Editor.class.getMethod("apply", new Class[0]);
		} catch (NoSuchMethodException e) {
			sApplyMethod = null;
		}
	}

	MultiDexExtractor() {
		super();
	}

	private static void apply(Editor editor) {
		if (sApplyMethod != null) {
			try {
				sApplyMethod.invoke(editor, new Object[0]);
			} catch (InvocationTargetException e) {
			} catch (IllegalAccessException e_2) {
			}
		}
		editor.commit();
	}

	private static void closeQuietly(Closeable closeable) {
		try {
			closeable.close();
		} catch (IOException e) {
			Log.w(TAG, "Failed to close resource", e);
			return;
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	private static void extract(java.util.zip.ZipFile r10_apk, java.util.zip.ZipEntry r11_dexFile, java.io.File r12_extractTo, java.lang.String r13_extractedFilePrefix) throws java.io.IOException, java.io.FileNotFoundException {
		r2 = r10_apk.getInputStream(r11_dexFile);
		r4_out = 0;
		r7 = ".zip";
		r8 = r12_extractTo.getParentFile();
		r6 = java.io.File.createTempFile(r13_extractedFilePrefix, r7, r8);
		r7 = "MultiDex";
		r8 = new java.lang.StringBuilder;
		r8.<init>();
		r9 = "Extracting ";
		r8 = r8.append(r9);
		r9 = r6_tmp.getPath();
		r8 = r8.append(r9);
		r8 = r8.toString();
		android.util.Log.i(r7, r8);
		r5 = new java.util.zip.ZipOutputStream;	 //Catch:{ all -> 0x00cd }
		r7 = new java.io.BufferedOutputStream;	 //Catch:{ all -> 0x00cd }
		r8 = new java.io.FileOutputStream;	 //Catch:{ all -> 0x00cd }
		r8.<init>(r6_tmp);	 //Catch:{ all -> 0x00cd }
		r7.<init>(r8);	 //Catch:{ all -> 0x00cd }
		r5.<init>(r7);	 //Catch:{ all -> 0x00cd }
		r1 = new java.util.zip.ZipEntry;	 //Catch:{ all -> 0x00c1 }
		r7 = "classes.dex";
		r1.<init>(r7);	 //Catch:{ all -> 0x00c1 }
		r8 = r11_dexFile.getTime();	 //Catch:{ all -> 0x00c1 }
		r1_classesDex.setTime(r8);	 //Catch:{ all -> 0x00c1 }
		r5_out.putNextEntry(r1_classesDex);	 //Catch:{ all -> 0x00c1 }
		r7 = 16384; // 0x4000 float:2.2959E-41 double:8.095E-320;
		r0 = new byte[r7];	 //Catch:{ all -> 0x00c1 }
		r3 = r2_in.read(r0_buffer);	 //Catch:{ all -> 0x00c1 }
	L_0x0053:
		r7 = -1;
		if (r3_length == r7) goto L_0x005f;
	L_0x0056:
		r7 = 0;
		r5_out.write(r0_buffer, r7, r3_length);	 //Catch:{ all -> 0x00c1 }
		r3_length = r2_in.read(r0_buffer);	 //Catch:{ all -> 0x00c1 }
		goto L_0x0053;
	L_0x005f:
		r5_out.closeEntry();	 //Catch:{ all -> 0x00c1 }
		r5_out.close();	 //Catch:{ all -> 0x00b8 }
		r7 = "MultiDex";
		r8 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00b8 }
		r8.<init>();	 //Catch:{ all -> 0x00b8 }
		r9 = "Renaming to ";
		r8 = r8.append(r9);	 //Catch:{ all -> 0x00b8 }
		r9 = r12_extractTo.getPath();	 //Catch:{ all -> 0x00b8 }
		r8 = r8.append(r9);	 //Catch:{ all -> 0x00b8 }
		r8 = r8.toString();	 //Catch:{ all -> 0x00b8 }
		android.util.Log.i(r7, r8);	 //Catch:{ all -> 0x00b8 }
		r7 = r6_tmp.renameTo(r12_extractTo);	 //Catch:{ all -> 0x00b8 }
		if (r7 != 0) goto L_0x00c6;
	L_0x0087:
		r7 = new java.io.IOException;	 //Catch:{ all -> 0x00b8 }
		r8 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00b8 }
		r8.<init>();	 //Catch:{ all -> 0x00b8 }
		r9 = "Failed to rename \"";
		r8 = r8.append(r9);	 //Catch:{ all -> 0x00b8 }
		r9 = r6_tmp.getAbsolutePath();	 //Catch:{ all -> 0x00b8 }
		r8 = r8.append(r9);	 //Catch:{ all -> 0x00b8 }
		r9 = "\" to \"";
		r8 = r8.append(r9);	 //Catch:{ all -> 0x00b8 }
		r9 = r12_extractTo.getAbsolutePath();	 //Catch:{ all -> 0x00b8 }
		r8 = r8.append(r9);	 //Catch:{ all -> 0x00b8 }
		r9 = "\"";
		r8 = r8.append(r9);	 //Catch:{ all -> 0x00b8 }
		r8 = r8.toString();	 //Catch:{ all -> 0x00b8 }
		r7.<init>(r8);	 //Catch:{ all -> 0x00b8 }
		throw r7;	 //Catch:{ all -> 0x00b8 }
	L_0x00b8:
		r7 = move-exception;
		r4_out = r5_out;
	L_0x00ba:
		closeQuietly(r2_in);
		r6_tmp.delete();
		throw r7;
	L_0x00c1:
		r7 = move-exception;
		r5_out.close();	 //Catch:{ all -> 0x00b8 }
		throw r7;	 //Catch:{ all -> 0x00b8 }
	L_0x00c6:
		closeQuietly(r2_in);
		r6_tmp.delete();
		return;
	L_0x00cd:
		r7 = move-exception;
		goto L_0x00ba;
	}
	*/
	private static void extract(ZipFile apk, ZipEntry dexFile, File extractTo, String extractedFilePrefix) throws IOException, FileNotFoundException {
		ZipOutputStream out;
		byte[] buffer;
		int length;
		InputStream in = apk.getInputStream(dexFile);
		File tmp = File.createTempFile(extractedFilePrefix, EXTRACTED_SUFFIX, extractTo.getParentFile());
		Log.i(TAG, "Extracting " + tmp.getPath());
		try {
			out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)));
			ZipEntry classesDex = new ZipEntry("classes.dex");
			classesDex.setTime(dexFile.getTime());
			out.putNextEntry(classesDex);
			buffer = new byte[16384];
			length = in.read(buffer);
			while (length != -1) {
				out.write(buffer, 0, length);
				length = in.read(buffer);
			}
			out.closeEntry();
			out.close();
			Log.i(TAG, "Renaming to " + extractTo.getPath());
			if (!tmp.renameTo(extractTo)) {
				throw new IOException("Failed to rename \"" + tmp.getAbsolutePath() + "\" to \"" + extractTo.getAbsolutePath() + "\"");
			} else {
				closeQuietly(in);
				tmp.delete();
			}
		} catch (Throwable th) {
			r7_Throwable = th;
		}
	}

	private static SharedPreferences getMultiDexPreferences(Context context) {
		int r0i;
		String r1_String = PREFS_FILE;
		if (VERSION.SDK_INT < 11) {
			r0i = 0;
		} else {
			r0i = TLRPC.USER_FLAG_LAST_NAME;
		}
		return context.getSharedPreferences(r1_String, r0i);
	}

	private static long getTimeStamp(File archive) {
		long timeStamp = archive.lastModified();
		if (timeStamp == -1) {
			timeStamp--;
		}
		return timeStamp;
	}

	private static long getZipCrc(File archive) throws IOException {
		long computedValue = ZipUtil.getZipCrc(archive);
		if (computedValue == -1) {
			computedValue--;
		}
		return computedValue;
	}

	private static boolean isModified(Context context, File archive, long currentCrc) {
		SharedPreferences prefs = getMultiDexPreferences(context);
		if (prefs.getLong(KEY_TIME_STAMP, NO_VALUE) != getTimeStamp(archive) || prefs.getLong(KEY_CRC, NO_VALUE) != currentCrc) {
			return true;
		} else {
			return false;
		}
	}

	static List<File> load(Context context, ApplicationInfo applicationInfo, File dexDir, boolean forceReload) throws IOException {
		List<File> files;
		Log.i(TAG, "MultiDexExtractor.load(" + applicationInfo.sourceDir + ", " + forceReload + ")");
		File sourceApk = new File(applicationInfo.sourceDir);
		long currentCrc = getZipCrc(sourceApk);
		if (forceReload || isModified(context, sourceApk, currentCrc)) {
			Log.i(TAG, "Detected that extraction must be performed.");
			files = performExtractions(sourceApk, dexDir);
			putStoredApkInfo(context, getTimeStamp(sourceApk), currentCrc, files.size() + 1);
		} else {
			try {
				files = loadExistingExtractions(context, sourceApk, dexDir);
			} catch (IOException e) {
				Log.w(TAG, "Failed to reload existing extracted secondary dex files, falling back to fresh extraction", e);
				files = performExtractions(sourceApk, dexDir);
				putStoredApkInfo(context, getTimeStamp(sourceApk), currentCrc, files.size() + 1);
			}
		}
		Log.i(TAG, "load found " + files.size() + " secondary dex files");
		return files;
	}

	private static List<File> loadExistingExtractions(Context context, File sourceApk, File dexDir) throws IOException {
		Log.i(TAG, "loading existing secondary dex files");
		String extractedFilePrefix = sourceApk.getName() + EXTRACTED_NAME_EXT;
		int totalDexNumber = getMultiDexPreferences(context).getInt(KEY_DEX_NUMBER, 1);
		List<File> files = new ArrayList(totalDexNumber);
		int secondaryNumber = TLRPC.USER_FLAG_FIRST_NAME;
		while (secondaryNumber <= totalDexNumber) {
			File extractedFile = new File(dexDir, extractedFilePrefix + secondaryNumber + EXTRACTED_SUFFIX);
			if (extractedFile.isFile()) {
				files.add(extractedFile);
				if (!verifyZipFile(extractedFile)) {
					Log.i(TAG, "Invalid zip file: " + extractedFile);
					throw new IOException("Invalid ZIP file.");
				} else {
					secondaryNumber++;
				}
			} else {
				throw new IOException("Missing extracted secondary dex file '" + extractedFile.getPath() + "'");
			}
		}
		return files;
	}

	private static void mkdirChecked(File dir) throws IOException {
		dir.mkdir();
		if (!dir.isDirectory()) {
			File parent = dir.getParentFile();
			if (parent == null) {
				Log.e(TAG, "Failed to create dir " + dir.getPath() + ". Parent file is null.");
			} else {
				Log.e(TAG, "Failed to create dir " + dir.getPath() + ". parent file is a dir " + parent.isDirectory() + ", a file " + parent.isFile() + ", exists " + parent.exists() + ", readable " + parent.canRead() + ", writable " + parent.canWrite());
			}
			throw new IOException("Failed to create cache directory " + dir.getPath());
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	private static java.util.List<java.io.File> performExtractions(java.io.File r14_sourceApk, java.io.File r15_dexDir) throws java.io.IOException {
		r10 = new java.lang.StringBuilder;
		r10.<init>();
		r11 = r14_sourceApk.getName();
		r10 = r10.append(r11);
		r11 = ".classes";
		r10 = r10.append(r11);
		r4 = r10.toString();
		prepareDexDir(r15_dexDir, r4_extractedFilePrefix);
		r6 = new java.util.ArrayList;
		r6.<init>();
		r0 = new java.util.zip.ZipFile;
		r0.<init>(r14_sourceApk);
		r9 = 2;
		r10 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00f1 }
		r10.<init>();	 //Catch:{ all -> 0x00f1 }
		r11 = "classes";
		r10 = r10.append(r11);	 //Catch:{ all -> 0x00f1 }
		r10 = r10.append(r9_secondaryNumber);	 //Catch:{ all -> 0x00f1 }
		r11 = ".dex";
		r10 = r10.append(r11);	 //Catch:{ all -> 0x00f1 }
		r10 = r10.toString();	 //Catch:{ all -> 0x00f1 }
		r1 = r0_apk.getEntry(r10);	 //Catch:{ all -> 0x00f1 }
	L_0x0042:
		if (r1_dexFile == 0) goto L_0x0149;
	L_0x0044:
		r10 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00f1 }
		r10.<init>();	 //Catch:{ all -> 0x00f1 }
		r10 = r10.append(r4_extractedFilePrefix);	 //Catch:{ all -> 0x00f1 }
		r10 = r10.append(r9_secondaryNumber);	 //Catch:{ all -> 0x00f1 }
		r11 = ".zip";
		r10 = r10.append(r11);	 //Catch:{ all -> 0x00f1 }
		r5 = r10.toString();	 //Catch:{ all -> 0x00f1 }
		r3 = new java.io.File;	 //Catch:{ all -> 0x00f1 }
		r3.<init>(r15_dexDir, r5_fileName);	 //Catch:{ all -> 0x00f1 }
		r6_files.add(r3_extractedFile);	 //Catch:{ all -> 0x00f1 }
		r10 = "MultiDex";
		r11 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00f1 }
		r11.<init>();	 //Catch:{ all -> 0x00f1 }
		r12 = "Extraction is needed for file ";
		r11 = r11.append(r12);	 //Catch:{ all -> 0x00f1 }
		r11 = r11.append(r3_extractedFile);	 //Catch:{ all -> 0x00f1 }
		r11 = r11.toString();	 //Catch:{ all -> 0x00f1 }
		android.util.Log.i(r10, r11);	 //Catch:{ all -> 0x00f1 }
		r8 = 0;
		r7 = 0;
	L_0x007d:
		r10 = 3;
		if (r8_numAttempts >= r10) goto L_0x00f9;
	L_0x0080:
		if (r7_isExtractionSuccessful != 0) goto L_0x00f9;
	L_0x0082:
		r8_numAttempts++;
		extract(r0_apk, r1_dexFile, r3_extractedFile, r4_extractedFilePrefix);	 //Catch:{ all -> 0x00f1 }
		r7_isExtractionSuccessful = verifyZipFile(r3_extractedFile);	 //Catch:{ all -> 0x00f1 }
		r11 = "MultiDex";
		r10 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00f1 }
		r10.<init>();	 //Catch:{ all -> 0x00f1 }
		r12 = "Extraction ";
		r12 = r10.append(r12);	 //Catch:{ all -> 0x00f1 }
		if (r7_isExtractionSuccessful == 0) goto L_0x00f6;
	L_0x009a:
		r10 = "success";
	L_0x009c:
		r10 = r12.append(r10);	 //Catch:{ all -> 0x00f1 }
		r12 = " - length ";
		r10 = r10.append(r12);	 //Catch:{ all -> 0x00f1 }
		r12 = r3_extractedFile.getAbsolutePath();	 //Catch:{ all -> 0x00f1 }
		r10 = r10.append(r12);	 //Catch:{ all -> 0x00f1 }
		r12 = ": ";
		r10 = r10.append(r12);	 //Catch:{ all -> 0x00f1 }
		r12 = r3_extractedFile.length();	 //Catch:{ all -> 0x00f1 }
		r10 = r10.append(r12);	 //Catch:{ all -> 0x00f1 }
		r10 = r10.toString();	 //Catch:{ all -> 0x00f1 }
		android.util.Log.i(r11, r10);	 //Catch:{ all -> 0x00f1 }
		if (r7_isExtractionSuccessful != 0) goto L_0x007d;
	L_0x00c5:
		r3_extractedFile.delete();	 //Catch:{ all -> 0x00f1 }
		r10 = r3_extractedFile.exists();	 //Catch:{ all -> 0x00f1 }
		if (r10 == 0) goto L_0x007d;
	L_0x00ce:
		r10 = "MultiDex";
		r11 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00f1 }
		r11.<init>();	 //Catch:{ all -> 0x00f1 }
		r12 = "Failed to delete corrupted secondary dex '";
		r11 = r11.append(r12);	 //Catch:{ all -> 0x00f1 }
		r12 = r3_extractedFile.getPath();	 //Catch:{ all -> 0x00f1 }
		r11 = r11.append(r12);	 //Catch:{ all -> 0x00f1 }
		r12 = "'";
		r11 = r11.append(r12);	 //Catch:{ all -> 0x00f1 }
		r11 = r11.toString();	 //Catch:{ all -> 0x00f1 }
		android.util.Log.w(r10, r11);	 //Catch:{ all -> 0x00f1 }
		goto L_0x007d;
	L_0x00f1:
		r10 = move-exception;
		r0_apk.close();	 //Catch:{ IOException -> 0x0156 }
	L_0x00f5:
		throw r10;
	L_0x00f6:
		r10 = "failed";
		goto L_0x009c;
	L_0x00f9:
		if (r7_isExtractionSuccessful != 0) goto L_0x0128;
	L_0x00fb:
		r10 = new java.io.IOException;	 //Catch:{ all -> 0x00f1 }
		r11 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00f1 }
		r11.<init>();	 //Catch:{ all -> 0x00f1 }
		r12 = "Could not create zip file ";
		r11 = r11.append(r12);	 //Catch:{ all -> 0x00f1 }
		r12 = r3_extractedFile.getAbsolutePath();	 //Catch:{ all -> 0x00f1 }
		r11 = r11.append(r12);	 //Catch:{ all -> 0x00f1 }
		r12 = " for secondary dex (";
		r11 = r11.append(r12);	 //Catch:{ all -> 0x00f1 }
		r11 = r11.append(r9_secondaryNumber);	 //Catch:{ all -> 0x00f1 }
		r12 = ")";
		r11 = r11.append(r12);	 //Catch:{ all -> 0x00f1 }
		r11 = r11.toString();	 //Catch:{ all -> 0x00f1 }
		r10.<init>(r11);	 //Catch:{ all -> 0x00f1 }
		throw r10;	 //Catch:{ all -> 0x00f1 }
	L_0x0128:
		r9_secondaryNumber++;
		r10 = new java.lang.StringBuilder;	 //Catch:{ all -> 0x00f1 }
		r10.<init>();	 //Catch:{ all -> 0x00f1 }
		r11 = "classes";
		r10 = r10.append(r11);	 //Catch:{ all -> 0x00f1 }
		r10 = r10.append(r9_secondaryNumber);	 //Catch:{ all -> 0x00f1 }
		r11 = ".dex";
		r10 = r10.append(r11);	 //Catch:{ all -> 0x00f1 }
		r10 = r10.toString();	 //Catch:{ all -> 0x00f1 }
		r1_dexFile = r0_apk.getEntry(r10);	 //Catch:{ all -> 0x00f1 }
		goto L_0x0042;
	L_0x0149:
		r0_apk.close();	 //Catch:{ IOException -> 0x014d }
	L_0x014c:
		return r6_files;
	L_0x014d:
		r2 = move-exception;
		r10 = "MultiDex";
		r11 = "Failed to close resource";
		android.util.Log.w(r10, r11, r2_e);
		goto L_0x014c;
	L_0x0156:
		r2_e = move-exception;
		r11 = "MultiDex";
		r12 = "Failed to close resource";
		android.util.Log.w(r11, r12, r2);
		goto L_0x00f5;
	}
	*/
	private static List<File> performExtractions(File sourceApk, File dexDir) throws IOException {
		ZipEntry dexFile;
		Throwable r10_Throwable;
		String extractedFilePrefix = sourceApk.getName() + EXTRACTED_NAME_EXT;
		prepareDexDir(dexDir, extractedFilePrefix);
		List<File> files = new ArrayList();
		ZipFile apk = new ZipFile(sourceApk);
		int secondaryNumber = TLRPC.USER_FLAG_FIRST_NAME;
		try {
			dexFile = apk.getEntry(DEX_PREFIX + TLRPC.USER_FLAG_FIRST_NAME + DEX_SUFFIX);
			while (dexFile != null) {
				File extractedFile = new File(dexDir, extractedFilePrefix + secondaryNumber + EXTRACTED_SUFFIX);
				files.add(extractedFile);
				Log.i(TAG, "Extraction is needed for file " + extractedFile);
				int numAttempts = 0;
				boolean isExtractionSuccessful = false;
				while (numAttempts < 3 && !isExtractionSuccessful) {
					String r10_String;
					numAttempts++;
					extract(apk, dexFile, extractedFile, extractedFilePrefix);
					isExtractionSuccessful = verifyZipFile(extractedFile);
					String r11_String = TAG;
					StringBuilder r12_StringBuilder = new StringBuilder().append("Extraction ");
					if (isExtractionSuccessful) {
						r10_String = LoginTask.BUNDLE_SUCCESS;
					} else {
						r10_String = "failed";
					}
					Log.i(r11_String, r12_StringBuilder.append(r10_String).append(" - length ").append(extractedFile.getAbsolutePath()).append(": ").append(extractedFile.length()).toString());
					if (!isExtractionSuccessful) {
						extractedFile.delete();
						if (extractedFile.exists()) {
							Log.w(TAG, "Failed to delete corrupted secondary dex '" + extractedFile.getPath() + "'");
						}
					}
				}
				secondaryNumber++;
				dexFile = apk.getEntry(DEX_PREFIX + secondaryNumber + DEX_SUFFIX);
			}
			try {
				apk.close();
				return files;
			} catch (IOException e) {
				Log.w(TAG, "Failed to close resource", e);
				return files;
			}
		} catch (Throwable th) {
			r10_Throwable = th;
			apk.close();
			return r10_Throwable;
		}
	}

	private static void prepareDexDir(File dexDir, String extractedFilePrefix) throws IOException {
		mkdirChecked(dexDir.getParentFile());
		mkdirChecked(dexDir);
		File[] files = dexDir.listFiles(new AnonymousClass_1(extractedFilePrefix));
		if (files == null) {
			Log.w(TAG, "Failed to list secondary dex dir content (" + dexDir.getPath() + ").");
		} else {
			File[] arr$ = files;
			int i$ = 0;
			while (i$ < arr$.length) {
				File oldFile = arr$[i$];
				Log.i(TAG, "Trying to delete old file " + oldFile.getPath() + " of size " + oldFile.length());
				if (!oldFile.delete()) {
					Log.w(TAG, "Failed to delete old file " + oldFile.getPath());
				} else {
					Log.i(TAG, "Deleted old file " + oldFile.getPath());
				}
				i$++;
			}
		}
	}

	private static void putStoredApkInfo(Context context, long timeStamp, long crc, int totalDexNumber) {
		Editor edit = getMultiDexPreferences(context).edit();
		edit.putLong(KEY_TIME_STAMP, timeStamp);
		edit.putLong(KEY_CRC, crc);
		edit.putInt(KEY_DEX_NUMBER, totalDexNumber);
		apply(edit);
	}

	/* JADX WARNING: inconsistent code */
	/*
	static boolean verifyZipFile(java.io.File r6_file) {
		r2 = new java.util.zip.ZipFile;	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
		r2.<init>(r6_file);	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
		r2_zipFile.close();	 //Catch:{ IOException -> 0x000a, ZipException -> 0x0029 }
		r3 = 1;
	L_0x0009:
		return r3;
	L_0x000a:
		r0_e = move-exception;
		r3 = "MultiDex";
		r4 = new java.lang.StringBuilder;	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
		r4.<init>();	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
		r5 = "Failed to close zip file: ";
		r4 = r4.append(r5);	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
		r5 = r6_file.getAbsolutePath();	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
		r4 = r4.append(r5);	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
		r4 = r4.toString();	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
		android.util.Log.w(r3, r4);	 //Catch:{ ZipException -> 0x0029, IOException -> 0x004d }
	L_0x0027:
		r3 = 0;
		goto L_0x0009;
	L_0x0029:
		r1 = move-exception;
		r3 = "MultiDex";
		r4 = new java.lang.StringBuilder;
		r4.<init>();
		r5 = "File ";
		r4 = r4.append(r5);
		r5 = r6_file.getAbsolutePath();
		r4 = r4.append(r5);
		r5 = " is not a valid zip file.";
		r4 = r4.append(r5);
		r4 = r4.toString();
		android.util.Log.w(r3, r4, r1_ex);
		goto L_0x0027;
	L_0x004d:
		r1_ex = move-exception;
		r3 = "MultiDex";
		r4 = new java.lang.StringBuilder;
		r4.<init>();
		r5 = "Got an IOException trying to open zip file: ";
		r4 = r4.append(r5);
		r5 = r6.getAbsolutePath();
		r4 = r4.append(r5);
		r4 = r4.toString();
		android.util.Log.w(r3, r4, r1);
		goto L_0x0027;
	}
	*/
	static boolean verifyZipFile(File file) {
		try {
			ZipFile zipFile = new ZipFile(file);
			zipFile.close();
			return true;
		} catch (ZipException e) {
			Log.w(TAG, "File " + file.getAbsolutePath() + " is not a valid zip file.", e);
		} catch (IOException e_2) {
			Log.w(TAG, "Got an IOException trying to open zip file: " + file.getAbsolutePath(), e_2);
		}
	}
}
