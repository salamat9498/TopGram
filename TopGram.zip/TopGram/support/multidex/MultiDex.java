package android.support.multidex;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.util.Log;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipFile;
import org.telegram.tgnet.TLRPC;

public final class MultiDex {
	private static final boolean IS_VM_MULTIDEX_CAPABLE;
	private static final int MAX_SUPPORTED_SDK_VERSION = 20;
	private static final int MIN_SDK_VERSION = 4;
	private static final String OLD_SECONDARY_FOLDER_NAME = "secondary-dexes";
	private static final String SECONDARY_FOLDER_NAME;
	static final String TAG = "MultiDex";
	private static final int VM_WITH_MULTIDEX_VERSION_MAJOR = 2;
	private static final int VM_WITH_MULTIDEX_VERSION_MINOR = 1;
	private static final Set<String> installedApk;

	private static final class V14 {
		private V14() {
			super();
		}

		private static void install(ClassLoader loader, List<File> additionalClassPathEntries, File optimizedDirectory) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
			Object dexPathList = MultiDex.findField(loader, "pathList").get(loader);
			MultiDex.expandFieldArray(dexPathList, "dexElements", makeDexElements(dexPathList, new ArrayList(additionalClassPathEntries), optimizedDirectory));
		}

		private static Object[] makeDexElements(Object dexPathList, ArrayList<File> files, File optimizedDirectory) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
			Class[] r2_Class_A = new Class[2];
			r2_Class_A[0] = ArrayList.class;
			r2_Class_A[1] = File.class;
			Object[] r1_Object_A = new Object[2];
			r1_Object_A[0] = files;
			r1_Object_A[1] = optimizedDirectory;
			return (Object[]) MultiDex.findMethod(dexPathList, "makeDexElements", r2_Class_A).invoke(dexPathList, r1_Object_A);
		}
	}

	private static final class V19 {
		private V19() {
			super();
		}

		private static void install(ClassLoader loader, List<File> additionalClassPathEntries, File optimizedDirectory) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
			Object dexPathList = MultiDex.findField(loader, "pathList").get(loader);
			ArrayList<IOException> suppressedExceptions = new ArrayList();
			MultiDex.expandFieldArray(dexPathList, "dexElements", makeDexElements(dexPathList, new ArrayList(additionalClassPathEntries), optimizedDirectory, suppressedExceptions));
			if (suppressedExceptions.size() > 0) {
				Iterator i$ = suppressedExceptions.iterator();
				while (i$.hasNext()) {
					Log.w(TAG, "Exception in makeDexElement", (IOException) i$.next());
				}
				Field suppressedExceptionsField = MultiDex.findField(loader, "dexElementsSuppressedExceptions");
				Object dexElementsSuppressedExceptions = (IOException[]) suppressedExceptionsField.get(loader);
				if (dexElementsSuppressedExceptions == null) {
					dexElementsSuppressedExceptions = suppressedExceptions.toArray(new IOException[suppressedExceptions.size()]);
				} else {
					Object combined = new Object[(suppressedExceptions.size() + dexElementsSuppressedExceptions.length)];
					suppressedExceptions.toArray(combined);
					System.arraycopy(dexElementsSuppressedExceptions, 0, combined, suppressedExceptions.size(), dexElementsSuppressedExceptions.length);
					dexElementsSuppressedExceptions = combined;
				}
				suppressedExceptionsField.set(loader, dexElementsSuppressedExceptions);
			}
		}

		private static Object[] makeDexElements(Object dexPathList, ArrayList<File> files, File optimizedDirectory, ArrayList<IOException> suppressedExceptions) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
			Class[] r2_Class_A = new Class[3];
			r2_Class_A[0] = ArrayList.class;
			r2_Class_A[1] = File.class;
			r2_Class_A[2] = ArrayList.class;
			Object[] r1_Object_A = new Object[3];
			r1_Object_A[0] = files;
			r1_Object_A[1] = optimizedDirectory;
			r1_Object_A[2] = suppressedExceptions;
			return (Object[]) MultiDex.findMethod(dexPathList, "makeDexElements", r2_Class_A).invoke(dexPathList, r1_Object_A);
		}
	}

	private static final class V4 {
		private V4() {
			super();
		}

		private static void install(ClassLoader loader, List<File> additionalClassPathEntries) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, IOException {
			int extraSize = additionalClassPathEntries.size();
			Field pathField = MultiDex.findField(loader, "path");
			StringBuilder path = new StringBuilder((String) pathField.get(loader));
			String[] extraPaths = new String[extraSize];
			File[] extraFiles = new File[extraSize];
			ZipFile[] extraZips = new ZipFile[extraSize];
			DexFile[] extraDexs = new DexFile[extraSize];
			ListIterator<File> iterator = additionalClassPathEntries.listIterator();
			while (iterator.hasNext()) {
				File additionalEntry = (File) iterator.next();
				String entryPath = additionalEntry.getAbsolutePath();
				path.append(':').append(entryPath);
				int index = iterator.previousIndex();
				extraPaths[index] = entryPath;
				extraFiles[index] = additionalEntry;
				extraZips[index] = new ZipFile(additionalEntry);
				extraDexs[index] = DexFile.loadDex(entryPath, entryPath + ".dex", 0);
			}
			pathField.set(loader, path.toString());
			MultiDex.expandFieldArray(loader, "mPaths", extraPaths);
			MultiDex.expandFieldArray(loader, "mFiles", extraFiles);
			MultiDex.expandFieldArray(loader, "mZips", extraZips);
			MultiDex.expandFieldArray(loader, "mDexs", extraDexs);
		}
	}


	static {
		SECONDARY_FOLDER_NAME = "code_cache" + File.separator + OLD_SECONDARY_FOLDER_NAME;
		installedApk = new HashSet();
		IS_VM_MULTIDEX_CAPABLE = isVMMultidexCapable(System.getProperty("java.vm.version"));
	}

	private MultiDex() {
		super();
	}

	private static boolean checkValidZipFiles(List<File> files) {
		Iterator i$ = files.iterator();
		while (i$.hasNext()) {
			if (!MultiDexExtractor.verifyZipFile((File) i$.next())) {
				return IS_VM_MULTIDEX_CAPABLE;
			}
		}
		return true;
	}

	private static void clearOldDexDir(Context context) throws Exception {
		File dexDir = new File(context.getFilesDir(), OLD_SECONDARY_FOLDER_NAME);
		if (dexDir.isDirectory()) {
			Log.i(TAG, "Clearing old secondary dex dir (" + dexDir.getPath() + ").");
			File[] files = dexDir.listFiles();
			if (files == null) {
				Log.w(TAG, "Failed to list secondary dex dir content (" + dexDir.getPath() + ").");
			} else {
				File[] arr$ = files;
				int i$ = 0;
				while (i$ < arr$.length) {
					File oldFile = arr$[i$];
					Log.i(TAG, "Trying to delete old file " + oldFile.getPath() + " of size " + oldFile.length());
					if (!oldFile.delete()) {
						Log.w(TAG, "Failed to delete old file " + oldFile.getPath());
					} else {
						Log.i(TAG, "Deleted old file " + oldFile.getPath());
					}
					i$++;
				}
				if (!dexDir.delete()) {
					Log.w(TAG, "Failed to delete secondary dex dir " + dexDir.getPath());
				} else {
					Log.i(TAG, "Deleted old secondary dex dir " + dexDir.getPath());
				}
			}
		}
	}

	private static void expandFieldArray(Object instance, String fieldName, Object[] extraElements) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
		Field jlrField = findField(instance, fieldName);
		Object original = (Object[]) jlrField.get(instance);
		Object combined = (Object[]) Array.newInstance(original.getClass().getComponentType(), original.length + extraElements.length);
		System.arraycopy(original, 0, combined, 0, original.length);
		System.arraycopy(extraElements, 0, combined, original.length, extraElements.length);
		jlrField.set(instance, combined);
	}

	private static Field findField(Object instance, String name) throws NoSuchFieldException {
		Class<?> clazz = instance.getClass();
		while (clazz != null) {
			Field field;
			try {
				field = clazz.getDeclaredField(name);
				if (!field.isAccessible()) {
					field.setAccessible(true);
					return field;
				} else {
					return field;
				}
			} catch (NoSuchFieldException e) {
				clazz = clazz.getSuperclass();
			}
		}
		throw new NoSuchFieldException("Field " + name + " not found in " + instance.getClass());
	}

	private static Method findMethod(Object instance, String name, Class<?> ... parameterTypes) throws NoSuchMethodException {
		Class<?> clazz = instance.getClass();
		while (clazz != null) {
			Method method;
			try {
				method = clazz.getDeclaredMethod(name, parameterTypes);
				if (!method.isAccessible()) {
					method.setAccessible(true);
					return method;
				} else {
					return method;
				}
			} catch (NoSuchMethodException e) {
				clazz = clazz.getSuperclass();
			}
		}
		throw new NoSuchMethodException("Method " + name + " with parameters " + Arrays.asList(parameterTypes) + " not found in " + instance.getClass());
	}

	private static ApplicationInfo getApplicationInfo(Context context) throws NameNotFoundException {
		PackageManager pm;
		String packageName;
		try {
			pm = context.getPackageManager();
			packageName = context.getPackageName();
			if (pm != null) {
				if (packageName == null) {
					return null;
				} else {
					return pm.getApplicationInfo(packageName, TLRPC.USER_FLAG_UNUSED);
				}
			} else {
				return null;
			}
		} catch (RuntimeException e) {
			Log.w(TAG, "Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", e);
			return null;
		}
	}

	public static void install(Context context) {
		Log.i(TAG, "install");
		if (IS_VM_MULTIDEX_CAPABLE) {
			Log.i(TAG, "VM has multidex support, MultiDex support library is disabled.");
		} else if (VERSION.SDK_INT < 4) {
			throw new RuntimeException("Multi dex installation failed. SDK " + VERSION.SDK_INT + " is unsupported. Min SDK version is " + MIN_SDK_VERSION + ".");
		} else {
			ApplicationInfo applicationInfo;
			try {
				applicationInfo = getApplicationInfo(context);
				if (applicationInfo != null) {
					Set r8_Set = installedApk;
					synchronized(r8_Set) {
						String apkPath = applicationInfo.sourceDir;
						if (installedApk.contains(apkPath)) {
						} else {
							ClassLoader loader;
							installedApk.add(apkPath);
							if (VERSION.SDK_INT > 20) {
								Log.w(TAG, "MultiDex is not guaranteed to work in SDK version " + VERSION.SDK_INT + ": SDK version higher than " + MAX_SUPPORTED_SDK_VERSION + " should be backed by " + "runtime with built-in multidex capabilty but it's not the " + "case here: java.vm.version=\"" + System.getProperty("java.vm.version") + "\"");
							}
							try {
								loader = context.getClassLoader();
								if (loader == null) {
									Log.e(TAG, "Context class loader is null. Must be running in test mode. Skip patching.");
								} else {
									try {
										clearOldDexDir(context);
									} catch (Throwable th) {
										Log.w(TAG, "Something went wrong when trying to clear old MultiDex extraction, continuing without cleaning.", th);
									}
									File dexDir = new File(applicationInfo.dataDir, SECONDARY_FOLDER_NAME);
									List<File> files = MultiDexExtractor.load(context, applicationInfo, dexDir, IS_VM_MULTIDEX_CAPABLE);
									if (checkValidZipFiles(files)) {
										installSecondaryDexes(loader, dexDir, files);
									} else {
										Log.w(TAG, "Files were not valid zip files.  Forcing a reload.");
										files = MultiDexExtractor.load(context, applicationInfo, dexDir, true);
										if (checkValidZipFiles(files)) {
											installSecondaryDexes(loader, dexDir, files);
										} else {
											throw new RuntimeException("Zip files were not valid.");
										}
									}
									Log.i(TAG, "install done");
								}
							} catch (RuntimeException e) {
								Log.w(TAG, "Failure while trying to obtain Context class loader. Must be running in test mode. Skip patching.", e);
								return;
							}
						}
					}
				}
			} catch (Exception e_2) {
				Throwable e_3 = e_2;
				Log.e(TAG, "Multidex installation failure", e_3);
				throw new RuntimeException("Multi dex installation failed (" + e_3.getMessage() + ").");
			}
		}
	}

	private static void installSecondaryDexes(ClassLoader loader, File dexDir, List<File> files) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException, IOException {
		if (!files.isEmpty()) {
			if (VERSION.SDK_INT >= 19) {
				V19.install(loader, files, dexDir);
			} else if (VERSION.SDK_INT >= 14) {
				V14.install(loader, files, dexDir);
			} else {
				V4.install(loader, files);
			}
		}
	}

	static boolean isVMMultidexCapable(String versionString) {
		String r4_String;
		boolean isMultidexCapable = IS_VM_MULTIDEX_CAPABLE;
		if (versionString != null) {
			Matcher matcher = Pattern.compile("(\\d+)\\.(\\d+)(\\.\\d+)?").matcher(versionString);
			if (matcher.matches()) {
				int major;
				int r5i = VM_WITH_MULTIDEX_VERSION_MINOR;
				try {
					major = Integer.parseInt(matcher.group(r5i));
					int minor = Integer.parseInt(matcher.group(VM_WITH_MULTIDEX_VERSION_MAJOR));
					if (major <= 2) {
						if (major != 2 || minor < 1) {
							isMultidexCapable = IS_VM_MULTIDEX_CAPABLE;
						}
					}
					isMultidexCapable = true;
				} catch (NumberFormatException e) {
				}
			}
		}
		String r5_String = TAG;
		StringBuilder r6_StringBuilder = new StringBuilder().append("VM with version ").append(versionString);
		if (isMultidexCapable) {
			r4_String = " has multidex support";
		} else {
			r4_String = " does not have multidex support";
		}
		Log.i(r5_String, r6_StringBuilder.append(r4_String).toString());
		return isMultidexCapable;
	}
}
